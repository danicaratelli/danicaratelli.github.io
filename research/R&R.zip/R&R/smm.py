# This file has all functions to help with the moment matching exercise
import numpy as np
from itertools import product
from multiprocessing import Pool
import utils
import statsmodels.api as sm
import Jac_help
import GreatRecession as GR
import pandas as pd
import os

def SMM(G, param_grid, Tstop, Tsim, TT, ss, shock_list):
    # Extracting values
    Ntot = len(param_grid)
    # ngrid = len(param_grid['SD1'])
    # Ntot = ngrid ** (len(param_grid.keys()))
    # # All possible N combination tuples
    # Ntuples = list(product(range(0, ngrid), repeat = len(param_grid.keys())))
    # real_tuples = []
    # for i in range(Ntot):        
    #     real_tuples.append((param_grid['SD1'][Ntuples[i][0]],
    #                         param_grid['SD2'][Ntuples[i][1]],
    #                         param_grid['corr12'][Ntuples[i][2]],
    #                         param_grid['rho1'][Ntuples[i][3]],
    #                         param_grid['rho2'][Ntuples[i][4]]))
        
    # Optimizing over parameters
    pool = Pool(processes=60)
    par_parallel = list(zip(param_grid, [G] * Ntot, [Tstop] * Ntot, [Tsim] * Ntot, [TT] * Ntot, [ss] * Ntot, [shock_list] * Ntot,))
    results = np.array(pool.starmap(obj_fun, par_parallel))


    return results

def dsimul(Tstop, TT, Tsim, rho1, rho2, SD1, SD2, corr12, ss, shock_list):
    # draw from join-normal
    mean_eps = [0, 0]
    cov12 = corr12 * SD1 * SD2
    cov_eps = [[SD2 ** 2, cov12], [cov12, SD1 ** 2]]  # diagonal covariance
    sim_eps = np.random.multivariate_normal(mean_eps, cov_eps, TT * Tsim)
    eps1 = sim_eps[:, 0].reshape((TT, Tsim))
    eps2 = sim_eps[:, 1].reshape((TT, Tsim))
    # only select first Tstop positive eps1
    # find first Tstop positive eps_zeta shocks
    for t in range(Tsim):
        locs_pos = np.where(eps1[:, t] > 0)[0]
        eps1[:Tstop, t] = eps1[locs_pos[:Tstop], t]
        eps1[Tstop:, t] = np.zeros(TT-Tstop)
        eps2[:Tstop, t] = eps2[locs_pos[:Tstop], t]
        eps2[Tstop:, t] = np.zeros(TT-Tstop)

    # get realizations
    sim1 = np.ones((TT, Tsim)) * ss[shock_list[0]]
    sim2 = np.ones((TT, Tsim)) * ss[shock_list[1]]
    for t0 in range(Tsim):
        for t1 in range(6 * Tstop-1):
            sim1[t1 + 1, t0] = ss[shock_list[0]] + rho2 * (sim1[t1, t0] - ss[shock_list[0]]) + eps1[t1 + 1, t0]
            sim2[t1 + 1, t0] = ss[shock_list[1]] + rho1 * (sim2[t1, t0] - ss[shock_list[1]]) + eps2[t1 + 1, t0]
    # making sure not to get negative separation probabilities
    return sim2, sim1

def agg_moments(moms, G, Tstop, Tsim, TT, ss, shock_list):
    SD1, SD2, corr12, rho1, rho2 = moms[0], moms[1], moms[2], moms[3], moms[4]

    # Simulate shocks    
    sim2, sim1 = dsimul(Tstop, TT, Tsim, rho1, rho2, SD1, SD2, corr12, ss, shock_list)

    # creating deviations from SS
    dsim2 = (sim2 - ss[shock_list[1]])
    dsim1 = (sim1 - ss[shock_list[0]])

    # EE and EU rates in levels
    EE_path = np.ones((TT, Tsim)) * ss['EE_rate']
    EU_path = np.ones((TT, Tsim)) * ss['EU_rate']
    Unemp_path = np.ones((TT, Tsim)) * ss['U']
    for it in range(Tsim):
        # EE rate in levels
        EE_path[:, it] += G['EE_rate'][shock_list[1]] @ dsim2[:, it] + G['EE_rate'][shock_list[0]] @ dsim1[:, it]
        # EU rate in levels
        EU_path[:, it] += G['EU_rate'][shock_list[1]] @ dsim2[:, it] + G['EU_rate'][shock_list[0]] @ dsim1[:, it]
        # EU rate in levels
        Unemp_path[:, it] += G['U'][shock_list[1]] @ dsim2[:, it] + G['U'][shock_list[0]] @ dsim1[:, it]

    # Standard Deviation
    EE_sd = np.mean(np.std(EE_path[:(2 * Tstop), :], axis=0))
    EU_sd = np.mean(np.std(EU_path[:(2 * Tstop), :], axis=0))
    Unemp_sd = np.mean(np.std(Unemp_path[:(2 * Tstop), :], axis=0))
    EE_ars = [sm.tsa.acf(EE_path[:(2 * Tstop), column])[1] for column in range(Tsim)]
    EE_ar = np.mean(EE_ars)
    EU_ars = [sm.tsa.acf(EU_path[:(2 * Tstop), column])[1] for column in range(Tsim)]
    EU_ar = np.mean(EU_ars)
    
    return EE_sd, EU_sd, Unemp_sd, EE_ar, EU_ar

def obj_fun(moms, G, Tstop, Tsim, TT, ss, shock_list):
    moms_tuple = moms['SD1'], moms['SD2'], moms['corr12'], moms['rho1'], moms['rho2']
    # get moments
    EE_sd, EU_sd, Unemp_sd, EE_ar, EU_ar = agg_moments(moms_tuple, G, Tstop, Tsim, TT, ss, shock_list)
    # xres = np.sum((np.abs(np.array([EE_sd, EU_sd, Unemp_sd, EE_ar, EU_ar]) - targets) / targets) ** 2) ** (1 / 2)
    xres = np.array([EE_sd, EU_sd, Unemp_sd, EE_ar, EU_ar])

    return xres

def distributional_simul(sim2, sim1, G, Tstop, TT, par, ss, shock_list, flname):    
    nB = par['nB']

    # creating deviations from SS
    dsim2 = (sim2 - ss[shock_list[1]])
    dsim1 = (sim1 - ss[shock_list[0]])
    dshocks = {shock_list[0]: dsim1, shock_list[1]: dsim2}

    # Get sequence of exogenous paths that deliver path for output    
    Z_path = ss['Z'] * np.ones(TT) + dshocks.get('Z', 0)
    transfer_path = ss['transfer'] * np.ones(TT) + dshocks.get('transfer', 0)
    zeta_path = ss['zeta'] * np.ones(TT) + dshocks.get('zeta', 0)
    sigmaslope_path = ss['sigmaslope'] * np.ones(TT) + dshocks.get('sigmaslope', 0)
    dbUI_path = np.broadcast_to(dshocks.get('bUI', 0), (TT,))
    bUI_path = Jac_help.type_bUI_path(ss, dbUI_path, TT)

    # all other relevant paths
    ra_path = ss['ra'] + GR.get_irf('ra', dshocks, G, TT)
    r_path = ss['r'] + GR.get_irf('r', dshocks, G, TT)
    rK_path = ss['rK'] + GR.get_irf('rK', dshocks, G, TT)
    tax_path = ss['tax'] + GR.get_irf('tax', dshocks, G, TT)
    lambdas_path = np.ones((TT, par['nP'])) * ss['lambdas'][np.newaxis, :]
    for ip in range(par['nP']):
        lambdas_path[:, ip] = ss['lambda' + str(ip)] + GR.get_irf('lambda' + str(ip), dshocks, G, TT)
    lambdas_path[lambdas_path < 0] = 0

    # # cut    
    # TT = 50
    # Z_path = Z_path[:TT]
    # transfer_path = transfer_path[:TT]
    # zeta_path = zeta_path[:TT]
    # sigmaslope_path = sigmaslope_path[:TT]
    # bUI_path = bUI_path[:TT]
    # ra_path = ra_path[:TT]
    # r_path = r_path[:TT]
    # rK_path = rK_path[:TT]
    # tax_path = tax_path[:TT]
    # lambdas_path = lambdas_path[:TT, :]


    # Distributions along transitions    
    QE_path = np.zeros(ss['QEss'].shape + (TT+1,))
    QE_path[:, :, :, :, :, :, 0] = ss['QEss']
    QEE_path = np.zeros(ss['QEEss'].shape + (TT+1,))
    QEE_path[:, :, :, :, :, :, :, 0] = ss['QEEss']
    QUE_path = np.zeros(ss['QUEss'].shape + (TT+1,))
    QUE_path[:, :, :, :, 0] = ss['QUEss']
    QU_path = np.zeros(ss['QUss'].shape + (TT+1,))
    QU_path[:, :, :, 0] = ss['QUss']
    # Policies along transitions
    CE_path = np.copy(ss['CEss'])
    CU_path = np.copy(ss['CUss'])
    Ebargaining = np.copy(ss['Ebargainingss'])
    dEbargaining = np.copy(ss['dEbargainingss'])
    Jbargaining = np.copy(ss['Jbargainingss'])
    U_old = ss['Uss']
    E_old = ss['Ess']
    J_old = ss['Jss']

    AE_path = np.zeros(ss['AEss'].shape + (TT+1,))
    AE_path[:, :, :, :, :, :, -1] = ss['AEss']
    AU_path = np.zeros(ss['AUss'].shape + (TT+1,))
    AU_path[:, :, :, -1] = ss['AUss']    

    WEwinpi_path = np.zeros(ss['WEwinpiss'].shape + (TT+1,))
    WEwinpi_path[:, :, :, :, :, :, :, -1] = ss['WEwinpiss']
    WEwini_path = np.zeros(ss['WEwiniss'].shape + (TT+1,), dtype='uint32')
    WEwini_path[:, :, :, :, :, :, :, -1] = ss['WEwiniss']
    WElosepi_path = np.zeros(ss['WElosepiss'].shape + (TT+1,))
    WElosepi_path[:, :, :, :, :, :, :, -1] = ss['WElosepiss']
    WElosei_path = np.zeros(ss['WEloseiss'].shape + (TT+1,), dtype='uint32')
    WElosei_path[:, :, :, :, :, :, :, -1] = ss['WEloseiss']
    WUpi_path = np.zeros(ss['WUpiss'].shape + (TT+1,))
    WUpi_path[:, :, :, :, -1] = ss['WUpiss']
    WUi_path = np.zeros(ss['WUiss'].shape + (TT+1,), dtype='uint32')
    WUi_path[:, :, :, :, -1] = ss['WUiss']
    Iwins_path = np.zeros(ss['Iwins'].shape + (TT+1,))
    Iwins_path[:, :, :, :, :, :, :, -1] = ss['Iwins']
    qs_path = np.zeros(ss['qss'].shape + (TT+1,))
    qs_path[:, :, :, :, :, :, :, -1] = ss['qss']

    # append to lambdas and sigmaJ
    lambdas_path = np.vstack([lambdas_path, ss['lambdas']])
    sigmaJ_path = np.ones(TT+1) * ss['sigmaJ']
    sigmaslope_path = np.append(sigmaslope_path, ss['sigmaslope'])

    beta_ss = par['beta']
    for t in range(TT - 1, -1, -1):
        for ib in range(nB):
            # Get policy functions
            par['beta'] = beta_ss + (2 * ib - 1) * par['dbeta']
            # input paths
            CU_path[:, :, ib], CE_path[:, :, :, :, :, ib], U_old[:, :, ib], E_old[:, :, :, :, :, ib], \
            Ebargaining[:, :, :, :, :, ib], dEbargaining[:, :, :, :, :, ib], AU_path[:, :, ib, t], AE_path[:, :, :, :, :, ib, t], \
            J_old[:, :, :, :, :, ib], Jbargaining[:, :, :, :, :, ib], JU0_trash, JE0_trash, \
            qs_path[:, :, :, :, :, :, ib, t], WUi_path[:, :, :, ib, t], WUpi_path[:, :, :, ib, t], \
            WEwini_path[:, :, :, :, :, :, ib, t], WEwinpi_path[:, :, :, :, :, :, ib, t], \
            WElosei_path[:, :, :, :, :, :, ib, t], WElosepi_path[:, :, :, :, :, :, ib, t], \
            Iwins_path[:, :, :, :, :, :, ib, t] = Jac_help.backward_iterate(ra_path[t], r_path[t], rK_path[t], Z_path[t], tax_path[t],
                                                    lambdas_path[t + 1, :], bUI_path[t, ib],
                                                    sigmaJ_path[t + 1], sigmaslope_path[t + 1], transfer_path[t],
                                                    CU_path[:, :, ib], CE_path[:, :, :, :, :, ib],
                                                    U_old[:, :, ib], E_old[:, :, :, :, :, ib],
                                                    Ebargaining[:, :, :, :, :, ib], dEbargaining[:, :, :, :, :, ib],
                                                    J_old[:, :, :, :, :, ib], Jbargaining[:, :, :, :, :, ib], par)
        
    for t in range(1, TT):
        for ib in range(nB):
            # Update distribution
            QUtmp, QEtmp, QUEtmp, QEEtmp = Jac_help.forward_iterate(par['nB'] * QU_path[:, :, ib, t - 1],
                                                            par['nB'] * QE_path[:, :, :, :, :, ib, t - 1],
                                                            AU_path[:, :, ib, t], AE_path[:, :, :, :, :, ib, t],
                                                            WUi_path[:, :, :, ib, t], WUpi_path[:, :, :, ib, t],
                                                            WEwini_path[:, :, :, :, :, :, ib, t],
                                                            WEwinpi_path[:, :, :, :, :, :, ib, t],
                                                            WElosei_path[:, :, :, :, :, :, ib, t],
                                                            WElosepi_path[:, :, :, :, :, :, ib, t],
                                                            qs_path[:, :, :, :, :, :, ib, t],
                                                            Iwins_path[:, :, :, :, :, :, ib, t],
                                                            lambdas_path[t - 1, :], sigmaJ_path[t - 1], sigmaslope_path[t - 1], par)
            QU_path[:, :, ib, t], \
            QE_path[:, :, :, :, :, ib, t], \
            QUE_path[:, :, :, ib, t], \
            QEE_path[:, :, :, :, :, :, ib, t] = QUtmp / nB, QEtmp / nB, QUEtmp / nB, QEEtmp / nB


    # Computing earnings by wealths
    EE = np.zeros(TT)
    EEL = np.zeros(TT)
    EEH = np.zeros(TT)
    EU = np.zeros(TT)
    EUL = np.zeros(TT)
    EUH = np.zeros(TT)
    u = np.zeros(TT)
    uL = np.zeros(TT)   # unemployment rate for Low-wealth workers
    uH = np.zeros(TT)   # unemployment rate for High-wealth workers
    for t in range(TT):
        # find median index
        Qt = np.sum(QE_path[:, :, :, :, :, :, t], axis=(0, 2, 3, 4, 5)) + np.sum(QU_path[:, :, :, t], axis=(0, 2))
        # Qt = np.sum(QE_path[:, :, :, :, :, :, t], axis=(0, 2, 3, 4, 5))
        xi, xpi = utils.simple_interpolation(0.5 * np.sum(Qt), np.cumsum(Qt))
        # assert np.abs(np.sum(Qt[:xi+1]) + (1 - xpi) * Qt[xi+1] - (np.sum(Qt[xi+2:]) + xpi * Qt[xi+1])< 1e-6), 'Threshold does not hold up'        
        QE = np.copy(QE_path[:, :, :, :, :, :, t])
        QEL = np.copy(QE_path[:, :xi + 2, :, :, :, :, t])
        QEL[:, -1, :, :, :, :] = QE_path[:, xi + 1, :, :, :, :, t] * (1 - xpi)
        QEH = np.copy(QE_path[:, xi + 1:, :, :, :, :, t])
        QEH[:, 0, :, :, :, :] = QE_path[:, xi + 1, :, :, :, :, t] * xpi
        assert np.abs(np.sum(QEL) + np.sum(QEH) - np.sum(QE_path[:, :, :, :, :, :, t])) < 1e-6, 'Threshold does not hold up'
        QEE = np.copy(QEE_path[:, :, :, :, :, :, :, t])
        QEEL = np.copy(QEE_path[:, :xi + 2, :, :, :, :, :, t])
        QEEL[:, -1, :, :, :, :] = QEE_path[:, xi + 1, :, :, :, :, :, t] * (1 - xpi)
        QEEH = np.copy(QEE_path[:, xi + 1:, :, :, :, :, :, t])
        QEEH[:, 0, :, :, :, :] = QEE_path[:, xi + 1, :, :, :, :, :, t] * xpi

        # Unemployment rate
        QU = QU_path[:, :, :, t]
        u[t] = np.sum(QU) / (np.sum(QU) + np.sum(QE))
        QUL = np.copy(QU[:, :xi + 2, :])
        QUL[:, -1, :] = QU[:, xi + 1, :] * (1 - xpi)
        uL[t] = np.sum(QUL) / (np.sum(QUL) + np.sum(QEL))
        QUH = np.copy(QU[:, xi + 1:, :])
        QUH[:, 0, :] = QU[:, xi + 1, :] * xpi
        uH[t] = np.sum(QUH) / (np.sum(QUH) + np.sum(QEH))        

        # Job-switching by wealth
        q = np.copy(qs_path[:, :, :, :, :, :, :, t])
        qL = np.copy(qs_path[:, :xi + 2, :, :, :, :, :, t])
        qL[:, -1, :, :, :, :] = qs_path[:, xi + 1, :, :, :, :, :, t] * (1 - xpi)
        qH = np.copy(qs_path[:, xi + 1:, :, :, :, :, :, t])
        qH[:, 0, :, :, :, :] = qs_path[:, xi + 1, :, :, :, :, :, t] * xpi
        # Job-switching
        # EE[t] = np.sum(np.sum(QEE * q, axis=(0, 1, 2, 4, 5, 6))) / np.sum(QE)
        # EEL[t] = np.sum(np.sum(QEEL * qL, axis=(0, 1, 2, 4, 5, 6))) / np.sum(QEL)
        # EEH[t] = np.sum(np.sum(QEEH * qH, axis=(0, 1, 2, 4, 5, 6))) / np.sum(QEH)
        EE[t] = np.sum(np.sum(QEE * q, axis=(0, 1, 2, 4, 5, 6))) / np.sum(QE[:, :, :, :-1, :, :])
        EEL[t] = np.sum(np.sum(QEEL * qL, axis=(0, 1, 2, 4, 5, 6))) / np.sum(QEL[:, :, :, :-1, :, :])
        EEH[t] = np.sum(np.sum(QEEH * qH, axis=(0, 1, 2, 4, 5, 6))) / np.sum(QEH[:, :, :, :-1, :, :])
        # Job-losing
        sigmas = par['sigma']
        # level shift in unemployment probability
        sigmas = sigmas + (sigmaJ_path[t] - sigmas[-1])
        # slope change in unemployment probability
        sigmas = sigmas * (1 + sigmaslope_path[t])
        EU[t] = np.sum(np.sum(QE, axis=(0, 1, 2, 3, 5)) * sigmas) / np.sum(QE)
        EUL[t] = np.sum(np.sum(QEL, axis=(0, 1, 2, 3, 5)) * sigmas) / np.sum(QEL)
        EUH[t] = np.sum(np.sum(QEH, axis=(0, 1, 2, 3, 5)) * sigmas) / np.sum(QEH)

    EEH, EEL, EUH, EUL, uH, uL = EEH, EEL, EUH, EUL, uH, uL
    d = np.vstack((EE, EEH, EEL, EU, EUH, EUL, u, uH, uL)).transpose()
    df_i = pd.DataFrame(d, columns=['EE', 'EEH', 'EEL', 'EU', 'EUH', 'EUL', 'u', 'uH', 'uL'])
    df_i.to_csv(flname +'.csv')
    # return EEH, EEL, EUH, EUL, uH, uL

def get_distributional_moments(moms, G, Tstop, TT, Tsim, par, ss, scale, shock_list, task_id, simname):
    # Simulation
    SD1, SD2, corr12, rho1, rho2 = moms['SD1'], moms['SD2'], moms['corr12'], moms['rho1'], moms['rho2']

    # Simulate shocks
    sim2, sim1 = dsimul(Tstop, TT, Tsim, rho1, rho2, SD1, SD2, corr12, ss, shock_list)
    sim2 = (sim2 - ss[shock_list[1]]) / scale + ss[shock_list[1]]
    sim1 = (sim1 - ss[shock_list[0]]) / scale + ss[shock_list[0]]
    sim2_list = [sim2[:, m] for m in range(Tsim)]
    sim2_list.insert(0, np.ones(TT) * ss[shock_list[1]])
    sim1_list = [sim1[:, m] for m in range(Tsim)]
    sim1_list.insert(0, np.ones(TT) * ss[shock_list[0]])

    # # Ghost run
    # if task_id == "0":
    #     distributional_simul(sim2_list[0], sim1_list[0], G, Tstop, TT, par, ss, shock_list, shock_list, "g")

    # All other runs (in parallel)
    # fnames = [simname + '/' + "_{task_id}_{i}" for i in range(1, Tsim)]
    flname = simname + '/simul_' + str(task_id)
    distributional_simul(sim2_list[1], sim1_list[1], G, Tstop, TT, par, ss, shock_list, flname)
    # pool = Pool(processes=5)
    # par_parallel = list(zip(sim2_list[1:], sim1_list[1:], [G] * Tsim, [Tstop] * Tsim, [TT] * Tsim, [par] * Tsim, [ss] * Tsim, [shock_list] * Tsim, fnames))
    # np.array(pool.starmap(distributional_simul, par_parallel))
