import utils
import numpy as np
import statsmodels.api as sm
import pandas as pd
#from sklearn.linear_model import LinearRegression

def simulate_workers(ss, K, H, par):
    # Vectorize distributions
    Dist = np.cumsum(np.append(np.reshape(ss['QUss'], -1), np.reshape(ss['QEss'], -1)))
    draws = np.random.rand(K)
    NU = np.prod(ss['QUss'].shape)
    NE = np.prod(ss['QEss'].shape)
    Ntot = len(Dist)

    # record random things
    eps_realizations = np.random.rand(H, K)
    a_realizations = np.random.rand(H, K)
    UE_realizations = np.random.rand(H, K)
    EU_realizations = np.random.rand(H, K)
    EE_realizations = np.random.rand(H, K)
    wUE_realizations = np.random.rand(H, K)
    wEE_realizations = np.random.rand(H, K)
    EV_realizations = np.random.rand(H, K)

    # to keep track of
    EE = np.zeros((H, K))
    Assets = np.zeros((H, K))
    Income = np.zeros((H, K))
    Tenure = np.zeros((H, K))
    Empstat = np.zeros((H, K))
    Plevel = np.zeros((H, K))
    Btype = np.zeros((H, K))
    #iQ = np.zeros((H, K))       # quantile of belonging

    # find threshold for quartiles
    #imid, pimid = utils.simple_interpolation(qmid, np.cumsum(np.sum(ss['QUss'], axis=(0,2)) + np.sum(ss['QEss'], axis=(0,2,3,4,5))))
    for k in range(K):
        # Start from period 0
        h = 0
        # Determine if unemployed or employed and find starting point
        if Dist[0] > draws[k]:
            kloc = 0
        else:
            kloc = np.where(draws[k] >= Dist)[0][-1]
        if kloc<NU:
            kis = 'U'
        else:
            kis = 'E'

        while h<H:
            if kis == 'U':
                if h==0:
                    idx_k = np.unravel_index(kloc, ss['QUss'].shape)
                # high or low wealth
                #iQ[h, k] = (idx_k[1] > imid) * 1 + (idx_k[1] == imid) * (np.random.rand() > pimid) * 1
                # recording variables
                Assets[h, k] = par['a_grid'][idx_k[1]]
                Btype[h, k] = idx_k[-1]
                # where worker ends up tomorrow
                anew = ss['AUss'][idx_k[0], idx_k[1], idx_k[2]]
                ai, aw = utils.simple_interpolation(anew, par['a_grid'])
                a_next = (aw < a_realizations[h, k]) * ai + (aw >= a_realizations[h, k]) * (ai + 1)
                eps_next = np.where(eps_realizations[h, k] < np.cumsum(par['Pi'][idx_k[0], :]))[0][0]
                # find a job or not?
                empstat_next = (UE_realizations[h, k] < ss['lambda0']) * 1 + (UE_realizations[h, k] >= ss['lambda0']) * 0
                if empstat_next == 0:
                    kis = 'U'
                    idx_k = (eps_next, a_next, idx_k[-1])
                else:
                    kis = 'E'
                    wU_pi = ss['WUpiss'][idx_k[0], idx_k[1], 0, idx_k[2]]
                    wU_i = ss['WUiss'][idx_k[0], idx_k[1], 0, idx_k[2]]
                    wnext = wU_i * (wUE_realizations[h, k] < wU_pi) + np.minimum(wU_i + 1, par['nW'] - 1) * (wUE_realizations[h, k] >= wU_pi)

                    idx_k = (eps_next, a_next, wnext, 0, 0, idx_k[-1])
            else:
                if h == 0:
                    idx_k = np.unravel_index(kloc - NU, ss['QEss'].shape)
                # high or low wealth
                #iQ[h, k] = (idx_k[1] > imid) * 1 + (idx_k[1] == imid) * (np.random.rand() > pimid) * 1
                # recording variables
                Assets[h, k] = par['a_grid'][idx_k[1]]
                Tenure[h, k] = np.arange(par['nT'])[idx_k[4]]
                Income[h, k] = par['w_grid'][idx_k[2]]
                Plevel[h, k] = idx_k[3]
                Empstat[h, k] = 1
                Btype[h, k] = idx_k[-1]
                # where worker ends up tomorrow
                anew = ss['AEss'][idx_k[0],idx_k[1],idx_k[2],idx_k[3],idx_k[4],idx_k[5]]
                ai, aw = utils.simple_interpolation(anew, par['a_grid'])
                a_next = (aw < a_realizations[h, k]) * ai + (aw >= a_realizations[h, k]) * np.minimum(ai + 1, par['nA'] - 1)
                eps_next = np.where(eps_realizations[h, k] < np.cumsum(par['Pi'][idx_k[0], :]))[0][0]
                # job loss?
                empstat_next = (EU_realizations[h, k] < par['sigma'][idx_k[4]]) * 0 + (EU_realizations[h, k] >= par['sigma'][idx_k[4]]) * 1
                if empstat_next==0:
                    kis = 'U'
                    idx_k = (eps_next, a_next, idx_k[-1])
                else:
                    kis = 'E'
                    # find a new job?
                    if idx_k[3] == par['nP'] - 1:
                        ee = 0
                    else:
                        ee = (EE_realizations[h, k] < par['s'] * ss['lambdas'][idx_k[3] + 1]) * 1 + (EE_realizations[h, k] >= par['s'] * ss['lambdas'][idx_k[3] + 1]) * 0
                    # no new job or new job
                    if ee == 0:
                        idx_k = (eps_next, a_next, idx_k[2], idx_k[3], np.minimum(idx_k[4] + 1, par['nT'] - 1), idx_k[-1])
                    else:
                        iwin = ss['Iwins'][eps_next, a_next, idx_k[2], idx_k[3], idx_k[4] - 1, np.minimum(idx_k[3] + 1, par['nP'] - 1), idx_k[5]]
                        qswitch = ss['qss'][eps_next, a_next, idx_k[2], idx_k[3], idx_k[4] - 1, np.minimum(idx_k[3] + 1, par['nP'] - 1), idx_k[5]]

                        # switch or not?
                        switch = (EV_realizations[h, k] < qswitch) * 1 + (EV_realizations[h, k] >= qswitch) * 0
                        if switch == 0:
                            # renegotiation
                            if iwin == 1:
                                wE_i = ss['WEloseiss'][eps_next, a_next, idx_k[2], idx_k[3], idx_k[4] - 1, np.minimum(idx_k[3] + 1, par['nP'] - 1), idx_k[5]]
                                wE_pi = ss['WElosepiss'][eps_next, a_next, idx_k[2], idx_k[3], idx_k[4] - 1, np.minimum(idx_k[3] + 1, par['nP'] - 1), idx_k[5]]
                            else:
                                wE_i = ss['WEwiniss'][eps_next, a_next, idx_k[2], idx_k[3], idx_k[4] - 1, np.minimum(idx_k[3] + 1, par['nP'] - 1), idx_k[5]]
                                wE_pi = ss['WEwinpiss'][eps_next, a_next, idx_k[2], idx_k[3], idx_k[4] - 1, np.minimum(idx_k[3] + 1, par['nP'] - 1), idx_k[5]]
                            wnext = wE_i * (wEE_realizations[h, k] < wE_pi) + np.minimum(wE_i + 1, par['nW'] - 1) * (wEE_realizations[h, k] >= wE_pi)
                            idx_k = (eps_next, a_next, wnext, idx_k[3], np.minimum(idx_k[4] + 1, par['nT'] - 1), idx_k[-1])
                        else:
                            EE[h, k] = 1
                            if iwin == 1:
                                wE_i = ss['WEwiniss'][eps_next, a_next, idx_k[2], idx_k[3], idx_k[4] - 1, np.minimum(idx_k[3] + 1, par['nP'] - 1), idx_k[5]]
                                wE_pi = ss['WEwinpiss'][eps_next, a_next, idx_k[2], idx_k[3], idx_k[4] - 1, np.minimum(idx_k[3] + 1, par['nP'] - 1), idx_k[5]]
                            else:
                                wE_i = ss['WEloseiss'][eps_next, a_next, idx_k[2], idx_k[3], idx_k[4] - 1, np.minimum(idx_k[3] + 1, par['nP'] - 1), idx_k[5]]
                                wE_pi = ss['WElosepiss'][eps_next, a_next, idx_k[2], idx_k[3], idx_k[4] - 1, np.minimum(idx_k[3] + 1, par['nP'] - 1), idx_k[5]]
                            wnext = wE_i * (wEE_realizations[h, k] < wE_pi) + np.minimum(wE_i + 1, par['nW'] - 1) * (wEE_realizations[h, k] >= wE_pi)
                            idx_k = (eps_next, a_next, wnext, np.minimum(idx_k[3] + 1, par['nP'] - 1), 0, idx_k[-1])

            h += 1
    return Assets, Income, Tenure, EE, Empstat, Plevel, Btype

def runReg(ss, K, H, nQ, par):
    # run simulation
    Assets, Income, Tenure, EE, Empstat, Plevel, Btype = simulate_workers(ss, K, H, par)

    # run overall regression
    # select only employed
    emp_keep = np.reshape(Empstat, -1)
    p_keep = np.reshape(Plevel, -1)
    #keep = np.where((emp_keep == 1))
    keep = np.where((emp_keep == 1) & (p_keep < par['nP'] - 1))
    EE_reg = np.reshape(EE, -1)[keep]
    Assets_reg = np.reshape(Assets, -1)[keep].reshape((-1, 1))
    Income_reg = np.reshape(Income, -1)[keep].reshape((-1, 1))
    Tenure_reg = np.reshape(Tenure, -1)[keep].reshape((-1, 1))
    Plevel_reg = np.reshape(Plevel, -1)[keep].reshape((-1, 1))
    Btype_reg = np.reshape(Btype, -1)[keep].reshape((-1, 1))
    #W_Y = Assets_reg / (4 * Income_reg)
    #if isp:
    #    data = pd.DataFrame({'y': EE_reg, 'wy': np.squeeze(W_Y),  'tenure': np.squeeze(Tenure_reg), 'fixed_effect': np.squeeze(Plevel_reg), 'beta_type': np.squeeze(Btype_reg)})
    #    model = sm.OLS(data['y'], (sm.add_constant(data[['wy','tenure']]).join(pd.get_dummies(data['fixed_effect']))))
    #else:
    #    data = pd.DataFrame({'y': EE_reg, 'wy': np.squeeze(W_Y),  'tenure': np.squeeze(Tenure_reg)})
    #    model = sm.OLS(data['y'], sm.add_constant(data[['wy', 'tenure']]))
    #result = model.fit()
    #coeff = result.params[1]
    #sd = result.cov_params()['wy'][1]

    # quantiles
    Coeffs = np.zeros(nQ-1)
    Coeffs_p = np.zeros(nQ-1)
    SDs = np.zeros(nQ-1)
    SDs_p = np.zeros(nQ-1)
    qntls = np.linspace(0, 1, nQ)
    rndAss = np.random.rand(int(len(keep[0])))
    for iq in range(1, nQ):
        # find asset thresholds
        loc_qlow, pi_qlow = utils.simple_interpolation(qntls[iq-1], np.cumsum(np.sum(ss['QUss'], axis=(0, 2)) + np.sum(ss['QEss'], axis=(0, 2, 3, 4, 5))))
        loc_qhigh, pi_qhigh = utils.simple_interpolation(qntls[iq], np.cumsum(np.sum(ss['QUss'], axis=(0,2)) + np.sum(ss['QEss'], axis=(0,2,3,4,5))))
        # find people with the right asset level
        Ass_squeeze = np.squeeze(Assets_reg)
        to_keep = (par['a_grid'][loc_qlow] < Ass_squeeze) & (Ass_squeeze <= par['a_grid'][loc_qhigh])
        to_keep = to_keep | (par['a_grid'][loc_qlow] == Ass_squeeze) * (rndAss < pi_qlow)
        to_keep = to_keep | (par['a_grid'][np.minimum(loc_qhigh+1, par['nA'] - 1)] == Ass_squeeze) * (rndAss > pi_qhigh)

        # run regression for specific quantile
        # select only employed
        EE_q = EE_reg[to_keep]
        Assets_q = Assets_reg[to_keep]
        Income_q = Income_reg[to_keep]
        Tenure_q = Tenure_reg[to_keep]
        Plevel_q = Plevel_reg[to_keep]
        Btype_q = Btype_reg[to_keep]
        W_Y_q = Assets_q / (4 * Income_q)
        # without extra controld
        data = pd.DataFrame({'y': EE_q, 'wy': np.squeeze(W_Y_q), 'tenure': np.squeeze(np.log(Tenure_q + 1))})
        model = sm.OLS(data['y'], sm.add_constant(data[['wy', 'tenure']]))
        result = model.fit()
        Coeffs[iq-1] = result.params[1]
        SDs[iq-1] = result.cov_params()['wy'][1]
        # with extra controls
        data = pd.DataFrame({'y': EE_q, 'wy': np.squeeze(W_Y_q), 'tenure': np.squeeze(np.log(Tenure_q + 1)), 'fixed_effect': np.squeeze(Plevel_q), 'beta_type': np.squeeze(Btype_q)})
        #model = sm.OLS(data['y'], (sm.add_constant(data[['wy','tenure', 'beta_type']]).join(pd.get_dummies(data['fixed_effect']))))
        model = sm.OLS(data['y'], (sm.add_constant(data[['wy','tenure']]).join(pd.get_dummies(data['fixed_effect']))))
        result = model.fit()
        Coeffs_p[iq-1] = result.params[1]
        SDs_p[iq-1] = result.cov_params()['wy'][1]

    return Coeffs, SDs, Coeffs_p, SDs_p

def histories(ss, K, H, par):
    # run simulation
    Assets, Income, Tenure, EE, Empstat, Plevel, Btype = simulate_workers(ss, K, H, par)
    # find median wealth
    imid, pimid = utils.simple_interpolation(0.5, np.cumsum(np.sum(ss['QEss'], axis=(0,2,3,4,5)) + np.sum(ss['QUss'], axis=(0,2))))

    # select only employed at final period
    keep = np.where((Empstat[-1,:] == 1))[0]
    Assets = Assets[:, keep]
    Income = Income[:, keep]
    Tenure = Tenure[:, keep]
    Plevel = Plevel[:, keep]
    EE = EE[:, keep]
    Empstat = Empstat[:, keep]
    # define those above (1) and below (0) median wealth
    iQ = np.ones(Assets.shape) * -1
    iQ[Assets < par['a_grid'][imid]] = 0
    iQ[Assets > par['a_grid'][imid]] = 1
    # attribute those at median
    rnds_iq = np.random.rand(Assets.shape[0], Assets.shape[1])    
    iQ[(rnds_iq > pimid) & (Assets == par['a_grid'][imid])] = 0
    iQ[(rnds_iq <= pimid) & (Assets == par['a_grid'][imid])] = 1
    print(np.mean(iQ==1))
    print(np.mean(iQ==0))

    # unemployment spells for low- and high-wealth workers
    islow = np.where(iQ[-1, :] == 0)[0]
    Uperiods_low = np.sum(Empstat[:-1, islow] == 0, axis=0)
    ishigh = np.where(iQ[-1, :] == 1)[0]
    Uperiods_high = np.sum(Empstat[:-1, ishigh] == 0, axis=0)
    # tenure history for low- and high-wealth workers
    Tenure_low = np.matrix.flatten(Tenure[:-1, islow])
    Tenure_high = np.matrix.flatten(Tenure[:-1, ishigh])

    return Uperiods_low, Uperiods_high, Tenure_low, Tenure_high
