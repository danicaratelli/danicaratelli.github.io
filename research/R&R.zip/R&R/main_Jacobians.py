import os
# set current director as working directory
os.chdir("")
import numpy as np
import load_params_SS as load_params
import matplotlib.pyplot as plt
import solveSS_AOB
import Jac
import pickle
import pandas as pd
import utils

# Options
ss_file_name = "ss_calibration.pkl"
TT = 250

# Load Steady State
with open(ss_file_name, 'rb') as file:
    ss = pickle.load(file)
# Load 
input = ss['inputs']
par = load_params.get_par(input)

# Steady state prices
r_ss = ss['r']
tax_ss = ss['tax']
thetas_ss = np.array([ss['theta0'], ss['theta1'], ss['theta2'], ss['theta3'], ss['theta4'], ss['theta5'], ss['theta6'], ss['theta7']])

# SS info in dictionary
print("Max asset policy = " + str(np.max((ss['QEss'] > 0) * ss['AEss'])))


# Transitions
shock_list = ['ra', 'Z', 'tax', 'transfer',
              'lambda0', 'lambda1', 'lambda2', 'lambda3', 'lambda4', 'lambda5', 'lambda6', 'lambda7',
              'rK', 'sigmaJ', 'sigmaslope', 'bUI']
path_name = 'Jacobians'
if not(os.path.isdir(path_name)):
    os.mkdir(path_name)


# Loop over variables to shock
for ii in range(len(shock_list)):
    shock_list_ii = shock_list[ii]
    Jac.get_jacobian(shock_list_ii, TT, par, ss)
    
# Loading and combining Jacobian
J = Jac.combine_Jac(path_name, shock_list)