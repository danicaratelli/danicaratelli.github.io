import numpy as np
from simple_block import simple
from solved_block import solved
import utils

'''Part 1: Simple Blocks'''

# labor market flow rates
@simple
def labor_flows(theta0, theta1, theta2, theta3, theta4, theta5, theta6, theta7, s, chi, eta):
    q0 = chi * (1 / theta0) ** eta
    lambda0 = theta0 * q0
    q1 = chi * (1 / theta1) ** eta
    lambda1 = theta1 * q1
    q2 = chi * (1 / theta2) ** eta
    lambda2 = theta2 * q2
    q3 = chi * (1 / theta3) ** eta
    lambda3 = theta3 * q3
    q4 = chi * (1 / theta4) ** eta
    lambda4 = theta4 * q4
    q5 = chi * (1 / theta5) ** eta
    lambda5 = theta5 * q5
    q6 = chi * (1 / theta6) ** eta
    lambda6 = theta6 * q6
    q7 = chi * (1 / theta7) ** eta
    lambda7 = theta7 * q7

    return q0, lambda0, q1, lambda1, q2, lambda2, q3, lambda3, q4, lambda4, q5, lambda5, q6, lambda6, q7, lambda7

# matching technology
@simple
def matching_tech(theta0, theta1, theta2, theta3, theta4, theta5, theta6, theta7, e0, e1, e2, e3, e4, e5, e6, e7):
    v0 = theta0 * e0
    v1 = theta1 * e1
    v2 = theta2 * e2
    v3 = theta3 * e3
    v4 = theta4 * e4
    v5 = theta5 * e5
    v6 = theta6 * e6
    v7 = theta7 * e7

    return v0, v1, v2, v3, v4, v5, v6, v7

@simple
def dividend(rK, K, drate, epsI):
    # capital adjustment costs
    phiK = K(-1) * ((K / K(-1) - 1) ** 2) / (2 * drate * epsI)
    # investment
    I = K - (1 - drate) * K(-1) + phiK
    # dividends
    div = rK * K(-1) - I
    return I, div

@simple
def earnings_posttax(earnings, tax):
    earnings_posttax = earnings * (1 - tax)
    return earnings_posttax

@simple
def intermediaries(p, div):
    ra = (div + p) / p(-1) - 1
    return ra

''' Part 2: Solved blocks'''
@simple
def labor(Y, K, Z, alpha):
    L = (Y / (Z * K(-1) ** alpha)) ** (1 / (1 - alpha))
    rK = alpha * Z * (L / K(-1)) ** (1 - alpha)
    return L, rK

@simple
def investment(Q, K, r, L, Z, drate, epsI, alpha):
    inv = (K / K(-1) - 1) / (drate * epsI) + 1 - Q
    rK_next = alpha * Z(+1) * (L(+1) / K) ** (1 - alpha)
    #rK_next = alpha * Z * (L / K(-1)) ** (1 - alpha)
    #val = rK_next - (K / K(-1) - (1 - drate) + (K / K(-1) - 1) ** 2 / (2 * drate * epsI)) + (K / K(-1)) * Q - (1 + r) * Q(-1)
    val = rK_next - (K(+1) / K - (1 - drate) + (K(+1) / K - 1) ** 2 / (2 * drate * epsI)) + (K(+1) / K) * Q(+1) - (1 + r) * Q
    return inv, val

production = solved(block_list=[labor, investment],
                    unknowns=['Q', 'K'],
                    targets=['inv', 'val'])

@solved(unknowns=['p'], targets=['equity'])
def capitalist(div, p, r):
    equity = div(+1) + p(+1) - p * (1 + r)
    return equity

'''Part 3: Final blocks'''
@simple
def asset_mkt(A, p):
    h1 = A - p
    return h1

@simple
def labor_mkt(N, L):
    h2 = N - L
    return h2

@simple
def fiscal(Tax, tax, Ubill, Pi, v0, v1, v2, v3, v4, v5, v6, v7, pgrid0, pgrid1, pgrid2, pgrid3, pgrid4, pgrid5, pgrid6, pgrid7, transfer, zeta, zeta_curv):
    h3 = Tax + (Pi - (v0 * (zeta * pgrid0) ** zeta_curv + v1 * (zeta * pgrid1) ** zeta_curv + v2 * (zeta * pgrid2) ** zeta_curv + v3 * (zeta * pgrid3) ** zeta_curv + v4 * (zeta * pgrid4) ** zeta_curv + v5 * (zeta * pgrid5) ** zeta_curv + v6 * (zeta * pgrid6) ** zeta_curv + v7 * (zeta * pgrid7) ** zeta_curv)) - (1 - tax) * Ubill - transfer
    # h3 = Tax + (Pi - 1.5 * (zeta) * (1.2 * v0 + v1 * (pgrid1 ** 0.75) + v2 * (pgrid2 ** 0.75) + v3 * (pgrid3 ** 0.75) + v4 * (pgrid4 ** 0.75) + v5 * (pgrid5 ** 0.75) + v6 * (pgrid6 ** 0.75) + v7 * (pgrid7 ** 0.75))) - (1 - tax) * Ubill - transfer
    return h3

@simple
def free_entry(J0_0, J0_1, J0_2, J0_3, J0_4, J0_5, J0_6, J0_7, q0, q1, q2, q3, q4, q5, q6, q7, pgrid0, pgrid1, pgrid2, pgrid3, pgrid4, pgrid5, pgrid6, pgrid7, r, zeta, zeta_curv):
    h4 = ((1 + r) * (zeta * pgrid0) ** zeta_curv / J0_0) - q0
    h5 = ((1 + r) * (zeta * pgrid1) ** zeta_curv / J0_1) - q1
    h6 = ((1 + r) * (zeta * pgrid2) ** zeta_curv / J0_2) - q2
    h7 = ((1 + r) * (zeta * pgrid3) ** zeta_curv / J0_3) - q3
    h8 = ((1 + r) * (zeta * pgrid4) ** zeta_curv / J0_4) - q4
    h9 = ((1 + r) * (zeta * pgrid5) ** zeta_curv / J0_5) - q5
    h10 = ((1 + r) * (zeta * pgrid6) ** zeta_curv / J0_6) - q6
    h11 = ((1 + r) * (zeta * pgrid7) ** zeta_curv / J0_7) - q7
    return h4, h5, h6, h7, h8, h9, h10, h11

@simple
def walras(Y, C, I, v0, v1, v2, v3, v4, v5, v6, v7, pgrid0, pgrid1, pgrid2, pgrid3, pgrid4, pgrid5, pgrid6, pgrid7, zeta, zeta_curv):
    LHS = C
    RHS = Y - I - (v0 * (zeta * pgrid0) ** zeta_curv + v1 * (zeta * pgrid1) ** zeta_curv + v2 * (zeta * pgrid2) ** zeta_curv + v3 * (zeta * pgrid3) ** zeta_curv + v4 * (zeta * pgrid4) ** zeta_curv + v5 * (zeta * pgrid5) ** zeta_curv + v6 * (zeta * pgrid6) ** zeta_curv + v7 * (zeta * pgrid7) ** zeta_curv)
    walras_res = LHS - RHS
    return walras_res
