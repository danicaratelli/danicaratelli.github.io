import os
import numpy as np
import load_params_SS as load_params
import solveSS_AOB
import Jac
import pickle
import pandas as pd
import utils
import sys
import time
import multiprocessing as mp
import itertools
from filelock import FileLock
import wealth_lorenz

# Options
i_ss = True # if want to estimate SS
i_naive = False # if want to solve naive SS
ss_tol = 1e-4 # calibration-screening tolerance; use 1e-5 later for final refinement
# input_index = 9
OUTPATH = "results"

# Grids
z_grid = np.array([-0.6414269805898185])
Pi_grid = np.array([0.85])
zeta_grid = np.array([1.1])
# p1_grid = np.array([-0.4])
# p2_grid = np.array([-0.30])
# p3_grid = np.array([-0.10])
# p4_grid = np.array([0.0])
# p5_grid = np.array([0.10])
# p6_grid = np.array([0.25])
# p7_grid = np.array([1.1])
# p8_grid = np.array([2.2])
poly1_grid = np.array([0.1271111788])
poly2_grid = np.array([0.0320758466])
poly3_grid = np.array([-0.0229250279])
poly4_grid = np.array([0.0032058894])
s_grid = np.array([0.32, 0.33, 0.35, 0.36, 0.38])
sigma0_grid = np.array([0.028]) #EU probability
bdeta_grid = np.array([0.012])
chi_grid = np.array([0.20, 0.21, 0.22]) #0.23

inputs = []
for vals in itertools.product(*[z_grid, Pi_grid, zeta_grid, poly1_grid, poly2_grid, poly3_grid, poly4_grid, s_grid, sigma0_grid, bdeta_grid, chi_grid]):
    inputs.append(dict(zip(['zlow', 'Pi11', 'zeta', 'poly1', 'poly2', 'poly3', 'poly4', 's', 'sigma0', 'dbeta', 'chi'], vals)))
    inputs[len(inputs) - 1]['index'] = len(inputs) - 1

inputs = inputs[:2]

# targets
targets = np.array([0.004,  # UI_to_GDI
                    0.56,   # job-finding prob
                    0.06,   # unemploymenyt rate
                    0.041,  # job-switching probability
                    -1.04,  # Q1 of wealth Lorenz
                    0.68,   # Q2 of wealth Lorenz
                    6.85,   # Q3 of wealth Lorenz
                    18.21,  # Q4 of wealth Lorenz
                    75.3])  # Q5 of wealth Lorenz
# weights
wgts = np.array([1, 1, 1, 2, 0.7, 0.7, 0.4, 0.1, 0.1])

def mp_worker(input, inaive=False):
    smm_index = input['index']
    # Output path
    outpath = os.path.join(OUTPATH, f"result_par{smm_index}.csv")
    # Load Parameters
    par = load_params.get_par(input)
    par['verbose_ss'] = True
    par['jac_init'] = 'identity'    
    # Set initial guess. The parameters listed solve for steady state. Because this takes ~90 minutes or more from a less educated guess, I list them here as the starting point so solving for steady state is quick.
    r = 0.002278244304438834   
    tax = -0.2902829273871056
    thetas = np.array([15.001011471099025, 0.171313592775733, 0.38304462748202056, 0.07032688363741249, 0.09508545407551863, 1.3493827872088155, 1.736562930225245, 5.877709860593139])    
    xguess = np.append(np.array([r, tax]), thetas)

    # ------ START SAMPLE SOLVE (TO DELETE)------
    start = time.time()
    # Solve model
    print('Solving steady state with tol = {}'.format(ss_tol))
    try: 
        r_ss, tax_ss, thetas_ss = solveSS_AOB.SS(xguess, par['Z'], par, smm_index, ss_tol)
        end_time = time.time()
        test_results = np.concatenate((
            [r_ss, tax_ss],
            np.asarray(thetas_ss).ravel(),
            [(end_time - start) / 60],
        ))
        pd.DataFrame([test_results]).to_csv(outpath, index=False, header=False)
        
        return smm_index, True
    except Exception as e:
        end_time = time.time()
        print('Failed to solve steady state.')
        print(f"Error: {e}")
        return smm_index, False


# Run in parallel
if __name__ == '__main__':
    n_total = len(inputs)
    n_workers = min(mp.cpu_count(), n_total)
    print(f"Running {n_total} parameter combinations with {n_workers} workers.")
    if n_workers == 1:
        results = [mp_worker(inp) for inp in inputs]
        for idx, (n, ok) in enumerate(results, start=1):
            status = "OK" if ok else "FAILED"
            print(f"Completed {idx}/{n_total} (Seq {n}): {status}")
    else:        
        with mp.Pool(processes=n_workers) as pool:
            for idx, (n, ok) in enumerate(pool.imap_unordered(mp_worker, inputs), start=1):
                status = "OK" if ok else "FAILED"
                print(f"Completed {idx}/{n_total} (Par {n}): {status}")
