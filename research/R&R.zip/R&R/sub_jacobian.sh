#!/bin/bash
#SBATCH --job-name=get_jacobians
#SBATCH --nodes=1          # Request N nodes
#SBATCH --output=outfile-%j.output
#SBATCH --exclusive
#SBATCH --nodelist=memq-dy-mem-1

#SBATCH --partition=memq

module load anaconda3/3.8.8gpu
/opt/aws_ofrpt/anaconda3-2021.04/bin/python3 -Xfaulthandler main_Jacobians.py