# This file has all functions to help with the Great Resignation experiment
import matplotlib.pyplot as plt
import numpy as np
import utils
import statsmodels.api as sm
import Jac_help
import os

def get_irf(var, dshocks, G, TT):
    xres = np.zeros(TT)
    for s in dshocks.keys():
        xres += G[var][s] @ dshocks[s]
    return xres

def findshocks_GRecession(G, paths, var_list, shock_list, TT):
    N = len(var_list)
    # Define objective function
    x0 = np.zeros(TT * N)
    def obj_fun(x):
        res = np.zeros(TT * N)
        j = 0
        for v in var_list:
            k = 0
            for s in shock_list:
                res[j * TT: TT * (1 + j)] += G[v][s] @ x[k * TT : TT * (1 + k)]
                k += 1
            j += 1
        res = res - paths.ravel()

        return res
    xstar, _ = utils.broyden_solver(obj_fun, x0, noisy=False, tol=1e-9, maxcount=1000)
    dshocks = {}
    j = 0
    for s in shock_list:
        dshocks[s] = xstar[j * TT: TT * (1 + j)]
        j += 1
    
    return dshocks



def GR_exercise(G, TT, dshocks, par, ss):
    nB = par['nB']  
    # Get sequence of exogenous paths that deliver path for output    
    Z_path = ss['Z'] * (np.ones(TT) + dshocks.get('Z', 0))
    transfer_path = ss['transfer'] * (np.ones(TT) + dshocks.get('transfer', 0))
    sigmaJ_path = ss['sigmaJ'] * (np.ones(TT) + dshocks.get('sigmaJ', 0))
    sigmaslope_path = ss['sigmaslope'] * (np.ones(TT) + dshocks.get('sigmaslope', 0))
    bUI_path = ss['bUI'] * (np.ones(TT) + dshocks.get('bUI', 0))
    zeta_path = ss['zeta'] * (np.ones(TT) + dshocks.get('zeta', 0))

    # all other relevant paths
    ra_path = ss['ra'] * (1 + get_irf('ra', dshocks, G, TT))
    r_path = ss['r'] * (1 + get_irf('r', dshocks, G, TT))
    rK_path = ss['rK'] * (1 + get_irf('rK', dshocks, G, TT))
    tax_path = ss['tax'] * (1 + get_irf('tax', dshocks, G, TT))
    lambdas_path = np.ones((TT, par['nP'])) * ss['lambdas'][np.newaxis, :]
    for ip in range(par['nP']):
        lambdas_path[:, ip] = ss['lambda' + str(ip)] * (1 + get_irf('lambda' + str(ip), dshocks, G, TT))
    lambdas_path[lambdas_path < 0] = 0

    # kill off after 20 periods
    ra_path[30:] = ss['ra']
    r_path[30:] = ss['r']
    rK_path[30:] = ss['rK']
    tax_path[30:] = ss['tax']
    for ip in range(par['nP']):
        lambdas_path[:30, ip] = ss['lambda' + str(ip)]

    # Distributions along transitions
    QE_path = np.zeros(ss['QEss'].shape + (TT+1,))
    QE_path[:, :, :, :, :, :, 0] = ss['QEss']
    QEE_path = np.zeros(ss['QEEss'].shape + (TT+1,))
    QEE_path[:, :, :, :, :, :, :, 0] = ss['QEEss']
    QUE_path = np.zeros(ss['QUEss'].shape + (TT+1,))
    QUE_path[:, :, :, :, 0] = ss['QUEss']
    QU_path = np.zeros(ss['QUss'].shape + (TT+1,))
    QU_path[:, :, :, 0] = ss['QUss']
    # Policies along transitions
    CE_path = np.copy(ss['CEss'])
    CU_path = np.copy(ss['CUss'])
    Ebargaining = np.copy(ss['Ebargainingss'])
    dEbargaining = np.copy(ss['dEbargainingss'])
    Jbargaining = np.copy(ss['Jbargainingss'])
    U_old = ss['Uss']
    E_old = ss['Ess']
    J_old = ss['Jss']

    AE_path = np.zeros(ss['AEss'].shape + (TT+1,))
    AE_path[:, :, :, :, :, :, -1] = ss['AEss']
    AU_path = np.zeros(ss['AUss'].shape + (TT+1,))
    AU_path[:, :, :, -1] = ss['AUss']    

    WEwinpi_path = np.zeros(ss['WEwinpiss'].shape + (TT+1,))
    WEwinpi_path[:, :, :, :, :, :, :, -1] = ss['WEwinpiss']
    WEwini_path = np.zeros(ss['WEwiniss'].shape + (TT+1,), dtype='uint32')
    WEwini_path[:, :, :, :, :, :, :, -1] = ss['WEwiniss']
    WElosepi_path = np.zeros(ss['WElosepiss'].shape + (TT+1,))
    WElosepi_path[:, :, :, :, :, :, :, -1] = ss['WElosepiss']
    WElosei_path = np.zeros(ss['WEloseiss'].shape + (TT+1,), dtype='uint32')
    WElosei_path[:, :, :, :, :, :, :, -1] = ss['WEloseiss']
    WUpi_path = np.zeros(ss['WUpiss'].shape + (TT+1,))
    WUpi_path[:, :, :, :, -1] = ss['WUpiss']
    WUi_path = np.zeros(ss['WUiss'].shape + (TT+1,), dtype='uint32')
    WUi_path[:, :, :, :, -1] = ss['WUiss']
    Iwins_path = np.zeros(ss['Iwins'].shape + (TT+1,))
    Iwins_path[:, :, :, :, :, :, :, -1] = ss['Iwins']
    qs_path = np.zeros(ss['qss'].shape + (TT+1,))
    qs_path[:, :, :, :, :, :, :, -1] = ss['qss']

    # append to lambdas and sigmaJ
    lambdas_path = np.vstack([lambdas_path, ss['lambdas']])
    sigmaJ_path = np.append(sigmaJ_path, ss['sigmaJ'])
    sigmaslope_path = np.append(sigmaslope_path, ss['sigmaslope'])

    beta_ss = par['beta']
    for t in range(TT - 1, -1, -1):
        print(t)
        for ib in range(nB):
            # Get policy functions
            par['beta'] = beta_ss + (2 * ib - 1) * par['dbeta']
            # input paths
            CU_path[:, :, ib], CE_path[:, :, :, :, :, ib], U_old[:, :, ib], E_old[:, :, :, :, :, ib], \
            Ebargaining[:, :, :, :, :, ib], dEbargaining[:, :, :, :, :, ib], AU_path[:, :, ib, t], AE_path[:, :, :, :, :, ib, t], \
            J_old[:, :, :, :, :, ib], Jbargaining[:, :, :, :, :, ib], JU0_trash, JE0_trash, \
            qs_path[:, :, :, :, :, :, ib, t], WUi_path[:, :, :, ib, t], WUpi_path[:, :, :, ib, t], \
            WEwini_path[:, :, :, :, :, :, ib, t], WEwinpi_path[:, :, :, :, :, :, ib, t], \
            WElosei_path[:, :, :, :, :, :, ib, t], WElosepi_path[:, :, :, :, :, :, ib, t], \
            Iwins_path[:, :, :, :, :, :, ib, t] = Jac_help.backward_iterate(ra_path[t], r_path[t], rK_path[t], Z_path[t], tax_path[t],
                                                    lambdas_path[t + 1, :], bUI_path[t], 
                                                    sigmaJ_path[t + 1], sigmaslope_path[t + 1], transfer_path[t],
                                                    CU_path[:, :, ib], CE_path[:, :, :, :, :, ib],
                                                    U_old[:, :, ib], E_old[:, :, :, :, :, ib],
                                                    Ebargaining[:, :, :, :, :, ib], dEbargaining[:, :, :, :, :, ib],
                                                    J_old[:, :, :, :, :, ib], Jbargaining[:, :, :, :, :, ib], par)

    par['beta'] = beta_ss

    for t in range(1, TT):
        print(t)
        for ib in range(nB):
            # Update distribution
            QUtmp, QEtmp, QUEtmp, QEEtmp = Jac_help.forward_iterate(par['nB'] * QU_path[:, :, ib, t - 1],
                                                            par['nB'] * QE_path[:, :, :, :, :, ib, t - 1],
                                                            AU_path[:, :, ib, t], AE_path[:, :, :, :, :, ib, t],
                                                            WUi_path[:, :, :, ib, t], WUpi_path[:, :, :, ib, t],
                                                            WEwini_path[:, :, :, :, :, :, ib, t],
                                                            WEwinpi_path[:, :, :, :, :, :, ib, t],
                                                            WElosei_path[:, :, :, :, :, :, ib, t],
                                                            WElosepi_path[:, :, :, :, :, :, ib, t],
                                                            qs_path[:, :, :, :, :, :, ib, t],
                                                            Iwins_path[:, :, :, :, :, :, ib, t],
                                                            lambdas_path[t - 1, :], sigmaJ_path[t - 1], sigmaslope_path[t - 1], par)
            QU_path[:, :, ib, t], \
            QE_path[:, :, :, :, :, ib, t], \
            QUE_path[:, :, :, ib, t], \
            QEE_path[:, :, :, :, :, :, ib, t] = QUtmp / nB, QEtmp / nB, QUEtmp / nB, QEEtmp / nB


    Earnings = np.sum(np.sum(QE_path, axis=(0,1,3,4,5)) * par['w_grid'][:, np.newaxis], axis=0)[:-1] / np.sum(QE_path, axis=(0, 1, 2, 3, 4, 5))[:-1]
    pdist = np.sum(QE_path, axis=(0,1,2,4,5))

    # Computing earnings by wealths
    EarningsL = np.zeros(TT)
    EarningsH = np.zeros(TT)
    AL = np.zeros(TT)
    AH = np.zeros(TT)
    EEL = np.zeros(TT)
    EEH = np.zeros(TT)
    EUL = np.zeros(TT)
    EUH = np.zeros(TT)
    Y = np.zeros(TT)
    uL = np.zeros(TT)   # unemployment rate for Low-wealth workers
    uH = np.zeros(TT)   # unemployment rate for High-wealth workers
    tenuresL = np.zeros((TT, par['nT']))
    tenuresH = np.zeros((TT, par['nT']))
    for t in range(TT):
        # find median index
        Qt = np.sum(QE_path[:, :, :, :, :, :, t], axis=(0, 2, 3, 4, 5)) + np.sum(QU_path[:, :, :, t], axis=(0, 2))
        # Qt = np.sum(QE_path[:, :, :, :, :, :, t], axis=(0, 2, 3, 4, 5))
        xi, xpi = utils.simple_interpolation(0.5 * np.sum(Qt), np.cumsum(Qt))
        assert np.abs(np.sum(Qt[:xi+1]) + (1 - xpi) * Qt[xi+1] - (np.sum(Qt[xi+2:]) + xpi * Qt[xi+1])< 1e-6), 'Threshold does not hold up'
        QEL = np.copy(QE_path[:, :xi + 2, :, :, :, :, t])
        QEL[:, -1, :, :, :, :] = QE_path[:, xi + 1, :, :, :, :, t] * (1 - xpi)
        QEH = np.copy(QE_path[:, xi + 1:, :, :, :, :, t])
        QEH[:, 0, :, :, :, :] = QE_path[:, xi + 1, :, :, :, :, t] * xpi
        assert np.abs(np.sum(QEL) + np.sum(QEH) - np.sum(QE_path[:, :, :, :, :, :, t])) < 1e-6, 'Threshold does not hold up'
        QEEL = np.copy(QEE_path[:, :xi + 2, :, :, :, :, :, t])
        QEEL[:, -1, :, :, :, :] = QEE_path[:, xi + 1, :, :, :, :, :, t] * (1 - xpi)
        QEEH = np.copy(QEE_path[:, xi + 1:, :, :, :, :, :, t])
        QEEH[:, 0, :, :, :, :] = QEE_path[:, xi + 1, :, :, :, :, :, t] * xpi
        tenuresL[t, :] = np.sum(QEL, axis=(0,1,2,3,5)) / np.sum(QEL)
        tenuresH[t, :] = np.sum(QEH, axis=(0, 1, 2, 3, 5)) / np.sum(QEH)

        # Unemployment rate
        QUL = np.copy(QU_path[:, :xi + 2, :, t])
        QUL[:, -1, :] = QU_path[:, xi + 1, :, t] * (1 - xpi)
        uL[t] = np.sum(QUL) / (np.sum(QUL) + np.sum(QEL))
        QUH = np.copy(QU_path[:, xi + 1:, :, t])
        QUH[:, 0, :] = QU_path[:, xi + 1, :, t] * xpi
        uH[t] = np.sum(QUH) / (np.sum(QUH) + np.sum(QEH))        

        # Earnings by wealth
        EarningsL[t] = np.sum(np.sum(QEL, axis=(0, 1, 3, 4, 5)) * par['w_grid']) / np.sum(QEL)
        EarningsH[t] = np.sum(np.sum(QEH, axis=(0, 1, 3, 4, 5)) * par['w_grid']) / np.sum(QEH)
        # Wealth for each group
        AL[t] = np.sum(np.sum(QEL, axis=(0, 2, 3, 4, 5)) * par['a_grid'][:xi+2])
        AH[t] = np.sum(np.sum(QEH, axis=(0, 2, 3, 4, 5)) * par['a_grid'][xi+1:])

        # Job-switching by wealth
        qL = np.copy(qs_path[:, :xi + 2, :, :, :, :, :, t])
        qL[:, -1, :, :, :, :] = qs_path[:, xi + 1, :, :, :, :, :, t] * (1 - xpi)
        qH = np.copy(qs_path[:, xi + 1:, :, :, :, :, :, t])
        qH[:, 0, :, :, :, :] = qs_path[:, xi + 1, :, :, :, :, :, t] * xpi
        # Job-switching
        EEL[t] = np.sum(np.sum(QEEL * qL, axis=(0, 1, 2, 4, 5, 6))) / np.sum(QEL)
        EEH[t] = np.sum(np.sum(QEEH * qH, axis=(0, 1, 2, 4, 5, 6))) / np.sum(QEH)
        # Job-losing
        sigmas = par['sigma']
        # level shift in unemployment probability
        sigmas = sigmas + (sigmaJ_path[t] - sigmas[-1])
        # slope change in unemployment probability
        sigmas = sigmas * (1 + sigmaslope_path[t])
        EUL[t] = np.sum(np.sum(QEL, axis=(0, 1, 2, 3, 5)) * sigmas) / np.sum(QEL)
        EUH[t] = np.sum(np.sum(QEH, axis=(0, 1, 2, 3, 5)) * sigmas) / np.sum(QEH)
        # output
        k_little = (rK_path[t] / (par['alpha'] * Z_path[t])) ** (1 / (par['alpha'] - 1))    # capital per effective unit of labor
        effZ = par['z_grid'][:, np.newaxis, np.newaxis, np.newaxis, np.newaxis, np.newaxis] * \
            par['p_grid'][np.newaxis, np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]
        Y[t] = np.sum(Z_path[t] * effZ * utils.f(k_little, par) * QE_path[:, :, :, :, :, :, t])

    # unemployment
    U = np.sum(QU_path, axis=(0,1,2))[:-1]


    return Y, Earnings, EarningsL, EarningsH, U, AL, AH, EEL, EEH, EUL, EUH, uL, uH, pdist

# def GR_exercise(G, TT, dshocks, par, ss):
#     nB = par['nB']  
#     # Get sequence of exogenous paths that deliver path for output    
#     Z_path = ss['Z'] * np.ones(TT) + dshocks.get('Z', 0)
#     transfer_path = ss['transfer'] * np.ones(TT) + dshocks.get('transfer', 0)
#     sigmaJ_path = ss['sigmaJ'] * np.ones(TT) + dshocks.get('sigmaJ', 0)
#     sigmaslope_path = ss['sigmaslope'] * np.ones(TT) + dshocks.get('sigmaslope', 0)
#     bUI_path = ss['bUI'] * np.ones(TT) + dshocks.get('bUI', 0)
#     zeta_path = ss['zeta'] * np.ones(TT) + dshocks.get('zeta', 0)

#     # all other relevant paths
#     ra_path = ss['ra'] + get_irf('ra', dshocks, G, TT)
#     r_path = ss['r'] + get_irf('r', dshocks, G, TT)
#     rK_path = ss['rK'] + get_irf('rK', dshocks, G, TT)
#     tax_path = ss['tax'] + get_irf('tax', dshocks, G, TT)
#     lambdas_path = np.ones((TT, par['nP'])) * ss['lambdas'][np.newaxis, :]
#     for ip in range(par['nP']):
#         lambdas_path[:, ip] = ss['lambda' + str(ip)] + get_irf('lambda' + str(ip), dshocks, G, TT)
#     lambdas_path[lambdas_path < 0] = 0

#     # kill off after 20 periods
#     ra_path[30:] = ss['ra']
#     r_path[30:] = ss['r']
#     rK_path[30:] = ss['rK']
#     tax_path[30:] = ss['tax']
#     for ip in range(par['nP']):
#         lambdas_path[:30, ip] = ss['lambda' + str(ip)]

#     # Distributions along transitions
#     QE_path = np.zeros(ss['QEss'].shape + (TT+1,))
#     QE_path[:, :, :, :, :, :, 0] = ss['QEss']
#     QEE_path = np.zeros(ss['QEEss'].shape + (TT+1,))
#     QEE_path[:, :, :, :, :, :, :, 0] = ss['QEEss']
#     QUE_path = np.zeros(ss['QUEss'].shape + (TT+1,))
#     QUE_path[:, :, :, :, 0] = ss['QUEss']
#     QU_path = np.zeros(ss['QUss'].shape + (TT+1,))
#     QU_path[:, :, :, 0] = ss['QUss']
#     # Policies along transitions
#     CE_path = np.copy(ss['CEss'])
#     CU_path = np.copy(ss['CUss'])
#     Ebargaining = np.copy(ss['Ebargainingss'])
#     dEbargaining = np.copy(ss['dEbargainingss'])
#     Jbargaining = np.copy(ss['Jbargainingss'])
#     U_old = ss['Uss']
#     E_old = ss['Ess']
#     J_old = ss['Jss']

#     AE_path = np.zeros(ss['AEss'].shape + (TT+1,))
#     AE_path[:, :, :, :, :, :, -1] = ss['AEss']
#     AU_path = np.zeros(ss['AUss'].shape + (TT+1,))
#     AU_path[:, :, :, -1] = ss['AUss']    

#     WEwinpi_path = np.zeros(ss['WEwinpiss'].shape + (TT+1,))
#     WEwinpi_path[:, :, :, :, :, :, :, -1] = ss['WEwinpiss']
#     WEwini_path = np.zeros(ss['WEwiniss'].shape + (TT+1,), dtype='uint32')
#     WEwini_path[:, :, :, :, :, :, :, -1] = ss['WEwiniss']
#     WElosepi_path = np.zeros(ss['WElosepiss'].shape + (TT+1,))
#     WElosepi_path[:, :, :, :, :, :, :, -1] = ss['WElosepiss']
#     WElosei_path = np.zeros(ss['WEloseiss'].shape + (TT+1,), dtype='uint32')
#     WElosei_path[:, :, :, :, :, :, :, -1] = ss['WEloseiss']
#     WUpi_path = np.zeros(ss['WUpiss'].shape + (TT+1,))
#     WUpi_path[:, :, :, :, -1] = ss['WUpiss']
#     WUi_path = np.zeros(ss['WUiss'].shape + (TT+1,), dtype='uint32')
#     WUi_path[:, :, :, :, -1] = ss['WUiss']
#     Iwins_path = np.zeros(ss['Iwins'].shape + (TT+1,))
#     Iwins_path[:, :, :, :, :, :, :, -1] = ss['Iwins']
#     qs_path = np.zeros(ss['qss'].shape + (TT+1,))
#     qs_path[:, :, :, :, :, :, :, -1] = ss['qss']

#     # append to lambdas and sigmaJ
#     lambdas_path = np.vstack([lambdas_path, ss['lambdas']])
#     sigmaJ_path = np.append(sigmaJ_path, ss['sigmaJ'])
#     sigmaslope_path = np.append(sigmaslope_path, ss['sigmaslope'])

#     beta_ss = par['beta']
#     for t in range(TT - 1, -1, -1):
#         print(t)
#         for ib in range(nB):
#             # Get policy functions
#             par['beta'] = beta_ss + (2 * ib - 1) * par['dbeta']
#             # input paths
#             CU_path[:, :, ib], CE_path[:, :, :, :, :, ib], U_old[:, :, ib], E_old[:, :, :, :, :, ib], \
#             Ebargaining[:, :, :, :, :, ib], dEbargaining[:, :, :, :, :, ib], AU_path[:, :, ib, t], AE_path[:, :, :, :, :, ib, t], \
#             J_old[:, :, :, :, :, ib], Jbargaining[:, :, :, :, :, ib], JU0_trash, JE0_trash, \
#             qs_path[:, :, :, :, :, :, ib, t], WUi_path[:, :, :, ib, t], WUpi_path[:, :, :, ib, t], \
#             WEwini_path[:, :, :, :, :, :, ib, t], WEwinpi_path[:, :, :, :, :, :, ib, t], \
#             WElosei_path[:, :, :, :, :, :, ib, t], WElosepi_path[:, :, :, :, :, :, ib, t], \
#             Iwins_path[:, :, :, :, :, :, ib, t] = Jac_help.backward_iterate(ra_path[t], r_path[t], rK_path[t], Z_path[t], tax_path[t],
#                                                     lambdas_path[t + 1, :], bUI_path[t], 
#                                                     sigmaJ_path[t + 1], sigmaslope_path[t + 1], transfer_path[t],
#                                                     CU_path[:, :, ib], CE_path[:, :, :, :, :, ib],
#                                                     U_old[:, :, ib], E_old[:, :, :, :, :, ib],
#                                                     Ebargaining[:, :, :, :, :, ib], dEbargaining[:, :, :, :, :, ib],
#                                                     J_old[:, :, :, :, :, ib], Jbargaining[:, :, :, :, :, ib], par)

#     par['beta'] = beta_ss

#     for t in range(1, TT):
#         print(t)
#         for ib in range(nB):
#             # Update distribution
#             QUtmp, QEtmp, QUEtmp, QEEtmp = Jac_help.forward_iterate(par['nB'] * QU_path[:, :, ib, t - 1],
#                                                             par['nB'] * QE_path[:, :, :, :, :, ib, t - 1],
#                                                             AU_path[:, :, ib, t], AE_path[:, :, :, :, :, ib, t],
#                                                             WUi_path[:, :, :, ib, t], WUpi_path[:, :, :, ib, t],
#                                                             WEwini_path[:, :, :, :, :, :, ib, t],
#                                                             WEwinpi_path[:, :, :, :, :, :, ib, t],
#                                                             WElosei_path[:, :, :, :, :, :, ib, t],
#                                                             WElosepi_path[:, :, :, :, :, :, ib, t],
#                                                             qs_path[:, :, :, :, :, :, ib, t],
#                                                             Iwins_path[:, :, :, :, :, :, ib, t],
#                                                             lambdas_path[t - 1, :], sigmaJ_path[t - 1], sigmaslope_path[t - 1], par)
#             QU_path[:, :, ib, t], \
#             QE_path[:, :, :, :, :, ib, t], \
#             QUE_path[:, :, :, ib, t], \
#             QEE_path[:, :, :, :, :, :, ib, t] = QUtmp / nB, QEtmp / nB, QUEtmp / nB, QEEtmp / nB


#     Earnings = np.sum(np.sum(QE_path, axis=(0,1,3,4,5)) * par['w_grid'][:, np.newaxis], axis=0)[:-1] / np.sum(QE_path, axis=(0, 1, 2, 3, 4, 5))[:-1]
#     pdist = np.sum(QE_path, axis=(0,1,2,4,5))

#     # Computing earnings by wealths
#     EarningsL = np.zeros(TT)
#     EarningsH = np.zeros(TT)
#     AL = np.zeros(TT)
#     AH = np.zeros(TT)
#     EEL = np.zeros(TT)
#     EEH = np.zeros(TT)
#     EUL = np.zeros(TT)
#     EUH = np.zeros(TT)
#     Y = np.zeros(TT)
#     uL = np.zeros(TT)   # unemployment rate for Low-wealth workers
#     uH = np.zeros(TT)   # unemployment rate for High-wealth workers
#     tenuresL = np.zeros((TT, par['nT']))
#     tenuresH = np.zeros((TT, par['nT']))
#     for t in range(TT):
#         # find median index
#         # Qt = np.sum(QE_path[:, :, :, :, :, :, t], axis=(0, 2, 3, 4, 5)) + np.sum(QU_path[:, :, :, t], axis=(0, 2))
#         Qt = np.sum(QE_path[:, :, :, :, :, :, t], axis=(0, 2, 3, 4, 5))
#         xi, xpi = utils.simple_interpolation(0.5 * np.sum(Qt), np.cumsum(Qt))
#         assert np.abs(np.sum(Qt[:xi+1]) + (1 - xpi) * Qt[xi+1] - (np.sum(Qt[xi+2:]) + xpi * Qt[xi+1])< 1e-6), 'Threshold does not hold up'
#         QEL = np.copy(QE_path[:, :xi + 2, :, :, :, :, t])
#         QEL[:, -1, :, :, :, :] = QE_path[:, xi + 1, :, :, :, :, t] * (1 - xpi)
#         QEH = np.copy(QE_path[:, xi + 1:, :, :, :, :, t])
#         QEH[:, 0, :, :, :, :] = QE_path[:, xi + 1, :, :, :, :, t] * xpi
#         assert np.abs(np.sum(QEL) + np.sum(QEH) - np.sum(QE_path[:, :, :, :, :, :, t])) < 1e-6, 'Threshold does not hold up'
#         QEEL = np.copy(QEE_path[:, :xi + 2, :, :, :, :, :, t])
#         QEEL[:, -1, :, :, :, :] = QEE_path[:, xi + 1, :, :, :, :, :, t] * (1 - xpi)
#         QEEH = np.copy(QEE_path[:, xi + 1:, :, :, :, :, :, t])
#         QEEH[:, 0, :, :, :, :] = QEE_path[:, xi + 1, :, :, :, :, :, t] * xpi
#         tenuresL[t, :] = np.sum(QEL, axis=(0,1,2,3,5)) / np.sum(QEL)
#         tenuresH[t, :] = np.sum(QEH, axis=(0, 1, 2, 3, 5)) / np.sum(QEH)

#         # Unemployment rate
#         QUL = np.copy(QU_path[:, :xi + 2, :, t])
#         QUL[:, -1, :] = QU_path[:, xi + 1, :, t] * (1 - xpi)
#         uL[t] = np.sum(QUL) / (np.sum(QUL) + np.sum(QEL))
#         QUH = np.copy(QU_path[:, xi + 1:, :, t])
#         QUH[:, 0, :] = QU_path[:, xi + 1, :, t] * xpi
#         uH[t] = np.sum(QUH) / (np.sum(QUH) + np.sum(QEH))        

#         # Earnings by wealth
#         EarningsL[t] = np.sum(np.sum(QEL, axis=(0, 1, 3, 4, 5)) * par['w_grid']) / np.sum(QEL)
#         EarningsH[t] = np.sum(np.sum(QEH, axis=(0, 1, 3, 4, 5)) * par['w_grid']) / np.sum(QEH)
#         # Wealth for each group
#         AL[t] = np.sum(np.sum(QEL, axis=(0, 2, 3, 4, 5)) * par['a_grid'][:xi+2])
#         AH[t] = np.sum(np.sum(QEH, axis=(0, 2, 3, 4, 5)) * par['a_grid'][xi+1:])

#         # Job-switching by wealth
#         qL = np.copy(qs_path[:, :xi + 2, :, :, :, :, :, t])
#         qL[:, -1, :, :, :, :] = qs_path[:, xi + 1, :, :, :, :, :, t] * (1 - xpi)
#         qH = np.copy(qs_path[:, xi + 1:, :, :, :, :, :, t])
#         qH[:, 0, :, :, :, :] = qs_path[:, xi + 1, :, :, :, :, :, t] * xpi
#         # Job-switching
#         EEL[t] = np.sum(np.sum(QEEL * qL, axis=(0, 1, 2, 4, 5, 6))) / np.sum(QEL)
#         EEH[t] = np.sum(np.sum(QEEH * qH, axis=(0, 1, 2, 4, 5, 6))) / np.sum(QEH)
#         # Job-losing
#         sigmas = par['sigma']
#         # level shift in unemployment probability
#         sigmas = sigmas + (sigmaJ_path[t] - sigmas[-1])
#         # slope change in unemployment probability
#         sigmas = sigmas * (1 + sigmaslope_path[t])
#         EUL[t] = np.sum(np.sum(QEL, axis=(0, 1, 2, 3, 5)) * sigmas) / np.sum(QEL)
#         EUH[t] = np.sum(np.sum(QEH, axis=(0, 1, 2, 3, 5)) * sigmas) / np.sum(QEH)
#         # output
#         k_little = (rK_path[t] / (par['alpha'] * Z_path[t])) ** (1 / (par['alpha'] - 1))    # capital per effective unit of labor
#         effZ = par['z_grid'][:, np.newaxis, np.newaxis, np.newaxis, np.newaxis, np.newaxis] * \
#             par['p_grid'][np.newaxis, np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]
#         Y[t] = np.sum(Z_path[t] * effZ * utils.f(k_little, par) * QE_path[:, :, :, :, :, :, t])

#     # unemployment
#     U = np.sum(QU_path, axis=(0,1,2))[:-1]


#     return Y, Earnings, EarningsL, EarningsH, U, AL, AH, EEL, EEH, EUL, EUH, uL, uH, pdist