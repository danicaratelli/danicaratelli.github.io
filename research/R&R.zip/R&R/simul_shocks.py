# Simulate shocks
import numpy as np
#import tran_temp
import utils
import statsmodels.api as sm
import quantecon

def dsimul(Tgarbage, Tsim, rho_Z, rho_sigmaJ, SD_Z, SD_sigmaJ, corr_Z_sigmaJ, ss):
    # Job-finding rate shock
    Tall = Tsim + Tgarbage
    # draw from join-normal
    mean_eps = [0, 0]
    cov_Z_sigmaJ = corr_Z_sigmaJ * SD_Z * SD_sigmaJ
    cov_eps = [[SD_sigmaJ ** 2, cov_Z_sigmaJ], [cov_Z_sigmaJ, SD_Z ** 2]]  # diagonal covariance
    sim_eps = np.random.multivariate_normal(mean_eps, cov_eps, Tall)
    # get realizations
    sigmaJ_sim = np.zeros(Tall)
    sigmaJ_sim[0] = ss['sigmaJ']
    Zlog_sim = np.zeros(Tall)
    Zlog_sim[0] = np.log(ss['Z'])
    for t in range(Tall-1):
        sigmaJ_sim[t + 1] = ss['sigmaJ'] + rho_sigmaJ * (sigmaJ_sim[t] - ss['sigmaJ']) + sim_eps[t + 1][0]
        Zlog_sim[t + 1] = np.log(ss['Z']) + rho_Z * (Zlog_sim[t] - np.log(ss['Z'])) + sim_eps[t+1][1]
    Z_sim = np.exp(Zlog_sim)
    # making sure not to get negative separation probabilities
    sigmaJ_sim[sigmaJ_sim <= 0] = 0

    return Z_sim[Tgarbage:Tall], sigmaJ_sim[Tgarbage:Tall]


def SMM(G, SMMtargets, TT, Tsim, Tgarbage, ss, param_grid):

    def obj_fun(n_rho_Z, n_rho_sigmaJ, n_SD_Z, n_SD_sigmaJ, n_corr_Z_sigmaJ, param_grid):
        # Extracting values
        rho_Z = param_grid['rho_Z'][n_rho_Z]
        rho_sigmaJ = param_grid['rho_sigmaJ'][n_rho_sigmaJ]
        SD_Z = param_grid['SD_Z'][n_SD_Z]
        SD_sigmaJ = param_grid['SD_sigmaJ'][n_SD_sigmaJ]
        corr_Z_sigmaJ = param_grid['corr_sigmaJ_Z'][n_corr_Z_sigmaJ]

        #print((rho_Z, rho_sigmaJ, SD_Z, SD_sigmaJ, corr_Z_sigmaJ))
        # Simulate shocks
        Z_sim, sigmaJ_sim = dsimul(Tgarbage, TT * Tsim, rho_Z, rho_sigmaJ, SD_Z, SD_sigmaJ, corr_Z_sigmaJ, ss)
        #sigmaJ_sim = np.zeros(TT * Tsim)
        # creating deviations from SS
        dZ_sim = (Z_sim - ss['Z'])
        dZ_sim = np.reshape(dZ_sim, (Tsim, TT)).transpose()
        dsigmaJ_sim = (sigmaJ_sim - ss['sigmaJ'])
        dsigmaJ_sim = np.reshape(dsigmaJ_sim, (Tsim, TT)).transpose()

        # EE and EU rates in levels
        EE_path = np.ones((TT, Tsim)) * ss['EE_rate']
        EU_path = np.ones((TT, Tsim)) * ss['EU_rate']
        for it in range(Tsim):
            # define shock
            di = dict()
            di['Z'] = dZ_sim[:, it]
            di['sigmaJ'] = dsigmaJ_sim[:, it]
            # EE rate in levels
            EE_path[:, it] += (utils.level_IRF(G, 'EE_rate', ['Z', 'sigmaJ'], di, ss['EE_rate'], TT) - ss['EE_rate'])
            # EU rate in levels
            EU_path[:, it] += (utils.level_IRF(G, 'EU_rate', ['Z', 'sigmaJ'], di, ss['EU_rate'], TT) - ss['EU_rate'])

        # Standard Deviation
        EE_sd = np.mean(np.std(EE_path, axis=0))
        EU_sd = np.mean(np.std(EU_path, axis=0))
        # Persistence
        EE_ar = np.zeros(Tsim)
        EU_ar = np.zeros(Tsim)
        for t in range(Tsim):
            EE_ar[t] = sm.tsa.acf(EE_path[:, t])[1]
            EU_ar[t] = sm.tsa.acf(EU_path[:, t])[1]
        EE_ar = np.mean(EE_ar)
        EE_ar = - np.log(2) / np.log(EE_ar)
        EU_ar = np.mean(EU_ar)
        EU_ar = - np.log(2) / np.log(EU_ar)
        xres = np.sum((np.abs(np.array([EE_sd, EE_ar, EU_sd, EU_ar]) - SMMtargets)/SMMtargets) ** 2) ** (1/2)
        #print(xres)

        return xres

    # Grid Search
    N_rho_Z = len(param_grid['rho_Z'])
    N_rho_sigmaJ = len(param_grid['rho_sigmaJ'])
    N_SD_Z = len(param_grid['SD_Z'])
    N_SD_sigmaJ = len(param_grid['SD_sigmaJ'])
    N_corr_Z_sigmaJ = len(param_grid['corr_sigmaJ_Z'])
    Residuals = 1000*np.ones((N_rho_Z, N_rho_sigmaJ, N_SD_Z, N_SD_sigmaJ, N_corr_Z_sigmaJ))
    for n_rho_Z in range(N_rho_Z):
        for n_rho_sigmaJ in range(N_rho_sigmaJ):
            for n_SD_Z in range(N_SD_Z):
                for n_SD_sigmaJ in range(N_SD_sigmaJ):
                    for n_corr_Z_sigmaJ in range(N_corr_Z_sigmaJ):
                        Residuals[n_rho_Z, n_rho_sigmaJ, n_SD_Z, n_SD_sigmaJ, n_corr_Z_sigmaJ] = obj_fun(n_rho_Z, n_rho_sigmaJ, n_SD_Z, n_SD_sigmaJ, n_corr_Z_sigmaJ, param_grid)


    return xstar

def HHsimul(ra_path, z_path, n_path, transfer_path, lambdaU_path, ss, par):

    # extract parameters
    nA, nP, nZ, nT, nB = par['nA'], par['nP'], par['nZ'], par['nT'], par['nB']

    # length of simulation
    TT = ra_path.shape[0]

    # adjust ra_path and lambdaU_path to include ex-post interest rate
    ra_path = np.append(ra_path, ss['r'])
    lambdaU_path = np.append(lambdaU_path, ss['lambdaU'])

    # Initiate matrices
    CUTs = np.zeros((nZ, nA, nB, TT + 1));
    CUTs[:, :, :, -1] = np.copy(ss['CUss'])
    CETs = np.zeros((nZ, nA, nP, nT, nB, TT + 1));
    CETs[:, :, :, :, :, -1] = np.copy(ss['CEss'])
    UTs = np.zeros((nZ, nA, nB, TT + 1));
    UTs[:, :, :, -1] = np.copy(ss['Uss'])
    ETs = np.zeros((nZ, nA, nP, nT, nB, TT + 1));
    ETs[:, :, :, :, :, -1] = np.copy(ss['Ess'])
    AUTs = np.zeros((nZ, nA, nB, TT + 1));
    AUTs[:, :, :, -1] = np.copy(ss['AUss'])
    AETs = np.zeros((nZ, nA, nP, nT, nB, TT + 1));
    AETs[:, :, :, :, :, -1] = np.copy(ss['AEss'])
    qTs = np.zeros((nZ, nA, nP, nT, nB, TT + 1));
    qTs[:, :, :, :, :, -1] = np.copy(ss['qss'])

    beta_ss = par['beta']
    # Backward iteration: get policies
    for t in range(TT - 1, -1, -1):
        for ib in range(nB):
            par['beta'] = beta_ss + (ib - 1) * 0.013
            # input paths
            CUTs[:, :, ib, t], CETs[:, :, :, :, ib, t], \
            UTs[:, :, ib, t], ETs[:, :, :, :, ib, t], \
            AUTs[:, :, ib, t], AETs[:, :, :, :, ib, t], \
            qTs[:, :, :, :, ib, t] = tran_temp.backward_iterate(ra_path[t + 1], ra_path[t], n_path[t], z_path[t],
                                                              transfer_path[t], lambdaU_path[t + 1],
                                                              CUTs[:, :, ib, t + 1], CETs[:, :, :, :, ib, t + 1],
                                                              UTs[:, :, ib, t + 1], ETs[:, :, :, :, ib, t + 1], par)
    par['beta'] = beta_ss

    # Forward iteration: get distribution

    # Initialize distribution
    QUTs = np.zeros((nZ, nA, nB, TT + 1))
    QETs = np.zeros((nZ, nA, nP, nT, nB, TT + 1))
    QUTs[:, :, :, 0] = np.copy(ss['QUss'])
    QETs[:, :, :, :, :, 0] = np.copy(ss['QEss'])

    # Forward iteration: update distribution
    for t in range(1, TT + 1):
        for ib in range(nB):
            QUTs[:, :, ib, t], QETs[:, :, :, :, ib, t] = tran_temp.forward_iterate(QUTs[:, :, ib, t - 1],
                                                                                   QETs[:, :, :, :, ib, t - 1],
                                                                                   AUTs[:, :, ib, t - 1],
                                                                                   AETs[:, :, :, :, ib, t - 1],
                                                                                   qTs[:, :, :, :, ib, t - 1],
                                                                                   lambdaU_path[t - 1], par)

    return CUTs, CETs, UTs, ETs, AUTs, AETs, QUTs, QETs, qTs


def simul_moments(params, args):
    # Extract parameters
    rho_Z = params['rho_Z']
    rho_lambda = params['rho_lambda']
    sigma_Z = params['sigma_Z']
    sigma_lambda = params['sigma_lambda']
    corr_lambda_Z = params['corr_lambda_Z']
    sigma_lambdaZ = corr_lambda_Z * (sigma_Z ** 0.5) * (sigma_lambda ** 0.5)
    # check var-covar matrix
    cov_eps = [[sigma_lambda, sigma_lambdaZ], [sigma_lambdaZ, sigma_Z]]
    if np.all(np.linalg.eigvals(cov_eps) > 0):
        G, Tgarbage, Tsim, TT, SMMtargets, ss, par = args
        # Simulate shocks
        Z_sim, lambdaU_sim = dsimul(Tgarbage, TT * Tsim, rho_Z, rho_lambda, sigma_Z, sigma_lambda, sigma_lambdaZ,
                                    ss['Z'], par['lambdaU'])
        # creating deviations from SS
        dZ_sim = (Z_sim - ss['Z']) / ss['Z']
        dZ_sim = np.reshape(dZ_sim, (Tsim, TT)).transpose()
        dlambdaU_sim = (lambdaU_sim - par['lambdaU'])
        dlambdaU_sim = np.reshape(dlambdaU_sim, (Tsim, TT)).transpose()

        # EE rate
        EE_path = ss['EE_rate'] + (G['EE_rate']['Z'] @ dZ_sim + G['EE_rate']['lambdaU'] @ dlambdaU_sim)
        EE_path = list(map(lambda x: (quantecon.filter.hamilton_filter(100 * EE_path[:, x], 8)[0][9:-1]), range(Tsim)))
        EE_path = np.vstack(EE_path).transpose()
        # EU rate
        EU_path = ss['EU_rate'] + (G['EU_rate']['Z'] @ dZ_sim + G['EU_rate']['lambdaU'] @ dlambdaU_sim)
        EU_path = list(map(lambda x: (quantecon.filter.hamilton_filter(100 * EU_path[:, x], 8)[0][9:-1]), range(Tsim)))
        EU_path = np.vstack(EU_path).transpose()
        # Standard Deviation
        EE_sd = np.mean(np.std(EE_path, axis=0))
        EU_sd = np.mean(np.std(EU_path, axis=0))
        # Persistence
        EE_ar = np.zeros(Tsim)
        EU_ar = np.zeros(Tsim)
        for t in range(Tsim):
            EE_ar[t] = sm.tsa.acf(EE_path[:, t])[1]
            EU_ar[t] = sm.tsa.acf(EU_path[:, t])[1]
        EE_ar = np.mean(EE_ar)
        EE_ar = - 3 * np.log(2) / np.log(EE_ar)
        EU_ar = np.mean(EU_ar)
        EU_ar = - 3 * np.log(2) / np.log(EU_ar)
    else:
        EE_sd = np.inf
        EE_ar = np.inf
        EU_sd = np.inf
        EU_ar = np.inf

    return EE_sd, EE_ar, EU_sd, EU_ar

def obj_fun(params, args):

    # get moments
    EE_sd, EE_ar, EU_sd, EU_ar = simul_moments(params, args)
    G, Tgarbage, Tsim, TT, SMMtargets, ss, par = args

    # return RMSE
    #xres = np.mean((np.abs(np.array([EE_sd, EE_ar, EU_sd, EU_ar]) - SMMtargets) / SMMtargets) ** 2) ** (1 / 2)
    xres = np.mean((np.abs(np.array([EE_sd, EE_ar]) - SMMtargets) / SMMtargets) ** 2) ** (1 / 2)

    return xres