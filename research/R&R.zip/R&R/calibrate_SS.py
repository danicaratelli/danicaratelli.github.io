import os
import numpy as np
import load_params_SS as load_params
import solveSS_AOB_new as solveSS_AOB
import Jac
import pickle
import pandas as pd
import utils
import sys
import time
import multiprocessing as mp
import itertools
from filelock import FileLock
import wealth_lorenz

# Options
i_ss = True # if want to estimate SS
i_naive = False # if want to solve naive SS
ss_tol = 1e-4 # calibration-screening tolerance; use 1e-5 later for final refinement
# input_index = 9
OUTPATH = "results"
main_run = True
SS_OUTPUT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ss_calibration.pkl")

# Grids
z_grid = np.array([-0.6414269805898185])
Pi_grid = np.array([0.85])
zeta_grid = np.array([1.1])
poly1_grid = np.array([0.09])
poly2_grid = np.array([0.0320758466])
poly3_grid = np.array([-0.0229250279])
poly4_grid = np.array([0.0036])
s_grid = np.array([1/3])
sigma0_grid = np.array([0.01998]) #EU probability
bdeta_grid = np.array([0.012])
chi_grid = np.array([0.19333333])
bUI_grid = np.array([0.225])

inputs = []
for vals in itertools.product(*[z_grid, Pi_grid, zeta_grid, poly1_grid, poly2_grid, poly3_grid, poly4_grid, s_grid, sigma0_grid, bdeta_grid, chi_grid, bUI_grid]):
    inputs.append(dict(zip(['zlow', 'Pi11', 'zeta', 'poly1', 'poly2', 'poly3', 'poly4', 's', 'sigma0', 'dbeta', 'chi', 'bUI'], vals)))
    inputs[len(inputs) - 1]['index'] = len(inputs) - 1

inputs = inputs[:2]

# targets
targets = np.array([0.12,       # UI_to_GDI
                    0.440679,   # job-finding prob
                    0.0495,     # unemploymenyt rate
                    0.0297,     # job-switching probability
                    -1.04,      # Q1 of wealth Lorenz
                    0.68,       # Q2 of wealth Lorenz
                    6.85,       # Q3 of wealth Lorenz
                    18.21,      # Q4 of wealth Lorenz
                    75.3])      # Q5 of wealth Lorenz
# weights

def mp_worker(input, inaive=False, main_run=main_run):
    smm_index = input['index']
    # Output path
    outpath = os.path.join(OUTPATH, f"result_par{smm_index}.csv")

    if os.path.exists(outpath) and not main_run:
        print(f"Output already exists for index {smm_index}: {outpath}")
        return smm_index, True

    # Load Parameters
    par = load_params.get_par(input)
    par['verbose_ss'] = True
    par['jac_init'] = 'identity'    
    # Set initial guess. The parameters listed solve for steady state. Because this takes ~90 minutes or more from a less educated guess, I list them here as the starting point so solving for steady state is quick.
    # r = 0.00355965416165203	
    # tax = -0.230163180807812
    # thetas = np.array([12.2336004885791, 0.418958899286918, 0.159046597490858, 0.0575880251549376, 0.0760460830997304, 0.833158884520071, 1.73323529712332, 5.51393496582616])
    # r       = 0.003930784789
    # tax     = -0.5675786466
    # thetas  = np.array([12.7736961, 0.2393976084, 0.08502900122, 0.03150098586, 0.2952975645, 2.616265282, 1.593719797, 6.660261413])
    r = 0.00400893452379362
    tax = -0.536164576107426
    thetas = np.array([12.9842258652721, 0.222531844880482, 0.0743124182356609, 0.0282348718727836, 0.278765459598922, 2.60888208845328, 1.5966271457106, 6.58345172958278])

    xguess = np.append(np.array([r, tax]), thetas)

    # ------ START SAMPLE SOLVE (TO DELETE)------
    start = time.time()
    # Solve model
    print('Solving steady state with tol = {}'.format(ss_tol))
    try: 
        r_ss, tax_ss, thetas_ss, ss = solveSS_AOB.SS(
            xguess, par['Z'], par, smm_index, ss_tol,
            save_results=main_run,
        )
        end_time = time.time()

        if main_run:
            with open(SS_OUTPUT_PATH, "wb") as f:
                pickle.dump(ss, f)

        # Compute moments
        SS_moments = solveSS_AOB.getSS_moments(r_ss, tax_ss, thetas_ss, par['Z'], par, smm_index)

        # Build output row as a DataFrame with headers
        row = {}
        # include input parameters
        for k, v in input.items():
            row[k] = v

        # add solution values
        row['r'] = r_ss
        row['tax'] = tax_ss
        # thetas -> theta1..theta8
        thetas_arr = np.asarray(thetas_ss).ravel()
        for i, val in enumerate(thetas_arr, start=1):
            row[f'theta{i}'] = val

        # add end_time (minutes)
        row['end_time'] = (end_time - start) / 60

        # target moments to include from SS_moments
        moment_names = ['UI_to_income_L', 'UI_to_income_H', 
                        'job_finding', 'urate', 'EE_rate', 'Q1', 'Q2', 'Q3', 'Q4', 'Q5']
        # if SS_moments is a dict, extract by name; if array-like, assume same order
        for name in moment_names:
            row[name] = SS_moments.get(name, np.nan)                                                        

        pd.DataFrame([row]).to_csv(outpath, index=False)


        return smm_index, True
    except Exception as e:
        end_time = time.time()
        print('Failed to solve steady state.')
        print(f"Error: {e}")
        return smm_index, False


# Run in parallel
if __name__ == '__main__':
    n_total = len(inputs)
    if main_run and n_total != 1:
        raise ValueError("main_run=True requires exactly one parameter combination.")
    n_workers = min(mp.cpu_count(), n_total)
    print(f"Running {n_total} parameter combinations with {n_workers} workers.")
    if n_workers == 1:
        results = [mp_worker(inp) for inp in inputs]
        for idx, (n, ok) in enumerate(results, start=1):
            status = "OK" if ok else "FAILED"
            print(f"Completed {idx}/{n_total} (Seq {n}): {status}")
    else:        
        with mp.Pool(processes=n_workers) as pool:
            for idx, (n, ok) in enumerate(pool.imap_unordered(mp_worker, inputs), start=1):
                status = "OK" if ok else "FAILED"
                print(f"Completed {idx}/{n_total} (Par {n}): {status}")



# #                   DATA        MODEL
# targets = np.array([0.12,       0.1376              # UI_to_GDI
#                     0.440679,   0.4544              # job-finding prob
#                     0.0495,     0.0487              # unemploymenyt rate
#                     0.0297,     0.02956             # job-switching probability
#                     -1.04,      0.56                # Q1 of wealth Lorenz
#                     0.68,       4.01                # Q2 of wealth Lorenz
#                     6.85,       8.25                # Q3 of wealth Lorenz
#                     18.21,      15.28               # Q4 of wealth Lorenz
#                     75.3])      71.89               # Q5 of wealth Lorenz
