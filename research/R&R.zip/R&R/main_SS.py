import os
import numpy as np
import load_params_SS as load_params
import solveSS_AOB
import Jac
import pickle
import pandas as pd
import utils
import sys
import time
import multiprocessing as mp
import itertools
from filelock import FileLock
import wealth_lorenz

# Options
i_ss = True # if want to estimate SS
i_naive = False # if want to solve naive SS

# start = time.time()

# ------ START SAMPLE SOLVE (TO DELETE)------
start = time.time()
# Solve model
r_ss, tax_ss, thetas_ss = solveSS_AOB.SS(xguess, par['Z'], par, smm_index, 1e-7)
# Try #2 ~19.48 hours
# r_ss = 0.00405907322544432
# tax_ss = -0.172574662243902
# thetas_ss = np.array([18.2242931092867	0.082348235663596	0.372087743500644	0.0321582023517724	0.0473004889968181	0.998978067860064	2.11424478029277	4.9849249296017])
# Try #1 ~19 hours
# r_ss = 0.004059073225444317
# tax_ss = -0.17257466224390183
# thetas_ss = np.array([18.22429311,  0.08234824,  0.37208774,  0.0321582 ,  0.04730049, 0.99897807,  2.11424478,  4.98492493])
end_time = time.time()
test_results = np.concatenate((
    [r_ss, tax_ss],
    np.asarray(thetas_ss).ravel(),
    [(end_time - start) / 60],
))
pd.DataFrame([test_results]).to_csv('test_results.csv', index=False, header=False)

print('Time to solve model: {} min'.format(round((end_time - start) / 60, 2)))
# ------ END SAMPLE SOLVE ------

# Function to run model on different input vals in parallel
def mp_worker(input, inaive=False):
    # Load Parameters
    par = load_params.get_par(input)
    smm_index = input['index']
    # Set initial guess. The parameters listed solve for steady state. Because this takes ~90 minutes or more from a less educated guess, I list them here as the starting point so solving for steady state is quick.
    r = 0.002278244304438834   
    tax = -0.2902829273871056
    thetas = np.array([15.001011471099025, 0.171313592775733, 0.38304462748202056, 0.07032688363741249, 0.09508545407551863, 1.3493827872088155, 1.736562930225245, 5.877709860593139])
    xguess = np.append(np.array([r, tax]), thetas)

    # Try running model and output results, catch any errors
    try:
        # Solve model
        r_ss, tax_ss, thetas_ss = solveSS_AOB.SS(xguess, par['Z'], par, smm_index, 1e-7)
        # SS info in dictionary
        ss = solveSS_AOB.getSS(r_ss, tax_ss, thetas_ss, par['Z'], par, smm_index, transfer=0)
        # Matching elasticity
        import Elasticity_estimate as elasticity
        nQ = 11
        Coeffs, SDs, Coeffs_p, SDs_p = elasticity.runReg(ss, 500000, 48, nQ, par)
        # Include elasticity estimates in "ss" dictionary
        ss['elasticity'] = Coeffs
        ss['elasticity_sd'] = SDs
        ss['elasticity_p'] = Coeffs_p
        ss['elasticity_sd_p'] = SDs_p
        ss['index'] = input['index']
        # Compute moments to match
        ss['urate'] = np.sum(ss['QUss'])                                                    # UI to GDI
        ss['UI_to_GDI'] = ss['urate'] * (1 - ss['tax']) * par['bUI'] / ss['earnings']       # unemployment rate
        ss['job_finding'] = ss['lambda0']
        # Lorenz
        Lz_networth, Lz_model, Lorenz_diff = wealth_lorenz.get_wealth_dist(ss, par)        
        Qs = np.diff(Lz_model)
        ss['Q1'] = Qs[0]
        ss['Q2'] = Qs[1]
        ss['Q3'] = Qs[2]
        ss['Q4'] = Qs[3]
        ss['Q5'] = Qs[4]
        # Inputs
        ss['inputs'] = input

        return ss
    except ValueError:
        return input['index']


if i_ss:
    # Grids
    z_grid = np.array([-0.6414269805898185])
    Pi_grid = np.array([0.85])
    zeta_grid = np.array([1.1])
    p1_grid = np.array([-0.4])
    p2_grid = np.array([-0.30])
    p3_grid = np.array([-0.10])
    p4_grid = np.array([0.0])
    p5_grid = np.array([0.10])
    p6_grid = np.array([0.25])
    p7_grid = np.array([1.1])
    p8_grid = np.array([2.2])
    s_grid = np.array([0.32, 0.33, 0.35, 0.36, 0.38])
    sigma0_grid = np.array([0.028, 0.029])
    bdeta_grid = np.array([0.012])
    chi_grid = np.array([0.20, 0.21, 0.22]) #0.23

    inputs = []
    for vals in itertools.product(*[z_grid, Pi_grid, zeta_grid, p1_grid, p2_grid, p3_grid, p4_grid, p5_grid, p6_grid, p7_grid, p8_grid, s_grid, sigma0_grid, bdeta_grid, chi_grid]):
        inputs.append(dict(zip(['zlow', 'Pi11', 'zeta', 'p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 's', 'sigma0', 'dbeta', 'chi'], vals)))
        inputs[len(inputs) - 1]['index'] = len(inputs) - 1

    # targets
    targets = np.array([0.004,  # UI_to_GDI
                        0.56,   # job-finding prob
                        0.06,   # unemploymenyt rate
                        0.041,  # job-switching probability
                        -1.04,  # Q1 of wealth Lorenz
                        0.68,   # Q2 of wealth Lorenz
                        6.85,   # Q3 of wealth Lorenz
                        18.21,  # Q4 of wealth Lorenz
                        75.3])  # Q5 of wealth Lorenz
    # weights
    wgts = np.array([1, 1, 1, 2, 0.7, 0.7, 0.4, 0.1, 0.1])
    # wgts = np.ones(len(targets))

    # collect sbatch arguments for input/output IDs
    id = int(sys.argv[1])
    job = int(sys.argv[2])
    tasks = int(sys.argv[3])
    versions = len(inputs)

    # Subset inputs to portion to be run on this node
    subset = [inputs[i] for i in range(versions) if i % tasks == id - 1]



    # Run each model on each input set in parallel and save outputs
    p = mp.Pool(mp.cpu_count())
    for result in p.imap(mp_worker, subset):
        # Write outputs to pickle if model succeeds
        if isinstance(result, dict):
            print('Model {i} succeeded at {t} min'.format(i = result['index'], t = round((time.time() - start) / 60, 2)))
            with FileLock('ss_SMM/job{j}_n{i}.pkl.lock'.format(j = job, i = result['index'])):
                with open('ss_SMM/job{j}_n{i}.pkl'.format(j = job, i = result['index']), 'wb') as f:
                    pickle.dump(result, f)
        else:
            print('Model {i} failed at {t} min'.format(i = result, t = round((time.time() - start) / 60, 2)))

    print('Total time: {} min'.format(round((time.time() - start) / 60, 2)))


    # Load SS
    all_files = os.listdir("ss_SMM")
    pkl_files = [f for f in all_files if f.endswith('.pkl')]
    # sbset = ['5', '6', '9', '14', '25', '26', '32', '35']
    # pkl_files = [item for item in pkl_files if any(f'n{x}' in item for x in sbset)]
    pkl_files = np.sort(pkl_files)
    Resids = np.zeros(len(pkl_files))
    import matplotlib.pyplot as plt
    fi = 0
    for file in pkl_files:
        print(" **** File: " + file + " **** ")
        with open("ss_SMM//" + file, 'rb') as file:
            d0 = pickle.load(file)
        print(d0['residuals'])
        # Check targets moments
        print("Targeted moments:        Data            Model\n")
        print("UI/GDI:                  " + str(targets[0]) + "           " + str(round(d0['UI_to_GDI'], 4)))
        print("job-finding:             " + str(targets[1]) + "           " + str(round(d0['job_finding'], 4)))
        print("u rate:                  " + str(targets[2]) + "           " + str(round(d0['urate'], 4)))
        print("EE:                      " + str(targets[3]) + "           " + str(round(d0['EE_rate'], 4)))
        print("Lorenz Q1:               " + str(targets[4]) + "           " + str(round(100 * d0['Q1'], 2)))
        print("Lorenz Q2:               " + str(targets[5]) + "           " + str(round(100 * d0['Q2'], 2)))
        print("Lorenz Q3:               " + str(targets[6]) + "           " + str(round(100 * d0['Q3'], 2)))
        print("Lorenz Q4:               " + str(targets[7]) + "           " + str(round(100 * d0['Q4'], 2)))
        print("Lorenz Q5:               " + str(targets[8]) + "           " + str(round(100 * d0['Q5'], 2)))
        print("Inputs:                  ")
        print(d0['inputs'])
        print("\n")    
        plt.figure()
        plt.plot(d0['elasticity'])
        plt.plot(d0['elasticity_p'])
        plt.title(file)
        print("Max asset policy = " + str(np.max((d0['QEss'] > 0) * d0['AEss'])))
        print("\n\n")
        # plt.figure()
        # plt.plot(d0['qss'][0, :, :, 0, -1, 1, 0])
        # plt.twinx()
        # plt.plot(np.sum(d0['QEss'], axis=(0,2,3,4,5)))

        # save residuals
        data_mom = np.array([d0['UI_to_GDI'], d0['job_finding'], d0['urate'], d0['EE_rate'], 100 * d0['Q1'], 100 * d0['Q2'], 100 * d0['Q3'], 100 * d0['Q4'], 100 * d0['Q5']])
        Resids[fi] = np.sum(wgts * np.abs(targets - data_mom) / targets)
        fi += 1

    calibration = pkl_files[np.where(Resids == np.min(Resids))[0][0]]

# print(calibration)
calibration = 'job109_n26.pkl'
with open("ss_SMM/" + calibration, 'rb') as file:
    ss = pickle.load(file)

if i_ss:
    with open('ss_calibration.pkl', 'wb') as f:
        pickle.dump(ss, f)

if i_naive:
    # Solve for naive model with flat probability of separation
    par_ss = load_params.get_par(ss['inputs'])
    # compute average separation probability
    sigma_mean = np.sum((np.sum(ss['QEss'], axis=(0,1,2,3,5)) / np.sum(ss['QEss'])) * par_ss['sigma'])
    inputs_naive = ss['inputs']
    inputs_naive['sigma0'] = sigma_mean
    par_naive = load_params.get_par(inputs_naive, inaive=i_naive)

    # Naive steady state
    ss_naive = mp_worker(inputs_naive, inaive=i_naive)

    with open('ss_naive.pkl', 'wb') as f:
        pickle.dump(ss_naive, f)
