import sys
sys.path.append("sequence-jacobian")

import utils
from graphviz import Digraph
from ypstruct import struct

"""
DAG Graph routine
Requires installing graphviz package and executables
https://www.graphviz.org/

On a mac this can be done as follows:
1) Download macports at:
https://www.macports.org/install.php
2) On the command line, install graphviz with macports by typing
sudo port install graphviz

"""

# Enhanced block sort
def block_sort_enhanced(block_list, findrequired=False, givedep=False, giveio=False):
    """Given list of blocks (either blocks themselves or dicts of Jacobians), find a topological sort and also
    optionally return which outputs must be computed as inputs of later blocks.
    
    Relies on blocks having 'inputs' and 'outputs' attributes (unless they are dicts of Jacobians, in which case it's
    inferred) that indicate their aggregate inputs and outputs"""

    # step 1: map outputs to blocks for topological sort
    outmap = dict()
    outset = set()
    
    for num, block in enumerate(block_list):
        if hasattr(block, 'outputs'):
            outputs = block.outputs
        elif isinstance(block, dict):
            outputs = block.keys()
        else:
            raise ValueError(f'{block} is not recognized as block or does not provide outputs')

        for o in outputs:
            if o in outmap:
                raise ValueError(f'{o} is output twice')
            outmap[o] = num
            if giveio:
                outset.add(o)

    # step 2: dependency graph for topological sort and input list
    dep = {num: set() for num in range(len(block_list))}
    inset = set()
    if findrequired:
        required = set()
    for num, block in enumerate(block_list):
        if hasattr(block, 'inputs'):
            inputs = block.inputs
        else:
            inputs = set(i for o in block for i in block[o])

        for i in inputs:
            if giveio:
                inset.add(i)
            if i in outmap:
                dep[num].add(outmap[i])
                if findrequired:
                    required.add(i)

    if givedep: 
        if findrequired: 
            if giveio:
                return dep, required, inset, outset
            else:
                return dep, inset, outset
        else:
            return dep
    elif findrequired:
            if giveio:
                 return utils.topological_sort(dep), required, inset, outset
            else:
                 return utils.topological_sort(dep), required
    else:
        return utils.topological_sort(dep)
    
def blockify(blck):
    blck_out = struct()
    # inputs
    blck_out.outputs = set(list(blck.keys()))
    # outputs
    blck_out.inputs = set(list(blck[list(blck.keys())[0]]))

    return blck_out


def drawdag(block_list, exogenous=[], unknowns=[], targets=[], showdag=False, debug=False, leftright=False, filename='modeldag'):
    '''
    Routine that draws DAG
    :param block_list: list of blocks to be represented
    :param exogenous: (optional) exogenous variables, to be represented on DAG
    :param unknowns:  (optional) unknown variables, to be represented on DAG
    :param unknowns:  (optional) target variables, to be represented on DAG
    :bool showdag: if True, export and plot pdf file. If false, export png file and do not plot
    :bool debug: if True, returns list of candidate unknown and targets
    :bool leftright: if True, plots dag from left to right instead of top to bottom
    :return: none
    '''

    # obtain the topological sort
    topsorted = block_sort_enhanced(block_list)
    # get sorted list of blocks
    block_list_sorted = [block_list[i] for i in topsorted]
    # Obtain the dependency list of the sorted set of blocks
    dep_list_sorted = block_sort_enhanced(block_list_sorted, givedep=True)
   
    # Draw DAG
    dot = Digraph(comment='Model DAG')

    # Make left-to-right
    if leftright:
        dot.attr(rankdir='LR', ratio='compress', center='true')
    else:
        dot.attr(ratio='auto', center='true')
    
    # add initial nodes (one for exogenous, one for unknowns) provided those are not empty lists
    if exogenous:
        dot.node('exog', 'exogenous', shape='box')
    if unknowns:
        dot.node('unknowns', 'unknowns', shape='box')
    if targets:
        dot.node('targets', 'targets', shape='diamond')
        
    # add nodes sequentially in order
    for i in dep_list_sorted:
        # Hand-inputted blocks
        if (type(block_list_sorted[i]).__name__ != "SimpleBlock") & (type(block_list_sorted[i]).__name__ != "SolvedBlock"):
            blocki = blockify(block_list_sorted[i])
        else:
            blocki = block_list_sorted[i]

        if hasattr(blocki, 'hetinput'):
            # HA block
            dot.node(str(i), 'HA [' + str(i) + ']')
        elif hasattr(blocki, 'block_list'):
            # Solved block
            dot.node(str(i), blocki.block_list[0].f.__name__ + '[solved,' + str(i) + ']')
        else:
            if type(blocki).__name__ == "SimpleBlock": # Simple block
                dot.node(str(i), blocki.f.__name__ + ' [' + str(i) + ']')
            else:   # Hand-made block
                dot.node(str(i), "HA" + ' [' + str(i) + ']')

        # nodes from exogenous to i (figure out if needed and draw)
        if exogenous:
            edgelabel = blocki.inputs & set(exogenous)
            if len(edgelabel) != 0:
                edgelabel_list = list(edgelabel)
                edgelabel_str = ', '.join(str(e) for e in edgelabel_list)
                dot.edge('exog', str(i), label=str(edgelabel_str))

        # nodes from unknowns to i (figure out if needed and draw)
        if unknowns:
            edgelabel = blocki.inputs & set(unknowns)
            if len(edgelabel) != 0:
                edgelabel_list = list(edgelabel)
                edgelabel_str = ', '.join(str(e) for e in edgelabel_list)
                dot.edge('unknowns', str(i), label=str(edgelabel_str))
        
        #  nodes from i to final targets
        for target in targets:
            if target in blocki.outputs:
                dot.edge(str(i), 'targets', label=target)
                    
        # nodes from any interior block to i
        for j in dep_list_sorted[i]:
            if (type(block_list_sorted[j]).__name__ != "SimpleBlock") & (type(block_list_sorted[j]).__name__ != "SolvedBlock"):
                blockj = blockify(block_list_sorted[j])
            else:
                blockj = block_list_sorted[j]
            # figure out inputs of i that are also outputs of j
            edgelabel = blocki.inputs & blockj.outputs
            edgelabel_list = list(edgelabel)
            edgelabel_str = ', '.join(str(e) for e in edgelabel_list)

            # draw edge from j to i
            dot.edge(str(j), str(i), label=str(edgelabel_str))

    if showdag:
        dot.render('export_DAG/' + filename, view=True, cleanup=True)
    else:
        dot.render('export_DAG/' + filename, format='png', cleanup=True)
        #print(dot.source)

    if debug:
        dep, required, inputs, outputs = block_sort_enhanced(block_list_sorted, findrequired=True, givedep=False, giveio=True)
        # Candidate targets: outputs that are not inputs to any block
        print("Candidate targets :")
        cand_targets=outputs.difference(required)
        print(cand_targets)
        # Candidate exogenous and unknowns (also includes parameters)
        # inputs that are not outputs of any block
        print("Candidate exogenous/unknowns :")
        cand_xu=inputs.difference(required)
        print(cand_xu)


def drawsolved(solvedblock, filename='solveddag'):
    # Inspects a solved block by drawing its DAG
    drawdag([solvedblock.block_list[0]], unknowns=solvedblock.unknowns, targets=solvedblock.targets, filename=filename, showdag=True)

def inspectsolved(block_list):
    # Inspects all the solved blocks by running through each and drawing its DAG in turn
    for block in block_list:
        if hasattr(block, 'block_list'):
            drawsolved(block, filename=str(block.block_list[0].f.__name__))