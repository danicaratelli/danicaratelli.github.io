import operator

import numpy as np
from scipy.stats import norm
from numba import njit, guvectorize
from numba.typed import List
import scipy.linalg
import re
import inspect
from math import isclose


def interp2grid(a_next, par, V_next, c_next = 0):
    i, pi = interpolate_coord(a_next, par['a_grid'])
    V_new = apply_coord(i, pi, V_next)
    if np.any(c_next) != 0:
        c_new = apply_coord(i, pi, c_next)
        return V_new, c_new
    else:
        return V_new

'''Part 1: Efficient linear interpolation exploiting monotonicity.

    Interpolates increasing query points xq against increasing data points x.

    - interpolate_y: (x, xq, y) -> yq
        get interpolated values of yq at xq

    - interpolate_coord: (x, xq) -> (xqi, xqpi)
        get representation xqi, xqpi of xq interpolated against x
        xq = xqpi * x[xqi] + (1-xqpi) * x[xqi+1]

    - apply_coord: (xqi, xqpi, y) -> yq
        use representation xqi, xqpi to get yq at xq
        yq = xqpi * y[xqi] + (1-xqpi) * y[xqi+1]

    Composing interpolate_coord and apply_coord gives interpolate_y.

    All three functions are written for vectors but can be broadcast to other dimensions
    since we use Numba's guvectorize decorator. In these cases, interpolation is always
    done on the final dimension.
'''


@guvectorize(['void(float64[:], float64[:], float64[:], float64[:])'], '(n),(nq),(n)->(nq)')
def interpolate_y(x, xq, y, yq):
    """Efficient linear interpolation exploiting monotonicity.

    Complexity O(n+nq), so most efficient when x and xq have comparable number of points.
    Extrapolates linearly when xq out of domain of x.

    Parameters
    ----------
    x  : array (n), ascending data points
    xq : array (nq), ascending query points
    y  : array (n), data points

    Returns
    ----------
    yq : array (nq), interpolated points
    """
    nxq, nx = xq.shape[0], x.shape[0]

    xi = 0
    x_low = x[0]
    x_high = x[1]
    for xqi_cur in range(nxq):
        xq_cur = xq[xqi_cur]
        while xi < nx - 2:
            if x_high >= xq_cur:
                break
            xi += 1
            x_low = x_high
            x_high = x[xi + 1]

        xqpi_cur = (x_high - xq_cur) / (x_high - x_low)
        yq[xqi_cur] = xqpi_cur * y[xi] + (1 - xqpi_cur) * y[xi + 1]


@guvectorize(['void(float64[:], float64[:], uint32[:], float64[:])'], '(n),(nq)->(nq),(nq)')
def interpolate_coord_original(x, xq, xqi, xqpi):
    """Get representation xqi, xqpi of xq interpolated against x:
    xq = xqpi * x[xqi] + (1-xqpi) * x[xqi+1]

    Parameters
    ----------
    x    : array (n), ascending data points
    xq   : array (nq), ascending query points

    Returns
    ----------
    xqi  : array (nq), indices of lower bracketing gridpoints
    xqpi : array (nq), weights on lower bracketing gridpoints
    """
    nxq, nx = xq.shape[0], x.shape[0]

    # interpolation
    xi = 0
    x_low = x[0]
    x_high = x[1]
    for xqi_cur in range(nxq):
        xq_cur = xq[xqi_cur]
        while xi < nx - 2:
            if x_high >= xq_cur:
                break
            xi += 1
            x_low = x_high
            x_high = x[xi + 1]
            xqpi[xqi_cur] = (x_high - xq_cur) / (x_high - x_low)

        xqi[xqi_cur] = xi

@guvectorize(['void(float64[:], float64[:], uint32[:], float64[:])'], '(n),(nq)->(nq),(nq)')
def interpolate_coord(x, xq, xqi, xqpi):
    """
    Adapted from Adrien's notebook
    Efficient linear interpolation. xq = xqpi * x[xqi] + (1-xqpi) * x[xqia]
    x must be sorted, but xq does not have to be
    Parameters
    ----------
    x    : array (n), ascending data points
    xq   : array (nq), query points
    xqi  : array (nq), empty to be filled with indices of lower bracketing gridpoints
    xqpi : array (nq), empty to be filled with weights on lower bracketing gridpoints
    """

    # size of arrays
    nxq, nx = xq.shape[0], x.shape[0]
    # sort and keep track of initial order
    ind_new = np.argsort(xq)
    ind_init = np.argsort(ind_new)
    xq = xq[ind_new]
    # take care of values below and above minimum
    id = np.arange(nxq)[(x[0] <= xq) & (xq <= x[nx - 1])]
    xqi[xq < x[0]] = 0
    xqpi[xq < x[0]] = 1
    xqi[xq > x[nx - 1]] = nx - 1
    xqpi[xq > x[nx - 1]] = 1
    # interpolation
    xi = 0
    x_low = x[0]
    x_high = x[1]
    for xqi_cur in id:
        xq_cur = xq[xqi_cur]
        while xi < nx - 2:
            if x_high >= xq_cur:
                break
            xi += 1
            x_low = x_high
            x_high = x[xi + 1]
        xqpi[xqi_cur] = (x_high - xq_cur) / (x_high - x_low)
        xqi[xqi_cur] = xi

    # revert back to initial order
    xqpi[:] = xqpi[ind_init]
    xqi[:] = xqi[ind_init]


@guvectorize(['void(float64[:], float64[:], uint32[:], float64[:])'], '(n),(nq)->(nq),(nq)')
def interpolate_coord_sorted(x, xq, xqi, xqpi):
    """Like interpolate_coord, but assumes xq is already sorted along the final axis."""
    nxq, nx = xq.shape[0], x.shape[0]

    xi = 0
    x_low = x[0]
    x_high = x[1]
    for xqi_cur in range(nxq):
        xq_cur = xq[xqi_cur]

        if xq_cur < x[0]:
            xqi[xqi_cur] = 0
            xqpi[xqi_cur] = 1.0
            continue
        if xq_cur > x[nx - 1]:
            xqi[xqi_cur] = nx - 1
            xqpi[xqi_cur] = 1.0
            continue

        while xi < nx - 2:
            if x_high >= xq_cur:
                break
            xi += 1
            x_low = x_high
            x_high = x[xi + 1]
        xqpi[xqi_cur] = (x_high - xq_cur) / (x_high - x_low)
        xqi[xqi_cur] = xi


@guvectorize(['void(int64[:], float64[:], float64[:], float64[:])',
              'void(uint32[:], float64[:], float64[:], float64[:])'], '(nq),(nq),(n)->(nq)')
def apply_coord(x_i, x_pi, y, yq):
    """Use representation xqi, xqpi to get yq at xq:
    yq = xqpi * y[xqi] + (1-xqpi) * y[xqi+1]
    Parameters
    ----------
    xqi  : array (nq), indices of lower bracketing gridpoints
    xqpi : array (nq), weights on lower bracketing gridpoints
    y  : array (n), data points
    Returns
    ----------
    yq : array (nq), interpolated points
    """
    nq = x_i.shape[0]
    for iq in range(nq):
        y_low = y[x_i[iq]]
        y_high = y[x_i[iq] + 1]
        yq[iq] = x_pi[iq] * y_low + (1 - x_pi[iq]) * y_high



'''Part 2: More robust linear interpolation that does not require monotonicity in query points.

    Intended for general use in interpolating policy rules that we cannot be sure are monotonic.
    Only get xqi, xqpi representation, for case where x is one-dimensional, in this application.
'''


def interpolate_coord_robust(x, xq, check_increasing=False):
    """Linear interpolation exploiting monotonicity only in data x, not in query points xq.
    Simple binary search, less efficient but more robust.
    xq = xqpi * x[xqi] + (1-xqpi) * x[xqi+1]

    Main application intended to be universally-valid interpolation of policy rules.
    Dimension k is optional.

    Parameters
    ----------
    x    : array (n), ascending data points
    xq   : array (k, nq), query points (in any order)

    Returns
    ----------
    xqi  : array (k, nq), indices of lower bracketing gridpoints
    xqpi : array (k, nq), weights on lower bracketing gridpoints
    """
    # Making sure nothing above x[-1]
    xq[xq > x[-1]] = x[-1]

    if x.ndim != 1:
        raise ValueError('Data input to interpolate_coord_robust must have exactly one dimension')

    if check_increasing and np.any(x[:-1] >= x[1:]):
        raise ValueError('Data input to interpolate_coord_robust must be strictly increasing')

    if xq.ndim == 1:
        return interpolate_coord_robust_vector(x, xq)
    else:
        i, pi = interpolate_coord_robust_vector(x, xq.ravel())
        return i.reshape(xq.shape), pi.reshape(xq.shape)


def interpolate_coord_1d(x, xq):
    """Fast coordinates for arbitrary query points against a single 1-D grid."""
    xq_arr = np.asarray(xq)
    i, pi = interpolate_coord_1d_vector(np.asarray(x), xq_arr.ravel())
    return i.reshape(xq_arr.shape), pi.reshape(xq_arr.shape)


@njit
def interpolate_coord_1d_vector(x, xq):
    n = len(x)
    nq = len(xq)
    xqi = np.empty(nq, dtype=np.uint32)
    xqpi = np.empty(nq)

    for iq in range(nq):
        xq_cur = xq[iq]
        if xq_cur < x[0]:
            ilow = 0
            weight = 1.0
        elif xq_cur > x[n - 1]:
            ilow = n - 1
            weight = 1.0
        else:
            ihigh = n - 1
            ilow = 0
            while ihigh - ilow > 1:
                imid = (ihigh + ilow) // 2
                if xq_cur > x[imid]:
                    ilow = imid
                else:
                    ihigh = imid
            weight = (x[ilow + 1] - xq_cur) / (x[ilow + 1] - x[ilow])

        xqi[iq] = ilow
        xqpi[iq] = weight

    return xqi, xqpi


@njit
def interpolate_coord_robust_vector(x, xq):
    """Does interpolate_coord_robust where xq must be a vector, more general function is wrapper"""

    n = len(x)
    nq = len(xq)
    xqi = np.empty(nq, dtype=np.uint32)
    xqpi = np.empty(nq)

    for iq in range(nq):
        if xq[iq] < x[0]:
            ilow = 0
        elif xq[iq] > x[-2]:
            ilow = n - 2
        else:
            # start binary search
            # should end with ilow and ihigh exactly 1 apart, bracketing variable
            ihigh = n - 1
            ilow = 0
            while ihigh - ilow > 1:
                imid = (ihigh + ilow) // 2
                if xq[iq] > x[imid]:
                    ilow = imid
                else:
                    ihigh = imid

        xqi[iq] = ilow
        xqpi[iq] = (x[ilow + 1] - xq[iq]) / (x[ilow + 1] - x[ilow])

    return xqi, xqpi

@njit
def simple_interpolation(x, xgrid):
    nx = xgrid.shape[0]
    if x < xgrid[0]:
        xloc_min = 0
        wx = 1.0
    elif x >= xgrid[nx - 1]:
        xloc_min = nx - 1
        wx = 0.0
    else:
        xloc_min = 0
        for i in range(1, nx):
            if x >= xgrid[i]:
                xloc_min = i
            else:
                break
        wx = 1 - (x - xgrid[xloc_min]) / (xgrid[xloc_min + 1] - xgrid[xloc_min])

    return xloc_min, wx


def labor_market_cache(par):
    """Cache labor-market adjacency lists used in tight steady-state loops."""
    cache = par.get('_labor_market_cache')
    nP = par['nP']
    nT = par['nT']
    if cache is not None and cache.get('nP') == nP and cache.get('nT') == nT:
        return cache['lmsU'], cache['lmsE'], cache['tnext']

    lmsU = np.where(par['gU'] > 0)[0].astype(np.int64)
    lmsE = List()
    for ip in range(nP):
        destinations = np.where(par['gE'][ip, :] > 0)[0].astype(np.int64)
        if ip == nP - 1:
            destinations = np.array([nP - 1], dtype=np.int64)
        lmsE.append(destinations)

    tnext = np.arange(1, nT + 1, dtype=np.int64)
    tnext[-1] = nT - 1
    cache = {'nP': nP, 'nT': nT, 'lmsU': lmsU, 'lmsE': lmsE, 'tnext': tnext}
    par['_labor_market_cache'] = cache
    return lmsU, lmsE, tnext


'''Part 4: grids and Markov chains'''

def agrid(amax, n, amin=0):
    """Create grid between amin-pivot and amax+pivot that is equidistant in logs."""
    pivot = np.abs(amin) + 0.25
    a_grid = np.geomspace(amin + pivot, amax + pivot, n) - pivot
    a_grid[0] = amin  # make sure *exactly* equal to amin
    return a_grid


def stationary(Pi, pi_seed=None, tol=1E-11, maxit=10000):
    """Find invariant distribution of a Markov chain by iteration."""
    if pi_seed is None:
        pi = np.ones(Pi.shape[0]) / Pi.shape[0]
    else:
        pi = pi_seed

    for it in range(maxit):
        pi_new = pi @ Pi
        if np.max(np.abs(pi_new - pi)) < tol:
            break
        pi = pi_new
    else:
        raise ValueError(f'No convergence after {maxit} forward iterations!')
    pi = pi_new

    return pi


def mean(x, pi):
    """Mean of discretized random variable with support x and probability mass function pi."""
    return np.sum(pi * x)


def variance(x, pi):
    """Variance of discretized random variable with support x and probability mass function pi."""
    return np.sum(pi * (x - np.sum(pi * x)) ** 2)


def std(x, pi):
    """Standard deviation of discretized random variable with support x and probability mass function pi."""
    return np.sqrt(variance(x, pi))


def cov(x, y, pi):
    """Covariance of two discretized random variables with supports x and y common probability mass function pi."""
    return np.sum(pi * (x - mean(x, pi)) * (y - mean(y, pi)))


def corr(x, y, pi):
    """Correlation of two discretized random variables with supports x and y common probability mass function pi."""
    return cov(x, y, pi) / (std(x, pi) * std(y, pi))


def markov_tauchen(rho, sigma, N=7, m=3):
    """Tauchen method discretizing AR(1) s_t = rho*s_(t-1) + eps_t.

    Parameters
    ----------
    rho   : scalar, persistence
    sigma : scalar, unconditional sd of s_t
    N     : int, number of states in discretized Markov process
    m     : scalar, discretized s goes from approx -m*sigma to m*sigma

    Returns
    ----------
    y  : array (N), states proportional to exp(s) s.t. E[y] = 1
    pi : array (N), stationary distribution of discretized process
    Pi : array (N*N), Markov matrix for discretized process
    """

    # make normalized grid, start with cross-sectional sd of 1
    s = np.linspace(-m, m, N)
    ds = s[1] - s[0]
    sd_innov = np.sqrt(1 - rho ** 2)

    # standard Tauchen method to generate Pi given N and m
    Pi = np.empty((N, N))
    Pi[:, 0] = norm.cdf(s[0] - rho * s + ds / 2, scale=sd_innov)
    Pi[:, -1] = 1 - norm.cdf(s[-1] - rho * s - ds / 2, scale=sd_innov)
    for j in range(1, N - 1):
        Pi[:, j] = (norm.cdf(s[j] - rho * s + ds / 2, scale=sd_innov) -
                    norm.cdf(s[j] - rho * s - ds / 2, scale=sd_innov))

    # invariant distribution and scaling
    pi = stationary(Pi)
    s *= (sigma / np.sqrt(variance(s, pi)))
    y = np.exp(s) / np.sum(pi * np.exp(s))

    return y, pi, Pi


def markov_rouwenhorst(rho, sigma, N=7):
    """Rouwenhorst method analog to markov_tauchen"""

    # parametrize Rouwenhorst for n=2
    p = (1 + rho) / 2
    Pi = np.array([[p, 1 - p], [1 - p, p]])

    # implement recursion to build from n=3 to n=N
    for n in range(3, N + 1):
        P1, P2, P3, P4 = (np.zeros((n, n)) for _ in range(4))
        P1[:-1, :-1] = p * Pi
        P2[:-1, 1:] = (1 - p) * Pi
        P3[1:, :-1] = (1 - p) * Pi
        P4[1:, 1:] = p * Pi
        Pi = P1 + P2 + P3 + P4
        Pi[1:-1] /= 2

    # invariant distribution and scaling
    pi = stationary(Pi)
    s = np.linspace(-1, 1, N)
    s *= (sigma / np.sqrt(variance(s, pi)))
    y = np.exp(s) / np.sum(pi * np.exp(s))

    return y, pi, Pi


'''Part 5: njitted routines to speed up some steps in backward iteration or aggregation'''


@njit
def setmin(x, xmin):
    """Set 2-dimensional array x where each row is ascending equal to equal to max(x, xmin)."""
    ni, nj = x.shape
    for i in range(ni):
        for j in range(nj):
            if x[i, j] < xmin:
                x[i, j] = xmin
            else:
                break


@njit
def within_tolerance(x1, x2, tol):
    """Efficiently test max(abs(x1-x2)) <= tol for arrays of same dimensions x1, x2."""
    y1 = x1.ravel()
    y2 = x2.ravel()

    for i in range(y1.shape[0]):
        if np.abs(y1[i] - y2[i]) > tol:
            return False
    return True


@njit
def fast_aggregate(X, Y):
    """If X has dims (T, ...) and Y has dims (T, ...), do dot product for each T to get length-T vector.

    Identical to np.sum(X*Y, axis=(1,...,X.ndim-1)) but avoids costly creation of intermediates, useful
    for speeding up aggregation in td by factor of 4 to 5."""
    T = X.shape[0]
    Xnew = X.reshape(T, -1)
    Ynew = Y.reshape(T, -1)
    Z = np.empty(T)
    for t in range(T):
        Z[t] = Xnew[t, :] @ Ynew[t, :]
    return Z


'''Part 6: numerical differentiation'''


def numerical_diff(func, ssinputs_dict, shock_dict, h=1E-4, y_ss_list=None):
    """Differentiate function numerically via forward difference, i.e. calculate

    f'(xss)*shock = (f(xss + h*shock) - f(xss))/h

    for small h. (Variable names inspired by application of differentiating around ss.)

    Parameters
    ----------
    func            : function, 'f' to be differentiated
    ssinputs_dict   : dict, values in 'xss' around which to differentiate
    shock_dict      : dict, values in 'shock' for which we're taking derivative
                        (keys in shock_dict are weak subset of keys in ssinputs_dict)
    h               : [optional] scalar, scaling of forward difference 'h'
    y_ss_list       : [optional] list, value of y=f(xss) if we already have it

    Returns
    ----------
    dy_list : list, output f'(xss)*shock of numerical differentiation
    """
    # compute ss output if not supplied
    if y_ss_list is None:
        y_ss_list = make_tuple(func(**ssinputs_dict))

    # response to small shock
    shocked_inputs = {**ssinputs_dict, **{k: ssinputs_dict[k] + h * shock for k, shock in shock_dict.items()}}
    y_list = make_tuple(func(**shocked_inputs))

    # scale responses back up, dividing by h
    dy_list = [(y - y_ss) / h for y, y_ss in zip(y_list, y_ss_list)]

    return dy_list


def numerical_diff_symmetric(func, ssinputs_dict, shock_dict, h=1E-4):
    """Same as numerical_diff, but differentiate numerically using central (symmetric) difference, i.e.

    f'(xss)*shock = (f(xss + h*shock) - f(xss - h*shock))/(2*h)
    """

    # response to small shock in each direction
    shocked_inputs_up = {**ssinputs_dict, **{k: ssinputs_dict[k] + h * shock for k, shock in shock_dict.items()}}
    y_up_list = make_tuple(func(**shocked_inputs_up))

    shocked_inputs_down = {**ssinputs_dict, **{k: ssinputs_dict[k] - h * shock for k, shock in shock_dict.items()}}
    y_down_list = make_tuple(func(**shocked_inputs_down))

    # scale responses back up, dividing by h
    dy_list = [(y_up - y_down) / (2 * h) for y_up, y_down in zip(y_up_list, y_down_list)]

    return dy_list


'''Part 7: simple nonlinear solvers'''


def newton_solver(f, x0, y0=None, tol=1E-9, maxcount=100, backtrack_c=0.5, noisy=True, jac_h=1E-5):
    """Simple line search solver for root x satisfying f(x)=0 using Newton direction.

    Backtracks if input invalid or improvement is not at least half the predicted improvement.

    Parameters
    ----------
    f               : function, to solve for f(x)=0, input and output are arrays of same length
    x0              : array (n), initial guess for x
    y0              : [optional] array (n), y0=f(x0), if already known
    tol             : [optional] scalar, solver exits successfully when |f(x)| < tol
    maxcount        : [optional] int, maximum number of Newton steps
    backtrack_c     : [optional] scalar, fraction to backtrack if step unsuccessful, i.e.
                        if we tried step from x to x+dx, now try x+backtrack_c*dx

    Returns
    ----------
    x       : array (n), (approximate) root of f(x)=0
    y       : array (n), y=f(x), satisfies |y| < tol
    """

    x, y = x0, y0
    if y is None:
        y = f(x)

    for count in range(maxcount):
        if noisy:
            printit(count, x, y)

        if np.max(np.abs(y)) < tol:
            return x, y

        J = obtain_J(f, x, y, h=jac_h)
        dx = np.linalg.solve(J, -y)

        # backtrack at most 29 times
        for bcount in range(30):
            try:
                ynew = f(x + dx)
            except ValueError:
                if noisy:
                    print('backtracking\n')
                dx *= backtrack_c
            else:
                predicted_improvement = -np.sum((J @ dx) * y) * ((1 - 1 / 2 ** bcount) + 1) / 2
                actual_improvement = (np.sum(y ** 2) - np.sum(ynew ** 2)) / 2
                if actual_improvement < predicted_improvement / 2:
                    if noisy:
                        print('backtracking\n')
                    dx *= backtrack_c
                else:
                    y = ynew
                    x += dx
                    break
        else:
            raise ValueError('Too many backtracks, maybe bad initial guess?')
    else:
        raise ValueError(f'No convergence after {maxcount} iterations')


def broyden_solver(f, x0, y0=None, tol=1E-9, maxcount=100, backtrack_c=0.5, noisy=True,
                   jac_h=1E-5, require_improvement=False, improvement_tol=0.0,
                   max_backtracks=30):
    """Similar to newton_solver, but solves f(x)=0 using approximate rather than exact Newton direction,
    obtaining approximate Jacobian J=f'(x) from Broyden updating (starting from exact Newton at f'(x0)).

    By default, backtracks only if error raised by evaluation of f, since an approximate Jacobian
    does not guarantee local improvement. If require_improvement is True, also backtracks when
    the residual norm grows by more than improvement_tol.
    """

    x, y = x0, y0
    if y is None:
        y = f(x)
    if np.max(np.abs(y)) < tol:
        return x, y

    # initialize J with Newton!
    J = obtain_J(f, x, y, h=jac_h)
    for count in range(maxcount):
        if noisy:
            printit(count, x, y)

        if np.max(np.abs(y)) < tol:
            return x, y

        dx = np.linalg.solve(J, -y)
        y_norm = np.linalg.norm(y)
        shrink = backtrack_c if backtrack_c < 1 else 0.5

        # backtrack at most max_backtracks times
        for bcount in range(max_backtracks):
            try:
                ynew = f(x + dx)
            except ValueError:
                if noisy:
                    print('backtracking\n')
                dx *= shrink
            else:
                ynew_norm = np.linalg.norm(ynew)
                if require_improvement and ynew_norm > (1 + improvement_tol) * y_norm:
                    if noisy:
                        print('backtracking\n')
                    dx *= shrink
                    continue
                J = broyden_update(J, dx, ynew - y)
                y = ynew
                x += dx
                break
        else:
            raise ValueError(f'Too many backtracks ({max_backtracks}), maybe bad initial guess?')
    else:
        raise ValueError(f'No convergence after {maxcount} iterations')


def obtain_J(f, x, y, h=1E-5):
    """Finds Jacobian f'(x) around y=f(x)"""
    nx = x.shape[0]
    ny = y.shape[0]
    J = np.empty((nx, ny))

    for i in range(nx):
        dx = h * (np.arange(nx) == i)
        J[:, i] = (f(x + dx) - y) / h
    return J


def broyden_update(J, dx, dy):
    """Returns Broyden update to approximate Jacobian J, given that last change in inputs to function
    was dx and led to output change of dy."""
    return J + np.outer(((dy - J @ dx) / np.linalg.norm(dx) ** 2), dx)


def printit(it, x, y, **kwargs):
    """Convenience printing function for noisy iterations"""
    print(f'On iteration {it}')
    print(('x = %.3f' + ',%.3f' * (len(x) - 1)) % tuple(x))
    print(('y = %.3f' + ',%.3f' * (len(y) - 1)) % tuple(y))
    for kw, val in kwargs.items():
        print(f'{kw} = {val:.3f}')
    print('\n')


'''Part 8: topological sort and related code'''


def block_sort(block_list, findrequired=False):
    """Given list of blocks (either blocks themselves or dicts of Jacobians), find a topological sort and also
    optionally return which outputs must be computed as inputs of later blocks.

    Relies on blocks having 'inputs' and 'outputs' attributes (unless they are dicts of Jacobians, in which case it's
    inferred) that indicate their aggregate inputs and outputs"""
    # step 1: map outputs to blocks for topological sort
    outmap = dict()
    for num, block in enumerate(block_list):
        if hasattr(block, 'outputs'):
            outputs = block.outputs
        elif isinstance(block, dict):
            outputs = block.keys()
        else:
            raise ValueError(f'{block} is not recognized as block or does not provide outputs')

        for o in outputs:
            if o in outmap:
                raise ValueError(f'{o} is output twice')
            outmap[o] = num

    # step 2: dependency graph for topological sort and input list
    dep = {num: set() for num in range(len(block_list))}
    if findrequired:
        required = set()
    for num, block in enumerate(block_list):
        if hasattr(block, 'inputs'):
            inputs = block.inputs
        else:
            inputs = set(i for o in block for i in block[o])

        for i in inputs:
            if i in outmap:
                dep[num].add(outmap[i])
                if findrequired:
                    required.add(i)

    # step 3: return topological sort, also 'required' if wanted
    if findrequired:
        return topological_sort(dep), required
    else:
        return topological_sort(dep)


def topological_sort(dep, names=None):
    """Given directed graph pointing from each node to the nodes it depends on, topologically sort nodes"""

    # get complete set version of dep, and its reversal, and build initial stack of nodes with no dependencies
    dep, revdep = complete_reverse_graph(dep)
    nodeps = [n for n in dep if not dep[n]]
    topsorted = []

    # Kahn's algorithm: find something with no dependency, delete its edges and update
    while nodeps:
        n = nodeps.pop()
        topsorted.append(n)
        for n2 in revdep[n]:
            dep[n2].remove(n)
            if not dep[n2]:
                nodeps.append(n2)

    # should be done: topsorted should be topologically sorted with same # of elements as original graphs!
    if len(topsorted) != len(dep):
        cycle_ints = find_cycle(dep, dep.keys() - set(topsorted))
        assert cycle_ints is not None, 'topological sort failed but no cycle, THIS SHOULD NEVER EVER HAPPEN'
        cycle = [names[i] for i in cycle_ints] if names else cycle_ints
        raise Exception(f'Topological sort failed: cyclic dependency {" -> ".join(cycle)}')

    return topsorted


def complete_reverse_graph(gph):
    """Given directed graph represented as a dict from nodes to iterables of nodes, return representation of graph that
    is complete (i.e. has each vertex pointing to some iterable, even if empty), and a complete version of reversed too.
    Have returns be sets, for easy removal"""

    revgph = {n: set() for n in gph}
    for n, e in gph.items():
        for n2 in e:
            n2_edges = revgph.setdefault(n2, set())
            n2_edges.add(n)

    gph_missing_n = revgph.keys() - gph.keys()
    gph = {**{k: set(v) for k, v in gph.items()}, **{n: set() for n in gph_missing_n}}
    return gph, revgph


def find_cycle(dep, onlyset=None):
    """Return list giving cycle if there is one, otherwise None"""

    # supposed to look only within 'onlyset', so filter out everything else
    if onlyset is not None:
        dep = {k: (set(v) & set(onlyset)) for k, v in dep.items() if k in onlyset}

    tovisit = set(dep.keys())
    stack = SetStack()
    while tovisit or stack:
        if stack:
            # if stack has something, still need to proceed with DFS
            n = stack.top()
            if dep[n]:
                # if there are any dependencies left, let's look at them
                n2 = dep[n].pop()
                if n2 in stack:
                    # we have a cycle, since this is already in our stack
                    i2loc = stack.index(n2)
                    return stack[i2loc:] + [stack[i2loc]]
                else:
                    # no cycle, visit this node only if we haven't already visited it
                    if n2 in tovisit:
                        tovisit.remove(n2)
                        stack.add(n2)
            else:
                # if no dependencies left, then we're done with this node, so let's forget about it
                stack.pop(n)
        else:
            # nothing left on stack, let's start the DFS from something new
            n = tovisit.pop()
            stack.add(n)

    # if we never find a cycle, we're done
    return None


class SetStack:
    """Stack implemented with list but tests membership with set to be efficient in big cases"""

    def __init__(self):
        self.myset = set()
        self.mylist = []

    def add(self, x):
        self.myset.add(x)
        self.mylist.append(x)

    def pop(self):
        x = self.mylist.pop()
        self.myset.remove(x)
        return x

    def top(self):
        return self.mylist[-1]

    def index(self, x):
        return self.mylist.index(x)

    def __contains__(self, x):
        return x in self.myset

    def __len__(self):
        return len(self.mylist)

    def __getitem__(self, i):
        return self.mylist.__getitem__(i)

    def __repr__(self):
        return self.mylist.__repr__()


'''Part 9: Assorted other utilities'''


def make_tuple(x):
    """If not tuple or list, make into tuple with one element.

    Wrapping with this allows user to write, e.g.:
    "return r" rather than "return (r,)"
    "policy='a'" rather than "policy=('a',)"
    """
    return (x,) if not (isinstance(x, tuple) or isinstance(x, list)) else x


def input_list(f):
    """Return list of function inputs"""
    return inspect.getfullargspec(f).args


def output_list(f):
    """Scans source code of function to detect statement like

    'return L, Div'

    and reports the list ['L', 'Div'].

    Important to write functions in this way when they will be scanned by output_list, for
    either SimpleBlock or HetBlock.
    """
    return re.findall('return (.*?)\n', inspect.getsource(f))[-1].replace(' ', '').split(',')


def demean(x):
    return x - x.sum() / x.size


# simpler aliases for LU factorization and solution
def factor(X):
    return scipy.linalg.lu_factor(X)


def factored_solve(Z, y):
    return scipy.linalg.lu_solve(Z, y)


# functions for handling saved Jacobians: extract keys from dicts or key pairs
# from nested dicts, and take subarrays with 'shape' of the values
def extract_dict(savedA, keys, shape):
    return {k: take_subarray(savedA[k], shape) for k in keys}


def extract_nested_dict(savedA, keys1, keys2, shape):
    return {k1: {k2: take_subarray(savedA[k1][k2], shape) for k2 in keys2} for k1 in keys1}


def take_subarray(A, shape):
    # verify leading dimensions of A are >= shape
    if not all(m <= n for m, n in zip(shape, A.shape)):
        raise ValueError(f'Saved has dimensions {A.shape}, want larger {shape} subarray')

    # take subarray along those dimensions: A[:shape, ...]
    return A[tuple(slice(None, x, None) for x in shape) + (Ellipsis,)]


def v(N, varphi, nu):
    return varphi * (N ** (1 + nu)) / (1 + nu)

def dv(N, varphi, nu):
    return varphi * (N ** nu)



# For DMP model

# CRRA Utility
def u(c, eis):
    # utility
    if eis == 1:
        return np.log(c)
    else:
        return (c ** (1 - 1 / eis)) / (1 - 1 / eis)


def du(c, eis):
    # Derivative of utility
    if eis == 1:
        return 1 / c
    else:
        return c ** (-1 / eis)


def dinvu(c, eis):
    # Inverse of derivative of utility
    if eis == 1:
        return 1 / c
    else:
        return c ** (-eis)

# # Quadratic utility
# def u(c, eis):
#     # utility
#     return c - eis * (c ** 2)
#
#
# def du(c, eis):
#     # Derivative of utility
#     return 1 - 2 * eis * c
#
#
# def dinvu(c, eis):
#     # Inverse of derivative of utility
#     return (1 - c) / (2 * eis)

def logsumexp(X, Y):
    x = np.maximum(X, Y)
    t = np.exp(X - x) + np.exp(Y - x)
    return x + np.log(t)

def f(k, par):
    """Production function per unit of capital"""
    y = k ** par['alpha']
    return y

def bound_map(x, a, b):
    # avoid overflow warnings in exp() while preserving logistic saturation
    x_clip = np.clip(x, -35.0, 35.0)
    return a + (b - a) / (1 + np.exp(-x_clip))

def bound_map_inv(x, a, b):
    return -np.log((b - a) / (x - a) - 1)

## NUMBA VERSION                     
def forward_step_dmp(DU, DE, pol_i, pol_pi, w_i, w_pi, Inew, qswitch, lambdas, par):
    """Endogenous update part of forward_step_dmp"""
    nZ, nA, nW, nP, nT = DE.shape
    # separation and job-finding probabilities
    sigma = par['sigma']
    # accessible labor markets and transition matrices
    gU = par['gU']
    gE = par['gE']
    s = par['s']
    lmsU, lmsE, _ = labor_market_cache(par)

    # extracting relevant policy arrays
    aU_i = pol_i["aU"]
    aU_pi = pol_pi["aU"]
    aE_i = pol_i["aE"]
    aE_pi = pol_pi["aE"]
    wU_i = w_i["U"]
    wU_pi = w_pi["U"]
    wEwin_i = w_i["Ewin"]
    wEwin_pi = w_pi["Ewin"]
    wElose_i = w_i["Elose"]
    wElose_pi = w_pi["Elose"]

    # update distribution: all but case in which workers have opportunity to switch
    DUmid, DEmid1, DEmid2, DUEmid, DEEmid = dnext_step1(DU, DE, aE_i, aE_pi, aU_i, aU_pi, wU_i, wU_pi, lambdas, sigma, gU, lmsU, gE, lmsE, s, nZ, nA, nW, nP, nT, par['Pi'])
    # Hard-cded 2x2 Pi.T
    _PiT = par['Pi'].T
    _p00, _p01, _p10, _p11 = _PiT[0, 0], _PiT[0, 1], _PiT[1, 0], _PiT[1, 1]
    def _pit(X, shape):
        Xf = X.reshape(2,-1)
        Yf = np.empty_like(Xf)
        Yf[0] = _p00 * Xf[0] + _p01 * Xf[1]
        Yf[1] = _p10 * Xf[0] + _p11 * Xf[1]
        return Yf.reshape(shape)
    DUEnew = _pit(DUEmid, (nZ, nA, nP))
    DUnew = _pit(DUmid, (nZ, nA))
    DEmid = DEmid1 + _pit(DEmid2, (nZ, nA, nW, nP, nT))
    DEEnew = _pit(DEEmid, (nZ, nA, nW, nP, nT, nP))    
    # update distribution: only case in which workers have opportunity to switch
    DEnew = dnext_step2(DE, Inew, qswitch, aE_i, aE_pi, wEwin_i, wEwin_pi, wElose_i, wElose_pi, lambdas, sigma, gE, lmsE, s, nZ, nA, nW, nP, nT, par['Pi'])
    # overall updated distributions
    DEnew += DEmid
    if par.get('check_distribution_mass', False):
        mass = np.sum(DUnew) + np.sum(DEnew)
        assert isclose(mass, 1, rel_tol=1e-9, abs_tol=0.0), 'Distribution function incorrect: total mass does not sum to 1, ' + str(mass)

    return DUnew, DEnew, DUEnew, DEEnew[:, :, :, :, 1:]

@njit
def dnext_step1(DU, DE, aE_i, aE_pi, aU_i, aU_pi, wU_i, wU_pi, lambdas, sigma, gU, lmsU, gE, lmsE, s, nZ, nA, nW, nP, nT, Pi):
    # Defining new distribution arrays
    DUnew = np.zeros_like(DU)
    DUE = np.zeros((nZ, nA, nP))
    DEnew1 = np.zeros_like(DE)
    DEnew2 = np.zeros_like(DE)
    DEE = np.zeros((nZ, nA, nW, nP, nT, nP))

    for iz in range(nZ):
        for ia in range(nA):
            du = DU[iz, ia]
            if du > 0.0:
                # unemployed interpolation info
                iaUp = aU_i[iz, ia]             # pol_i["aU"]
                iaUp_next = min(iaUp + 1, nA - 1)
                alphaU = aU_pi[iz, ia]           # pol_pi["aU"]

                for ip_d in lmsU:
                    # (U->U) workers who remain unemployed
                    DUnew[iz, iaUp] += alphaU * du * (1 - lambdas[ip_d] * gU[ip_d])
                    DUnew[iz, iaUp_next] += (1 - alphaU) * du * (1 - lambdas[ip_d] * gU[ip_d])
                    # DUE (to compute expected value for vacant firms)
                    DUE[iz, iaUp, ip_d] += alphaU * du * lambdas[ip_d] * gU[ip_d]
                    DUE[iz, iaUp_next, ip_d] += (1 - alphaU) * du * lambdas[ip_d] * gU[ip_d]

                # have to determine at which wage they start:
                for zi in range(nZ):
                    du_zi = du * Pi[iz, zi]
                    if du_zi > 0.0:
                        for ip_d in lmsU:
                            # (U->E) workers find employment
                            iwU00 = wU_i[zi, iaUp, ip_d]
                            alphaW_00 = wU_pi[zi, iaUp, ip_d]
                            iwU01 = min(iwU00 + 1, nW - 1)
                            alphaW_01 = (1 - alphaW_00)
                            iwU10 = wU_i[zi, iaUp_next, ip_d]
                            alphaW_10 = wU_pi[zi, iaUp_next, ip_d]
                            iwU11 = min(iwU10 + 1, nW - 1)
                            alphaW_11 = (1 - alphaW_10)

                            DEnew1[zi, iaUp, iwU00, ip_d, 0] += alphaU * alphaW_00 * du_zi * lambdas[ip_d] * gU[ip_d]
                            DEnew1[zi, iaUp, iwU01, ip_d, 0] += alphaU * alphaW_01 * du_zi * lambdas[ip_d] * gU[ip_d]
                            DEnew1[zi, iaUp_next, iwU10, ip_d, 0] += (1 - alphaU) * alphaW_10 * du_zi * lambdas[ip_d] * gU[ip_d]
                            DEnew1[zi, iaUp_next, iwU11, ip_d, 0] += (1 - alphaU) * alphaW_11 * du_zi * lambdas[ip_d] * gU[ip_d]
    
            for iw in range(nW):
                for ip_o in range(nP):
                    for ip_d in lmsE[ip_o]:
                        # probability of meeting firm in rung k+1
                        lfind = s * lambdas[ip_d] * gE[ip_o, ip_d]
                        for it in range(nT):
                            # relevant for current states
                            prsep = sigma[it]
                            de = DE[iz, ia, iw, ip_o, it]
                            
                            if de > 0.0:
                                # employed interpolation info (stayers)
                                tnext = min(it + 1, nT - 1)
                                alphaE = aE_pi[iz, ia, iw, ip_o, it]
                                iaE = aE_i[iz, ia, iw, ip_o, it]
                                iaE_next = min(iaE + 1, nA - 1)

                                # (E->U) workers who lose their job
                                DUnew[iz, iaE] += alphaE * de * prsep
                                DUnew[iz, iaE_next] += (1 - alphaE) * de * prsep

                                # (E->E: no offer)
                                prnooffer = (1 - prsep) * (1 - lfind)
                                DEnew2[iz, iaE, iw, ip_o, tnext] += alphaE * de * prnooffer
                                DEnew2[iz, iaE_next, iw, ip_o, tnext] += (1 - alphaE) * de * prnooffer

                                # DEE (to compute expected value for vacant firms)
                                DEE[iz, iaE, iw, ip_o, tnext, ip_d] += (1 - prsep) * alphaE * de * lfind
                                DEE[iz, iaE_next, iw, ip_o, tnext, ip_d] += (1 - prsep) * (1 - alphaE) * de * lfind



    return DUnew, DEnew1, DEnew2, DUE, DEE

@njit
def dnext_step2(DE, Inew, qswitch, aE_i, aE_pi, wEwin_i, wEwin_pi, wElose_i, wElose_pi, lambdas, sigma, gE, lmsE, s, nZ, nA, nW, nP, nT, Pi):                
    # Defining new distribution arrays
    DEnew = np.zeros_like(DE)

    # Useful constructor
    Prwin_switch = ((Inew == 1) * qswitch)
    Prwin_stay = ((Inew == 1) * (1 - qswitch))
    Prlose_switch = ((1 - (Inew == 1)) * qswitch)
    Prlose_stay = ((1 - (Inew == 1)) * (1 - qswitch))

    for iz in range(nZ):
        for ia in range(nA):
            for iw in range(nW):
                for ip_o in range(nP):
                    for ip_d in lmsE[ip_o]:
                        lfind = s * lambdas[ip_d] * gE[ip_o, ip_d]
                        for it in range(nT):
                            de_home = DE[iz, ia, iw, ip_o, it]
                            if de_home > 0:
                                # relevant for current tenure
                                tnext = min(it + 1, nT - 1)
                                itnew = tnext - 1
                                alpha = aE_pi[iz, ia, iw, ip_o, it]
                                iaE = aE_i[iz, ia, iw, ip_o, it]
                                iaE_next = min(iaE + 1, nA - 1)

                                # relevant for current states
                                prsep = sigma[it]
                                proffer = (1 - prsep) * lfind

                                for zi in range(nZ):
                                    # mass of workers at state (iz, ia, iw, ip, it) going to zi
                                    de = de_home * Pi[iz, zi]

                                    # For iaE
                                    # useful info about wages next period
                                    iwE00_win = wEwin_i[zi, iaE, iw, ip_o, itnew, ip_d]
                                    iwE01_win = min(iwE00_win + 1, nW - 1)
                                    alphaW00_win = wEwin_pi[zi, iaE, iw, ip_o, itnew, ip_d]
                                    alphaW01_win = 1 - alphaW00_win
                                    iwE00_lose = wElose_i[zi, iaE, iw, ip_o, itnew, ip_d]
                                    iwE01_lose = min(iwE00_lose + 1, nW - 1)
                                    alphaW00_lose = wElose_pi[zi, iaE, iw, ip_o, itnew, ip_d]
                                    alphaW01_lose = 1 - alphaW00_lose

                                    # relevant for switching probabilities
                                    prwin_switch = Prwin_switch[zi, iaE, iw, ip_o, itnew, ip_d]
                                    prwin_stay = Prwin_stay[zi, iaE, iw, ip_o, itnew, ip_d]
                                    prlose_switch = Prlose_switch[zi, iaE, iw, ip_o, itnew, ip_d]
                                    prlose_stay = Prlose_stay[zi, iaE, iw, ip_o, itnew, ip_d]

                                    # winning firm is on next rung and worker moves
                                    DEnew[zi, iaE, iwE00_win, ip_d, 0] += alpha * alphaW00_win * proffer * prwin_switch * de
                                    DEnew[zi, iaE, iwE01_win, ip_d, 0] += alpha * alphaW01_win * proffer * prwin_switch * de
                                    # winning firm is on current rung but worker moves to next rung
                                    DEnew[zi, iaE, iwE00_lose, ip_d, 0] += alpha * alphaW00_lose * proffer * prlose_switch * de
                                    DEnew[zi, iaE, iwE01_lose, ip_d, 0] += alpha * alphaW01_lose * proffer * prlose_switch * de
                                    # winning firm is on next rung but worker stays on current rung
                                    DEnew[zi, iaE, iwE00_win, ip_o, tnext] += alpha * alphaW00_win * proffer * prwin_stay * de
                                    DEnew[zi, iaE, iwE01_win, ip_o, tnext] += alpha * alphaW01_win * proffer * prwin_stay * de
                                    # winning firm is on current rung and worker stays on current rung
                                    DEnew[zi, iaE, iwE00_lose, ip_o, tnext] += alpha * alphaW00_lose * proffer * prlose_stay * de
                                    DEnew[zi, iaE, iwE01_lose, ip_o, tnext] += alpha * alphaW01_lose * proffer * prlose_stay * de

                                    # For iaE_next
                                    # useful info about wages next period
                                    iwE10_win = wEwin_i[zi, iaE_next, iw, ip_o, itnew, ip_d]
                                    iwE11_win = min(iwE10_win + 1, nW - 1)
                                    alphaW10_win = wEwin_pi[zi, iaE_next, iw, ip_o, itnew, ip_d]
                                    alphaW11_win = 1 - alphaW10_win
                                    iwE10_lose = wElose_i[zi, iaE_next, iw, ip_o, itnew, ip_d]
                                    iwE11_lose = min(iwE10_lose + 1, nW - 1)
                                    alphaW10_lose = wElose_pi[zi, iaE_next, iw, ip_o, itnew, ip_d]
                                    alphaW11_lose = 1 - alphaW10_lose

                                    # relevant for switching probabilities
                                    prwin_switch_next = Prwin_switch[zi, iaE_next, iw, ip_o, itnew, ip_d]
                                    prwin_stay_next = Prwin_stay[zi, iaE_next, iw, ip_o, itnew, ip_d]
                                    prlose_switch_next = Prlose_switch[zi, iaE_next, iw, ip_o, itnew, ip_d]
                                    prlose_stay_next = Prlose_stay[zi, iaE_next, iw, ip_o, itnew, ip_d]

                                    # winning firm is on next rung and worker moves
                                    DEnew[zi, iaE_next, iwE10_win, ip_d, 0] += (1 - alpha) * alphaW10_win * proffer * prwin_switch_next * de
                                    DEnew[zi, iaE_next, iwE11_win, ip_d, 0] += (1 - alpha) * alphaW11_win * proffer * prwin_switch_next * de
                                    # winning firm is on current rung but worker moves to next rung
                                    DEnew[zi, iaE_next, iwE10_lose, ip_d, 0] += (1 - alpha) * alphaW10_lose * proffer * prlose_switch_next * de
                                    DEnew[zi, iaE_next, iwE11_lose, ip_d, 0] += (1 - alpha) * alphaW11_lose * proffer * prlose_switch_next * de
                                    # winning firm is on next rung but worker stays on current rung
                                    DEnew[zi, iaE_next, iwE10_win, ip_o, tnext] += (1 - alpha) * alphaW10_win * proffer * prwin_stay_next * de
                                    DEnew[zi, iaE_next, iwE11_win, ip_o, tnext] += (1 - alpha) * alphaW11_win * proffer * prwin_stay_next * de
                                    # winning firm is on current rung and worker stays on current rung
                                    DEnew[zi, iaE_next, iwE10_lose, ip_o, tnext] += (1 - alpha) * alphaW10_lose * proffer * prlose_stay_next * de
                                    DEnew[zi, iaE_next, iwE11_lose, ip_o, tnext] += (1 - alpha) * alphaW11_lose * proffer * prlose_stay_next * de
    return DEnew

# Update distribution modification for transition dynamics
## NUMBA VERSION                        
def forward_step_dmp_td(DU, DE, pol_i, pol_pi, w_i, w_pi, Inew, qswitch, lambdas, sigmaJ, sigmaslope, par):
    """Endogenous update part of forward_step_dmp"""
    nZ, nA, nW, nP, nT = DE.shape
    # separation and job-finding probabilities
    sigma = par['sigma']
    # level shift in unemployment probability
    sigma = sigma + (sigmaJ - sigma[-1])
    # slope change in unemployment probability
    sigma = sigma * (1 + sigmaslope)
    # accessible labor markets and transition matrices
    gU = par['gU']
    gE = par['gE']
    s = par['s']
    lmsU, lmsE, _ = labor_market_cache(par)

    # extracting relevant policy arrays
    aU_i = pol_i["aU"]
    aU_pi = pol_pi["aU"]
    aE_i = pol_i["aE"]
    aE_pi = pol_pi["aE"]
    wU_i = w_i["U"]
    wU_pi = w_pi["U"]
    wEwin_i = w_i["Ewin"]
    wEwin_pi = w_pi["Ewin"]
    wElose_i = w_i["Elose"]
    wElose_pi = w_pi["Elose"]

    # update distribution: all but case in which workers have opportunity to switch
    DUmid, DEmid1, DEmid2, DUEmid, DEEmid = dnext_step1(DU, DE, aE_i, aE_pi, aU_i, aU_pi, wU_i, wU_pi, lambdas, sigma, gU, lmsU, gE, lmsE, s, nZ, nA, nW, nP, nT, par['Pi'])
    # Hard-cded 2x2 Pi.T
    _PiT = par['Pi'].T
    _p00, _p01, _p10, _p11 = _PiT[0, 0], _PiT[0, 1], _PiT[1, 0], _PiT[1, 1]
    def _pit(X, shape):
        Xf = X.reshape(2,-1)
        Yf = np.empty_like(Xf)
        Yf[0] = _p00 * Xf[0] + _p01 * Xf[1]
        Yf[1] = _p10 * Xf[0] + _p11 * Xf[1]
        return Yf.reshape(shape)
    DUEnew = _pit(DUEmid, (nZ, nA, nP))
    DUnew = _pit(DUmid, (nZ, nA))
    DEmid = DEmid1 + _pit(DEmid2, (nZ, nA, nW, nP, nT))
    DEEnew = _pit(DEEmid, (nZ, nA, nW, nP, nT, nP))
    # update distribution: only case in which workers have opportunity to switch
    DEnew = dnext_step2(DE, Inew, qswitch, aE_i, aE_pi, wEwin_i, wEwin_pi, wElose_i, wElose_pi, lambdas, sigma, gE, lmsE, s, nZ, nA, nW, nP, nT, par['Pi'])
    # overall updated distributions
    DEnew += DEmid
    if par.get('check_distribution_mass', False):
        mass = np.sum(DUnew) + np.sum(DEnew)
        assert isclose(mass, 1, rel_tol=1e-9, abs_tol=0.0), 'Distribution function incorrect: total mass does not sum to 1, ' + str(mass)


    return DUnew, DEnew, DUEnew, DEEnew[:, :, :, :, 1:]

# Go to level for multiple shocks
def level_IRF(G, out, shock_list, di, ss_val, TT):
    irf_level = np.ones(TT) * ss_val
    for shock in shock_list:
        di_s = di[shock] - ss_val
        for t in range(TT):
            for s in range(TT):
                irf_ts = G[out][shock][t, s]
                irf_level[t] += irf_ts * di_s[s]

    return irf_level
