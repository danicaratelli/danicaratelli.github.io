import numpy as np
import os
import wagesUE_AOB
import wagesEE_AOB
import utils
from numba import njit
import time
import matplotlib.pyplot as plt


def _profile_add(profiler, key, dt):
    if profiler is None:
        return
    slot = profiler.setdefault(key, {'time': 0.0, 'calls': 0})
    slot['time'] += dt
    slot['calls'] += 1


# Household functions: iterations + distribution
def solveBells(r, tax, Z, par, lambdas, ib, beta_star, smm_index, transfer=0, itmax=10000, tol=1e-8, iprint = False,
               warm_start=None, profiler=None):
    t0 = time.perf_counter()
    # extracting relevant parameters
    nZ = par['nZ']
    nP = par['nP']
    nW = par['nW']
    nA = par['nA']
    nT = par['nT']
    w_grid = par['w_grid']
    p_grid = par['p_grid']
    z_grid = par['z_grid']
    a_grid = par['a_grid']
    bUI = par['bUI'][int(ib / 2)]

    # set beta according to ib
    beta = beta_star + par['dbeta'] * (ib - 1)
    if par.get('verbose_hh', False):
        print(beta)

    # Step 1: initial guess for consumption policies and value functions
    if warm_start is not None:
        cU = warm_start['cU']
        cE = warm_start['cE']
        U_p = warm_start['U']
        E_p = warm_start['E']
        E_bargaining_p = warm_start['E_bargaining']
        dU_p = warm_start['dU']
        dE_p = warm_start['dE']
        dE_bargaining_p = warm_start['dE_bargaining']
        J_p = warm_start['J']
        J_bargaining_p = warm_start['J_bargaining']
    elif os.path.exists('SS_b' + str(ib + 1) + '_' + str(smm_index) + '.npy'):
        with open('SS_b' + str(ib + 1) + '_' + str(smm_index) + '.npy', 'rb') as f:
            if par.get('verbose_hh', False):
                print("got it!")
            cU = np.load(f)
            cE = np.load(f)
            U_p = np.load(f)
            E_p = np.load(f)
            E_bargaining_p = np.load(f)
            dU_p = np.load(f)
            dE_p = np.load(f)
            dE_bargaining_p = np.load(f)
            J_p = np.load(f)
            J_bargaining_p = np.load(f)
    else:
        # print("did not get it!")
        cU = (bUI + 0.5 * (a_grid[np.newaxis, :] - a_grid[0])) * np.ones((nZ, 1))
        cE = (0.6 * w_grid[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]
              + 1.0 * z_grid[:, np.newaxis, np.newaxis, np.newaxis, np.newaxis]
              * (a_grid[np.newaxis, :, np.newaxis, np.newaxis, np.newaxis] - a_grid[0] + bUI)) * np.ones((nZ, 1, nW, nP, nT))
        U_p = utils.u(cU, par['eis'])
        E_p = utils.u(cE, par['eis'])
        E_bargaining_p = E_p[:,:,:,:,0, np.newaxis] * 1.05 ** np.arange(par['M'])[np.newaxis, np.newaxis, np.newaxis, np.newaxis, :]
        dE_p = utils.du(cE, par['eis'])
        dE_bargaining_p = dE_p[:, :, :, :, 0, np.newaxis] * 1.05 ** np.arange(par['M'])[np.newaxis, np.newaxis, np.newaxis, np.newaxis, :]
        dU_p = (1 + r) * utils.du(cU, par['eis'])
        dE_p = (1 + r) * utils.du(cE, par['eis'])
        J_p = ((z_grid[:, np.newaxis] * p_grid[np.newaxis, :])[:, np.newaxis, np.newaxis, :, np.newaxis]
                     - w_grid[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]) * np.ones((nZ, nA, nW, nP, nT)) * (1 - r) / (1 - par['sigma'][-1])
        J_bargaining_p = J_p[:,:,:,:,0, np.newaxis] * 0.95 ** np.arange(par['M'])[np.newaxis, np.newaxis, np.newaxis, np.newaxis, :]

    # Run until convergence
    itnum = 0
    dist = np.inf
    converged = False
    while (itnum < itmax) & (dist > tol):
        t_agent = time.perf_counter()
        dE_new, dE_bargaining_new, dU_new, E_new, E_bargaining_new, U_new, \
        cE_new, cU_new, J_new, J_bargaining_new, JU0, JE0, \
        qswitch, w_id, w_pi, Iswitch = agent_step(r, tax, Z, lambdas, U_p, E_p, E_bargaining_p, dU_p, dE_p, dE_bargaining_p, J_p, J_bargaining_p, par, beta, transfer, ib)
        _profile_add(profiler, 'agent_step', time.perf_counter() - t_agent)

        if iprint & (itnum % 100 == 0):
            dist = np.max([np.max(np.abs(U_new - U_p)), np.max(np.abs(E_new - E_p)), np.max(np.abs(E_bargaining_new - E_bargaining_p)),
                           np.max(np.abs(cU_new - cU)), np.max(np.abs(cE_new - cE)), np.max(np.abs(J_bargaining_new - J_bargaining_p)),
                           np.max(np.abs(J_new - J_p))])
            print('Iteration: ', itnum, 'Improvement: ', dist)
            print('U: ', np.max(np.abs(U_new - U_p)), ' E: ', np.max(np.abs(E_new - E_p)),
                  ' E_barg: ', np.max(np.abs(E_bargaining_new - E_bargaining_p)),
                  ' cU: ', np.max(np.abs(cU_new - cU)), ' cE: ', np.max(np.abs(cE_new - cE)),
                  ' J: ', np.max(np.abs(J_new - J_p)), ' J_barg: ', np.max(np.abs(J_bargaining_new - J_bargaining_p)))
        
        if itnum % 10 == 0:
            converged = (utils.within_tolerance(U_new, U_p, tol) and
                         utils.within_tolerance(E_new, E_p, tol) and
                         utils.within_tolerance(E_bargaining_new, E_bargaining_p, tol) and
                         utils.within_tolerance(cU_new, cU, tol) and
                         utils.within_tolerance(cE_new, cE, tol) and
                         utils.within_tolerance(J_bargaining_new, J_bargaining_p, tol) and
                     utils.within_tolerance(J_new, J_p, tol))

        # updating matrices
        U_p = U_new
        dU_p = dU_new
        E_p = E_new
        dE_p = dE_new
        E_bargaining_p = E_bargaining_new
        dE_bargaining_p = dE_bargaining_new
        cU = cU_new
        cE = cE_new
        J_p = J_new
        J_bargaining_p = J_bargaining_new
        itnum += 1
        if converged:
            break

    if not converged:
        raise ValueError(f'No convergence after {itmax} forward iterations!. Tol = {tol}')

    # Get asset policy functions
    aU_new = (1 + r) * a_grid[np.newaxis, :] + transfer + (1 - tax) * bUI - cU_new
    aE_new = (1 + r) * a_grid[np.newaxis, :, np.newaxis, np.newaxis, np.newaxis] + transfer + \
             (1 - tax) * w_grid[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis] - cE_new

    # # Beta back to original
    # par['beta'] = beta_star

    _profile_add(profiler, 'solveBells', time.perf_counter() - t0)
    warm_out = {
        'U': U_new, 'E': E_new, 'E_bargaining': E_bargaining_new,
        'dU': dU_new, 'dE': dE_new, 'dE_bargaining': dE_bargaining_new,
        'cU': cU_new, 'cE': cE_new, 'J': J_new, 'J_bargaining': J_bargaining_new,
    }

    return U_new, E_new, E_bargaining_new, dU_new, dE_new, dE_bargaining_new, cU_new, cE_new, aU_new, aE_new, J_new, \
           J_bargaining_new, JU0, JE0, w_id, w_pi, Iswitch, qswitch, warm_out

def agent_step(r, tax, Z, lambdas, U_p, E_p, E_bargaining_p, dU_p, dE_p, dE_bargaining_p, J_p, J_bargaining_p, par, beta, transfer, ib):
    # extracting relevant parameters
    # beta = par['beta']
    nZ = par['nZ']
    nP = par['nP']
    nW = par['nW']
    nT = par['nT']
    nA = par['nA']
    M = par['M']
    w_grid = par['w_grid']
    z_grid = par['z_grid']
    p_grid = par['p_grid']
    a_grid = par['a_grid']
    PiZ = par['Pi']
    gU = par['gU']
    gE = par['gE']
    s = par['s']
    bUI = par['bUI'][int(ib / 2)]

    # Accessible labor markets
    lmsU, lmsE, tnext = utils.labor_market_cache(par)

    # Useful changes
    sigma = par['sigma']
    sigma = sigma[np.newaxis, np.newaxis, np.newaxis, np.newaxis, :]
    rK = r + par['drate']       # rental rate of capital
    k_little = (rK / (par['alpha'] * Z)) ** (1 / (par['alpha'] - 1))    # capital per effective unit of labor
    
    # Step 2: compute values for unemployed agent
    # Step 2a: wages from unemployment
    UE_next, dUE_next, JU0, wU_idx, wU_pi = wagesUE_AOB.wageUE_AOB(U_p, E_bargaining_p, dE_p, J_bargaining_p, lmsU, par)

    # Step 2b: continuation values
    lam_gU = lambdas[0]
    Ucont = beta * (PiZ @ ((1 - lam_gU) * U_p + UE_next[:, :, 0] * lam_gU))
    dUcont = beta * (PiZ @ ((1 - lam_gU) * dU_p + dUE_next[:, :, 0] * lam_gU))

    # Step 2c: Endogenous grid method to derive updated consumption policy
    cU_next = utils.dinvu(dUcont, par['eis'])
    U_next = utils.u(cU_next, par['eis']) + Ucont
    aU_next = (cU_next + a_grid[np.newaxis, :] - (1 - tax) * bUI - transfer) / (1 + r)
    # Interpolate from the endogenous asset grid back to the fixed asset grid.
    aU_i, aU_pi = utils.interpolate_coord_sorted(aU_next, a_grid)
    U_new = utils.apply_coord(aU_i, aU_pi, U_next)
    cU_new = utils.apply_coord(aU_i, aU_pi, cU_next)

    # check for binding constraint
    iconst = (a_grid[:, np.newaxis] < aU_next[:, 0]).T
    for iz in range(nZ):
        if np.sum(iconst[iz]) > 0:
            cU_new[iz, iconst[iz]] = (1 + r) * a_grid[iconst[iz]] + (1 - tax) * bUI + transfer - a_grid[0]
            U_new[iz, iconst[iz]] = utils.u(cU_new[iz, iconst[iz]], par['eis']) + Ucont[iz, 0]
    # update marginal value for the unemployed
    dU_new = (1 + r) * utils.du(cU_new, par['eis'])

    # Step 3: compute values for employed agent
    # Step 3a: wages from employment to employment
    EE_next, dEE_next, J_incumbent, J_poacher, \
    wage_i, wage_i_loser, wage_pi, wage_pi_loser, \
    iscase, Iswitch, qswitch = wagesEE_AOB.wageEE_AOB(E_bargaining_p, dE_bargaining_p, E_p, dE_p, J_bargaining_p, J_p, lmsE, par)

    # Step 3b: continuation values
    # separate into unemployment or stick to current job
    gelam = (1 - s * gE @ lambdas)[np.newaxis, np.newaxis, np.newaxis, :, np.newaxis]
    Econt = sigma * U_p[:, :, np.newaxis, np.newaxis, np.newaxis] + (1 - sigma) * gelam * E_p[:, :, :, :, tnext]
    dEcont = sigma * dU_p[:, :, np.newaxis, np.newaxis, np.newaxis] + (1 - sigma) * gelam * dE_p[:, :, :, :, tnext] 
    # get offer from next rung
    for ip in range(nP - 1):
        slp1 = s * lambdas[ip + 1]
        Econt[:, :, :, ip, :] += (1 - sigma[:, :, :, 0, :]) * (EE_next[:, :, :, ip, tnext - 1, ip + 1] * slp1)
        dEcont[:, :, :, ip, :] += (1 - sigma[:, :, :, 0, :]) * (dEE_next[:, :, :, ip, tnext - 1, ip + 1] * slp1)

    # discount and expectation
    Econt = beta * (Econt.transpose() @ PiZ.transpose()).transpose()
    dEcont = beta * (dEcont.transpose() @ PiZ.transpose()).transpose()
    
    # print("Step 3c")
    # Step 3c: Endogenous grid method to derive updated consumption policy
    cE_next = utils.dinvu(dEcont, par['eis'])
    E_next = utils.u(cE_next, par['eis']) + Econt
    aE_next = (cE_next + a_grid[np.newaxis, :, np.newaxis, np.newaxis, np.newaxis]
               - (1 - tax) * w_grid[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis] - transfer) / (1 + r)
    # Interpolate from the endogenous asset grid back to the fixed asset grid.
    aE_next_t = np.moveaxis(aE_next, 1, -1)
    E_next_t = np.moveaxis(E_next, 1, -1)
    cE_next_t = np.moveaxis(cE_next, 1, -1)
    a_grid_t = np.broadcast_to(a_grid, aE_next_t.shape)
    aE_i, aE_pi = utils.interpolate_coord_sorted(aE_next_t, a_grid_t)
    E_new = np.moveaxis(utils.apply_coord(aE_i, aE_pi, E_next_t), -1, 1)
    cE_new = np.moveaxis(utils.apply_coord(aE_i, aE_pi, cE_next_t), -1, 1)
    iconst = (a_grid[:, np.newaxis, np.newaxis, np.newaxis, np.newaxis] < aE_next[:, 0, :, :, :]).swapaxes(0, 1)
    if iconst.any():
        cE_bc = ((1 + r) * a_grid[np.newaxis, :, np.newaxis, np.newaxis, np.newaxis] 
                 + (1 - tax) * w_grid[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]
                 + transfer - a_grid[0])
        cE_new = np.where(iconst, cE_bc, cE_new)
        E_new = np.where(iconst,
                         utils.u(cE_new, par['eis']) + Econt[:, 0:1, :, :, :],
                         E_new)
    dE_new = (1 + r) * utils.du(cE_new, par['eis'])
    
    # print("Step 3d")
    # Step 3d: Endogenous grid method to derive updated employment value for other bargaining sub-periods
    E_bargaining_tail = np.zeros((nZ, nA, nW, nP, M-1))
    dE_bargaining_tail = np.zeros((nZ, nA, nW, nP, M-1))
    E_next0_t = np.moveaxis(E_next[:, :, :, :, 0], 1, -1)
    cE_next0_t = np.moveaxis(cE_next[:, :, :, :, 0], 1, -1)
    # print("Step 3d - interpolation")
    for m in range(1, M, 1):
        aE_m = (cE_next[:, :, :, :, 0] + a_grid[np.newaxis, :, np.newaxis, np.newaxis]
                   - (1 - tax) * (((M - m) / M) * w_grid[np.newaxis, np.newaxis, :, np.newaxis]) - transfer) / (1 + r)
        # interpolate to fit asset grid
        # print("Step 3d - interpolation for real start")
        # E_m, cE_m = utils.interp2grid(aE_m.swapaxes(1, 3), par, E_next[:, :, :, :, 0].swapaxes(1, 3), cE_next[:, :, :, :, 0].swapaxes(1, 3))
        cE_m = np.zeros((nZ, nA, nW, nP))
        aE_m_t = np.moveaxis(aE_m, 1, -1)
        a_grid_m_t = np.broadcast_to(a_grid, aE_m_t.shape)
        aE_m_i, aE_m_pi = utils.interpolate_coord_sorted(aE_m_t, a_grid_m_t)
        E_bargaining_tail[:, :, :, :, m-1] = np.moveaxis(utils.apply_coord(aE_m_i, aE_m_pi, E_next0_t), -1, 1)
        cE_m[:, :, :, :] = np.moveaxis(utils.apply_coord(aE_m_i, aE_m_pi, cE_next0_t), -1, 1)
        # print("Step 3d - interpolation for real end")
        # cE_m = cE_m.swapaxes(1, 3)
        #E_bargaining[:, :, :, :, m-1] = E_m #.swapaxes(1, 3)
        iconst = (a_grid[:, np.newaxis, np.newaxis, np.newaxis] < aE_m[:, 0, :, :]).swapaxes(0, 1)
        if iconst.any():
            cE_m_bc = ((1+r) * a_grid[np.newaxis, :, np.newaxis, np.newaxis]
                       + (1 - tax) * ((M - m) / M) * w_grid[np.newaxis, np.newaxis, :, np.newaxis]
                       + transfer - a_grid[0])
            cE_m = np.where(iconst, cE_m_bc, cE_m)
            E_bargaining_tail[:, :, :, :, m-1] = np.where(
                        iconst,
                        utils.u(cE_m, par['eis']) + Econt[:, 0:1, :, :, 0],
                        E_bargaining_tail[:, :, :, :, m-1])
        dE_bargaining_tail[:, :, :, :, m-1] = (1 + r) * utils.du(cE_m, par['eis'])
    # append starting sub-period (CHECK THIS IS THE SAME AS LOOPING OVER 0:M)
    E_bargaining = np.empty((nZ, nA, nW, nP, M))
    dE_bargaining = np.empty((nZ, nA, nW, nP, M))
    E_bargaining[:, :, :, :, 0] = E_new[:, :, :, :, 0]
    dE_bargaining[:, :, :, :, 0] = dE_new[:, :, :, :, 0]
    E_bargaining[:, :, :, :, 1:] = E_bargaining_tail
    dE_bargaining[:, :, :, :, 1:] = dE_bargaining_tail

    # Get asset policy functions
    aE_new = (1 + r) * a_grid[np.newaxis, :, np.newaxis, np.newaxis, np.newaxis] + transfer + \
             (1 - tax) * w_grid[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis] - cE_new
    # interpolate assets
    aE_idx, aE_pi = utils.interpolate_coord_1d(par['a_grid'], aE_new)

    # print("Step 4")
    # J update
    # effective units of labor
    effZ = z_grid[:, np.newaxis, np.newaxis, np.newaxis, np.newaxis] * p_grid[np.newaxis, np.newaxis, np.newaxis, :, np.newaxis]
    # flow
    J_flow = (effZ * (Z * utils.f(k_little, par) - rK * k_little) - w_grid[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis])
    # continuation value
    J_cont = get_J_cont(J_p, J_incumbent, aE_pi, aE_idx, lambdas, tnext, PiZ, gE, s, nZ, nA, nW, nP, nT)
    # Total firm value
    J_new = J_flow + ((1 - sigma) / (1 + r)) * J_cont
    # Firm revenue in bargaining sub-periods
    J_bargaining_tail = np.zeros((nZ, nA, nW, nP, M-1))
    for m in range(1, M, 1):
        J_flow_m = ((M-m)/M) * J_flow[:, :, :, :, 0]
        J_bargaining_tail[:, :, :, :, m-1] = J_flow_m + ((1 - par['sigma'][0]) / (1 + r)) * J_cont[:, :, :, :, 0]
    # append starting sub-period
    J_bargaining = np.empty((nZ, nA, nW, nP, M))
    J_bargaining[:, :, :, :, 0] = J_new[:, :, :, :, 0]
    J_bargaining[:, :, :, :, 1:] = J_bargaining_tail

    w_idx = {'U': wU_idx, 'Ewin': wage_i, 'Elose': wage_i_loser}
    w_pi = {'U': wU_pi, 'Ewin': wage_pi, 'Elose': wage_pi_loser}


    return dE_new, dE_bargaining, dU_new, E_new, E_bargaining, U_new, cE_new, cU_new, J_new, J_bargaining, JU0, J_poacher, qswitch, w_idx, w_pi, Iswitch


@njit
def get_J_cont(J_p, J_incumbent, aE_pi, aE_idx, lambdas, tnext, PiZ, gE, s, nZ, nA, nW, nP, nT):
    # Exploit strict ladder: gE[ip_o, ip_o+1]=1;
    # s*lambdas@gE[ip_o] => s*lambdas[ip_o+1]; Pitmp@(s*lambdas*gE_o) => Pitmp[:,ip_o+1]*s*lambdas[ip_o+1]
    J_cont = np.zeros((nZ, nA, nW, nP, nT))
    for iz in range(nZ):
        piz = PiZ[iz, :]
        for ia in range(nA):
            for iw in range(nW):
                for ip_o in range(nP):
                    has_next = ip_o < nP - 1
                    lam_next = s * lambdas[ip_o + 1] if has_next else 0.0
                    ip1 = ip_o + 1 if has_next else 0  # dummy index for top rung
                    for it in range(nT):
                        ia0 = aE_idx[iz, ia, iw, ip_o, it]
                        ia1 = min(ia0 + 1, nA - 1)
                        alpha = aE_pi[iz, ia, iw, ip_o, it]
                        Jpinterp = (alpha * J_p[:, ia0, iw, ip_o, tnext[it]]
                                    + (1 - alpha) * J_p[:, ia1, iw, ip_o, tnext[it]])
                        J_cont[iz, ia, iw, ip_o, it] = piz @ Jpinterp * (1.0 - lam_next)
                        if has_next:
                            Jiinterp = (alpha * J_incumbent[:, ia0, iw, ip_o, tnext[it] - 1, ip1]
                                        + (1 - alpha) * J_incumbent[:, ia1, iw, ip_o, tnext[it] - 1, ip1])
                            J_cont[iz, ia, iw, ip_o, it] += piz @ Jiinterp * lam_next

    return J_cont

# For transition dynamics
def agent_step_td(r_post, rK, r, tax, Z, lambdas, bUI, sigmaJ, sigmaslope, U_p, E_p, E_bargaining_p, dE_bargaining_p, dU_p, dE_p, J_p, J_bargaining_p, par, transfer):
    # extracting relevant parameters
    beta = par['beta']
    nZ = par['nZ']
    nP = par['nP']
    nW = par['nW']
    nT = par['nT']
    nA = par['nA']
    M = par['M']
    w_grid = par['w_grid']
    z_grid = par['z_grid']
    p_grid = par['p_grid']
    a_grid = par['a_grid']
    PiZ = par['Pi']
    gU = par['gU']
    gE = par['gE']
    s = par['s']

    # accessible labor markets
    lmsU, lmsE, tnext = utils.labor_market_cache(par)

    # Useful changes
    sigma = par['sigma']
    # level shift in unemployment probability
    sigma = sigma + (sigmaJ - sigma[-1])
    # slope change in unemployment probability
    sigma = sigma * (1 + sigmaslope)
    sigma = sigma[np.newaxis, np.newaxis, np.newaxis, np.newaxis, :]
    k_little = (rK / (par['alpha'] * Z)) ** (1 / (par['alpha'] - 1))    # capital per effective unit of labor

    # Step 2: compute values for unemployed agent
    # Step 2a: wages from unemployment
    UE_next, dUE_next, JU0, wU_idx, wU_pi = wagesUE_AOB.wageUE_AOB(U_p, E_bargaining_p, dE_p, J_bargaining_p, lmsU, par)

    # Step 2b: continuation values
    # finding the derivative of the value function upon employment = beta * (1+r) * E[dE_p(:,(1+r)a,w,p)]
    lam_gU = lambdas[0]
    Ucont = beta * (PiZ @ ((1 - lam_gU) * U_p + UE_next[:, :, 0] * lam_gU))
    dUcont = beta * (PiZ @ ((1 - lam_gU) * dU_p + dUE_next[:, :, 0] * lam_gU))

    # Step 2c: Endogenous grid method to derive updated consumption policy
    cU_next = utils.dinvu(dUcont, par['eis'])
    aU_next = (cU_next + a_grid[np.newaxis, :] - (1 - tax) * bUI - transfer) / (1 + r_post)
    U_next = utils.u(cU_next, par['eis']) + Ucont
    # interpolate to fit asset grid
    # U_new, cU_new = utils.interp2grid(aU_next, par, U_next, cU_next)        
    U_new = np.zeros((nZ, nA))
    cU_new = np.zeros((nZ, nA))
    for iz in range(nZ):        
        U_new[iz, :], cU_new[iz, :] = utils.interp2grid(aU_next[iz, :], par, U_next[iz, :], cU_next[iz, :])

    # check for binding constraint
    iconst = (a_grid[:, np.newaxis] < aU_next[:, 0]).T
    for iz in range(nZ):
        if np.sum(iconst[iz]) > 0:
            cU_new[iz, iconst[iz]] = (1 + r_post) * a_grid[iconst[iz]] + (1 - tax) * bUI + transfer - a_grid[0]
            U_new[iz, iconst[iz]] = utils.u(cU_new[iz, iconst[iz]], par['eis']) + Ucont[iz, 0]

    # update marginal value for the unemployed
    # dU_new = (1 + r_post) * utils.du(cU_new, par['eis'])

    # Step 3: compute values for employed agent
    # Step 3a: wages from employment to employment
    EE_next, dEE_next, J_incumbent, J_poacher, \
    wage_i, wage_i_loser, wage_pi, wage_pi_loser, \
    iscase, Iswitch, qswitch = wagesEE_AOB.wageEE_AOB(E_bargaining_p, dE_bargaining_p, E_p, dE_p, J_bargaining_p, J_p, lmsE, par)

    # Step 3b: continuation values
    # separate into unemployment or stick to current job
    gelam = (1 - s * gE @ lambdas)[np.newaxis, np.newaxis, np.newaxis, :, np.newaxis]
    Econt = sigma * U_p[:, :, np.newaxis, np.newaxis, np.newaxis] + (1 - sigma) * gelam * E_p[:, :, :, :, tnext]
    dEcont = sigma * dU_p[:, :, np.newaxis, np.newaxis, np.newaxis] + (1 - sigma) * gelam * dE_p[:, :, :, :, tnext]
    # get offer from next rung (only possible if not already at top of ladder and not with tenure 0)
    for ip in range(nP-1):
        slp1 = s * lambdas[ip + 1]
        Econt[:, :, :, ip, :] += (1 - sigma[:, :, :, 0, :]) * (EE_next[:, :, :, ip, tnext - 1, ip + 1] * slp1)
        dEcont[:, :, :, ip, :] += (1 - sigma[:, :, :, 0, :]) * (dEE_next[:, :, :, ip, tnext - 1, ip + 1] * slp1)

    # discount and expectation
    Econt = beta * (Econt.transpose() @ PiZ.transpose()).transpose()
    dEcont = beta * (dEcont.transpose() @ PiZ.transpose()).transpose()

    # Step 3c: Endogenous grid method to derive updated consumption policy
    cE_next = utils.dinvu(dEcont, par['eis'])
    aE_next = (cE_next + a_grid[np.newaxis, :, np.newaxis, np.newaxis, np.newaxis]
               - (1 - tax) * w_grid[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis] - transfer) / (1 + r_post)
    E_next = utils.u(cE_next, par['eis']) + Econt
    # interpolate to fit asset grid
    E_new = np.zeros((nZ, nA, nW, nP, nT))
    cE_new = np.zeros((nZ, nA, nW, nP, nT))
    for iz in range(nZ):        
        for iw in range(nW):
            for ip in range(nP):
                for it in range(nT):
                    E_new[iz, :, iw, ip, it], cE_new[iz, :, iw, ip, it] = utils.interp2grid(aE_next[iz, :, iw, ip, it], par, E_next[iz, :, iw, ip, it], cE_next[iz, :, iw, ip, it])
    # E_new, cE_new = utils.interp2grid(aE_next.swapaxes(1, 4), par, E_next.swapaxes(1, 4), cE_next.swapaxes(1, 4))
    # cE_new = cE_new.swapaxes(1, 4)
    # E_new = E_new.swapaxes(1, 4)
    iconst = (a_grid[:, np.newaxis, np.newaxis, np.newaxis, np.newaxis] < aE_next[:, 0, :, :, :]).swapaxes(0, 1)
    if iconst.any():
        cE_bc = ((1 + r_post) * a_grid[np.newaxis, :, np.newaxis, np.newaxis, np.newaxis] 
                 + (1 - tax) * w_grid[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]
                 + transfer - a_grid[0])
        cE_new = np.where(iconst, cE_bc, cE_new)
        E_new = np.where(iconst,
                         utils.u(cE_new, par['eis']) + Econt[:, 0:1, :, :, :],
                         E_new)
    # THINK WHETHER THIS IS r or r_post
    dE_new = (1 + r) * utils.du(cE_new, par['eis'])

    # Step 3d: Endogenous grid method to derive updated employment value for other bargaining sub-periods
    E_bargaining_new = np.zeros((nZ, nA, nW, nP, M-1))
    dE_bargaining_new = np.zeros((nZ, nA, nW, nP, M-1))
    for m in range(1, M, 1):
        aE_m = (cE_next[:, :, :, :, 0] + a_grid[np.newaxis, :, np.newaxis, np.newaxis]
                   - (1 - tax) * (((M - m) / M) * w_grid[np.newaxis, np.newaxis, :, np.newaxis]) - transfer) / (1 + r_post)
        # interpolate to fit asset grid
        cE_m = np.zeros((nZ, nA, nW, nP))
        for iz in range(nZ):
            for ip in range(nP):
                for iw in range(nW):
                    #E_m[nZ, :, n], cE_m = utils.interp2grid(aE_m[iz, :, iw, ip], par, E_next[iz, :, iw, ip, 0], cE_next[iz, :, iw, ip, 0])
                    E_bargaining_new[iz, :, iw, ip, m-1], cE_m[iz, :, iw, ip] = utils.interp2grid(aE_m[iz, :, iw, ip], par, E_next[iz, :, iw, ip, 0], cE_next[iz, :, iw, ip, 0])
        # E_m, cE_m = utils.interp2grid(aE_m.swapaxes(1, 3), par, E_next[:, :, :, :, 0].swapaxes(1, 3), cE_next[:, :, :, :, 0].swapaxes(1, 3))
        # cE_m = cE_m.swapaxes(1, 3)
        # E_bargaining_new[:, :, :, :, m-1] = E_m.swapaxes(1, 3)
        iconst = (a_grid[:, np.newaxis, np.newaxis, np.newaxis] < aE_m[:, 0, :, :]).swapaxes(0, 1)
        if iconst.any():
            cE_m_bc = ((1+r) * a_grid[np.newaxis, :, np.newaxis, np.newaxis]
                       + (1 - tax) * ((M - m) / M) * w_grid[np.newaxis, np.newaxis, :, np.newaxis]
                       + transfer - a_grid[0])
            cE_m = np.where(iconst, cE_m_bc, cE_m)
            E_bargaining_new[:, :, :, :, m-1] = np.where(
                        iconst,
                        utils.u(cE_m, par['eis']) + Econt[:, 0:1, :, :, 0],
                        E_bargaining_new[:, :, :, :, m-1])
        dE_bargaining_new[:, :, :, :, m-1] = (1 + r) * utils.du(cE_m, par['eis'])
    # append starting sub-period
    E_bargaining_new = np.append(E_new[:, :, :, :, 0, np.newaxis], E_bargaining_new, axis=4)
    dE_bargaining_new = np.append(dE_new[:, :, :, :, 0, np.newaxis], dE_bargaining_new, axis=4)

    # Get asset policy functions
    aE_new = (1 + r_post) * a_grid[np.newaxis, :, np.newaxis, np.newaxis, np.newaxis] + transfer + \
             (1 - tax) * w_grid[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis] - cE_new
    # interpolate assets
    aE_idx, aE_pi = utils.interpolate_coord_1d(par['a_grid'], aE_new)

    # J update
    # effective units of labor
    effZ = z_grid[:, np.newaxis, np.newaxis, np.newaxis, np.newaxis] * p_grid[np.newaxis, np.newaxis, np.newaxis, :, np.newaxis]
    # flow
    J_flow = (effZ * (Z * utils.f(k_little, par) - rK * k_little) - w_grid[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis])
    # continuation value
    J_cont = get_J_cont(J_p, J_incumbent, aE_pi, aE_idx, lambdas, tnext, PiZ, gE, s, nZ, nA, nW, nP, nT)
    # Total firm value
    J_new = J_flow + ((1 - sigma) / (1 + r)) * J_cont
    # Firm revenue in bargaining sub-periods
    J_bargaining_new = np.zeros((nZ, nA, nW, nP, M - 1))
    for m in range(1, M, 1):
        J_flow_m = ((M - m) / M) * J_flow[:, :, :, :, 0]
        J_bargaining_new[:, :, :, :, m - 1] = J_flow_m + ((1 - par['sigma'][0]) / (1 + r)) * J_cont[:, :, :, :, 0]
    # append starting sub-period
    J_bargaining_new = np.append(J_new[:, :, :, :, 0, np.newaxis], J_bargaining_new, axis=4)

    w_idx = {'U': wU_idx, 'Ewin': wage_i, 'Elose': wage_i_loser}
    w_pi = {'U': wU_pi, 'Ewin': wage_pi, 'Elose': wage_pi_loser}

    return E_new, E_bargaining_new, dE_bargaining_new, U_new, cE_new, cU_new, J_new, J_bargaining_new, JU0, J_poacher, qswitch, w_idx, w_pi, Iswitch


def _anderson_mix(x_hist, gx_hist):
    """One Anderson(m) mixing step.

    x_hist  : list of the last m iterates x_{n-m+1}, ..., x_n  (flat vectors)
    gx_hist : corresponding G(x) values (flat vectors)

    Returns the Anderson-mixed next iterate x_{n+1} as a flat vector.
    Uses the "type-1" formulation: solve the constrained LS
        min_{c: sum c_i = 1} || sum c_i * (G(x_i) - x_i) ||^2
    then return sum c_i * G(x_i).
    """
    k = len(x_hist)
    if k == 1:
        return gx_hist[0].copy()

    # Residual matrix F, columns = G(x_i) - x_i
    F = np.column_stack([g - x for x, g in zip(x_hist, gx_hist)])  # (n, k)

    # Reduce to unconstrained: c = [theta; 1 - sum(theta)] with theta in R^{k-1}
    # min || (F[:,:-1] - F[:,-1:]) @ theta + F[:,-1] ||^2
    Ftil = F[:, :-1] - F[:, -1:]   # (n, k-1)
    rhs = -F[:, -1]                # (n,)

    # Tikhonov regularisation for numerical safety
    lam = 1e-10 * max(np.linalg.norm(Ftil) ** 2 / max(k - 1, 1), 1e-30)
    A = Ftil.T @ Ftil + lam * np.eye(k - 1)
    b = Ftil.T @ rhs
    try:
        theta = np.linalg.solve(A, b)
    except np.linalg.LinAlgError:
        return gx_hist[-1].copy()

    c = np.append(theta, 1.0 - theta.sum())

    # Convex combination of G(x_i) values
    out = np.zeros_like(gx_hist[0])
    for ci, gxi in zip(c, gx_hist):
        out += ci * gxi
    return out

def update_dist(aU, aE, w_i, w_pi, Inew, qswitch, lambdas, par, ib, smm_index, itmax = 10000, tol = 1e-9, iprint = False,
                warm_dist=None, profiler=None):
    t0 = time.perf_counter()
    # initialize distribution uniformly for unemployed and employed
    if warm_dist is not None:
        DU = warm_dist['DU']
        DE = warm_dist['DE']
    elif os.path.exists('distributions_b' + str(ib + 1) + '_' + str(smm_index) + '.npy'):
        with open('distributions_b' + str(ib + 1) + '_' + str(smm_index) + '.npy', 'rb') as f:
            if par.get('verbose_hh', False):
                print("got it!")
            DU = np.load(f)
            DE = np.load(f)
    else:
        DU = np.zeros((par['nZ'], par['nA']))
        DE = np.zeros((par['nZ'], par['nA'], par['nW'], par['nP'], par['nT']))
        DU[:, 0] = 1 / par['nZ']

    # interpolate assets
    aU_i, aU_pi = utils.interpolate_coord_1d(par['a_grid'], aU)
    aE_i, aE_pi = utils.interpolate_coord_1d(par['a_grid'], aE)
    pol_i = {'aU': aU_i, 'aE': aE_i}
    pol_pi = {'aU': aU_pi, 'aE': aE_pi}

    # Anderson(m) acceleration
    anderson_m = par.get('dist_anderson_m', 5)
    
    du_shape = DU.shape
    de_shape = DE.shape
    du_size = DU.size

    def _flatten(Du, De):
        return np.concatenate([Du.ravel(), De.ravel()])
    
    def _unflatten(x):
        Du = x[:du_size].reshape(du_shape)
        De = x[du_size:].reshape(de_shape)
        return Du, De
    
    x_hist = []
    gx_hist = []
    DUE = DEE = None

    # iterate until convergence by tol, or itmax
    for it in range(itmax):
        DUnnew, DEnnew, DUE, DEE = utils.forward_step_dmp(
            DU, DE, pol_i, pol_pi, w_i, w_pi, Inew, qswitch, lambdas, par)

        if utils.within_tolerance(DU, DUnnew, tol) and utils.within_tolerance(DE, DEnnew, tol):
            DU, DE = DUnnew, DEnnew
            break

        if iprint and (it % 150 == 0):
            print('Iteration: ', it, 'Improvement: ',
                np.max(np.abs(DUnnew - DU)) + np.max(np.abs(DEnnew - DE)))

        if anderson_m > 0:
            # Accumulate history (rolling window of depth m)
            x_hist.append(_flatten(DU, DE))
            gx_hist.append(_flatten(DUnnew, DEnnew))
            if len(x_hist) > anderson_m:
                x_hist.pop(0)
                gx_hist.pop(0)

            x_next = _anderson_mix(x_hist, gx_hist)
            DU, DE = _unflatten(x_next)
            # Distributions must be non-negative and sum to 1
            np.clip(DU, 0.0, None, out=DU)
            np.clip(DE, 0.0, None, out=DE)
            total = DU.sum() + DE.sum()
            if total > 0:
                DU /= total
                DE /= total
        else:
            DU, DE = DUnnew, DEnnew
    else:
        raise ValueError(f'No convergence after {itmax} Anderson iterations!')

    _profile_add(profiler, 'update_dist', time.perf_counter() - t0)
    return DUnnew, DEnnew, DUE, DEE

def solveHH(args, transfer = 0, warm_start=None, profiler=None, bellman_tol=1e-7, dist_tol=1e-9):
    t0 = time.perf_counter()
    r, tax, Z, par, lambdas, ib, smm_index = args
    beta_star = par['beta']
    # policy iteration
    U, E, E_bargaining, dU, dE, dE_bargaining, cU, cE, aU, aE, J, J_bargaining,\
    JU0, JE0, w_i, w_pi, Inew, qswitch, warm_policy = solveBells(
        r, tax, Z, par, lambdas, ib, beta_star, smm_index, transfer, 10000, bellman_tol, False,
        warm_start=warm_start.get('policy') if warm_start else None, profiler=profiler
    )
    # distribution
    DU, DE, DUE, DEE = update_dist(
        aU, aE, w_i, w_pi, Inew, qswitch, lambdas, par, ib, smm_index, 15000, dist_tol, False,
        warm_dist=warm_start.get('dist') if warm_start else None, profiler=profiler
    )
    # file1 = open('myfile.txt', 'a')
    # file1.write('\n')
    # file1.write(f'Max asset policy = {np.max((DE > 0) * aE)}')
    # file1.close()
    if par.get('verbose_hh', False):
        print('Max asset policy = ', np.max((DE > 0) * aE))
        print('\n')

    _profile_add(profiler, 'solveHH', time.perf_counter() - t0)
    return U, E, E_bargaining, dU, dE, dE_bargaining, cU, cE, J, J_bargaining, JU0, JE0, DU, DE, DUE, DEE, qswitch, w_i, w_pi, Inew, {
        'policy': warm_policy,
        'dist': {'DU': DU, 'DE': DE}
    }


# def solveHH_step1(args, transfer = 0):
#     r, tax, Z, par, lambdas, ib = args
#     # policy iteration
#     U, E, E_bargaining, dU, dE, dE_bargaining, cU, cE, aU, aE, J, J_bargaining,\
#     JU0, JE0, w_i, w_pi, Inew, qswitch = solveBells(r, tax, Z, par, lambdas, ib, transfer, 10000, 1e-6, False)


#     return U, E, E_bargaining, dU, dE, dE_bargaining, cU, cE, aU, aE, J, J_bargaining, JU0, JE0, w_i, w_pi, Inew, qswitch


# def solveHH_step2(args, args_policy, transfer = 0):
#     r, tax, Z, par, lambdas, ib = args
#     U, E, E_bargaining, dU, dE, dE_bargaining, cU, cE, aU, aE, J, J_bargaining,\
#     JU0, JE0, w_i, w_pi, Inew, qswitch = args_policy
    
#     # update distribution
#     DU, DE, DUE, DEE = update_dist(aU, aE, w_i, w_pi, Inew, qswitch, lambdas, par, ib, 15000, 1e-9, False)
#     # file1 = open('myfile.txt', 'a')
#     # file1.write('\n')
#     # file1.write(f'Max asset policy = {np.max((DE > 0) * aE)}')
#     # file1.close()
#     print('Max asset policy = ', np.max((DE > 0) * aE))
#     print('\n')

#     return DU, DE, DUE, DEE
