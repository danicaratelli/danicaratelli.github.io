import numpy as np

def build_asset_grid(amin, amax, nA):
    """Build the asset grid used in the household problem."""
    return np.sinh(np.linspace(np.arcsinh(amin), np.arcsinh(amax), nA))

def get_par(input, inaive=False):
    zlow = input['zlow']
    Pi11 = input['Pi11']
    zeta = input['zeta']
    # p1 = input['p1']
    # p2 = input['p2']
    # p3 = input['p3']
    # p4 = input['p4']
    # p5 = input['p5']
    # p6 = input['p6']
    # p7 = input['p7']
    # p8 = input['p8']
    poly1 = input['poly1']
    poly2 = input['poly2']
    poly3 = input['poly3']
    poly4 = input['poly4']
    def fpoly(n):
        return (n-4) * (poly1 + poly2 * n + poly3 * n**2 + poly4 * n**3)
    p1, p2, p3, p4, p5, p6, p7, p8 = fpoly(np.array([1, 2, 3, 4, 5, 6, 7, 8]))
    s = input['s']
    sigma0 = input['sigma0']
    dbeta = input['dbeta']
    chi = input['chi']
    
    # Define grid dimensions
    par = dict()
    # Preserve the authoritative calibration schema so a steady state built
    # from this parameter dictionary is self-contained for transition code.
    par['inputs'] = dict(input)
    par['nA'] = 150  # number of asset possibilities
    par['nZ'] = 2  # number of idio productivities
    par['nB'] = 2  # number of beta types
    par['nP'] = 8  # number of ladder rungs
    par['nT'] = 6  # number of tenure spots
    par['nW'] = 15  # number of wage spots

    # Steady State variable values
    # Preference
    par['eis'] = 1 / 2  # elasticity of intra-temporal substitution
    par['EValpha'] = 100.  # EV scale parameter
    par['varphi'] = 1.  # disutility of labor
    par['nu'] = 1.  # inverse Frisch
    # Production
    par['drate'] = 0.025  # capital depreciation rate
    par['epsI'] = 4.  # capital adjustment parameter
    # ***  Set up grids ***
    # liquid assets
    par['amax'] = 2500.
    par['amin'] = 1e-6

    # Define grids
    # assets
    par['a_grid'] = build_asset_grid(par['amin'], par['amax'], par['nA'])
    # idiosyncratic productivity states
    par['z_grid'] = np.exp([zlow, -zlow])
    par['Pi'] = np.array([[Pi11, 1-Pi11], [1-Pi11, Pi11]])
    # match-specific productivity states
    par['p_grid'] = np.exp(np.array([p1, p2, p3, p4, p5, p6, p7, p8]))

    # Labor market
    par['eta'] = 2 / 3  # matching function elasticity (Shimer 2005)
    par['chi'] = chi  # scale parameter in matching function (to match job-finding rate)
    par['s'] = s
    # added quarters 5-8 to the first to account for the fact that I cannot separate for a whole quarter
    if inaive:
        par['sigma'] = sigma0 * np.ones(par['nT'])
    else:
        par['sigma'] = sigma0 + np.array([0.034658580405289, 0.011597533122565, 0.0083209846867160, 0.0074163134821540, 0.0056355458861450, 0])        
    par['bUI'] = np.ones(par['nB']) * input['bUI']  # unemployment benefits
    par['zeta'] = zeta
    par['zeta_curv'] = 1.4

    # Transition matrices
    par['gU'] = np.zeros(par['nP'])
    par['gU'][0] = 1
    par['gE'] = np.zeros((par['nP'], par['nP']))
    for ip in range(par['nP']-1):
        par['gE'][ip, ip+1] = 1

    # wage grid
    par['w_grid'] = np.exp(np.linspace(np.log(np.min(par['bUI'])), np.log(13), par['nW']))

    # production
    par['alpha'] = 0.3

    # Solve Worker's Problem
    par['beta'] = 0.97
    par['dbeta'] = dbeta
    par['M'] = 3

    par['Z'] = 1  # steady state productivity

    return par
