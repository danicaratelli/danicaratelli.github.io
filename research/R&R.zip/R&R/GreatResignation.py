# This file has all functions to help with the Great Resignation experiment
import numpy as np
import utils
import Jac_help
import matplotlib.pyplot as plt

def findshocks_GResignation(G, data_path, transfer_path, UI_path, ishock, rhox, TT):
    Ndata = len(data_path)
    # Define objective function
    x0 = np.zeros(Ndata)
    transfer_path_xl = np.zeros(TT)
    transfer_path_xl[0:Ndata] = transfer_path
    UI_path_xl = np.zeros(TT)
    UI_path_xl[0:Ndata] = UI_path
    def obj_fun(x):
        x_xl = np.append(x[:-1], x[-1] * (rhox ** np.arange(TT + 1 - len(x0))))
        irf = (G['EE_rate'][ishock] @ x_xl) + (G['EE_rate']['transfer'] @ transfer_path_xl) + (G['EE_rate']['bUI'] @ UI_path_xl)
        res = (data_path - irf[:Ndata])

        return res
    xstar, _ = utils.broyden_solver(obj_fun, x0, noisy=False, tol=1e-9, maxcount=1000)
    xstar = np.append(xstar[:-1], xstar[-1] * (rhox ** np.arange(TT + 1 - len(x0))))

    return xstar

def GResignation(G, data_path, transfer_path, UI_path, ishock, rhox, TT):
    # find shock to mimic great resignation
    data_head = data_path[:1]
    shock_path = findshocks_GResignation(G, data_path[1:], transfer_path, UI_path, ishock, rhox, TT)
    # paths for TT
    shock_path = np.append(shock_path, np.zeros(TT - len(shock_path)))
    UI_path = np.append(UI_path, np.zeros(TT - len(UI_path)))
    transfer_path = np.append(transfer_path, np.zeros(TT - len(transfer_path)))
    #Ndata = len(data_path[1:])

    # EE variables
    EE_notransfer = np.append(data_head,(G['EE_rate'][ishock] @ shock_path) + (G['EE_rate']['bUI'] @ UI_path))
    EE_noUI = np.append(data_head, (G['EE_rate'][ishock] @ shock_path) + (G['EE_rate']['transfer'] @ transfer_path))
    EE_nonothing = np.append(data_head, (G['EE_rate'][ishock] @ shock_path))

    # Output
    Y_path = np.append(data_head, (G['Y'][ishock] @ shock_path) + (G['Y']['bUI'] @ UI_path) + (G['Y']['transfer'] @ transfer_path))

    # Unemployment
    U_path = np.append(data_head, (G['U'][ishock] @ shock_path) + (G['U']['bUI'] @ UI_path) + (G['U']['transfer'] @ transfer_path))

    # Assets
    A_path = np.append(data_head, (G['A'][ishock] @ shock_path) + (G['A']['bUI'] @ UI_path) + (G['A']['transfer'] @ transfer_path))

    return shock_path, EE_notransfer, EE_noUI, EE_nonothing, Y_path, U_path, A_path

# def GResignation_dist(G, shock_path, transfer_path, UI_path, ishock, par, ss, TT):
#     assert ishock=='Z', 'Need to correct shock'
#     # prepare fiscal stimulus shocks
#     Z_path = shock_path + ss['Z']
#
#     # Compute EE by H and L wealth in each scenario
#     EEL = np.zeros((TT, 4))
#     EEH = np.zeros((TT, 4))
#     EE_all = np.zeros((TT, 4))
#
#     for k in range(1):
#         if k == 0:    # both UI and checks
#             bUI_path = np.append(UI_path, np.zeros(TT - len(UI_path))) + ss['bUI']
#             tran_path = np.append(transfer_path, np.zeros(TT - len(transfer_path))) + ss['transfer']
#         elif k == 1:     # no UI but checks
#             bUI_path = np.append(UI_path, np.zeros(TT - len(UI_path))) + ss['bUI']
#             tran_path = np.zeros(TT) + ss['transfer']
#         elif k == 2:  # no checks but UI
#             bUI_path = np.zeros(TT) + ss['bUI']
#             tran_path = np.append(transfer_path, np.zeros(TT - len(transfer_path))) + ss['transfer']
#         elif k == 3:  # no checks no UI
#             bUI_path = np.zeros(TT) + ss['bUI']
#             tran_path = np.zeros(TT) + ss['transfer']
#
#         # shock
#         di = dict()
#         di['Z'] = shock_path
#         di['bUI'] = (bUI_path - ss['bUI'])
#         di['transfer'] = tran_path
#         shock_list = ['Z', 'bUI', 'transfer']
#
#         # all other relevant paths
#         sigmaJ_path = np.ones(TT) * ss['sigmaJ']
#         sigmaslope_path = np.ones(TT) * ss['sigmaslope']
#         ra_path = utils.level_IRF(G, 'ra', shock_list, di, ss['ra'], TT)
#         r_path = utils.level_IRF(G, 'r', shock_list, di, ss['r'], TT)
#         rK_path = utils.level_IRF(G, 'rK', shock_list, di, ss['rK'], TT)
#         tax_path = utils.level_IRF(G, 'tax', shock_list, di, ss['tax'], TT)
#         lambdas_path = np.ones((TT, par['nP'])) * ss['lambdas'][np.newaxis, :]
#         for ip in range(par['nP']):
#             lambdas_path[:, ip] = utils.level_IRF(G, 'lambda' + str(ip), shock_list, di, ss['lambdas'][ip], TT)
#
#         # Distributions along transitions
#         QE_path = np.zeros(ss['QEss'].shape + (TT+1,))
#         QE_path[:, :, :, :, :, :, 0] = ss['QEss']
#         QEE_path = np.zeros(ss['QEEss'].shape + (TT+1,))
#         QEE_path[:, :, :, :, :, :, 0] = ss['QEEss']
#         QU_path = np.zeros(ss['QUss'].shape + (TT+1,))
#         QU_path[:, :, :, 0] = ss['QUss']
#         # Policies along transitions
#         CE_path = np.zeros(ss['CEss'].shape + (TT+1,))
#         CE_path[:, :, :, :, :, :, -1] = ss['CEss']
#         CU_path = np.zeros(ss['CUss'].shape + (TT+1,))
#         CU_path[:, :, :, -1] = ss['CUss']
#         AE_path = np.zeros(ss['AEss'].shape + (TT+1,))
#         AE_path[:, :, :, :, :, :, -1] = ss['AEss']
#         AU_path = np.zeros(ss['AUss'].shape + (TT+1,))
#         AU_path[:, :, :, -1] = ss['AUss']
#         U_old = ss['Uss']
#         E_old = ss['Ess']
#         J_old = ss['Jss']
#         WEwinpi_path = np.zeros(ss['WEwinpiss'].shape + (TT+1,))
#         WEwinpi_path[:, :, :, :, :, :, -1] = ss['WEwinpiss']
#         WEwini_path = np.zeros(ss['WEwiniss'].shape + (TT+1,), dtype='uint32')
#         WEwini_path[:, :, :, :, :, :, -1] = ss['WEwiniss']
#         WElosepi_path = np.zeros(ss['WElosepiss'].shape + (TT+1,))
#         WElosepi_path[:, :, :, :, :, :, -1] = ss['WElosepiss']
#         WElosei_path = np.zeros(ss['WEloseiss'].shape + (TT+1,), dtype='uint32')
#         WElosei_path[:, :, :, :, :, :, -1] = ss['WEloseiss']
#         WUpi_path = np.zeros(ss['WUpiss'].shape + (TT+1,))
#         WUpi_path[:, :, :, -1] = ss['WUpiss']
#         WUi_path = np.zeros(ss['WUiss'].shape + (TT+1,), dtype='uint32')
#         WUi_path[:, :, :, -1] = ss['WUiss']
#         Iwins_path = np.zeros(ss['Iwins'].shape + (TT+1,))
#         Iwins_path[:, :, :, :, :, :, -1] = ss['Iwins']
#         qs_path = np.zeros(ss['qss'].shape + (TT+1,))
#         qs_path[:, :, :, :, :, :, -1] = ss['qss']
#
#         # append to lambdas and sigmaJ
#         lambdas_path = np.vstack([ss['lambdas'], lambdas_path])
#         sigmaJ_path = np.append(ss['sigmaJ'], sigmaJ_path)
#         sigmaslope_path = np.append(0, sigmaslope_path)
#
#         beta_ss = par['beta']
#         for t in range(TT - 1, -1, -1):
#             print(t)
#             for ib in range(par['nB']):
#                 # Get policy functions
#                 par['beta'] = beta_ss + (2 * ib - 1) * par['dbeta']
#                 print(par['beta'])
#                 # input paths
#                 CU_path[:, :, ib, t], CE_path[:, :, :, :, :, ib, t], U_old[:, :, ib], E_old[:, :, :, :, :, ib], \
#                 AU_path[:, :, ib, t], AE_path[:, :, :, :, :, ib, t], J_old[:, :, :, :, :, ib], cacaU, cacaE, \
#                 qs_path[:, :, :, :, :, ib, t], WUi_path[:, :, ib, t], WUpi_path[:, :, ib, t], \
#                 WEwini_path[:, :, :, :, :, ib, t], WEwinpi_path[:, :, :, :, :, ib, t], \
#                 WElosei_path[:, :, :, :, :, ib, t], WElosepi_path[:, :, :, :, :, ib, t], \
#                 Iwins_path[:, :, :, :, :, ib, t] = Jac_help.backward_iterate(ra_path[t], r_path[t], rK_path[t], Z_path[t],
#                                                                              tax_path[t],
#                                                                              lambdas_path[t+1, :], bUI_path[t],
#                                                                              sigmaJ_path[t+1], sigmaslope_path[t+1], tran_path[t],
#                                                                              CU_path[:, :, ib, t + 1],
#                                                                              CE_path[:, :, :, :, :, ib, t + 1],
#                                                                              U_old[:, :, ib], E_old[:, :, :, :, :, ib],
#                                                                              J_old[:, :, :, :, :, ib], par)
#
#         for t in range(1, TT + 1):
#             for ib in range(par['nB']):
#                 # Update distribution
#                 QUtmp, QEtmp, QEEtmp = Jac_help.forward_iterate(par['nB'] * QU_path[:, :, ib, t - 1],
#                                                                 par['nB'] * QE_path[:, :, :, :, :, ib, t - 1],
#                                                                 AU_path[:, :, ib, t], AE_path[:, :, :, :, :, ib, t],
#                                                                 WUi_path[:, :, ib, t], WUpi_path[:, :, ib, t],
#                                                                 WEwini_path[:, :, :, :, :, ib, t],
#                                                                 WEwinpi_path[:, :, :, :, :, ib, t],
#                                                                 WElosei_path[:, :, :, :, :, ib, t],
#                                                                 WElosepi_path[:, :, :, :, :, ib, t],
#                                                                 qs_path[:, :, :, :, :, ib, t],
#                                                                 Iwins_path[:, :, :, :, :, ib, t],
#                                                                 lambdas_path[t - 1, :], sigmaJ_path[t - 1], sigmaslope_path[t-1], par)
#                 QU_path[:, :, ib, t], \
#                 QE_path[:, :, :, :, :, ib, t], \
#                 QEE_path[:, :, :, :, :, ib, t] = QUtmp / par['nB'], QEtmp / par['nB'], QEEtmp / par['nB']
#
#         par['beta'] = beta_ss
#
#         # Computing distributional EE
#         for t in range(1, TT+1):
#             # find median index
#             Qt = np.sum(QE_path[:, :, :, :, :, :, t-1], axis=(0, 2, 3, 4, 5)) + np.sum(QU_path[:, :, :, t-1], axis=(0, 2))
#             xi, xpi = utils.simple_interpolation(0.5 * np.sum(Qt), np.cumsum(Qt))
#             assert np.abs(np.sum(Qt[:xi+1]) + (1 - xpi) * Qt[xi+1] - (np.sum(Qt[xi+2:]) + xpi * Qt[xi+1])< 1e-6), 'Threshold does not hold up'
#             QEL = np.copy(QE_path[:, :xi + 2, :, :, :, :, t-1])
#             QEL[:, -1, :, :, :, :] = QE_path[:, xi + 1, :, :, :, :, t-1] * (1 - xpi)
#             QEH = np.copy(QE_path[:, xi + 1:, :, :, :, :, t-1])
#             QEH[:, 0, :, :, :, :] = QE_path[:, xi + 1, :, :, :, :, t-1] * xpi
#             QEEL = np.copy(QEE_path[:, :xi + 2, :, :, :, :, t])
#             QEEL[:, -1, :, :, :, :] = QEE_path[:, xi + 1, :, :, :, :, t] * (1 - xpi)
#             QEEH = np.copy(QEE_path[:, xi + 1:, :, :, :, :, t])
#             QEEH[:, 0, :, :, :, :] = QEE_path[:, xi + 1, :, :, :, :, t] * xpi
#             # EE by wealth
#             qL = np.copy(qs_path[:, :xi + 2, :, :, :, :, t-1])
#             qL[:, -1, :, :, :, :] = qs_path[:, xi + 1, :, :, :, :, t-1] * (1 - xpi)
#             qH = np.copy(qs_path[:, xi + 1:, :, :, :, :, t-1])
#             qH[:, 0, :, :, :, :] = qs_path[:, xi + 1, :, :, :, :, t-1] * xpi
#             # Job-switching
#             EEL[t-1,k] = np.sum(np.sum(QEEL * qL, axis=(0, 1, 2, 4, 5)) * lambdas_path[t-1, 1:]) / np.sum(QEL)
#             EEH[t-1,k] = np.sum(np.sum(QEEH * qH, axis=(0, 1, 2, 4, 5)) * lambdas_path[t-1, 1:]) / np.sum(QEH)
#             EE_all[t - 1, k] = np.sum(np.sum(QEE_path[:, :, :, :, :, :, t-1] * qs_path[:, :, :, :, :, :, t-1], axis=(0, 1, 2, 4, 5)) * lambdas_path[t-1, 1:]) / np.sum(QE_path[:, :, :, :, :, :, t-1])
#             # np.sum(np.sum(QEETs[:, :, :, :, :, :, t - 1] * qTs_pre, axis=(0, 1, 2, 4, 5)) * lambdas_path_td[t, 1:])
#             #EEL[t - 1, k] = np.sum(np.sum(QEEL * qs_path[:, :xi + 2, :, :, :, :, t], axis=(0, 1, 2, 4, 5))
#             #                       * lambdas_path[t-1, 1:].T, axis=0) / np.sum(QEL)
#             #EEH[t - 1, k] = np.sum(np.sum(QEEH * qs_path[:, xi + 1:, :, :, :, :, t], axis=(0, 1, 2, 4, 5))
#             #                       * lambdas_path[t - 1, 1:].T, axis=0) / np.sum(QEH)
#             #EE_all[t - 1, k] = np.sum(np.sum(QEE_path[:, :, :, :, :, :, t] * qs_path[:, :, :, :, :, :, t - 1], axis=(0, 1, 2, 4, 5))
#             #                       * lambdas_path[t - 1, 1:].T, axis=0) / np.sum(QE_path[:, :, :, :, :, :, t-1])
#
#     return EEH, EEL, EE_all, np.sum(QU_path, axis=(0,1,2))



def GResignation_dist(G, shock_path, transfer_path, UI_path, ishock, par, ss, TT, k):
    # prepare fiscal stimulus shocks
    Z_path = np.ones(TT)
    sigmaJ_path = shock_path + ss[ishock]

    # Compute EE by H and L wealth in each scenario
    EEL = np.zeros((TT, 1))
    EEH = np.zeros((TT, 1))
    EE_all = np.zeros((TT, 1))

    for p in range(1):
        if k == 0:    # both UI and checks
            bUI_path = np.append(UI_path, np.zeros(TT - len(UI_path))) + ss['bUI']
            tran_path = np.append(transfer_path, np.zeros(TT - len(transfer_path))) + ss['transfer']
        elif k == 1:     # no UI but checks
            bUI_path = np.append(UI_path, np.zeros(TT - len(UI_path))) + ss['bUI']
            tran_path = np.zeros(TT) + ss['transfer']
        elif k == 2:  # no checks but UI
            bUI_path = np.zeros(TT) + ss['bUI']
            tran_path = np.append(transfer_path, np.zeros(TT - len(transfer_path))) + ss['transfer']
        elif k == 3:  # no checks no UI
            bUI_path = np.zeros(TT) + ss['bUI']
            tran_path = np.zeros(TT) + ss['transfer']

        # shock
        di = dict()
        di['sigmaJ'] = shock_path
        di['bUI'] = (bUI_path - ss['bUI'])
        di['transfer'] = tran_path
        shock_list = ['sigmaJ', 'bUI', 'transfer']

        # all other relevant paths
        #sigmaJ_path = np.ones(TT) * ss['sigmaJ']
        sigmaslope_path = np.ones(TT) * ss['sigmaslope']
        ra_path = utils.level_IRF(G, 'ra', shock_list, di, ss['ra'], TT)
        r_path = utils.level_IRF(G, 'r', shock_list, di, ss['r'], TT)
        rK_path = utils.level_IRF(G, 'rK', shock_list, di, ss['rK'], TT)
        tax_path = utils.level_IRF(G, 'tax', shock_list, di, ss['tax'], TT)
        lambdas_path = np.ones((TT, par['nP'])) * ss['lambdas'][np.newaxis, :]
        for ip in range(par['nP']):
            lambdas_path[:, ip] = utils.level_IRF(G, 'lambda' + str(ip), shock_list, di, ss['lambdas'][ip], TT)

        # Distributions along transitions
        QE_path = np.zeros(ss['QEss'].shape + (TT+1,))
        QE_path[:, :, :, :, :, :, 0] = ss['QEss']
        QEE_path = np.zeros(ss['QEEss'].shape + (TT+1,))
        QEE_path[:, :, :, :, :, :, :, 0] = ss['QEEss']
        QU_path = np.zeros(ss['QUss'].shape + (TT+1,))
        QU_path[:, :, :, 0] = ss['QUss']
        # Policies along transitions
        # CE_path = np.zeros(ss['CEss'].shape + (TT+1,))
        # CE_path[:, :, :, :, :, :, -1] = ss['CEss']
        CE_path = np.copy(ss['CEss'])
        # CU_path = np.zeros(ss['CUss'].shape + (TT+1,))
        # CU_path[:, :, :, -1] = ss['CUss']
        CU_path = np.copy(ss['CUss'])
        AE_path = np.zeros(ss['AEss'].shape + (TT+1,))
        AE_path[:, :, :, :, :, :, -1] = ss['AEss']
        AU_path = np.zeros(ss['AUss'].shape + (TT+1,))
        AU_path[:, :, :, -1] = ss['AUss']
        U_old = np.copy(ss['Uss'])
        E_old = np.copy(ss['Ess'])
        J_old = np.copy(ss['Jss'])
        Ebargaining_old = np.copy(ss['Ebargainingss'])
        dEbargaining_old = np.copy(ss['dEbargainingss'])
        Jbargaining_old = np.copy(ss['Jbargainingss'])
        WEwinpi_path = np.zeros(ss['WEwinpiss'].shape + (TT+1,))
        WEwinpi_path[:, :, :, :, :, :, :, -1] = ss['WEwinpiss']
        WEwini_path = np.zeros(ss['WEwiniss'].shape + (TT+1,), dtype='uint32')
        WEwini_path[:, :, :, :, :, :, :, -1] = ss['WEwiniss']
        WElosepi_path = np.zeros(ss['WElosepiss'].shape + (TT+1,))
        WElosepi_path[:, :, :, :, :, :, :, -1] = ss['WElosepiss']
        WElosei_path = np.zeros(ss['WEloseiss'].shape + (TT+1,), dtype='uint32')
        WElosei_path[:, :, :, :, :, :, :, -1] = ss['WEloseiss']
        WUpi_path = np.zeros(ss['WUpiss'].shape + (TT+1,))
        WUpi_path[:, :, :, :, -1] = ss['WUpiss']
        WUi_path = np.zeros(ss['WUiss'].shape + (TT+1,), dtype='uint32')
        WUi_path[:, :, :, :, -1] = ss['WUiss']
        Iwins_path = np.zeros(ss['Iwins'].shape + (TT+1,))
        Iwins_path[:, :, :, :, :, :, :, -1] = ss['Iwins']
        qs_path = np.zeros(ss['qss'].shape + (TT+1,))
        qs_path[:, :, :, :, :, :, :, -1] = ss['qss']

        # append to lambdas and sigmaJ
        lambdas_path = np.vstack([ss['lambdas'], lambdas_path])
        sigmaJ_path = np.append(ss['sigmaJ'], sigmaJ_path)
        sigmaslope_path = np.append(0, sigmaslope_path)

        beta_ss = par['beta']
        for t in range(TT - 1, -1, -1):
            print(t)
            for ib in range(par['nB']):
                # Get policy functions
                par['beta'] = beta_ss + (2 * ib - 1) * par['dbeta']
                # input paths
                CU_path[:, :, ib], CE_path[:, :, :, :, :, ib], U_old[:, :, ib], E_old[:, :, :, :, :, ib], \
                Ebargaining_old[:, :, :, :, :, ib], dEbargaining_old[:, :, :, :, :, ib], AU_path[:, :, ib, t], AE_path[:, :, :, :, :, ib, t], \
                J_old[:, :, :, :, :, ib], Jbargaining_old[:, :, :, :, :, ib], cacaU, cacaE, \
                qs_path[:, :, :, :, :, :, ib, t], WUi_path[:, :, :, ib, t], WUpi_path[:, :, :, ib, t], \
                WEwini_path[:, :, :, :, :, :, ib, t], WEwinpi_path[:, :, :, :, :, :, ib, t], \
                WElosei_path[:, :, :, :, :, :, ib, t], WElosepi_path[:, :, :, :, :, :, ib, t], \
                Iwins_path[:, :, :, :, :, :, ib, t] = Jac_help.backward_iterate(ra_path[t], r_path[t], rK_path[t], Z_path[t], tax_path[t],
                                                                             lambdas_path[t+1, :], bUI_path[t], sigmaJ_path[t+1], 
                                                                             sigmaslope_path[t+1], tran_path[t],
                                                                             CU_path[:, :, ib], CE_path[:, :, :, :, :, ib],
                                                                             U_old[:, :, ib], E_old[:, :, :, :, :, ib],
                                                                             Ebargaining_old[:, :, :, :, :, ib], dEbargaining_old[:, :, :, :, :, ib],
                                                                             J_old[:, :, :, :, :, ib], Jbargaining_old[:, :, :, :, :, ib], par)
        for t in range(1, TT + 1):
            print(t)
            for ib in range(par['nB']):
                # Update distribution
                QUtmp, QEtmp, QEEtmp = Jac_help.forward_iterate(par['nB'] * QU_path[:, :, ib, t - 1],
                                                                par['nB'] * QE_path[:, :, :, :, :, ib, t - 1],
                                                                AU_path[:, :, ib, t], AE_path[:, :, :, :, :, ib, t],
                                                                WUi_path[:, :, :, ib, t], WUpi_path[:, :, :, ib, t],
                                                                WEwini_path[:, :, :, :, :, :, ib, t],
                                                                WEwinpi_path[:, :, :, :, :, :, ib, t],
                                                                WElosei_path[:, :, :, :, :, :, ib, t],
                                                                WElosepi_path[:, :, :, :, :, :, ib, t],
                                                                qs_path[:, :, :, :, :, :, ib, t],
                                                                Iwins_path[:, :, :, :, :, :, ib, t],
                                                                lambdas_path[t - 1, :], sigmaJ_path[t - 1], sigmaslope_path[t-1], par)
                            # QUtmp, QEtmp, QUEtmp, QEEtmp = forward_iterate(nB * QUTs[:, :, ib, t - 1], nB * QETs[:, :, :, :, :, ib, t - 1],
                            #                        AUTs_pre[:, :, ib], AETs_pre[:, :, :, :, :, ib],
                            #                        WUiTs_pre[:, :, ib], WUpiTs_pre[:, :, ib],
                            #                        WEwiniTs_pre[:, :, :, :, :, ib], WEwinpiTs_pre[:, :, :, :, :, ib],
                            #                        WEloseiTs_pre[:, :, :, :, :, ib], WElosepiTs_pre[:, :, :, :, :, ib],
                            #                        qTs_pre[:, :, :, :, :, ib], IwinTs_pre[:, :, :, :, :, ib],
                            #                        lambdas_path_td[t - 1, :], sigmaJ_path_td[t - 1], sigmaslope_path_td[t - 1], par)

                
                QU_path[:, :, ib, t], \
                QE_path[:, :, :, :, :, ib, t], \
                QEE_path[:, :, :, :, :, :, ib, t] = QUtmp / par['nB'], QEtmp / par['nB'], QEEtmp / par['nB']

        par['beta'] = beta_ss

        # Computing distributional EE
        for t in range(1, TT+1):
            # find median index
            Qt = np.sum(QE_path[:, :, :, :, :, :, t-1], axis=(0, 2, 3, 4, 5)) + np.sum(QU_path[:, :, :, t-1], axis=(0, 2))
            xi, xpi = utils.simple_interpolation(0.5 * np.sum(Qt), np.cumsum(Qt))
            assert np.abs(np.sum(Qt[:xi+1]) + (1 - xpi) * Qt[xi+1] - (np.sum(Qt[xi+2:]) + xpi * Qt[xi+1])< 1e-6), 'Threshold does not hold up'
            QEL = np.copy(QE_path[:, :xi + 2, :, :, :, :, t-1])
            QEL[:, -1, :, :, :, :] = QE_path[:, xi + 1, :, :, :, :, t-1] * (1 - xpi)
            QEH = np.copy(QE_path[:, xi + 1:, :, :, :, :, t-1])
            QEH[:, 0, :, :, :, :] = QE_path[:, xi + 1, :, :, :, :, t-1] * xpi
            QEEL = np.copy(QEE_path[:, :xi + 2, :, :, :, :, :, t])
            QEEL[:, -1, :, :, :, :] = QEE_path[:, xi + 1, :, :, :, :, :, t] * (1 - xpi)
            QEEH = np.copy(QEE_path[:, xi + 1:, :, :, :, :, :, t])
            QEEH[:, 0, :, :, :, :] = QEE_path[:, xi + 1, :, :, :, :, :, t] * xpi
            # EE by wealth
            qL = np.copy(qs_path[:, :xi + 2, :, :, :, :, :,  t-1])
            qL[:, -1, :, :, :, :] = qs_path[:, xi + 1, :, :, :, :, :, t-1] * (1 - xpi)
            qH = np.copy(qs_path[:, xi + 1:, :, :, :, :, :, t-1])
            qH[:, 0, :, :, :, :] = qs_path[:, xi + 1, :, :, :, :, :, t-1] * xpi
            # Job-switching
            EEL[t-1,p] = np.sum(np.sum(QEEL * qL, axis=(0, 1, 2, 4, 5)) * lambdas_path[t-1, 1:]) / np.sum(QEL)
            EEH[t-1,p] = np.sum(np.sum(QEEH * qH, axis=(0, 1, 2, 4, 5)) * lambdas_path[t-1, 1:]) / np.sum(QEH)
            EE_all[t - 1, p] = np.sum(np.sum(QEE_path[:, :, :, :, :, :, :, t-1] * qs_path[:, :, :, :, :, :, :, t-1], axis=(0, 1, 2, 4, 5)) * lambdas_path[t-1, 1:]) / np.sum(QE_path[:, :, :, :, :, :, t-1])
            # np.sum(np.sum(QEETs[:, :, :, :, :, :, t - 1] * qTs_pre, axis=(0, 1, 2, 4, 5)) * lambdas_path_td[t, 1:])
            #EEL[t - 1, k] = np.sum(np.sum(QEEL * qs_path[:, :xi + 2, :, :, :, :, t], axis=(0, 1, 2, 4, 5))
            #                       * lambdas_path[t-1, 1:].T, axis=0) / np.sum(QEL)
            #EEH[t - 1, k] = np.sum(np.sum(QEEH * qs_path[:, xi + 1:, :, :, :, :, t], axis=(0, 1, 2, 4, 5))
            #                       * lambdas_path[t - 1, 1:].T, axis=0) / np.sum(QEH)
            #EE_all[t - 1, k] = np.sum(np.sum(QEE_path[:, :, :, :, :, :, t] * qs_path[:, :, :, :, :, :, t - 1], axis=(0, 1, 2, 4, 5))
            #                       * lambdas_path[t - 1, 1:].T, axis=0) / np.sum(QE_path[:, :, :, :, :, :, t-1])

    return EEH, EEL, EE_all, np.sum(QU_path, axis=(0,1,2))