import os
# set current director as working directory
os.chdir("")
import numpy as np
import load_params_SS as load_params
import matplotlib.pyplot as plt
import solveSS_AOB
import Jac
import pickle
import pandas as pd
import utils
import sys

# Options
TT = 250

# **** Benchmark model **** #
# Load Steady State
with open("ss_calibration.pkl", 'rb') as file:
    ss = pickle.load(file)
# Load 
input = ss['inputs']
par = load_params.get_par(input, inaive=False)

# Loading and combining Jacobian
shock_list = ['ra', 'Z', 'tax', 'transfer',
              'lambda0', 'lambda1', 'lambda2', 'lambda3', 'lambda4', 'lambda5', 'lambda6', 'lambda7',
              'rK', 'sigmaJ', 'sigmaslope', 'bUI']
J = Jac.combine_Jac('Jacobians_ss_250', shock_list)

# Blocks (inflation block)
import jacobian as jac
import model_blocks as blocks

# version with capitalist and production as solved blocks
block_list = [J, blocks.labor_flows, blocks.matching_tech, blocks.dividend, blocks.intermediaries,
              blocks.production, blocks.capitalist, blocks.earnings_posttax,
              blocks.asset_mkt, blocks.labor_mkt, blocks.fiscal, blocks.free_entry, blocks.walras]

exogenous = ['Z', 'transfer', 'sigmaJ', 'sigmaslope', 'bUI', 'zeta', 'drate', 'chi']
unknowns = ['theta0', 'theta1', 'theta2', 'theta3', 'theta4', 'theta5', 'theta6', 'theta7', 'Y', 'r', 'tax']
targets = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'h7', 'h8', 'h9', 'h10', 'h11']

# Get Jacobian
G = jac.get_G(block_list, exogenous, unknowns, targets, T=TT, ss=ss)

# ****** Great Resignation ****** #
# set autocorr for transfers
rho_tran = 0.9999
# include path to counterfact_data
df = pd.read_excel(r'PATH-HERE/counterfact_data.xlsx')
data_path = np.asarray(list(filter(lambda x: ~np.isnan(x), df['Pandemic EErate'].to_numpy()))) / 100
NQ = int(len(data_path) / 3)
data_pathQ = np.zeros(NQ)
for i in range(1,NQ):
    data_pathQ[i] = np.sum(data_path[3*i:3*(i+1)])
#data_pathQ = np.append(np.append(0, data_pathQ), np.zeros(138))
data_pathQ = data_pathQ[1:]
NQ = len(data_pathQ)
data_pathQ = np.append(data_pathQ, np.zeros(TT - len(data_pathQ)))
# Wealth path over 2019:Q4-2022:Q4 (from Fed distirbutional financial flows)
# HP filter aggregate wealth. Take trend from 2019:Q4 and add cycle for the next 12 months. This is the growth relative to 2019:Q4
wealth_path = np.array([1, 0.9799631077859208, 0.9057310951465315, 0.9536747627941575, 0.9704445568865703, 1.016648750493575, 1.0367021718779348, 1.0669461483391185, 1.0711655164247817, 1.079366418345637, 1.0749223267524415, 1., 1])
wealth_path = wealth_path * ss['p'] - ss['p']
wealth_path = np.append(wealth_path, np.zeros(TT - len(wealth_path)))
# Computing transfer shock
total_transfers_Y = df['CARES checks'][0] / df['$ GDP 2020:Q1'][0] + df['CAA checks'][0] / df['$ GDP 2020:Q4'][0] + df['ARPA checks'][0] / df['$ GDP 2021:Q1'][0]
transfer_path = np.zeros(NQ)
transfer_path[3:] = (total_transfers_Y * (ss['Y'] * 4)) * (rho_tran ** np.arange(NQ-3)) / np.sum(rho_tran ** np.arange(NQ-3))
transfer_path = np.append(transfer_path, np.zeros(TT - len(transfer_path)))
# Computing UI shock
total_UI_Y = df['CARES UI'][0] / df['$ GDP 2020:Q1'][0] + df['CAA UI'][0] / df['$ GDP 2020:Q4'][0] + df['ARPA UI'][0] / df['$ GDP 2021:Q1'][0]
UI_path = np.zeros(NQ)
UI_path[3:] = (total_UI_Y * (ss['Y'] * 4)) * (rho_tran ** np.arange(NQ-3)) / np.sum(rho_tran ** np.arange(NQ-3))
UI_path = np.append(UI_path, np.zeros(TT - len(UI_path)))
# identify shock paths to match EE and wealth path in the data
A1 = G['EE_rate']['chi'] 
B1 = G['EE_rate']['drate']
A2 = G['p']['chi']
B2 = G['p']['drate']
Y1 = data_pathQ - ((G['EE_rate']['transfer'] @ transfer_path) + (G['EE_rate']['bUI'] @ UI_path))
Y2 = wealth_path - ((G['p']['transfer'] @ transfer_path) + (G['p']['bUI'] @ UI_path))
block_matrix = np.block([[A1, B1], [A2, B2]])
block_vector = np.concatenate([Y1, Y2])
shocks_linal = np.linalg.solve(block_matrix, block_vector)
# Get counterfactual EE rates
EE_noUI = np.append(ss['EE_rate'] * np.ones(4), ss['EE_rate'] + (G['EE_rate']['transfer'] @ transfer_path) + (G['EE_rate']['chi'] @ shocks_linal[:TT]) + (G['EE_rate']['drate'] @ shocks_linal[TT:]))
EE_notransfer = np.append(ss['EE_rate'] * np.ones(4), ss['EE_rate'] + (G['EE_rate']['bUI'] @ UI_path) + (G['EE_rate']['chi'] @ shocks_linal[:TT]) + (G['EE_rate']['drate'] @ shocks_linal[TT:]))
EE_nonothing = np.append(ss['EE_rate'] * np.ones(4), ss['EE_rate'] + (G['EE_rate']['chi'] @ shocks_linal[:TT]) + (G['EE_rate']['drate'] @ shocks_linal[TT:]))
EE_data = np.append(ss['EE_rate'] * np.ones(4), ss['EE_rate'] + (G['EE_rate']['bUI'] @ UI_path) + (G['EE_rate']['transfer'] @ transfer_path) + (G['EE_rate']['chi'] @ shocks_linal[:TT]) + (G['EE_rate']['drate'] @ shocks_linal[TT:]))
plt.plot(EE_data); plt.plot(EE_noUI); plt.plot(EE_notransfer); plt.plot(EE_nonothing); plt.xlim([0, 20])
print("Total cumulated change in EE rate ", str(np.round(np.sum((EE_data - EE_nonothing)[:40]), decimals=4)))

# # save to file
df_pandemic = pd.DataFrame({'EE_data': EE_data[:40], 'EE_notransfer': EE_notransfer[:40], 'EE_noUI': EE_noUI[:40], 'EE_nonothing': EE_nonothing[:40]})
df_pandemic.to_csv(r'pandemic_output.csv')

# ****** Great Recession ****** #
import GreatRecession as GR
# get Great Recession targets paths to match (include path)
df_GR = pd.read_csv(r'PATH-HERE/GR_inputs.csv')
df_GR.GDP_GR = df_GR.GDP_GR / df_GR.GDP_GR[1]
Wpath = df_GR.Wealth_GR[:10] * ss['p'] - ss['p']
# get Great Recession empirical earnings paths (include path)
df = pd.read_csv(r'PATH-HERE/counterfactual_data_GreatRecession.csv')
EarningsSS = np.sum(np.sum(ss['QEss'], axis=(0, 1, 3, 4, 5)) * par['w_grid']) / (1 - ss['U'])
imid, pimid = utils.simple_interpolation(0.5, np.cumsum(np.sum(ss['QEss'], axis=(0,2,3,4,5)) + np.sum(ss['QUss'], axis=(0,2))))
QEL = np.copy(ss['QEss'][:, :imid + 2, :, :, :, :])
QEL[:, -1, :, :, :, :] = ss['QEss'][:, imid + 1, :, :, :, :] * (1 - pimid)
QEH = np.copy(ss['QEss'][:, imid + 1:, :, :, :, :])
QEH[:, 0, :, :, :, :] = ss['QEss'][:, imid + 1, :, :, :, :] * pimid
EarningsLSS = np.sum(np.sum(QEL, axis=(0, 1, 3, 4, 5)) * par['w_grid']) / np.sum(QEL)
EarningsHSS = np.sum(np.sum(QEH, axis=(0, 1, 3, 4, 5)) * par['w_grid']) / np.sum(QEH)
EE_rateL = np.sum(ss['QEEss'][:, :imid + 2, :, :, :, :, :] * ss['qss'][:, :imid + 2, :, :, :, :, :]) / np.sum(ss['QEss'][:, :imid + 2, :, :, :, :])
EE_rateH = np.sum(ss['QEEss'][:, imid + 1:, :, :, :, :, :] * ss['qss'][:, imid + 1:, :, :, :, :, :]) / np.sum(ss['QEss'][:, imid + 1:, :, :, :, :])
Earnings_path = df.TotalEarnings.to_numpy()[0::3]
Earnings_path = Earnings_path * ss['earnings'] - ss['earnings']
Earnings_path = Earnings_path[~np.isnan(Earnings_path)]

# Aggregate wealth (US economy taken from Board distributional accounts)
Wpath_XL = np.append(Wpath, np.zeros(TT - len(Wpath)))
Earningspath_XL = np.append(Earnings_path, np.zeros(TT - len(Earnings_path)))
scale_factor = 10

# Find shock path
paths = np.vstack((Wpath_XL / scale_factor, Earningspath_XL / scale_factor))
var_list = ['p', 'earnings']
shock_list = ['drate', 'chi']
dshocks = GR.findshocks_GRecession(G, paths, var_list, shock_list, TT)
df_shocks = pd.DataFrame({'drate': dshocks['drate'], 'chi': dshocks['chi']})
# Nipping shock for stability past 10 years
df_shocks['drate'][40:] = 0
df_shocks['chi'][40:] = 0


# Linear earnings dynamics:
earnings = EarningsSS + scale_factor * (G['earnings']['drate'] @ df_shocks['drate'] + G['earnings']['chi'] @ df_shocks['chi'])
earningsH = EarningsHSS + scale_factor * (G['earningsH']['drate'] @ df_shocks['drate'] + G['earningsH']['chi'] @ df_shocks['chi'])
earningsL = EarningsLSS + scale_factor * (G['earningsL']['drate'] @ df_shocks['drate'] + G['earningsL']['chi'] @ df_shocks['chi'])
earnings_plots = pd.DataFrame({'earnings': np.append(EarningsSS, earnings),
                         'earningsH': np.append(EarningsHSS, earningsH),
                         'earningsL': np.append(EarningsLSS, earningsL)})

# Non-linear dynamics
Y, Earnings, EarningsL, EarningsH, U, AL, AH, EEL, EEH, EUL, EUH, uL, uH, pdist = GR.GR_exercise(G, TT, dshocks, par, ss)
# ghost run
dshocks_g = {'chi': np.zeros(TT), 'drate': np.zeros(TT)}
Y_g, Earnings_g, EarningsL_g, EarningsH_g, U_g, AL_g, AH_g, EEL_g, EEH_g, EUL_g, EUH_g, uL_g, uH_g, pdist_g = GR.GR_exercise(G, TT, dshocks_g, par, ss)
# saving EE rate by wealth as a difference from SS (t=30)
EEH = np.append(0, scale_factor * (EEH - EEH[40]))
EEL = np.append(0, scale_factor * (EEL - EEL[40]))
EE_plots = pd.DataFrame({'EEH': EEH,
                         'EEL': EEL})


# **** Naive model **** #

# Load Steady State
with open("ss_naive.pkl", 'rb') as file:
    ss_naive = pickle.load(file)
# Load 
input = ss_naive['inputs']
par_naive = load_params.get_par(input, inaive=True)

# Loading and combining Jacobian
shock_list = ['ra', 'Z', 'tax', 'transfer',
              'lambda0', 'lambda1', 'lambda2', 'lambda3', 'lambda4', 'lambda5', 'lambda6', 'lambda7',
              'rK', 'sigmaJ', 'sigmaslope', 'bUI']
J_naive = Jac.combine_Jac('Jacobians_naive_250', shock_list)

# version with capitalist and production as solved blocks
block_list = [J_naive, blocks.labor_flows, blocks.matching_tech, blocks.dividend, blocks.intermediaries,
              blocks.production, blocks.capitalist, blocks.earnings_posttax,
              blocks.asset_mkt, blocks.labor_mkt, blocks.fiscal, blocks.free_entry, blocks.walras]

# Get Jacobian
G_naive = jac.get_G(block_list, exogenous, unknowns, targets, T=TT, ss=ss_naive)

# Get steady state values
EarningsSS = np.sum(np.sum(ss_naive['QEss'], axis=(0, 1, 3, 4, 5)) * par_naive['w_grid']) / (1 - ss_naive['U'])
imid, pimid = utils.simple_interpolation(0.5, np.cumsum(np.sum(ss_naive['QEss'], axis=(0,2,3,4,5)) + np.sum(ss_naive['QUss'], axis=(0,2))))
QEL = np.copy(ss_naive['QEss'][:, :imid + 2, :, :, :, :])
QEL[:, -1, :, :, :, :] = ss_naive['QEss'][:, imid + 1, :, :, :, :] * (1 - pimid)
QEH = np.copy(ss_naive['QEss'][:, imid + 1:, :, :, :, :])
QEH[:, 0, :, :, :, :] = ss_naive['QEss'][:, imid + 1, :, :, :, :] * pimid
EarningsLSS = np.sum(np.sum(QEL, axis=(0, 1, 3, 4, 5)) * par_naive['w_grid']) / np.sum(QEL)
EarningsHSS = np.sum(np.sum(QEH, axis=(0, 1, 3, 4, 5)) * par_naive['w_grid']) / np.sum(QEH)

# Linear earnings dynamics:
earnings_naive = EarningsSS + scale_factor * (G_naive['earnings']['drate'] @ df_shocks['drate'] + G_naive['earnings']['chi'] @ df_shocks['chi'])
earningsH_naive = EarningsHSS + scale_factor * (G_naive['earningsH']['drate'] @ df_shocks['drate'] + G_naive['earningsH']['chi'] @ df_shocks['chi'])
earningsL_naive = EarningsLSS + scale_factor * (G_naive['earningsL']['drate'] @ df_shocks['drate'] + G_naive['earningsL']['chi'] @ df_shocks['chi'])
earnings_plots['earnings_naive'] = np.append(EarningsSS, earnings_naive)
earnings_plots['earningsH_naive'] = np.append(EarningsHSS, earningsH_naive)
earnings_plots['earningsL_naive'] = np.append(EarningsLSS, earningsL_naive)

# Non-linear dynamics
Y, Earnings, EarningsL, EarningsH, U, AL, AH, EEL, EEH, EUL, EUH, uL, uH, pdist = GR.GR_exercise(G_naive, TT, dshocks, par_naive, ss_naive)
# ghost run
dshocks_g = {'chi': np.zeros(TT), 'drate': np.zeros(TT)}
Y_g, Earnings_g, EarningsL_g, EarningsH_g, U_g, AL_g, AH_g, EEL_g, EEH_g, EUL_g, EUH_g, uL_g, uH_g, pdist_g = GR.GR_exercise(G_naive, TT, dshocks_g, par_naive, ss_naive)


# add to dataframe
EEH = np.append(0, scale_factor * (EEH - EEH[40]))
EEL = np.append(0, scale_factor * (EEL - EEL[40]))
EE_plots['EEH_naive'] = EEH
EE_plots['EEL_naive'] = EEL

# Plotting earnings
plt.figure()
# High Wealth
diff_earningsH = 100 * (earnings_plots.earningsH - earnings_plots.earningsH[0]) / earnings_plots.earningsH[0]
diff_earningsH = diff_earningsH[np.where(diff_earningsH < 0)[0][0]:]
diff_earningsH = diff_earningsH.values
plt.plot(diff_earningsH[:40])

# Low Wealth
diff_earningsL = 100 * (earnings_plots.earningsL - earnings_plots.earningsL[0]) / earnings_plots.earningsL[0]
diff_earningsL = diff_earningsL[np.where(diff_earningsL < 0)[0][0]:]
diff_earningsL = diff_earningsL.values
plt.plot(diff_earningsL[:40])


# Save to file
earnings_plots.to_csv(r'GR_earnings.csv')
EE_plots.to_csv(r'GR_EE.csv')