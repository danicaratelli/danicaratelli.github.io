"""Steady-state solver with in-memory-only household warm starts."""

from solveSS_AOB import *
import solveSS_AOB as _solver


def SS(xguess, Z, par, smm_index, tol=1e-6, save_results=False):
    """Solve the steady state and optionally construct the complete result."""
    r_ss, tax_ss, thetas_ss, warm_cache = _solver.SS(
        xguess, Z, par, smm_index, tol, _return_cache=True
    )
    ss = None
    if save_results:
        ss = getSS(
            r_ss, tax_ss, thetas_ss, Z, par, smm_index,
            warm_cache=warm_cache,
        )
    return r_ss, tax_ss, thetas_ss, ss
