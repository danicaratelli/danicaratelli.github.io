import numpy as np
import os
import pickle
import multiprocessing as mp
import multiprocessing.pool
from concurrent.futures import ProcessPoolExecutor
import Jac_help
from concurrent.futures import ThreadPoolExecutor


# Jacobian of DMP block
def jac_worker(args):
    shock, TT, par, ss, pert, num_processes = args
    print('Starting shock: ' + shock)
    # identifying which labor market if shock is lambda#
    lambda_set = set()
    for p in range(par['nP']):
        lambda_set.add('lambda' + str(p))
    if shock in lambda_set:
        ip = int(shock[-1])
    else:
        ip = 0

    # initialize Jacobian dictionary
    outputs = ['A', 'U', 'C', 'N', 'EE_rate', 'EU_rate', 'Tax', 'earnings', 'Ubill', 'Pi',
               'A_pre', 'AU', 'AU_pre', 'AE', 'AE_pre', 'CU', 'CE',
               'walrasU', 'walrasE', 'walras', 
               'earningsH', 'earningsL', 'EE_rateH', 'EE_rateL']
    nB = par['nB']
    for ipp in range(par['nP']):
        outputs += ['J0_' + str(ipp)]
        outputs += ['e' + str(ipp)]

    JHH = dict()
    for o in outputs:
        JHH[o] = dict()
        if (o=='tax') or (o=='ra') or (o=='transfer') or (o=='rK') or (o=='bUI'):
            JHH[o][shock] = np.zeros((TT+1,TT))
        else:
            JHH[o][shock] = np.zeros((TT, TT))
                
    # compute response to each shock
    print("     go backward")
    # Backward iteration (unique, shock only T-1):    # real run
    Jac_help.backward_onepop(shock, TT, ss, par, ip, shock, pert)
    # ghost run
    Jac_help.backward_onepop(shock, TT, ss, par, ip, shock, 0)
    
    # Forward iteration to update distribution
    print("     go forward")
    if num_processes == 1:
        forward_results = [
            Jac_help.go_forward(shock, TT, ss, par, ip, pert, shock, tshock)
            for tshock in range(TT)
        ]
    else:
        # backward_onepop populates this Numba-managed cache, which cannot be
        # serialized for multiprocessing. Each worker can rebuild it locally.
        worker_par = par.copy()
        worker_par.pop('_labor_market_cache', None)
        par_parallel = list(zip(
            [shock] * TT, [TT] * TT, [ss] * TT, [worker_par] * TT,
            [ip] * TT, [pert] * TT, [shock] * TT, np.arange(TT)
        ))
        with mp.Pool(processes=num_processes) as pool:
            forward_results = pool.starmap(Jac_help.go_forward, par_parallel)
    results = list(zip(*forward_results))
    res = results[0]        # Actual
    res_g = results[1]      # Ghost run

    for tshock in range(TT):
        # tax rate
        xtmp_tax = np.zeros(TT + 1)
        xtmp_tax[tshock] = 1
        tax_path_td = np.ones(TT + 1) * ss['tax']
        tax_path_td = tax_path_td + xtmp_tax * pert * (shock == 'tax')
        tax_path_td_g = np.ones(TT + 1) * ss['tax']
        # Lump-sum transfer (transfer)
        xtmp_transfer = np.zeros(TT + 1)
        xtmp_transfer[tshock] = 1
        transfer_path_td = np.ones(TT + 1) * ss['transfer']
        transfer_path_td = transfer_path_td + xtmp_transfer * pert * (shock == 'transfer')
        transfer_path_td_g = np.ones(TT + 1) * ss['transfer']
        # Deposit rate (ra)
        xtmp_ra = np.zeros(TT + 1)
        xtmp_ra[tshock] = 1
        ra_path_td = np.ones(TT + 1) * ss['r']
        ra_path_td = ra_path_td + xtmp_ra * pert * (shock == 'ra')
        ra_path_td_g = np.ones(TT + 1) * ss['r']

        # Using Steady State
        # effect on assets
        JHH['A'][shock][:, tshock] = (res[tshock]['A'] - res_g[tshock]['A']) / pert
        # effect on labor
        JHH['N'][shock][:, tshock] = (res[tshock]['N'] - res_g[tshock]['N']) / pert
        # effect on consumption
        JHH['C'][shock][:, tshock] = (res[tshock]['C'] - res_g[tshock]['C']) / pert
        # effect on unemployed mass
        JHH['U'][shock][:, tshock] = (res[tshock]['U'] - res_g[tshock]['U']) / pert
        # effect on EE rate
        JHH['EE_rate'][shock][:, tshock] = (res[tshock]['EE_rate'] - res_g[tshock]['EE_rate']) / pert
        # effect on EU rate
        JHH['EU_rate'][shock][:, tshock] = (res[tshock]['EU_rate'] - res_g[tshock]['EU_rate']) / pert
        # effect on tax bill
        JHH['Tax'][shock][:, tshock] = (res[tshock]['Tax'] - res_g[tshock]['Tax']) / pert
        # effect on earnings
        JHH['earnings'][shock][:, tshock] = (res[tshock]['earnings'] - res_g[tshock]['earnings']) / pert
        # effect on govt. expenditure
        JHH['Ubill'][shock][:, tshock] = (res[tshock]['Ubill'] - res_g[tshock]['Ubill']) / pert
        for ipp in range(par['nP']):
            # effect on worker distribution over rungs
            JHH['e' + str(ipp)][shock][:, tshock] = (res[tshock]['e' + str(ipp)] - res_g[tshock]['e' + str(ipp)]) / pert
            # effect on expected value for vacant firms
            JHH['J0_' + str(ipp)][shock][:, tshock] = (res[tshock]['J0_' + str(ipp)] - res_g[tshock]['J0_' + str(ipp)]) / pert
        JHH['Pi'][shock][:, tshock] = (res[tshock]['Pi'] - res_g[tshock]['Pi']) / pert
        # Extra for convenience
        JHH['A_pre'][shock][:, tshock] = (res[tshock]['A_pre'] - res_g[tshock]['A_pre']) / pert
        JHH['AU'][shock][:, tshock] = (res[tshock]['AU'] - res_g[tshock]['AU']) / pert
        JHH['AE'][shock][:, tshock] = (res[tshock]['AE'] - res_g[tshock]['AE']) / pert
        JHH['AU_pre'][shock][:, tshock] = (res[tshock]['AU_pre'] - res_g[tshock]['AU_pre']) / pert
        JHH['AE_pre'][shock][:, tshock] = (res[tshock]['AE_pre'] - res_g[tshock]['AE_pre']) / pert
        JHH['CU'][shock][:, tshock] = (res[tshock]['CU'] - res_g[tshock]['CU']) / pert
        JHH['CE'][shock][:, tshock] = (res[tshock]['CE'] - res_g[tshock]['CE']) / pert
        # Walras' Law
        term1 = (res[tshock]['C'] + res[tshock]['A'] - ((1 + ra_path_td[:-1]) * res[tshock]['A_pre'] + (1 - tax_path_td[:-1]) * (res[tshock]['Ubill'] + res[tshock]['Tax'] / tax_path_td[:-1]) + transfer_path_td[:-1]))
        term2 = (res_g[tshock]['C'] + res_g[tshock]['A'] - ((1 + ra_path_td_g[:-1]) * res_g[tshock]['A_pre'] + (1 - tax_path_td_g[:-1]) * (res_g[tshock]['Ubill'] + res_g[tshock]['Tax'] / tax_path_td_g[:-1]) + transfer_path_td_g[:-1]))
        JHH['walras'][shock][:, tshock] = (term1 - term2) / pert
        term1 = (res[tshock]['CE'] + res[tshock]['AE'] - ((1 + ra_path_td[:-1]) * res[tshock]['AE_pre'] + (1 - tax_path_td[:-1]) * res[tshock]['Tax'] / tax_path_td[:-1] + transfer_path_td[:-1] * (1 - res[tshock]['U'])))
        term2 = (res_g[tshock]['CE'] + res_g[tshock]['AE'] - ((1 + ra_path_td_g[:-1]) * res_g[tshock]['AE_pre'] + (1 - tax_path_td_g[:-1]) * res_g[tshock]['Tax'] / tax_path_td_g[:-1] + transfer_path_td_g[:-1] * (1 - res_g[tshock]['U'])))
        JHH['walrasE'][shock][:, tshock] = (term1 - term2) / pert
        term1 = (res[tshock]['CU'] + res[tshock]['AU'] - ((1 + ra_path_td[:-1]) * res[tshock]['AU_pre'] + (1 - tax_path_td[:-1]) * res[tshock]['Ubill'] + transfer_path_td[:-1] * res[tshock]['U']))
        term2 = (res_g[tshock]['CU'] + res_g[tshock]['AU'] - ((1 + ra_path_td_g[:-1]) * res_g[tshock]['AU_pre'] + (1 - tax_path_td_g[:-1]) * res_g[tshock]['Ubill'] + transfer_path_td_g[:-1] * res_g[tshock]['U']))
        JHH['walrasU'][shock][:, tshock] = (term1 - term2) / pert

        # Distributional 
        JHH['earningsH'][shock][:, tshock] = (res[tshock]['earningsH'] - res_g[tshock]['earningsH']) / pert
        JHH['earningsL'][shock][:, tshock] = (res[tshock]['earningsL'] - res_g[tshock]['earningsL']) / pert
        JHH['EE_rateH'][shock][:, tshock] = (res[tshock]['EE_rateH'] - res_g[tshock]['EE_rateH']) / pert
        JHH['EE_rateL'][shock][:, tshock] = (res[tshock]['EE_rateL'] - res_g[tshock]['EE_rateL']) / pert
        # # Testing Walras
        # JHH['Cres'][shock][:, tshock] = (res[tshock]['C'] - (res[tshock]['CU'] + res[tshock]['CE']) - (res_g[tshock]['C'] - (res_g[tshock]['CU'] + res_g[tshock]['CE']))) / pert
        # JHH['Ares'][shock][:, tshock] = (res[tshock]['A'] - (res[tshock]['AU'] + res[tshock]['AE']) - (res_g[tshock]['A'] - (res_g[tshock]['AU'] + res_g[tshock]['AE']))) / pert
        # JHH['A_preres'][shock][:, tshock] = (res[tshock]['A_pre'] - (res[tshock]['AU_pre'] + res[tshock]['AE_pre']) - (res_g[tshock]['A_pre'] - (res_g[tshock]['AU_pre'] + res_g[tshock]['AE_pre']))) / pert



    # save JHH
    print("     saving file")
    filename = os.path.join('Jacobians', 'Jac_' + shock + '.pkl')    
    with open(filename, 'wb') as jhh_file:
        pickle.dump(JHH, jhh_file)
    
    print('Ending shock: ' + shock)
    return JHH

# def get_jacobian(shock_list, TT, par, ss, pert = 1e-3):
#     # create folders for Jac    
#     for shock in shock_list:
#         if not(os.path.isdir('Jacobian_' + shock)):
#             os.mkdir('Jacobian_' + shock)

#     # start parallel run
#     # declare global pool
#     global pool
#     #num_processes = int(os.environ["SLURM_NPROCS"])
#     num_processes = 1
#     # print(num_processes)
    
#     with ProcessPoolExecutor(max_workers=num_processes) as p:
#         p.map(jac_worker, [(shock, TT, par, ss, pert) for shock in shock_list])

def get_jacobian(shock_name, TT, par, ss, pert=1e-3, num_processes=None):
    # create folders for Jac
    # print(shock_name)
    if not(os.path.isdir('Jacobian_' + shock_name)):
        os.mkdir('Jacobian_' + shock_name)

    # get Jacobians
    if num_processes is None:
        num_processes = par.get('jacobian_workers', min(TT, mp.cpu_count()))
    jac_worker((shock_name, TT, par, ss, pert, num_processes))




def combine_Jac(path_name, file_names):
    Jac = dict()
    # load outputs
    with open(os.path.join(path_name, 'Jac_' + file_names[0] + '.pkl'), 'rb') as JHH_pickle:
        JHH = pickle.load(JHH_pickle)
    outputs = list(JHH.keys())

    for o in list(set(outputs) - set(['tax', 'ra', 'transfer', 'rK', 'bUI'])):
        Jac[o] = dict()
        for i in file_names:
            with open(os.path.join(path_name, 'Jac_' + i + '.pkl'), 'rb') as Jac_pickle:
                Jac_i = pickle.load(Jac_pickle)
            Jac[o][i] = Jac_i[o][i]

    return Jac
