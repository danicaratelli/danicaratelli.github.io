# From impulse to levels
def to_level(G, out, shock, di, ss_val, TT):
    irf_level = np.ones(TT) * ss_val
    for t in range(TT):
        for s in range(TT):
            irf_ts = G[out][shock][t, s]
            irf_level[t] += irf_ts * di[s]
    return irf_level

rho = 0.8
imp = 'bUI'
isize = 1
di = isize * ss[imp] * rho ** (np.arange(TT))

for o in list(set(G.keys()).intersection(set(ss.keys()))):
    exec(o + "_lev" + " = to_level(G, o, imp, di, ss[o], TT)")


# Profits equation
plt.close()
plt.figure()
plt.subplot(2,3,1)
plt.plot(A_lev - p_lev)
plt.title('A-p')
plt.subplot(2,3,2)
#earnings_lev = to_level(G, 'earnings', imp, di, ss['Tax'] / ss['tax'], TT)
#plt.plot((Pi_lev) - (Y_lev - rK_lev * np.append(ss['K'], K_lev[:-1]) - earnings_lev))
profits_res_lev = to_level(G, 'profits_res', imp, di, ss['Y'] - ss['rK'] * ss['K'] - ss['Tax'] / ss['tax'], TT)
plt.plot(Pi_lev - profits_res_lev)
plt.title('Profits')
plt.subplot(2,3,3)
tmp = ss['rK'] * ss['K'] + (rK_lev - ss['rK']) * ss['K'] + (np.append(ss['K'], K_lev[:-1]) - ss['K']) * ss['rK']
plt.plot(div_lev - (tmp - I_lev))
#plt.plot(div_lev - (rK_lev * np.append(ss['K'], K_lev[:-1]) - I_lev))
plt.title('Dividends')
plt.subplot(2,3,4)
tmp = (1 + ss['ra']) * ss['p'] + ((ra_lev - ss['ra']) * ss['p'] + (np.append(ss['p'], p_lev[:-1]) - ss['p']) * (1 + ss['ra']))
plt.plot(tmp - (div_lev + p_lev))
plt.title('r_post')
plt.subplot(2,3,5)
plt.plot(to_level(G, 'res_budge', imp, di, 0, TT))
plt.title('Agg. budget')
plt.subplot(2,3,6)
plt.plot(to_level(G, 'walras_res', imp, di, 0, TT))
plt.title('Walras')

#plt.figure()
plt.subplot(2,2,4)
plt.plot(Y_lev, label='Output Y', color='black', linewidth=3)
Yother_lev = to_level(G, 'Yother', imp, di, ss['Y'], TT)
plt.plot(Yother_lev, label='C + I + vacancy cost', color='red', linestyle='dashed', linewidth=2)
plt.legend()
plt.title('Response to a ' + str(isize * 100) + '% icnrease in ' + imp)

plt.figure()
plt.subplot(2,2,1)
plt.plot(C_lev)
plt.title('Consumption')
plt.subplot(2,2,2)
plt.plot(to_level(G, 'A0', imp, di, ss['A'] * (1 + ss['ra']), TT))
plt.title('(1+r)*A(-1)')
plt.subplot(2,2,3)
earnings_lev = to_level(G, 'vcost', imp, di, ss['Tax'] / ss['tax'], TT)
plt.plot(earnings_lev)
plt.title('Earnings')
plt.subplot(2,2,4)
plt.plot(to_level(G, 'vcost', imp, di, ss['vcost'], TT))
plt.title('Vacancy Costs')

A0_lev = to_level(G, 'A0', imp, di, ss['A'] * (1 + ss['ra']), TT)
plt.plot((C_lev + A_lev - (A0_lev + earnings_lev + (Pi_lev - vcost_lev))), color='blue', linestyle='dotted')
          C + A - ((1 + ra) * A(-1) + Tax / tax + Pi - zeta * (v0 * pgrid0 + v1 * pgrid1 + v2 * pgrid2))

plt.plot(to_level(G, 'res_budge', imp, di, 0, TT), color='red', linestyle='dotted')
#
plt.plot((Pi_lev - vcost_lev) - (Ubill_lev * (1 - tax_lev) - Tax_lev))