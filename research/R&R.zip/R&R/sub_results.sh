#!/bin/bash
#SBATCH --job-name=get_results
#SBATCH --nodes=1                # Request N nodes
#SBATCH --ntasks-per-node=1      # Request n cores per node
#SBATCH --mem=200GB              # Request n GB RAM per core
#SBATCH --time=48:00:00          # total run time limit (HH:MM:SS)
#SBATCH --output=get_results-%j.output   # output
#SBATCH --partition=memq         # default partition

/data/unixhome/dcaratelli/anaconda3/bin/python main_results.py
