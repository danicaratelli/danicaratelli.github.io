import utils
import numpy as np
from numba import njit

def wageUE_AOB(U_p, E_bargaining_p, dE_p, J_bargaining_p, lms, par):
    # Extract relevant parameters
    M = par['M']        # number of bargaining subperiods
    nZ = par['nZ']      # number of idiosyncratic productivity shocks
    nA = par['nA']      # asset level of household
    nP = par['nP']      # possible firms met
    nW = par['nW']      # possible wages

    # Flip firm values
    J_bargaining_p_flip = np.flip(J_bargaining_p, axis=2)
    # initialize wage matrices and value matrices
    wage_i = np.zeros((nZ, nA, nP), dtype='uint32')
    wage_pi = np.zeros((nZ, nA, nP))
    V = np.zeros((nZ, nA, nP))
    dV = np.zeros((nZ, nA, nP))
    Pi = np.zeros((nZ, nA, nP))
    # get wages
    wage_i, wage_pi = get_wU(wage_i, wage_pi, U_p, E_bargaining_p, J_bargaining_p, J_bargaining_p_flip, lms, nZ, nA, nW, M)
    # get values
    V, dV, Pi = get_values(V, dV, Pi, E_bargaining_p[:, :, :, :, 0], dE_p[:, :, :, :, 0], J_bargaining_p[:, :, :, :, 0], wage_i, wage_pi, lms, nA, nZ, nW)

    return V, dV, Pi, wage_i, wage_pi

@njit
def get_wU(wage_i, wage_pi, U_p, E_bargaining_p, J_bargaining_p, J_bargaining_p_flip, lms, nZ, nA, nW, M):
    # Looping backwards to compute wages (and values)
    for iz in range(nZ):
        for ia in range(nA):
            # value of waiting for
            Wwait = U_p[iz, ia]
            Jwait = 0   # fill-in, will be updated later
            for ip in lms:
                for m in range(M-1, -1, -1):
                    if ((m+1) % 2)==1:  # firm's turn to propose wage
                        # get indifference wage
                        wage_i[iz, ia, ip], wage_pi[iz, ia, ip] = utils.simple_interpolation(Wwait, E_bargaining_p[iz, ia, :, ip, m])
                        # update waiting value
                        Jwait = J_bargaining_p[iz, ia, wage_i[iz, ia, ip], ip, m] * wage_pi[iz, ia, ip] + J_bargaining_p[iz, ia, np.minimum(wage_i[iz, ia, ip] + 1, nW - 1), ip, m] * (1 - wage_pi[iz, ia, ip])
                    else:
                        # get indifference wage
                        idx_tmp, pi_tmp = utils.simple_interpolation(Jwait, (J_bargaining_p_flip[iz, ia, :, ip, m]))
                        wage_i[iz, ia, ip], wage_pi[iz, ia, ip] = max(nW - (idx_tmp + 2), 0), 1 - pi_tmp
                        # update waiting value
                        Wwait = E_bargaining_p[iz, ia, wage_i[iz, ia, ip], ip, m] * wage_pi[iz, ia, ip] + E_bargaining_p[iz, ia, np.minimum(wage_i[iz, ia, ip] + 1, nW - 1), ip, m] * (1 - wage_pi[iz, ia, ip])


    return wage_i, wage_pi

@njit
def get_values(V, dV, Pi, E0, dE0, J0, wage_i, wage_pi, lms, nA, nZ, nW):
    for iz in range(nZ):
        for ia in range(nA):
            for ip in lms:
                # value of newly employed worker
                V[iz, ia, ip] = E0[iz, ia, wage_i[iz, ia, ip], ip] * wage_pi[iz, ia, ip] + E0[iz, ia, min(wage_i[iz, ia, ip] + 1, nW - 1), ip] * (1 - wage_pi[iz, ia, ip])
                # derivative
                dV[iz, ia, ip] = dE0[iz, ia, wage_i[iz, ia, ip], ip] * wage_pi[iz, ia, ip] + dE0[iz, ia, min(wage_i[iz, ia, ip] + 1, nW - 1), ip] * (1 - wage_pi[iz, ia, ip])
                # value of new firm
                Pi[iz, ia, ip] = J0[iz, ia, wage_i[iz, ia, ip], ip] * wage_pi[iz, ia, ip] + J0[iz, ia, min(wage_i[iz, ia, ip] + 1, nW - 1), ip] * (1 - wage_pi[iz, ia, ip])

    return V, dV, Pi