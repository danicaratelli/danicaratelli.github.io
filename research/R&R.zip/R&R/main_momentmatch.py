import os
# set current director as working directory
os.chdir("")
import numpy as np
import load_params_SS as load_params
import matplotlib.pyplot as plt
import Jac
import pickle
import pandas as pd
import pickle
import sys
import time
import multiprocessing as mp
import itertools
from filelock import FileLock


# Options
TT = 250
inaive = False
i_headline = False
i_distributional = True
shock_list = ['chi', 'drate']

# **** Benchmark model **** #
# Load Steady State
if inaive:
    fname = "ss_naive.pkl"
    jacname = "Jacobians_naive_250"
    tdname = "transition_naive_SMM"
    simname = "simuls_naive"
else:
    fname = "ss_calibration.pkl"
    jacname = "Jacobians_ss_250"
    tdname = "transition_SMM"
    simname = "simuls"


with open(fname, 'rb') as file:
    ss = pickle.load(file)

# Load
input = ss['inputs']
par = load_params.get_par(input, inaive)

# Loading and combining Jacobian
shock_list_model = ['ra', 'Z', 'tax', 'transfer',
              'lambda0', 'lambda1', 'lambda2', 'lambda3', 'lambda4', 'lambda5', 'lambda6', 'lambda7',
              'rK', 'sigmaJ', 'sigmaslope', 'bUI']
J = Jac.combine_Jac(jacname, shock_list_model)

# Blocks (inflation block)
import jacobian as jac
import model_blocks as blocks

# version with capitalist and production as solved blocks
block_list = [J, blocks.labor_flows, blocks.matching_tech, blocks.dividend, blocks.intermediaries,
              blocks.production, blocks.capitalist, blocks.earnings_posttax,
              blocks.asset_mkt, blocks.labor_mkt, blocks.fiscal, blocks.free_entry, blocks.walras]

exogenous = ['Z', 'transfer', 'sigmaJ', 'sigmaslope', 'bUI', 'zeta', 'drate', 'chi']
unknowns = ['theta0', 'theta1', 'theta2', 'theta3', 'theta4', 'theta5', 'theta6', 'theta7', 'Y', 'r', 'tax']
targets = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'h7', 'h8', 'h9', 'h10', 'h11']

# Get Jacobian
G = jac.get_G(block_list, exogenous, unknowns, targets, T=TT, ss=ss)

import smm
# in the simulation I discard Tgarbage number of periods from the start and end at (TT - Tgarbage) so that I go back to steady state
Tstop = 10
Tsim = 200
ngrid = 10
targets = np.array([1.19 / 100, 1.20 / 100, 1.57 / 100, 0.8914, 0.9109])  # SD and persistent of EU, EE, UE rates, and unemployment rate (in order)
ws = np.array([1, 0.75, 0.5, 0.3, 0.3])
ws = ws / np.sum(ws)

# Grids
if i_headline:
# optimal parameters:
    # Standard deviation of chi:    0.0083
    # Standard deviation of drate:  0.0283
    # Correlation of shocks:       -0.3889
    # Autocorrelation of chi:       0.7833
    # Autocorrelation of drate:     0.955
    SD1 = np.linspace(0.005, 0.015, ngrid)
    SD2 = np.linspace(0.015, 0.035, ngrid)
    corr12 = np.linspace(-0.7, -0.3, ngrid)
    rho1 = np.linspace(0.75, 0.85, ngrid)
    rho2 = np.linspace(0.9, 0.999, ngrid)


    inputs = []
    for vals in itertools.product(*[SD2, SD1, corr12, rho2,rho1]):
        inputs.append(dict(zip(['SD2', 'SD1', 'corr12', 'rho2', 'rho1'], vals)))
        inputs[len(inputs) - 1]['index'] = len(inputs) - 1

    # collect sbatch arguments for input/output IDs
    id = int(sys.argv[1])
    job = int(sys.argv[2])
    tasks = int(sys.argv[3])
    versions = len(inputs)

    # Subset inputs to portion to be run on this node
    subset = [inputs[i] for i in range(versions) if i % tasks == id - 1]

    # Run SMM
    def mp_worker(input):
        mom_res = smm.obj_fun(input, G, Tstop, Tsim, TT, ss, shock_list)
        xres = {'moments': mom_res, 'input': input}
        return xres

    # Run linear model to match headline moments
    # Run each model on each input set in parallel and save outputs
    start = time.time()
    p = mp.Pool(mp.cpu_count())
    for result in p.imap(mp_worker, subset):
        # Write outputs to pickle if model succeeds
        iloc = result['input']['index']
        todump = np.append(iloc, result['moments'])
        # smm_moments[iloc, :] = result['moments']
        # smm_inputs[iloc] = result['input']
        if isinstance(result, dict):
            print('Model {i} succeeded at {t} min'.format(i = iloc, t = round((time.time() - start) / 60, 2)))
            with FileLock(tdname + '/job{j}_n{i}.pkl.lock'.format(j = job, i = iloc)):
                with open(tdname + '/job{j}_n{i}.pkl'.format(j = job, i = iloc), 'wb') as f:
                    pickle.dump(todump, f)
        else:
            print('Model {i} failed at {t} min'.format(i = iloc, t = round((time.time() - start) / 60, 2)))

elif i_distributional:

    # # Load SS
    # all_files = os.listdir(tdname)
    # pkl_files = [f for f in all_files if f.endswith('.pkl')]
    # # pkl_files = np.sort(pkl_files)
    # smm_moments = np.nan * np.zeros((ngrid ** 5, 5))
    # # smm_inputs = [{} for _ in range(len(inputs))]
    # for file in pkl_files:
    #     # print(" **** File: " + file + " **** ")
    #     with open(tdname + "//" + file, 'rb') as file:
    #         ftmp = pickle.load(file)
    #     iloc = int(ftmp[0])
    #     smm_moments[iloc, :] = ftmp[1:]

    # # Extract best parameters
    # ws = np.array([0.4, 0.3, 0.3, 0.0, 0.0])
    # loc_star = np.argmin(np.sum(ws * (smm_moments - targets[np.newaxis, :]) ** 2, axis=1))
    # mom_star = smm_moments[loc_star]
    # inputs_star = inputs[loc_star]
    # SD2, SD1, corr12, rho2, rho1 = inputs_star['SD2'], inputs_star['SD1'], inputs_star['corr12'], inputs_star['rho2'], inputs_star['rho1']
    # print('Headline moments: (Model, Data)')
    # print('Standard deviation of EE:           ', (np.round(mom_star[0],4), np.round(targets[0],4)))
    # print('                   of EU:           ', (np.round(mom_star[1],4), np.round(targets[1],4)))
    # print('                   of Unemployment: ', (np.round(mom_star[2],4), np.round(targets[2],4)))
    # print('\n')
    # # print('Optimal parameters:')
    # # print('Standard deviation of ' + shock_list[0] + ':   ', np.round(inputs_star['SD1'],4))
    # # print('Standard deviation of ' + shock_list[1] + ': ', np.round(inputs_star['SD2'],4))
    # # print('Correlation of shocks:      ', np.round(inputs_star['corr12'],4))
    # # print('Autocorrelation of ' + shock_list[0] + ':      ', np.round(inputs_star['rho1'],4))
    # # print('Autocorrelation of ' + shock_list[1] + ':    ', np.round(inputs_star['rho2'],4))

    if inaive:
        SD1, SD2, corr12, rho1, rho2 = 0.0139, 0.0194, -0.6556, 0.85, 0.955
        SD1 = SD1 * .780327868852459
        SD2 = SD2 * .780327868852459
    else:
        SD1, SD2, corr12, rho1, rho2 = 0.0083, 0.0283, -0.3889, 0.7833, 0.955
        SD1 = SD1 * 0.672696438665913
        SD2 = SD2 * 0.672696438665913
    

    # # Simulate moments
    # sim2, sim1 = smm.dsimul(Tstop, TT, Tsim, rho1, rho2, SD1, SD2, corr12, ss, shock_list)
    # sim2 = sim2 - ss[shock_list[1]]
    # sim1 = sim1 - ss[shock_list[0]]

    # EEs = G['EE_rate'][shock_list[0]] @ sim1 + G['EE_rate'][shock_list[1]] @ sim2
    # EUs = G['EU_rate'][shock_list[0]] @ sim1 + G['EU_rate'][shock_list[1]] @ sim2

    # EELs = G['EE_rateL'][shock_list[0]] @ sim1 + G['EE_rateL'][shock_list[1]] @ sim2
    # EEHs = G['EE_rateH'][shock_list[0]] @ sim1 + G['EE_rateH'][shock_list[1]] @ sim2

    # np.mean(np.std(EEs[:(2 * Tstop), :], axis=0))
    # np.mean(np.std(EUs[:(2 * Tstop), :], axis=0))


    # Get distributional moments
    moms = {'SD1': SD1, 'SD2': SD2, 'corr12': corr12, 'rho1': rho1, 'rho2': rho2}
    # Tsim = 21
    scale = 10
    # save simulations
    Tsim = 100
    inputs = np.arange(Tsim)


    # collect sbatch arguments for input/output IDs
    id = int(sys.argv[1])
    job = int(sys.argv[2])
    tasks = int(sys.argv[3])
    versions = len(inputs)

    # Subset inputs to portion to be run on this node
    subset = [inputs[i] for i in range(versions) if i % tasks == id - 1]

    # Run SMM
    def mp_worker(input):
        istring = str(input)
        smm.get_distributional_moments(moms, G, Tstop, TT, Tsim, par, ss, scale, shock_list, istring, simname)

    # Run linear model to match headline moments
    # Run each model on each input set in parallel and save outputs
    start = time.time()
    p = mp.Pool(mp.cpu_count())
    for result in p.imap(mp_worker, subset):
        # Once over, print time
        print('Model succeeded at {t} min'.format(t = round((time.time() - start) / 60, 2)))
    
    # Load distributional simulations    
    all_files = os.listdir(simname)
    csv_files = [f for f in all_files if f.endswith('.csv')]
    EE_moments = np.zeros((len(csv_files), 3)) #all, L, H
    EU_moments = np.zeros((len(csv_files), 3)) #all, L, H
    U_moments = np.zeros((len(csv_files), 3)) #all, L, H
    j = 0
    for file in csv_files:
        # print(" **** File: " + file + " **** ")
        with open(simname + "//" + file, 'rb') as file:
            ftmp = pd.read_csv(file)        
        # EE rate
        EEj = np.array(ftmp.EE)
        EELj = np.array(ftmp.EEL)
        EEHj = np.array(ftmp.EEH)
        EE_moments[j, 0] = np.std(EEj[:6*Tstop])
        EE_moments[j, 1] = np.std(EELj[:6*Tstop])
        EE_moments[j, 2] = np.std(EEHj[:6*Tstop])
        # EU rate
        EUj = np.array(ftmp.EU)
        EULj = np.array(ftmp.EUL)
        EUHj = np.array(ftmp.EUH)
        EU_moments[j, 0] = np.std(EUj[:6*Tstop])
        EU_moments[j, 1] = np.std(EULj[:6*Tstop])
        EU_moments[j, 2] = np.std(EUHj[:6*Tstop])
        # U rate
        Uj = np.array(ftmp.u)
        ULj = np.array(ftmp.uL)
        UHj = np.array(ftmp.uH)
        U_moments[j, 0] = np.std(Uj[:6*Tstop])
        U_moments[j, 1] = np.std(ULj[:6*Tstop])
        U_moments[j, 2] = np.std(UHj[:6*Tstop])

        j+=1

    # Print results
    sdee = scale * np.mean(EE_moments[:,0])
    sdeeL = scale * np.mean(EE_moments[:,1])
    sdeeH = scale * np.mean(EE_moments[:,2])

    newscale = 1 #0.0119 / sdee
    print('Headline moments: (Model, Data)')
    print('Standard deviation of EE - Headline:              ', (np.round(100 * newscale *sdee,3), 1.19))
    print('                   of EE - High wealth:           ', (np.round(100 * newscale *sdeeH,3), 0.99))
    print('                   of EE - Low wealth:            ', (np.round(100 * newscale *sdeeL,3), 1.54))    
    
    sdeu = scale * np.mean(EU_moments[:,0])
    sdeuL = scale * np.mean(EU_moments[:,1])
    sdeuH = scale * np.mean(EU_moments[:,2])

    print('Headline moments: (Model, Data)')
    print('Standard deviation of EU - Headline:              ', (np.round(100 * newscale *sdeu,3), 1.20))
    print('                   of EU - High wealth:           ', (np.round(100 * newscale *sdeuH,3), 0.91))
    print('                   of EU - Low wealth:            ', (np.round(100 * newscale *sdeuL,3), 1.55))

    sdu = scale * np.mean(U_moments[:,0])
    sduL = scale * np.mean(U_moments[:,1])
    sduH = scale * np.mean(U_moments[:,2])

    print('Headline moments: (Model, Data)')
    print('Standard deviation of U - Headline:              ', (np.round(100 * newscale *sdu,3), 1.57))
    print('                   of U - High wealth:           ', (np.round(100 * newscale *sduH,3), 1.03))
    print('                   of U - Low wealth:            ', (np.round(100 * newscale *sduL,3), 2.45))