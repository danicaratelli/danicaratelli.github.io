#!/bin/bash
#SBATCH --job-name=model
#SBATCH --array=1-1
#SBATCH --ntasks-per-node=1
#SBATCH --mem=0
#SBATCH --exclusive
#SBATCH --partition=memq        # default partition

module purge
module load anaconda3/3.11.4
python3 main_SS.py $SLURM_ARRAY_TASK_ID $SLURM_ARRAY_JOB_ID $SLURM_ARRAY_TASK_COUNT