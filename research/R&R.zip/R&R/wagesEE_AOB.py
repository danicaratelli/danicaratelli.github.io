import numpy as np
import utils
from numba import njit

def wageEE_AOB(E_bargaining_p, dE_bargaining_p, E_p, dE_p, J_bargaining_p, J_p, lms, par):
    # Extract relevant parameters
    M = par['M']        # number of bargaining subperiods
    nZ = par['nZ']      # number of idiosyncratic productivity shocks
    nA = par['nA']      # asset level of household
    nP = par['nP']      # possible firms met
    nW = par['nW']      # possible wages
    nT = par['nT']      # possible tenure
    EValpha = par['EValpha']

    # Flip firm values
    J_flip = np.flip(J_p, axis=2)
    J_bargaining_p_flip = np.flip(J_bargaining_p, axis=2)
    # Initialize wage matrices. Dimensions correspond to:
    # nZ->idio. shock, nA->assets, nW->wage pre-poach, nP->rung incumbent, nT->tenure pre-poach, nP->rung poacher
    wage_i = np.ones((nZ, nA, nW, nP, nT-1, nP), dtype='uint32')
    wage_pi = np.ones((nZ, nA, nW, nP, nT-1, nP))

    # Determine break-even values and which of the four cases we are in
    # 1) best offer from poacher is worse than current contract
    # 2) stay at incumbent and Bertand competition between firms
    # 3) move to poacher and Bertand competition between firms
    # 4) move to poacher and 1-1 negotiation
    Vpoacher_max, dVpoacher_max, Vincumbent_max, dVincumbent_max, w_idx, w_pi, iscase = get_case(E_p, dE_p, E_bargaining_p, dE_bargaining_p, J_flip, J_bargaining_p_flip, lms, nZ, nA, nW, nP, nT, M)
    iscase[iscase == 1] = 2  # TO REMOVE
    Iswitch = (iscase==0) * -1 + ((iscase >=1) & (iscase <=2)) * 0 + (iscase>2) * 1.0 # 0: stay, 1: switch, -1: NA

    # Probability of switching (based on maximal values inconsistency with EV formulas?)
    # Vincumbent_max = Vincumbent_max.astype('ufloat128')
    # Vpoacher_max = Vpoacher_max.astype('ufloat128')
    # qswitch = 1 / (1 + np.exp(EValpha * (Vincumbent_max[:, :, :, :, np.newaxis] - Vpoacher_max[:, :, np.newaxis, np.newaxis, :, 0])))
    # ad hoc: difference is very large and qswitch there is 1
    ev_tmp = EValpha * (Vincumbent_max[:, :, :, :, np.newaxis] - Vpoacher_max[:, :, np.newaxis, np.newaxis, :, 0])    
    ev_tmp[ev_tmp > 50] = 50
    qswitch = 1 / (1 + np.exp(ev_tmp))    
    # in case 1: 0 probability of switching
    # qswitch[iscase[:, :, 0, :, :, :]==1] = 0
    qswitch = qswitch[:, :, np.newaxis, :, :, :]
    # qswitch = 0.5 + 0 * qswitch # TO REMOVE

    # Case 1 (stay at incumbent with no change in wage)
    wage_i = wage_i * np.arange(nW, dtype=np.uint32)[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis, np.newaxis]
    V = np.repeat(E_p[:, :, :, :, 1:, np.newaxis], par['nP'], axis=5)
    dV = np.repeat(dE_p[:, :, :, :, 1:, np.newaxis], par['nP'], axis=5)
    Pi = np.repeat(J_p[:, :, :, :, 1:, np.newaxis], par['nP'], axis=5)

    # Cases 2 (Bertrand and stay) and 3 (Bertrand and switch)
    wage_i, wage_pi, V, dV, Pi = get_wE_23(wage_i, wage_pi, V, dV, Pi, Vpoacher_max, Vincumbent_max, iscase, E_p, dE_p, J_p, lms, nZ, nA, nW, nP, nT)

    # get wages and values for case 4
    wage_i, wage_pi, V, dV, Pi = get_wE_4(iscase, wage_i, wage_pi, V, dV, Pi, Vpoacher_max, Vincumbent_max, E_bargaining_p, dE_bargaining_p, J_bargaining_p, J_bargaining_p_flip, lms, nZ, nA, nW, nP, nT, M)

    Vfinal, dVfinal, J_incumbent, J_poacher, wage_i_loser, wage_pi_loser = finalize_wageEE(
        iscase, qswitch, V, dV, Pi, Vpoacher_max, dVpoacher_max,
        Vincumbent_max, dVincumbent_max, w_idx, w_pi, EValpha, np.euler_gamma,
        par['gE'], nZ, nA, nW, nP, nT
    )


    return Vfinal, dVfinal, J_incumbent, J_poacher, wage_i, wage_i_loser, wage_pi, wage_pi_loser, iscase, Iswitch, qswitch


@njit
def _logsumexp_scalar(x, y):
    m = x if x >= y else y
    return m + np.log(np.exp(x - m) + np.exp(y - m))


@njit
def finalize_wageEE(iscase, qswitch, V, dV, Pi, Vpoacher_max, dVpoacher_max,
                    Vincumbent_max, dVincumbent_max, w_idx, w_pi, EValpha,
                    euler_gamma, gE, nZ, nA, nW, nP, nT):
    Vfinal = np.empty_like(V)
    dVfinal = np.empty_like(dV)
    J_incumbent = np.zeros_like(Pi)
    J_poacher = np.zeros_like(Pi)
    wage_i_loser = np.ones((nZ, nA, nW, nP, nT - 1, nP), dtype=np.uint32)
    wage_pi_loser = np.ones((nZ, nA, nW, nP, nT - 1, nP))

    for iz in range(nZ):
        for ia in range(nA):
            for iw in range(nW):
                for ip_o in range(nP):
                    for it in range(nT - 1):
                        for ip_d in range(nP):
                            case = iscase[iz, ia, iw, ip_o, it, ip_d]
                            accessible = gE[ip_o, ip_d] > 0 or (ip_o == nP - 1 and ip_d == nP - 1)
                            if case >= 1 and case <= 2:
                                Vloser = Vpoacher_max[iz, ia, ip_d, 0]
                                dVloser = dVpoacher_max[iz, ia, ip_d, 0]
                                if accessible:
                                    wage_i_loser[iz, ia, iw, ip_o, it, ip_d] = w_idx[iz, ia, ip_d, 0, 0]
                                    wage_pi_loser[iz, ia, iw, ip_o, it, ip_d] = w_pi[iz, ia, ip_d, 0, 0]
                            elif case >= 3:
                                Vloser = Vincumbent_max[iz, ia, ip_o, it]
                                dVloser = dVincumbent_max[iz, ia, ip_o, it]
                                if accessible:
                                    wage_i_loser[iz, ia, iw, ip_o, it, ip_d] = w_idx[iz, ia, ip_o, it + 1, 0]
                                    wage_pi_loser[iz, ia, iw, ip_o, it, ip_d] = w_pi[iz, ia, ip_o, it + 1, 0]
                            else:
                                Vloser = 0.0
                                dVloser = dVpoacher_max[iz, ia, ip_d, 0]
                                if accessible:
                                    wage_i_loser[iz, ia, iw, ip_o, it, ip_d] = 0
                                    wage_pi_loser[iz, ia, iw, ip_o, it, ip_d] = 0.0

                            term0 = _logsumexp_scalar(EValpha * V[iz, ia, iw, ip_o, it, ip_d],
                                                       EValpha * Vloser)
                            Vfinal[iz, ia, iw, ip_o, it, ip_d] = (euler_gamma + term0) / EValpha
                            dVfinal[iz, ia, iw, ip_o, it, ip_d] = np.exp(
                                _logsumexp_scalar(EValpha * V[iz, ia, iw, ip_o, it, ip_d] + np.log(dV[iz, ia, iw, ip_o, it, ip_d]),
                                                   EValpha * Vloser + np.log(dVloser)) - term0
                            )

                            q = qswitch[iz, ia, 0, ip_o, it, ip_d]
                            if case == 1 or case == 2:
                                J_incumbent[iz, ia, iw, ip_o, it, ip_d] = (1 - q) * Pi[iz, ia, iw, ip_o, it, ip_d]
                            elif case == 3 or case == 4:
                                J_poacher[iz, ia, iw, ip_o, it, ip_d] = q * Pi[iz, ia, iw, ip_o, it, ip_d]

    return Vfinal, dVfinal, J_incumbent, J_poacher, wage_i_loser, wage_pi_loser

@njit
def get_case(E_p, dE_p, E_bargaining_p, dE_bargaining_p, J_flip, J_bargaining_p_flip, lms, nZ, nA, nW, nP, nT, M):
    # max wage, making firm indifferent with posting vacancy
    w_idx = np.zeros((nZ, nA, nP, nT, M), dtype='uint32')
    w_pi = np.zeros((nZ, nA, nP, nT, M))
    for ip in range(nP):
        for iz in range(nZ):
            for it in range(nT):
                for ia in range(nA):
                    idx_tmp, pi_tmp = utils.simple_interpolation(0, J_flip[iz, ia, :, ip, it])
                    w_idx[iz, ia, ip, it, 0], w_pi[iz, ia, ip, it, 0] = max(nW - (idx_tmp + 2), 0), 1 -pi_tmp
                    if it == 0:
                        for im in range(1, M):
                            idx_tmp, pi_tmp = utils.simple_interpolation(0, J_bargaining_p_flip[iz, ia, :, ip, im])
                            w_idx[iz, ia, ip, it, im], w_pi[iz, ia, ip, it, im] = max(nW - (idx_tmp + 2), 0), 1 -pi_tmp

    # full value when staying and switching
    Vincumbent_max = np.zeros((nZ, nA, nP, nT - 1))
    dVincumbent_max = np.zeros((nZ, nA, nP, nT - 1))
    Vpoacher_max = np.zeros((nZ, nA, nP, M))
    dVpoacher_max = np.zeros((nZ, nA, nP, M))
    for ip in range(nP):
        for iz in range(nZ):
            for ia in range(nA):
                # value of switching (for each bargaining sub-period)
                for im in range(M):
                    Vpoacher_max[iz, ia, ip, im] = E_bargaining_p[iz, ia, w_idx[iz, ia, ip, 0, im], ip, im] * w_pi[iz, ia, ip, 0, im] + \
                                              E_bargaining_p[iz, ia, np.minimum(w_idx[iz, ia, ip, 0, im] + 1, nW - 1), ip, im] * (1 - w_pi[iz, ia, ip, 0, im])
                    dVpoacher_max[iz, ia, ip, im] = dE_bargaining_p[iz, ia, w_idx[iz, ia, ip, 0, im], ip, im] * w_pi[iz, ia, ip, 0, im] + \
                                                   dE_bargaining_p[iz, ia, np.minimum(w_idx[iz, ia, ip, 0, im] + 1, nW - 1), ip, im] * (1 - w_pi[iz, ia, ip, 0, im])
                # value of staying (for each tenure)
                for it in range(1, nT):
                    Vincumbent_max[iz, ia, ip, it - 1] = (E_p[iz, ia, w_idx[iz, ia, ip, it, 0], ip, it] * w_pi[iz, ia, ip, it, 0] +
                                                     E_p[iz, ia, np.minimum(w_idx[iz, ia, ip, it, 0] + 1, nW - 1), ip, it] * (1 - w_pi[iz, ia, ip, it, 0]))
                    dVincumbent_max[iz, ia, ip, it - 1] = (dE_p[iz, ia, w_idx[iz, ia, ip, it, 0], ip, it] * w_pi[iz, ia, ip, it, 0] +
                                                      dE_p[iz, ia, np.minimum(w_idx[iz, ia, ip, it, 0] + 1, nW - 1), ip, it] * (1 - w_pi[iz, ia, ip, it, 0]))

    # determine case we are in
    iscase = np.zeros((nZ, nA, nW, nP, nT-1, nP))
    for iz in range(nZ):
        for ia in range(nA):
            for iw in range(nW):
                for ip_o in range(nP):
                    for it in range(1, nT):
                        for ip_d in lms[ip_o]:
                            # case 1: worker retained by incumbent with no renegotiation
                            if Vpoacher_max[iz, ia, ip_d, 0] <= E_p[iz, ia, iw, ip_o, it]:
                                iscase[iz, ia, iw, ip_o, it - 1, ip_d] = 1
                            elif Vpoacher_max[iz, ia, ip_d, 0] < Vincumbent_max[iz, ia, ip_o, it - 1]:
                                iscase[iz, ia, iw, ip_o, it - 1, ip_d] = 2
                            elif Vpoacher_max[iz, ia, ip_d, 1] <= Vincumbent_max[iz, ia, ip_o, it - 1] < Vpoacher_max[iz, ia, ip_d, 0]:
                                iscase[iz, ia, iw, ip_o, it - 1, ip_d] = 3
                            elif Vincumbent_max[iz, ia, ip_o, it - 1] <= Vpoacher_max[iz, ia, ip_d, 1]:
                                iscase[iz, ia, iw, ip_o, it - 1, ip_d] = 4

    return Vpoacher_max, dVpoacher_max, Vincumbent_max, dVincumbent_max, w_idx, w_pi, iscase

@njit
def get_wE_23(wage_i, wage_pi, V, dV, Pi, Vpoacher_max, Vincumbent_max, iscase, E_p, dE_p, J_p, lms, nZ, nA, nW, nP, nT):
    for iz in range(nZ):
        for ia in range(nA):
            for iw in range(nW):
                for ip_o in range(nP):
                    for it in range(1, nT):
                        for ip_d in lms[ip_o]:
                            if iscase[iz, ia, iw, ip_o, it-1, ip_d]==2:
                                wage_i[iz, ia, iw, ip_o, it - 1, ip_d], wage_pi[iz, ia, iw, ip_o, it - 1, ip_d] = utils.simple_interpolation(Vpoacher_max[iz, ia, ip_d, 0], E_p[iz, ia, :, ip_o, it])
                                V[iz, ia, iw, ip_o, it - 1, ip_d] = Vpoacher_max[iz, ia, ip_d, 0]
                                                                    #(E_p[iz, ia, wage_i[iz, ia, iw, ip_o, it-1, ip_d], ip_o, it] * wage_pi[iz, ia, iw, ip_o, it-1, ip_d] +
                                                                    #  E_p[iz, ia, np.minimum(wage_i[iz, ia, iw, ip_o, it-1, ip_d] + 1, nW - 1), ip_o, it] * (1 - wage_pi[iz, ia, iw, ip_o, it-1, ip_d]))
                                dV[iz, ia, iw, ip_o, it - 1, ip_d] = (dE_p[iz, ia, wage_i[iz, ia, iw, ip_o, it-1, ip_d], ip_o, it] * wage_pi[iz, ia, iw, ip_o, it-1, ip_d] +
                                                                      dE_p[iz, ia, np.minimum(wage_i[iz, ia, iw, ip_o, it-1, ip_d] + 1, nW - 1), ip_o, it] * (1 - wage_pi[iz, ia, iw, ip_o, it-1, ip_d]))
                                Pi[iz, ia, iw, ip_o, it - 1, ip_d] = (J_p[iz, ia, wage_i[iz, ia, iw, ip_o, it-1, ip_d], ip_o, it] * wage_pi[iz, ia, iw, ip_o, it-1, ip_d] +
                                                                      J_p[iz, ia, np.minimum(wage_i[iz, ia, iw, ip_o, it-1, ip_d] + 1, nW - 1), ip_o, it] * (1 - wage_pi[iz, ia, iw, ip_o, it-1, ip_d]))
                            elif iscase[iz, ia, iw, ip_o, it-1, ip_d]==3:
                                wage_i[iz, ia, iw, ip_o, it - 1, ip_d], wage_pi[iz, ia, iw, ip_o, it-1, ip_d] = utils.simple_interpolation(Vincumbent_max[iz, ia, ip_o, it-1], E_p[iz, ia, :, ip_d, 0])
                                V[iz, ia, iw, ip_o, it - 1, ip_d] = Vincumbent_max[iz, ia, ip_o, it-1]
                                dV[iz, ia, iw, ip_o, it - 1, ip_d] = (dE_p[iz, ia, wage_i[iz, ia, iw, ip_o, it - 1, ip_d], ip_d, 0] * wage_pi[iz, ia, iw, ip_o, it - 1, ip_d] +
                                                                  dE_p[iz, ia, np.minimum(wage_i[iz, ia, iw, ip_o, it - 1, ip_d] + 1, nW - 1), ip_d, 0] * (1 - wage_pi[iz, ia, iw, ip_o, it - 1, ip_d]))
                                Pi[iz, ia, iw, ip_o, it - 1, ip_d] = (J_p[iz, ia, wage_i[iz, ia, iw, ip_o, it - 1, ip_d], ip_d, 0] * wage_pi[iz, ia, iw, ip_o, it - 1, ip_d] +
                                                                  J_p[iz, ia, np.minimum(wage_i[iz, ia, iw, ip_o, it - 1, ip_d] + 1, nW - 1), ip_d, 0] * (1 - wage_pi[iz, ia, iw, ip_o, it - 1, ip_d]))

    return wage_i, wage_pi, V, dV, Pi

@njit
def get_wE_4(iscase, wage_i, wage_pi, V, dV, Pi, Vpoacher_max, Vincumbent_max, E_bargaining_p, dE_bargaining_p, J_bargaining_p, J_bargaining_p_flip, lms, nZ, nA, nW, nP, nT, M):
    # Looping backwards to compute wages (and values)
    for iz in range(nZ):
        for ia in range(nA):
            for iw in range(nW):
                for ip_o in range(nP):
                    for it in range(1, nT):
                        for ip_d in lms[ip_o]:
                            # check cases
                            if iscase[iz, ia, iw, ip_o, it - 1, ip_d] == 4:
                                # initialize waiting values
                                Wwait = Vincumbent_max[iz, ia, ip_o, it-1]
                                Jwait = 0
                                # finding last sub-period in which max value of switching > max value of staying
                                mend = M - 1
                                while Vpoacher_max[iz, ia, ip_d, mend] < Vincumbent_max[iz, ia, ip_o, it-1]:
                                    mend -= 1
                                for m in range(mend, -1, -1):
                                    if ((m + 1) % 2) == 1:  # firm's turn to propose wage
                                        # get indifference wage
                                        wage_i[iz, ia, iw, ip_o, it-1, ip_d], wage_pi[iz, ia, iw, ip_o, it-1, ip_d] = utils.simple_interpolation(Wwait, E_bargaining_p[iz, ia, :, ip_d, m])
                                        # update waiting value
                                        Jwait = J_bargaining_p[iz, ia, wage_i[iz, ia, iw, ip_o, it-1, ip_d], ip_d, m] * wage_pi[iz, ia, iw, ip_o, it-1, ip_d] + \
                                                J_bargaining_p[iz, ia, np.minimum(wage_i[iz, ia, iw, ip_o, it-1, ip_d] + 1, nW - 1), ip_d, m] * (1 - wage_pi[iz, ia, iw, ip_o, it-1, ip_d])
                                        if m==0:    #if change that firms start will need to include this also in else that follows
                                            V[iz, ia, iw, ip_o, it-1, ip_d] = Wwait
                                            dV[iz, ia, iw, ip_o, it - 1, ip_d] = dE_bargaining_p[iz, ia, wage_i[iz, ia, iw, ip_o, it-1, ip_d], ip_d, m] * wage_pi[iz, ia, iw, ip_o, it-1, ip_d] + \
                                                                                 dE_bargaining_p[iz, ia, np.minimum(wage_i[iz, ia, iw, ip_o, it-1, ip_d] + 1, nW - 1), ip_d, m] * (1 - wage_pi[iz, ia, iw, ip_o, it-1, ip_d])
                                            Pi[iz, ia, iw, ip_o, it - 1, ip_d] = Jwait
                                    else:
                                        # get indifference wage
                                        idx_tmp, pi_tmp = utils.simple_interpolation(Jwait, (J_bargaining_p_flip[iz, ia, :, ip_d, m]))
                                        wage_i[iz, ia, iw, ip_o, it-1, ip_d], wage_pi[iz, ia, iw, ip_o, it-1, ip_d] = max(nW - (idx_tmp + 2), 0), 1 -pi_tmp
                                        # update waiting value
                                        Wwait = E_bargaining_p[iz, ia, wage_i[iz, ia, iw, ip_o, it-1, ip_d], ip_d, m] * wage_pi[iz, ia, iw, ip_o, it-1, ip_d] + \
                                                E_bargaining_p[iz, ia, np.minimum(wage_i[iz, ia, iw, ip_o, it-1, ip_d] + 1, nW - 1), ip_d, m] * (1 - wage_pi[iz, ia, iw, ip_o, it-1, ip_d])

    return wage_i, wage_pi, V, dV, Pi

@njit
def get_V_4(iscase, wage_i, wage_pi, V, dV, Pi, E_p, dE_p, J_p, lms, nZ, nA, nW, nP, nT):
    # Looping backwards to compute wages (and values)
    for iz in range(nZ):
        for ia in range(nA):
            for iw in range(nW):
                for ip_o in range(nP):
                    for it in range(1, nT):
                        for ip_d in lms[ip_o]:
                            # check cases
                            if iscase[iz, ia, iw, ip_o, it - 1, ip_d] == 4:
                                # value of newly employed worker
                                V[iz, ia, iw, ip_o, it-1, ip_d] = E_p[iz, ia, wage_i[iz, ia, iw, ip_o, it-1, ip_d], ip_d, 0] * wage_pi[iz, ia, iw, ip_o, it-1, ip_d] + \
                                                                E_p[iz, ia, min(wage_i[iz, ia, iw, ip_o, it-1, ip_d] + 1, nW - 1), ip_d, 0] * (1 - wage_pi[iz, ia, iw, ip_o, it-1, ip_d])
                                # derivative
                                dV[iz, ia, iw, ip_o, it-1, ip_d] = dE_p[iz, ia, wage_i[iz, ia, iw, ip_o, it-1, ip_d], ip_d, 0] * wage_pi[iz, ia, iw, ip_o, it-1, ip_d] + \
                                                                 dE_p[iz, ia, min(wage_i[iz, ia, iw, ip_o, it-1, ip_d] + 1, nW - 1), ip_d, 0] * (1 - wage_pi[iz, ia, iw, ip_o, it-1, ip_d])
                                # value of new firm
                                Pi[iz, ia, iw, ip_o, it-1, ip_d] = J_p[iz, ia, wage_i[iz, ia, iw, ip_o, it-1, ip_d], ip_d, 0] * wage_pi[iz, ia, iw, ip_o, it-1, ip_d] + \
                                                                 J_p[iz, ia, min(wage_i[iz, ia, iw, ip_o, it-1, ip_d] + 1, nW - 1), ip_d, 0] * (1 - wage_pi[iz, ia, iw, ip_o, it-1, ip_d])

    return V, dV, Pi
