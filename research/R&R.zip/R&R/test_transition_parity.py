import unittest
import pickle
import tempfile
from pathlib import Path

import numpy as np

import HHhelp_AOB as HH
import Jac
import Jac_help
import load_params_SS
import model_blocks
import solveSS_AOB
import utils


INPUTS = {
    'zlow': -0.6414269805898185, 'Pi11': 0.85, 'zeta': 1.1,
    'poly1': 0.09, 'poly2': 0.0320758466, 'poly3': -0.0229250279,
    'poly4': 0.0036, 's': 1 / 3, 'sigma0': 0.01998,
    'dbeta': 0.012, 'chi': 0.19333333, 'bUI': 0.225, 'index': 0,
}


def initial_household_state(par, r, bUI):
    a = par['a_grid']
    w = par['w_grid']
    z = par['z_grid']
    p = par['p_grid']
    cU = (bUI + 0.5 * (a[np.newaxis, :] - a[0])) * np.ones((par['nZ'], 1))
    cE = (0.6 * w[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]
          + z[:, np.newaxis, np.newaxis, np.newaxis, np.newaxis]
          * (a[np.newaxis, :, np.newaxis, np.newaxis, np.newaxis] - a[0] + bUI))
    cE = cE * np.ones((par['nZ'], 1, par['nW'], par['nP'], par['nT']))
    U = utils.u(cU, par['eis'])
    E = utils.u(cE, par['eis'])
    Eb = E[:, :, :, :, 0, np.newaxis] * 1.05 ** np.arange(par['M'])
    dU = (1 + r) * utils.du(cU, par['eis'])
    dE = (1 + r) * utils.du(cE, par['eis'])
    dEb = utils.du(cE, par['eis'])[:, :, :, :, 0, np.newaxis] * 1.05 ** np.arange(par['M'])
    J = ((z[:, np.newaxis] * p[np.newaxis, :])[:, np.newaxis, np.newaxis, :, np.newaxis]
         - w[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis])
    J = J * np.ones((par['nZ'], par['nA'], par['nW'], par['nP'], par['nT']))
    J *= (1 - r) / (1 - par['sigma'][-1])
    Jb = J[:, :, :, :, 0, np.newaxis] * 0.95 ** np.arange(par['M'])
    return cU, cE, U, E, Eb, dU, dE, dEb, J, Jb


class TransitionParityChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.par = load_params_SS.get_par(INPUTS)
        cls.par['bUI'] = np.array([0.17, 0.31])
        cls.r = 0.004
        cls.tax = -0.17
        cls.transfer = 0.0
        thetas = np.array([15.001011471099025, 0.171313592775733,
                           0.38304462748202056, 0.07032688363741249,
                           0.09508545407551863, 1.3493827872088155,
                           1.736562930225245, 5.877709860593139])
        _, cls.lambdas = solveSS_AOB.matching_fnc_1(thetas, cls.par)

    def assert_close(self, left, right, tol=2e-11):
        np.testing.assert_allclose(left, right, rtol=tol, atol=tol)

    def test_steady_state_bookkeeping_regressions(self):
        DU = np.array([[[0.10, 0.05], [0.15, 0.10]]])
        DE = np.zeros((1, 2, 1, 1, 1, 2))
        DE[0, 0, 0, 0, 0, :] = (0.20, 0.10)
        DE[0, 1, 0, 0, 0, :] = (0.20, 0.10)
        a_grid = np.array([1.0, 3.0])
        A_pre, AU_pre, AE_pre = solveSS_AOB.aggregate_pre_assets(DU, DE, a_grid)
        self.assertAlmostEqual(A_pre, AU_pre + AE_pre)
        self.assertAlmostEqual(A_pre, 2.10)

        DU_scaled = np.array([[0.10, 0.15]])
        DE_scaled = np.array([[[[[0.25]]]]])
        DU_normalized, DE_normalized = HH.normalize_distribution_mass(DU_scaled, DE_scaled)
        self.assertAlmostEqual(DU_normalized.sum() + DE_normalized.sum(), 1.0)
        self.assertAlmostEqual(DU_scaled.sum() + DE_scaled.sum(), 0.5)

        original_inputs = dict(INPUTS)
        par = load_params_SS.get_par(original_inputs)
        original_inputs['bUI'] = 999.0
        self.assertEqual(par['inputs']['bUI'], INPUTS['bUI'])

        self.assertAlmostEqual(solveSS_AOB.validate_ss_residuals([1e-7, -2e-7], 1e-4), 2e-7)
        with self.assertRaises(ValueError):
            solveSS_AOB.validate_ss_residuals([0.0, 2e-3], 1e-4)
        with self.assertRaises(ValueError):
            solveSS_AOB.validate_ss_residuals([np.nan], 1e-4)

    def test_household_baseline_parity_both_types(self):
        par = self.par
        beta0 = INPUTS.get('beta', 0.97)
        for type_index, ss_ib in enumerate((0, 2)):
            beta = beta0 + (2 * type_index - 1) * par['dbeta']
            par['beta'] = beta
            state = initial_household_state(par, self.r, par['bUI'][type_index])
            cU, cE, U, E, Eb, dU, dE, dEb, J, Jb = state
            ss_out = HH.agent_step(self.r, self.tax, par['Z'], self.lambdas,
                                   U, E, Eb, dU, dE, dEb, J, Jb, par, beta,
                                   self.transfer, ss_ib)
            td_out = HH.agent_step_td(self.r, self.r + par['drate'], self.r,
                                      self.tax, par['Z'], self.lambdas,
                                      par['bUI'][type_index], par['sigma'][-1], 0.0,
                                      U, E, Eb, dEb, dU, dE, J, Jb, par,
                                      self.transfer)
            pairs = ((ss_out[3], td_out[0]), (ss_out[4], td_out[1]),
                     (ss_out[1], td_out[2]), (ss_out[5], td_out[3]),
                     (ss_out[6], td_out[4]), (ss_out[7], td_out[5]),
                     (ss_out[8], td_out[6]), (ss_out[9], td_out[7]),
                     (ss_out[10], td_out[8]), (ss_out[11], td_out[9]),
                     (ss_out[12], td_out[10]), (ss_out[15], td_out[13]))
            for left, right in pairs:
                self.assert_close(left, right)
            self.assert_close(ss_out[0], (1 + self.r) * utils.du(td_out[4], par['eis']))
            self.assert_close(ss_out[2], (1 + self.r) * utils.du(td_out[5], par['eis']))
            for key in ('U', 'Ewin', 'Elose'):
                np.testing.assert_array_equal(ss_out[13][key], td_out[11][key])
                self.assert_close(ss_out[14][key], td_out[12][key])

    def test_distribution_baseline_parity(self):
        par = self.par
        rng = np.random.default_rng(1234)
        DU = rng.random((par['nZ'], par['nA']))
        DE = rng.random((par['nZ'], par['nA'], par['nW'], par['nP'], par['nT']))
        mass = DU.sum() + DE.sum()
        DU, DE = DU / mass, DE / mass
        aU = np.broadcast_to(par['a_grid'], DU.shape)
        aE = np.broadcast_to(par['a_grid'][np.newaxis, :, np.newaxis, np.newaxis, np.newaxis], DE.shape)
        pol_i = {}
        pol_pi = {}
        pol_i['aU'], pol_pi['aU'] = utils.interpolate_coord_1d(par['a_grid'], aU)
        pol_i['aE'], pol_pi['aE'] = utils.interpolate_coord_1d(par['a_grid'], aE)
        wU = np.zeros((par['nZ'], par['nA'], par['nP']), dtype=np.uint32)
        wE = np.zeros((par['nZ'], par['nA'], par['nW'], par['nP'], par['nT'] - 1, par['nP']), dtype=np.uint32)
        w_i = {'U': wU, 'Ewin': wE, 'Elose': wE}
        w_pi = {key: np.ones_like(value, dtype=float) for key, value in w_i.items()}
        qswitch = np.zeros_like(wE, dtype=float)
        Inew = np.zeros_like(wE, dtype=float)
        base = utils.forward_step_dmp(DU, DE, pol_i, pol_pi, w_i, w_pi,
                                      Inew, qswitch, self.lambdas, par)
        td = utils.forward_step_dmp_td(DU, DE, pol_i, pol_pi, w_i, w_pi,
                                      Inew, qswitch, self.lambdas,
                                      par['sigma'][-1], 0.0, par)
        for left, right in zip(base, td):
            self.assert_close(left, right)
        self.assert_close(base[0].sum() + base[1].sum(), 1.0)

    def test_unequal_benefits_common_level_shock_and_bill(self):
        ss = {'bUIL': 0.17, 'bUIH': 0.31}
        path = Jac_help.type_bUI_path(ss, np.array([0.0, 0.04]), 2)
        self.assert_close(path, np.array([[0.17, 0.31], [0.21, 0.35]]))
        unemployed_mass = np.array([0.03, 0.07])
        self.assertAlmostEqual(unemployed_mass @ path[1], 0.03 * 0.21 + 0.07 * 0.35)
        assets = np.array([0.2, 0.8])
        consumption = np.array([0.1, 0.2])
        low_budget = (1 + self.r) * assets + (1 - self.tax) * path[0, 0] - consumption
        high_budget = (1 + self.r) * assets + (1 - self.tax) * path[0, 1] - consumption
        self.assert_close(high_budget - low_budget,
                          np.full(2, (1 - self.tax) * (0.31 - 0.17)))

    def test_vacancy_cost_convention(self):
        par = self.par
        p = par['p_grid']
        expected = (par['zeta'] * p) ** par['zeta_curv']
        vacancies = np.linspace(0.1, 0.8, 8)
        fiscal_args = (0.0, 0.0, 0.0, vacancies @ expected,
                       *vacancies, *p, 0.0, par['zeta'], par['zeta_curv'])
        self.assertAlmostEqual(float(model_blocks.fiscal.ss(*fiscal_args)), 0.0)
        walras_args = (vacancies @ expected, 0.0, 0.0,
                       *vacancies, *p, par['zeta'], par['zeta_curv'])
        self.assertAlmostEqual(float(model_blocks.walras.ss(*walras_args)), 0.0)
        J0 = np.linspace(0.8, 1.5, 8)
        q = (1 + self.r) * expected / J0
        free_entry_args = (*J0, *q, *p, self.r, par['zeta'], par['zeta_curv'])
        self.assert_close(np.asarray(model_blocks.free_entry.ss(*free_entry_args)), 0.0)

    def test_short_jacobian_serialization_and_combination_shapes(self):
        shocks = ('bUI', 'ra', 'sigmaJ')
        horizon = 4
        with tempfile.TemporaryDirectory(dir='.') as tmpdir:
            path = Path(tmpdir)
            for scale, shock in enumerate(shocks, start=1):
                matrix = np.eye(horizon) * scale
                payload = {'A': {shock: matrix}, 'Ubill': {shock: matrix / 10}}
                with (path / f'Jac_{shock}.pkl').open('wb') as file:
                    pickle.dump(payload, file)
            combined = Jac.combine_Jac(str(path), list(shocks))
            for output in ('A', 'Ubill'):
                for shock in shocks:
                    self.assertEqual(combined[output][shock].shape, (horizon, horizon))
                    self.assertTrue(np.isfinite(combined[output][shock]).all())


if __name__ == '__main__':
    unittest.main(verbosity=2)
