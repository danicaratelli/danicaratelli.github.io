import numpy as np
import HHhelp_AOB as HH
import utils
import time
import os
import pickle
import multiprocessing as mp

def backward_onepop(ishock, TT, ss, par, ip, filename_add, pert):
    # set shock only for penulitmate period
    tshock = TT - 1
    # extract parameters
    nZ, nA, nW, nP, nT, nB = par['nZ'], par['nA'], par['nW'], par['nP'], par['nT'], par['nB']
    M = par['M']

    # Initiate matrices
    CUTs_old = np.copy(ss['CUss'])
    CETs_old = np.copy(ss['CEss'])
    UTs_old = np.copy(ss['Uss'])
    ETs_old = np.copy(ss['Ess'])
    JTs_old = np.copy(ss['Jss'])
    EbargainingTs_old = np.copy(ss['Ebargainingss'])
    dEbargainingTs_old = np.copy(ss['dEbargainingss'])
    JTbargaining_old = np.copy(ss['Jbargainingss'])    

    CUTs = np.zeros((nZ, nA, nB))
    CETs = np.zeros((nZ, nA, nW, nP, nT, nB))
    UTs = np.zeros((nZ, nA, nB))
    ETs = np.zeros((nZ, nA, nW, nP, nT, nB))
    EbargainingTs = np.zeros((nZ, nA, nW, nP, M, nB))
    dEbargainingTs = np.zeros((nZ, nA, nW, nP, M, nB))
    AUTs = np.zeros((nZ, nA, nB))
    AETs = np.zeros((nZ, nA, nW, nP, nT, nB))
    WUiTs = np.zeros((nZ, nA, nP, nB), dtype='uint32')
    WUpiTs = np.zeros((nZ, nA, nP, nB))
    WEwiniTs = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB), dtype='uint32')
    WEwinpiTs = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))
    WEloseiTs = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB), dtype='uint32')
    WElosepiTs = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))
    JTs = np.zeros((nZ, nA, nW, nP, nT, nB))
    JbargainingTs = np.zeros((nZ, nA, nW, nP, M, nB))
    JU0Ts = np.zeros((nZ, nA, nP, nB))
    JE0Ts = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))
    qTs = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))
    IwinTs = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))

    # Set inputs w/ shock at tshock
    r_path = np.ones(TT + 1) * ss['r']
    rK_path = np.ones(TT) * ss['rK']
    Z_path = np.ones(TT) * ss['Z']
    tax_path = np.ones(TT) * ss['tax']
    transfer_path = np.ones(TT) * ss['transfer']
    bUI_path = np.ones(TT) * ss['bUI']
    sigmaJ_path = np.ones(TT + 1) * ss['sigmaJ']
    sigmaslope_path = np.zeros(TT + 1)
    lambdas_path = np.ones((TT + 1, nP)) * ss['lambdas'][np.newaxis, :]

    if ishock == "ra":
        r_path[tshock] = ss['r'] + pert
    if ishock == "rK":
        rK_path[tshock] = ss['rK'] + pert
    elif ishock == "Z":
        Z_path[tshock] = ss['Z'] + pert
    elif ishock == "tax":
        tax_path[tshock] = ss['tax'] + pert
    elif ishock == "lambda":
        lambdas_path[tshock, ip] = ss['lambdas'][ip] + pert
    elif ishock == "transfer":
        transfer_path[tshock] = ss['transfer'] + pert
    elif ishock == "bUI":
        bUI_path[tshock] = ss['bUI'] + pert
    elif ishock == "sigmaJ":
        sigmaJ_path[tshock] = ss['sigmaJ'] + pert
    elif ishock == "sigmaslope":
        sigmaslope_path[tshock] = ss['sigmaslope'] + pert

    beta_ss = par['beta']    
    # Backward iteration: get policies
    for t in range(TT - 1, -1, -1):                
        for ib in range(nB):
            par['beta'] = beta_ss + (2 * ib - 1) * par['dbeta']
            # input paths
            CUTs[:, :, ib], CETs[:, :, :, :, :, ib], UTs[:, :, ib], ETs[:, :, :, :, :, ib], \
            EbargainingTs[:, :, :, :, :, ib], dEbargainingTs[:, :, :, :, :, ib], AUTs[:, :, ib], AETs[:, :, :, :, :, ib], \
            JTs[:, :, :, :, :, ib], JbargainingTs[:, :, :, :, :, ib], JU0Ts[:, :, :, ib], JE0Ts[:, :, :, :, :, :, ib], \
            qTs[:, :, :, :, :, :, ib], WUiTs[:, :, :, ib], WUpiTs[:, :, :, ib], \
            WEwiniTs[:, :, :, :, :, :, ib], WEwinpiTs[:, :, :, :, :, :, ib], \
            WEloseiTs[:, :, :, :, :, :, ib], WElosepiTs[:, :, :, :, :, :, ib], \
            IwinTs[:, :, :, :, :, :, ib] = backward_iterate(r_path[t + 1], r_path[t], rK_path[t], Z_path[t], tax_path[t],
                                                         lambdas_path[t + 1, :], bUI_path[t], sigmaJ_path[t + 1],
                                                         sigmaslope_path[t + 1], transfer_path[t],
                                                         CUTs_old[:, :, ib], CETs_old[:, :, :, :, :, ib],
                                                         UTs_old[:, :, ib], ETs_old[:, :, :, :, :, ib],
                                                         EbargainingTs_old[:, :, :, :, :, ib], dEbargainingTs_old[:, :, :, :, :, ib],
                                                         JTs_old[:, :, :, :, :, ib], JTbargaining_old[:, :, :, :, :, ib], par)        
        if pert == 0:
            filename = os.path.join('Jacobian_' + filename_add, 'Backit_g' + str(t) + '.npy')
        else:
            filename = os.path.join('Jacobian_' + filename_add, 'Backit_' + str(t) + '.npy')

        with open(filename, 'wb') as f:
            np.save(f, CUTs)
            np.save(f, CETs)
            np.save(f, UTs)
            np.save(f, ETs)
            np.save(f, AUTs)
            np.save(f, AETs)
            np.save(f, JTs)
            np.save(f, JU0Ts)
            np.save(f, JE0Ts)
            np.save(f, qTs)
            np.save(f, WUiTs)
            np.save(f, WUpiTs)
            np.save(f, WEwiniTs)
            np.save(f, WEwinpiTs)
            np.save(f, WEloseiTs)
            np.save(f, WElosepiTs)
            np.save(f, IwinTs)

        CUTs_old = np.copy(CUTs)
        CETs_old = np.copy(CETs)
        UTs_old = np.copy(UTs)
        ETs_old = np.copy(ETs)
        EbargainingTs_old = np.copy(EbargainingTs)
        dEbargainingTs_old = np.copy(dEbargainingTs)
        JTs_old = np.copy(JTs)
        JbargainingTs_old = np.copy(JbargainingTs)

    par['beta'] = beta_ss

def backward_iterate(r_ante, r_post, rK, Z, tax, lambdas, bUI, sigmaJ, sigmaslope, transfer, cU_p, cE_p, U_p, E_p, E_bargaining_p, dE_bargaining_p, J_p, J_bargaining_p, par):
    dU_p = (1 + r_ante) * utils.du(cU_p, par['eis'])
    dE_p = (1 + r_ante) * utils.du(cE_p, par['eis'])
    E, E_bargaining, dE_bargaining, U, cE, cU, J, J_bargaining, JU0, JE0,\
    qswitch, w_idx, w_pi, Iswitch = HH.agent_step_td(r_post, rK, r_ante, tax, Z, lambdas, bUI, sigmaJ, sigmaslope, U_p,
                                                    E_p, E_bargaining_p, dE_bargaining_p, dU_p, dE_p, J_p, J_bargaining_p, par, transfer)

    # assets
    aU = (1 + r_post) * par['a_grid'][np.newaxis, :] + transfer + (1 - tax) * bUI - cU
    aE = (1 + r_post) * par['a_grid'][np.newaxis, :, np.newaxis, np.newaxis, np.newaxis] + transfer + \
         (1 - tax) * par['w_grid'][np.newaxis, np.newaxis, :, np.newaxis, np.newaxis] - cE

    return cU, cE, U, E, E_bargaining, dE_bargaining, aU, aE, J, J_bargaining, JU0, JE0, qswitch, w_idx['U'], w_pi['U'], \
           w_idx['Ewin'], w_pi['Ewin'], w_idx['Elose'], w_pi['Elose'], Iswitch

def go_forward(ishock, TT, ss, par, ip, pert, iname, tshock):
    print("Started " + str(tshock) + '\n')
    # identifying which labor market if shock is lambda#
    lambda_set = set()
    for p in range(par['nP']):
        lambda_set.add('lambda' + str(p))

    # job-finding probability
    xtmp_lambda = np.zeros((TT + 1, par['nP']))
    xtmp_lambda[tshock, ip] = 1
    lambdas_path_td = np.ones((TT + 1, par['nP'])) * ss['lambdas'][np.newaxis, :]
    lambdas_path_td = lambdas_path_td + xtmp_lambda * pert * (ishock in lambda_set)
    lambdas_path_td_g = np.ones((TT + 1, par['nP'])) * ss['lambdas'][np.newaxis, :]

    # productivity
    xtmp_Z = np.zeros(TT + 1)
    xtmp_Z[tshock] = 1
    Z_path_td = np.ones(TT + 1) * ss['Z']
    Z_path_td = Z_path_td + xtmp_Z * pert * (ishock == 'Z')
    Z_path_td_g = np.ones(TT + 1) * ss['Z']
    # rental rate on capital rK
    xtmp_rK = np.zeros(TT + 1)
    xtmp_rK[tshock] = 1
    rK_path_td = np.ones(TT + 1) * ss['rK']
    rK_path_td = rK_path_td + xtmp_rK * pert * (ishock == 'rK')
    rK_path_td_g = np.ones(TT + 1) * ss['rK']
    # tax rate
    xtmp_tax = np.zeros(TT + 1)
    xtmp_tax[tshock] = 1
    tax_path_td = np.ones(TT + 1) * ss['tax']
    tax_path_td = tax_path_td + xtmp_tax * pert * (ishock == 'tax')
    tax_path_td_g = np.ones(TT + 1) * ss['tax']
    # unemployment benefits (bUI)
    xtmp_bUI = np.zeros(TT + 1)
    xtmp_bUI[tshock] = 1
    bUI_path_td = np.ones(TT + 1) * ss['bUI']
    bUI_path_td = bUI_path_td + xtmp_bUI * pert * (ishock == 'bUI')
    bUI_path_td_g = np.ones(TT + 1) * ss['bUI']
    # level pr. of unemployment (sigmaJ)
    xtmp_sigmaJ = np.zeros(TT + 1)
    xtmp_sigmaJ[tshock] = 1
    sigmaJ_path_td = np.ones(TT + 1) * ss['sigmaJ']
    sigmaJ_path_td = sigmaJ_path_td + xtmp_sigmaJ * pert * (ishock == 'sigmaJ')
    sigmaJ_path_td_g = np.ones(TT + 1) * ss['sigmaJ']
    # slope pr. of unemployment (sigmaJ)
    xtmp_sigmaslope = np.zeros(TT + 1)
    xtmp_sigmaslope[tshock] = 1
    sigmaslope_path_td = np.zeros(TT + 1)
    sigmaslope_path_td = sigmaslope_path_td + xtmp_sigmaslope * pert * (ishock == 'sigmaslope')
    sigmaslope_path_td_g = np.zeros(TT + 1)

    if (ishock in lambda_set) | (ishock == 'sigmaJ') | (ishock == 'sigmaslope'):
        # Actual
        td_res = forward_flow_onepop(TT, ss, par, tshock, Z_path_td, rK_path_td, lambdas_path_td, tax_path_td,
                                     bUI_path_td, sigmaJ_path_td, sigmaslope_path_td, iname, pert)
        # Ghost
        td_res_g = forward_flow_onepop(TT, ss, par, tshock, Z_path_td_g, rK_path_td_g, lambdas_path_td_g, tax_path_td_g, 
                                       bUI_path_td_g, sigmaJ_path_td_g, sigmaslope_path_td_g, iname, 0)
    else:
        # Actual
        td_res = forward_onepop(TT, ss, par, tshock, Z_path_td, rK_path_td, lambdas_path_td, tax_path_td,
                                bUI_path_td, sigmaJ_path_td, sigmaslope_path_td, iname, pert)
        # Ghost
        td_res_g = forward_onepop(TT, ss, par, tshock, Z_path_td_g, rK_path_td_g, lambdas_path_td_g, tax_path_td_g,
                                  bUI_path_td_g, sigmaJ_path_td_g, sigmaslope_path_td_g, iname, 0)
    print("Ended " + str(tshock) + '\n')
    return td_res, td_res_g

def forward_onepop(TT, ss, par, tshock, Z_path_td, rK_path_td, lambdas_path_td, tax_path_td, bUI_path_td, sigmaJ_path_td, sigmaslope_path_td, filename_add, pert):
    # extract parameters
    nZ, nA, nW, nP, nT, nB = par['nZ'], par['nA'], par['nW'], par['nP'], par['nT'], par['nB']

    # Initialize distribution: if ra is perturbed then move distribution accordingly
    QUTs = np.zeros((nZ, nA, nB, TT + 1))
    QETs = np.zeros((nZ, nA, nW, nP, nT, nB, TT + 1))
    QUETs = np.zeros((nZ, nA, nP, nB, TT + 1))
    QEETs = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB, TT + 1))


    QUTs[:, :, :, 0] = np.copy(ss['QUss'])
    QETs[:, :, :, :, :, :, 0] = np.copy(ss['QEss'])
    QUETs[:, :, :, :, 0] = np.copy(ss['QUEss'])
    QEETs[:, :, :, :, :, :, :, 0] = np.copy(ss['QEEss'])

    # Aggregates
    td_res = dict()
    td_res['A'] = np.zeros(TT)  # assets
    td_res['C'] = np.zeros(TT)  # consumption
    td_res['N'] = np.zeros(TT)  # efficiency units of labor
    td_res['U'] = np.zeros(TT)  # unemployment (=rate)
    td_res['EE_rate'] = np.zeros(TT)  # EE rate
    td_res['EE_rateH'] = np.zeros(TT)  # EE rate (high wealth)
    td_res['EE_rateL'] = np.zeros(TT)  # EE rate (low wealth)
    td_res['EU_rate'] = np.zeros(TT)  # EU rate
    td_res['Tax'] = np.zeros(TT)  # tax revenue
    td_res['earnings'] = np.zeros(TT)  # earnings
    td_res['earningsH'] = np.zeros(TT)  # earnings (high wealth)
    td_res['earningsL'] = np.zeros(TT)  # earnings (low wealth)
    td_res['Ubill'] = np.zeros(TT)  # govt. expenditure
    td_res['Pi'] = np.zeros(TT)  # firm profits
    for ipp in range(par['nP']):
        td_res['e' + str(ipp)] = np.zeros(TT)  # mass on each rung
        td_res['J0_' + str(ipp)] = np.zeros(TT)  # expected values at each rung
    # Extra for convenience
    td_res['A_pre'] = np.zeros(TT)
    td_res['AE'] = np.zeros(TT)  # assets (employed)
    td_res['AE_pre'] = np.zeros(TT)  # assets (employed)
    td_res['AU'] = np.zeros(TT)  # assets (unemployed)
    td_res['AU_pre'] = np.zeros(TT)  # assets (unemployed)
    td_res['CE'] = np.zeros(TT)  # consumption (employed)
    td_res['CU'] = np.zeros(TT)  # consumption (unemployed)

    # Forward iteration: update distribution
    for t in range(1, TT + 1):        
        # loading previous period's policies
        if t - 1 > tshock:
            AUTs_pre = ss['AUss']
            AETs_pre = ss['AEss']
            CUTs_pre = ss['CUss']
            CETs_pre = ss['CEss']
            qTs_pre = ss['qss']
            WUiTs_pre = ss['WUiss']
            WUpiTs_pre = ss['WUpiss']
            WEwiniTs_pre = ss['WEwiniss']
            WEwinpiTs_pre = ss['WEwinpiss']
            WEloseiTs_pre = ss['WEloseiss']
            WElosepiTs_pre = ss['WElosepiss']
            IwinTs_pre = ss['Iwins']
            JU0Ts_pre = ss['JU0s']
            JE0Ts_pre = ss['JE0s']
            #JU0Ts_pre = ss['J0_0']
            #JE0Ts_pre = np.array([ss['J0_1'], ss['J0_2'], ss['J0_3'], ss['J0_4'], ss['J0_5'], ss['J0_6'], ss['J0_7']])
        else:
            if pert == 0:
                filename = os.path.join('Jacobian_' + filename_add, 'Backit_g' + str(TT - 1 - tshock + t - 1) + '.npy')
            else:
                filename = os.path.join('Jacobian_' + filename_add, 'Backit_' + str(TT - 1 - tshock + t - 1) + '.npy')
            with open(filename, 'rb') as f:
                CUTs_pre = np.load(f)
                CETs_pre = np.load(f)
                UTs_pre = np.load(f)
                ETs_pre = np.load(f)
                AUTs_pre = np.load(f)
                AETs_pre = np.load(f)
                JTs_pre = np.load(f)
                JU0Ts_pre = np.load(f)
                JE0Ts_pre = np.load(f)
                qTs_pre = np.load(f)
                WUiTs_pre = np.load(f)
                WUpiTs_pre = np.load(f)
                WEwiniTs_pre = np.load(f)
                WEwinpiTs_pre = np.load(f)
                WEloseiTs_pre = np.load(f)
                WElosepiTs_pre = np.load(f)
                IwinTs_pre = np.load(f)

        for ib in range(nB):
            QUtmp, QEtmp, QUEtmp, QEEtmp = forward_iterate(nB * QUTs[:, :, ib, t - 1], nB * QETs[:, :, :, :, :, ib, t - 1],
                                                   AUTs_pre[:, :, ib], AETs_pre[:, :, :, :, :, ib],
                                                   WUiTs_pre[:, :, :, ib], WUpiTs_pre[:, :, :, ib],
                                                   WEwiniTs_pre[:, :, :, :, :, :, ib], WEwinpiTs_pre[:, :, :, :, :, :, ib],
                                                   WEloseiTs_pre[:, :, :, :, :, :, ib], WElosepiTs_pre[:, :, :, :, :, :, ib],
                                                   qTs_pre[:, :, :, :, :, :, ib], IwinTs_pre[:, :, :, :, :, :, ib],
                                                   lambdas_path_td[t - 1, :], sigmaJ_path_td[t - 1], sigmaslope_path_td[t - 1], par)
            QUTs[:, :, ib, t], QETs[:, :, :, :, :, ib, t], QUETs[:, :, :, ib, t], QEETs[:, :, :, :, :, :, ib, t] = QUtmp / nB, QEtmp / nB, QUEtmp / nB, QEEtmp / nB

        # Filling out aggregates
        td_res['A'][t - 1] = np.sum(QUTs[:, :, :, t - 1] * AUTs_pre) + np.sum(QETs[:, :, :, :, :, :, t - 1] * AETs_pre)
        td_res['C'][t - 1] = np.sum(QUTs[:, :, :, t - 1] * CUTs_pre) + np.sum(QETs[:, :, :, :, :, :, t - 1] * CETs_pre)
        td_res['AE'][t - 1] = np.sum(QETs[:, :, :, :, :, :, t - 1] * AETs_pre)
        td_res['N'][t - 1] = np.sum(np.sum(QETs[:, :, :, :, :, :, t - 1], axis=(1, 2, 4, 5)) * par['z_grid'][:, np.newaxis] * par['p_grid'][np.newaxis, :])
        td_res['U'][t - 1] = np.sum(QUTs[:, :, :, t - 1])
        # Updating unemployment probability
        sigma = par['sigma']
        # level shift in unemployment probability
        sigma = sigma + (sigmaJ_path_td[t - 1] - sigma[-1])
        # slope change in unemployment probability
        sigma = sigma * (1 + sigmaslope_path_td[t - 1])
        
        td_res['EU_rate'][t - 1] = np.sum(np.sum(QETs[:, :, :, :, :, :, t - 1], axis=(0, 1, 2, 3, 5)) * sigma) / np.sum(QETs[:, :, :, :, :, :, t - 1])
        td_res['EE_rate'][t - 1] = np.sum(QEETs[:, :, :, :, :, :, :, t] * qTs_pre, axis=(0, 1, 2, 3, 4, 5, 6)) / np.sum(QETs[:, :, :, :, :, :, t - 1])
        td_res['Ubill'][t - 1] = np.sum(QUTs[:, :, :, t - 1]) * bUI_path_td[t - 1]
        td_res['Tax'][t - 1] = tax_path_td[t - 1] * np.sum(np.sum(QETs[:, :, :, :, :, :, t - 1], axis=(0, 1, 3, 4, 5)) * par['w_grid'])
        td_res['earnings'][t - 1] = np.sum(np.sum(QETs[:, :, :, :, :, :, t - 1], axis=(0, 1, 3, 4, 5)) * par['w_grid']) / np.sum(QETs[:, :, :, :, :, :, t - 1])

        # Computing flow profits
        k_little = (rK_path_td[t - 1] / (par['alpha'] * Z_path_td[t - 1])) ** (1 / (par['alpha'] - 1))  # capital per effective unit of labor
        effZ = par['z_grid'][:, np.newaxis, np.newaxis] * par['p_grid'][np.newaxis, np.newaxis, :]
        pi_flow = np.sum((effZ * (Z_path_td[t - 1] * utils.f(k_little, par) - rK_path_td[t - 1] * k_little) - par['w_grid'][np.newaxis, :, np.newaxis]) * np.sum(QETs[:, :, :, :, :, :, t - 1], axis=(1, 4, 5)))
        td_res['Pi'][t - 1] = pi_flow

        # Mass of searchers
        Utot = np.sum(QUTs[:, :, :, t])
        Esearchers = np.sum(QEETs[:, :, :, :, :, :, :, t], axis=(0, 1, 2, 3, 4, 6))
        searchers = par['gU'] * Utot + Esearchers
        for ipp in range(par['nP']):
            td_res['e' + str(ipp)][t - 1] = searchers[ipp]

        # Expected values for vacant firms and flow-profits for active firms
        JU0_tmp = np.sum(JU0Ts_pre * QUETs[:, :, :, :, t], axis=(0, 1, 3)) / np.sum(QUETs[:, :, :, :, t])
        Dswitchers = np.sum(QEETs[:, :, :, :, :, :, :, t], axis=(0, 1, 2, 3, 4, 6))
        JE0_tmp = np.sum(JE0Ts_pre * QEETs[:, :, :, :, :, :, :, t], axis=(0, 1, 2, 3, 4, 6)) / Dswitchers
        if Dswitchers[0] == 0:
            JE0_tmp[0] = 0
        js_tmp = JU0_tmp + JE0_tmp
        for ipp in range(par['nP']):
            td_res['J0_' + str(ipp)][t - 1] = js_tmp[ipp]

        # Distributional variables
        # find median wealth threshold
        Qt = np.sum(QETs[:, :, :, :, :, :, t-1], axis=(0, 2, 3, 4, 5)) + np.sum(QUTs[:, :, :, t - 1], axis=(0, 2))
        xi, xpi = utils.simple_interpolation(0.5 * np.sum(Qt), np.cumsum(Qt))
        mass_diff = np.abs(np.sum(Qt[:xi+1]) + (1 - xpi) * Qt[xi+1] - (np.sum(Qt[xi+2:]) + xpi * Qt[xi+1]))
        if mass_diff >= 1e-6:
            error_message = f"Threshold does not hold up. mass_diff = {mass_diff}"
            raise AssertionError(error_message)
        QEL = np.copy(QETs[:, :xi + 2, :, :, :, :, t-1])
        QEL[:, -1, :, :, :, :] = QETs[:, xi + 1, :, :, :, :, t-1] * (1 - xpi)
        QEH = np.copy(QETs[:, xi + 1:, :, :, :, :, t-1])
        QEH[:, 0, :, :, :, :] = QETs[:, xi + 1, :, :, :, :, t-1] * xpi        
        # earnings
        td_res['earningsH'][t - 1] = np.sum(np.sum(QEH, axis=(0, 1, 3, 4, 5)) * par['w_grid']) / np.sum(QEH)
        td_res['earningsL'][t - 1] = np.sum(np.sum(QEL, axis=(0, 1, 3, 4, 5)) * par['w_grid']) / np.sum(QEL)
        
        QEEL = np.copy(QEETs[:, :xi + 2, :, :, :, :, :, t])
        QEEL[:, -1, :, :, :, :] = QEETs[:, xi + 1, :, :, :, :, :, t] * (1 - xpi)
        qL = np.copy(qTs_pre[:, :xi + 2, :, :, :, :, :])
        qL[:, -1, :, :, :, :] = qTs_pre[:, xi + 1, :, :, :, :, :] * (1 - xpi)        
        QEEH = np.copy(QEETs[:, xi + 1:, :, :, :, :, :, t])
        QEEH[:, 0, :, :, :, :] = QEETs[:, xi + 1, :, :, :, :, :, t] * xpi
        qH = np.copy(qTs_pre[:, xi + 1:, :, :, :, :, :])
        qH[:, 0, :, :, :, :] = qTs_pre[:, xi + 1, :, :, :, :, :] * xpi
        td_res['EE_rateL'][t - 1] = np.sum(QEEL * qL, axis=(0, 1, 2, 3, 4, 5, 6)) / np.sum(QEL)
        td_res['EE_rateH'][t - 1] = np.sum(QEEH * qH, axis=(0, 1, 2, 3, 4, 5, 6)) / np.sum(QEH)


        # Extra for convenience
        td_res['A_pre'][t - 1] = np.sum((np.sum(QUTs[:, :, :, t - 1], axis=(0, 2)) + np.sum(QETs[:, :, :, :, :, :, t - 1], axis=(0, 2, 3, 4, 5))) * par['a_grid'])
        td_res['AE'][t - 1] = np.sum(QETs[:, :, :, :, :, :, t - 1] * AETs_pre)
        td_res['AE_pre'][t - 1] = np.sum(np.sum(QETs[:, :, :, :, :, :, t - 1], axis=(0, 2, 3, 4, 5)) * par['a_grid'])
        td_res['AU'][t - 1] = np.sum(QUTs[:, :, :, t - 1] * AUTs_pre)
        td_res['AU_pre'][t - 1] = np.sum(np.sum(QUTs[:, :, :, t - 1], axis=(0, 2)) * par['a_grid'])
        td_res['CU'][t - 1] = np.sum(CUTs_pre * QUTs[:, :, :, t - 1])
        td_res['CE'][t - 1] = np.sum(CETs_pre * QETs[:, :, :, :, :, :, t - 1])

    return td_res


def forward_flow_onepop(TT, ss, par, tshock, Z_path_td, rK_path_td, lambdas_path_td, tax_path_td, bUI_path_td, sigmaJ_path_td, sigmaslope_path_td, filename_add, pert):
    # extract parameters
    nZ, nA, nW, nP, nT, nB = par['nZ'], par['nA'], par['nW'], par['nP'], par['nT'], par['nB']

    # Initialize distribution: if ra is perturbed then move distribution accordingly
    QUTs = np.zeros((nZ, nA, nB, TT + 2))
    QETs = np.zeros((nZ, nA, nW, nP, nT, nB, TT + 2))
    QUETs = np.zeros((nZ, nA, nP, nB, TT + 2))
    QEETs = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB, TT + 2))

    # Initial dry run (important for tshock=0 cases)
    for ib in range(nB):
        QUtmp, QEtmp, QUEtmp, QEEtmp = forward_iterate(nB * ss['QUss'][:, :, ib], nB * ss['QEss'][:, :, :, :, :, ib],
                                               ss['AUss'][:, :, ib], ss['AEss'][:, :, :, :, :, ib],
                                               ss['WUiss'][:, :, :, ib], ss['WUpiss'][:, :, :, ib],
                                               ss['WEwiniss'][:, :, :, :, :, :, ib], ss['WEwinpiss'][:, :, :, :, :, :, ib],
                                               ss['WEloseiss'][:, :, :, :, :, :, ib], ss['WElosepiss'][:, :, :, :, :, :, ib],
                                               ss['qss'][:, :, :, :, :, :, ib], ss['Iwins'][:, :, :, :, :, :, ib],
                                               lambdas_path_td[0, :], sigmaJ_path_td[0], sigmaslope_path_td[0], par)

        QUTs[:, :, ib, 0] = QUtmp / nB
        QETs[:, :, :, :, :, ib, 0] = QEtmp / nB
        QUETs[:, :, :, ib, 0] = QUEtmp / nB
        QEETs[:, :, :, :, :, :, ib, 0] = QEEtmp / nB

    # Aggregates
    td_res = dict()
    td_res['A'] = np.zeros(TT)  # assets
    td_res['C'] = np.zeros(TT)  # consumption
    td_res['N'] = np.zeros(TT)  # efficiency units of labor
    td_res['U'] = np.zeros(TT)  # unemployment (=rate)
    td_res['EE_rate'] = np.zeros(TT)  # EE rate
    td_res['EE_rateH'] = np.zeros(TT)  # EE rate
    td_res['EE_rateL'] = np.zeros(TT)  # EE rate
    td_res['EU_rate'] = np.zeros(TT)  # EU rate
    td_res['Tax'] = np.zeros(TT)  # tax revenue
    td_res['earnings'] = np.zeros(TT)  # earnings    
    td_res['earningsH'] = np.zeros(TT)  # earnings    
    td_res['earningsL'] = np.zeros(TT)  # earnings    
    td_res['Ubill'] = np.zeros(TT)  # govt. expenditure
    td_res['Pi'] = np.zeros(TT)  # firm profits
    for ipp in range(par['nP']):
        td_res['e' + str(ipp)] = np.zeros(TT)  # mass on each rung
        td_res['J0_' + str(ipp)] = np.zeros(TT)  # expected values at each rung
    # Extra for convenience
    td_res['A_pre'] = np.zeros(TT)
    td_res['AE'] = np.zeros(TT)  # assets (employed)
    td_res['AE_pre'] = np.zeros(TT)  # assets (employed)
    td_res['AU'] = np.zeros(TT)  # assets (unemployed)
    td_res['AU_pre'] = np.zeros(TT)  # assets (unemployed)
    td_res['CE'] = np.zeros(TT)  # consumption (employed)
    td_res['CU'] = np.zeros(TT)  # consumption (unemployed)

    # Forward iteration: update distribution
    for t in range(1, TT + 1):
        # loading previous period's policies
        if (t > tshock):
            AUTs_pre = ss['AUss']
            AETs_pre = ss['AEss']
            CUTs_pre = ss['CUss']
            CETs_pre = ss['CEss']
            qTs_pre = ss['qss']
            WUiTs_pre = ss['WUiss']
            WUpiTs_pre = ss['WUpiss']
            WEwiniTs_pre = ss['WEwiniss']
            WEwinpiTs_pre = ss['WEwinpiss']
            WEloseiTs_pre = ss['WEloseiss']
            WElosepiTs_pre = ss['WElosepiss']
            IwinTs_pre = ss['Iwins']
            JU0Ts_pre = ss['JU0s'] #ss['J0_0']
            JE0Ts_pre = ss['JE0s'] #np.array([ss['J0_1'], ss['J0_2'], ss['J0_3'], ss['J0_4'], ss['J0_5'], ss['J0_6'], ss['J0_7']])
        else:
            if pert == 0:
                filename = os.path.join('Jacobian_' + filename_add, 'Backit_g' + str(TT - tshock + t - 1) + '.npy')
            else:
                filename = os.path.join('Jacobian_' + filename_add, 'Backit_' + str(TT - tshock + t - 1) + '.npy')
            with open(filename, 'rb') as f:
                CUTs_pre = np.load(f)
                CETs_pre = np.load(f)
                UTs_pre = np.load(f)
                ETs_pre = np.load(f)
                AUTs_pre = np.load(f)
                AETs_pre = np.load(f)
                JTs_pre = np.load(f)
                JU0Ts_pre = np.load(f)
                JE0Ts_pre = np.load(f)
                qTs_pre = np.load(f)
                WUiTs_pre = np.load(f)
                WUpiTs_pre = np.load(f)
                WEwiniTs_pre = np.load(f)
                WEwinpiTs_pre = np.load(f)
                WEloseiTs_pre = np.load(f)
                WElosepiTs_pre = np.load(f)
                IwinTs_pre = np.load(f)

        # print(np.max(np.abs(AETs_pre - ss['AEss'])))
        for ib in range(nB):
            QUtmp, QEtmp, QUEtmp, QEEtmp = forward_iterate(nB * QUTs[:, :, ib, t - 1], nB * QETs[:, :, :, :, :, ib, t - 1],
                                                   AUTs_pre[:, :, ib], AETs_pre[:, :, :, :, :, ib],
                                                   WUiTs_pre[:, :, :, ib], WUpiTs_pre[:, :, :, ib],
                                                   WEwiniTs_pre[:, :, :, :, :, :, ib], WEwinpiTs_pre[:, :, :, :, :, :, ib],
                                                   WEloseiTs_pre[:, :, :, :, :, :, ib], WElosepiTs_pre[:, :, :, :, :, :, ib],
                                                   qTs_pre[:, :, :, :, :, :, ib], IwinTs_pre[:, :, :, :, :, :, ib],
                                                   lambdas_path_td[t, :], sigmaJ_path_td[t], sigmaslope_path_td[t], par)


            QUTs[:, :, ib, t], QETs[:, :, :, :, :, ib, t], QUETs[:, :, :, ib, t], QEETs[:, :, :, :, :, :, ib, t] = QUtmp / nB, QEtmp / nB, QUEtmp / nB, QEEtmp / nB

        # Filling out aggregates
        td_res['A'][t - 1] = np.sum(QUTs[:, :, :, t - 1] * AUTs_pre) + np.sum(QETs[:, :, :, :, :, :, t - 1] * AETs_pre)
        td_res['C'][t - 1] = np.sum(QUTs[:, :, :, t - 1] * CUTs_pre) + np.sum(QETs[:, :, :, :, :, :, t - 1] * CETs_pre)
        td_res['AE'][t - 1] = np.sum(QETs[:, :, :, :, :, :, t - 1] * AETs_pre)
        td_res['N'][t - 1] = np.sum(np.sum(QETs[:, :, :, :, :, :, t - 1], axis=(1, 2, 4, 5)) * par['z_grid'][:, np.newaxis] * par['p_grid'][np.newaxis, :])
        td_res['U'][t - 1] = np.sum(QUTs[:, :, :, t - 1])
        # Updating unemployment probability
        sigma = par['sigma']
        # level shift in unemployment probability
        sigma = sigma + (sigmaJ_path_td[t - 1] - sigma[-1])
        # slope change in unemployment probability
        sigma = sigma * (1 + sigmaslope_path_td[t - 1])

        td_res['EU_rate'][t - 1] = np.sum(np.sum(QETs[:, :, :, :, :, :, t - 1], axis=(0, 1, 2, 3, 5)) * sigma) / np.sum(QETs[:, :, :, :, :, :, t - 1])
        td_res['EE_rate'][t - 1] = np.sum(QEETs[:, :, :, :, :, :, :, t] * qTs_pre, axis=(0, 1, 2, 3, 4, 5, 6)) / np.sum(QETs[:, :, :, :, :, :, t - 1])
        td_res['Ubill'][t - 1] = np.sum(QUTs[:, :, :, t - 1]) * bUI_path_td[t - 1]
        td_res['Tax'][t - 1] = tax_path_td[t - 1] * np.sum(np.sum(QETs[:, :, :, :, :, :, t - 1], axis=(0, 1, 3, 4, 5)) * par['w_grid'])
        td_res['earnings'][t - 1] = np.sum(np.sum(QETs[:, :, :, :, :, :, t - 1], axis=(0, 1, 3, 4, 5)) * par['w_grid']) / np.sum(QETs[:, :, :, :, :, :, t - 1])
        # Computing flow profits
        k_little = (rK_path_td[t - 1] / (par['alpha'] * Z_path_td[t - 1])) ** (1 / (par['alpha'] - 1))  # capital per effective unit of labor
        effZ = par['z_grid'][:, np.newaxis, np.newaxis] * par['p_grid'][np.newaxis, np.newaxis, :]
        pi_flow = np.sum((effZ * (Z_path_td[t - 1] * utils.f(k_little, par) - rK_path_td[t - 1] * k_little) - par['w_grid'][np.newaxis, :, np.newaxis]) * np.sum(QETs[:, :, :, :, :, :, t - 1], axis=(1, 4, 5)))
        td_res['Pi'][t - 1] = pi_flow

        # Mass of searchers
        Utot = np.sum(QUTs[:, :, :, t])
        Esearchers = np.sum(QEETs[:, :, :, :, :, :, :, t], axis=(0, 1, 2, 3, 4, 6))
        searchers = par['gU'] * Utot + Esearchers
        for ipp in range(par['nP']):
            td_res['e' + str(ipp)][t - 1] = searchers[ipp]

        # Expected values for vacant firms and flow-profits for active firms
        JU0_tmp = np.sum(JU0Ts_pre * QUETs[:, :, :, :, t], axis=(0, 1, 3)) / np.sum(QUETs[:, :, :, :, t])
        Dswitchers = np.sum(QEETs[:, :, :, :, :, :, :, t], axis=(0, 1, 2, 3, 4, 6))
        JE0_tmp = np.sum(JE0Ts_pre * QEETs[:, :, :, :, :, :, :, t], axis=(0, 1, 2, 3, 4, 6)) / Dswitchers
        if Dswitchers[0] == 0:
            JE0_tmp[0] = 0
        js_tmp = JU0_tmp + JE0_tmp
        for ipp in range(par['nP']):
            td_res['J0_' + str(ipp)][t - 1] = js_tmp[ipp]


        # Distributional variables
        # find median wealth threshold
        Qt = np.sum(QETs[:, :, :, :, :, :, t-1], axis=(0, 2, 3, 4, 5)) + np.sum(QUTs[:, :, :, t - 1], axis=(0, 2))
        xi, xpi = utils.simple_interpolation(0.5 * np.sum(Qt), np.cumsum(Qt))
        mass_diff = np.abs(np.sum(Qt[:xi+1]) + (1 - xpi) * Qt[xi+1] - (np.sum(Qt[xi+2:]) + xpi * Qt[xi+1]))
        if mass_diff >= 1e-6:
            error_message = f"Threshold does not hold up. mass_diff = {mass_diff}"
            raise AssertionError(error_message)        
        QEL = np.copy(QETs[:, :xi + 2, :, :, :, :, t-1])
        QEL[:, -1, :, :, :, :] = QETs[:, xi + 1, :, :, :, :, t-1] * (1 - xpi)
        QEH = np.copy(QETs[:, xi + 1:, :, :, :, :, t-1])
        QEH[:, 0, :, :, :, :] = QETs[:, xi + 1, :, :, :, :, t-1] * xpi
        # earnings        
        td_res['earningsH'][t - 1] = np.sum(np.sum(QEH, axis=(0, 1, 3, 4, 5)) * par['w_grid']) / np.sum(QEH)
        td_res['earningsL'][t - 1] = np.sum(np.sum(QEL, axis=(0, 1, 3, 4, 5)) * par['w_grid']) / np.sum(QEL)
        
        QEEL = np.copy(QEETs[:, :xi + 2, :, :, :, :, :, t])
        QEEL[:, -1, :, :, :, :] = QEETs[:, xi + 1, :, :, :, :, :, t] * (1 - xpi)
        qL = np.copy(qTs_pre[:, :xi + 2, :, :, :, :, :])
        qL[:, -1, :, :, :, :] = qTs_pre[:, xi + 1, :, :, :, :, :] * (1 - xpi)        
        QEEH = np.copy(QEETs[:, xi + 1:, :, :, :, :, :, t])
        QEEH[:, 0, :, :, :, :] = QEETs[:, xi + 1, :, :, :, :, :, t] * xpi
        qH = np.copy(qTs_pre[:, xi + 1:, :, :, :, :, :])
        qH[:, 0, :, :, :, :] = qTs_pre[:, xi + 1, :, :, :, :, :] * xpi
        td_res['EE_rateL'][t - 1] = np.sum(QEEL * qL, axis=(0, 1, 2, 3, 4, 5, 6)) / np.sum(QEL)
        td_res['EE_rateH'][t - 1] = np.sum(QEEH * qH, axis=(0, 1, 2, 3, 4, 5, 6)) / np.sum(QEH)

        # Extra for convenience
        td_res['A_pre'][t - 1] = np.sum((np.sum(QUTs[:, :, :, t - 1], axis=(0, 2)) + np.sum(QETs[:, :, :, :, :, :, t - 1], axis=(0, 2, 3, 4, 5))) * par['a_grid'])
        td_res['AE'][t - 1] = np.sum(QETs[:, :, :, :, :, :, t - 1] * AETs_pre)
        td_res['AE_pre'][t - 1] = np.sum(np.sum(QETs[:, :, :, :, :, :, t - 1], axis=(0, 2, 3, 4, 5)) * par['a_grid'])
        td_res['AU'][t - 1] = np.sum(QUTs[:, :, :, t - 1] * AUTs_pre)
        td_res['AU_pre'][t - 1] = np.sum(np.sum(QUTs[:, :, :, t - 1], axis=(0, 2)) * par['a_grid'])
        td_res['CU'][t - 1] = np.sum(CUTs_pre * QUTs[:, :, :, t - 1])
        td_res['CE'][t - 1] = np.sum(CETs_pre * QETs[:, :, :, :, :, :, t - 1])

    return td_res

def forward_iterate(QU, QE, aU, aE, wU_i, wU_pi, wEwin_i, wEwin_pi, wElose_i, wElose_pi, qswitch, Inew, lambdas, sigmaJ, sigmaslope, par):
    # interpolated policy functions
    pol_i = {}
    pol_pi = {}

    # use robust binary search-based method that only requires grids, not policies, to be monotonic
    pol_i["aU"], pol_pi["aU"] = utils.interpolate_coord_robust(par['a_grid'], aU)  # unemployed assets
    pol_i["aE"], pol_pi["aE"] = utils.interpolate_coord_robust(par['a_grid'], aE)  # employed assets (stayer)

    # define w_i and w_pi
    w_i = {'U': wU_i, 'Ewin': wEwin_i, 'Elose': wElose_i}
    w_pi = {'U': wU_pi, 'Ewin': wEwin_pi, 'Elose': wElose_pi}

    DUnew, DEnew, DUE, DEE = utils.forward_step_dmp_td(QU, QE, pol_i, pol_pi, w_i, w_pi, Inew, qswitch, lambdas, sigmaJ, sigmaslope, par)
    return DUnew, DEnew, DUE, DEE