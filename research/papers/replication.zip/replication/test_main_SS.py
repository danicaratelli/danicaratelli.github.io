import os
import numpy as np
import load_params_SS as load_params
import solveSS_AOB
import Jac
import pickle
import pandas as pd
import utils
import sys
import time
import multiprocessing as mp
import itertools
from filelock import FileLock
import wealth_lorenz

# Options
i_ss = True # if want to estimate SS
i_naive = False # if want to solve naive SS
ss_tol = 1e-4 # calibration-screening tolerance; use 1e-5 later for final refinement
input_index = 9

# Grids
z_grid = np.array([-0.6414269805898185])
Pi_grid = np.array([0.85])
zeta_grid = np.array([1.1])
p1_grid = np.array([-0.4])
p2_grid = np.array([-0.30])
p3_grid = np.array([-0.10])
p4_grid = np.array([0.0])
p5_grid = np.array([0.10])
p6_grid = np.array([0.25])
p7_grid = np.array([1.1])
p8_grid = np.array([2.2])
s_grid = np.array([0.32, 0.33, 0.35, 0.36, 0.38])
sigma0_grid = np.array([0.028, 0.029])
bdeta_grid = np.array([0.012])
chi_grid = np.array([0.20, 0.21, 0.22]) #0.23

inputs = []
for vals in itertools.product(*[z_grid, Pi_grid, zeta_grid, p1_grid, p2_grid, p3_grid, p4_grid, p5_grid, p6_grid, p7_grid, p8_grid, s_grid, sigma0_grid, bdeta_grid, chi_grid]):
    inputs.append(dict(zip(['zlow', 'Pi11', 'zeta', 'p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 's', 'sigma0', 'dbeta', 'chi'], vals)))
    inputs[len(inputs) - 1]['index'] = len(inputs) - 1

# targets
targets = np.array([0.004,  # UI_to_GDI
                    0.56,   # job-finding prob
                    0.06,   # unemploymenyt rate
                    0.041,  # job-switching probability
                    -1.04,  # Q1 of wealth Lorenz
                    0.68,   # Q2 of wealth Lorenz
                    6.85,   # Q3 of wealth Lorenz
                    18.21,  # Q4 of wealth Lorenz
                    75.3])  # Q5 of wealth Lorenz
# weights
wgts = np.array([1, 1, 1, 2, 0.7, 0.7, 0.4, 0.1, 0.1])

def mp_worker(input, inaive=False):
    # Load Parameters
    par = load_params.get_par(input)
    par['verbose_ss'] = True
    smm_index = input['index']
    # Set initial guess. The parameters listed solve for steady state. Because this takes ~90 minutes or more from a less educated guess, I list them here as the starting point so solving for steady state is quick.
    r = 0.002278244304438834   
    tax = -0.2902829273871056
    thetas = np.array([15.001011471099025, 0.171313592775733, 0.38304462748202056, 0.07032688363741249, 0.09508545407551863, 1.3493827872088155, 1.736562930225245, 5.877709860593139])    
    xguess = np.append(np.array([r, tax]), thetas)

    # ------ START SAMPLE SOLVE (TO DELETE)------
    start = time.time()
    # Solve model
    print('Solving steady state with tol = {}'.format(ss_tol))
    r_ss, tax_ss, thetas_ss = solveSS_AOB.SS(xguess, par['Z'], par, smm_index, ss_tol)
    # Try # 6 ~ 7.42 hours
    # r_ss = 0.00447230279975839
    # tax_ss = -0.156663124085524
    # thetas_ss = np.array([17.4351971488963, 0.0632644993683686, 0.333650130619535, 0.0268039938685904, 0.0431434628763821, 0.790970661669124, 2.05384606840144, 4.34185140182558])
    # Try # 5 ~ 15.45 hours
    # r_ss = 0.00447345014281818
    # tax_ss = -0.156638068957646
    # thetas_ss = np.array([17.4346197423405, 0.0632571895222633, 0.333670917481126, 0.026661006190783, 0.0430970805228311, 0.796578281295913, 2.05376152467184, 4.34146680995868])
    # Try # 4 ~ 5.24 hours
    # r_ss = 0.00405848702011946
    # tax_ss = -0.172604844368504
    # thetas_ss =  np.array([18.2250679134026,	0.0823426246372685,	0.372002961570071,	0.0322291100694188,	0.0473088772836751,	0.999066002317185,	2.114260884984,	4.98511441928861])
    # Try # 3 ~18.95 hours
    # r_ss = 0.00405907322544432
    # tax_ss = -0.172574662243902
    # theta_ss = np.array([18.2242931092867,	0.082348235663596,	0.372087743500644,	0.0321582023517724,	0.0473004889968181,	0.998978067860064,	2.11424478029277,	4.9849249296017])
    # Try #2 ~19.48 hours
    # r_ss = 0.00405907322544432
    # tax_ss = -0.172574662243902
    # thetas_ss = np.array([18.2242931092867	0.082348235663596	0.372087743500644	0.0321582023517724	0.0473004889968181	0.998978067860064	2.11424478029277	4.9849249296017])
    # Try #1 ~19 hours
    # r_ss = 0.004059073225444317
    # tax_ss = -0.17257466224390183
    # thetas_ss = np.array([18.22429311,  0.08234824,  0.37208774,  0.0321582 ,  0.04730049, 0.99897807,  2.11424478,  4.98492493])
    end_time = time.time()
    test_results = np.concatenate((
        [r_ss, tax_ss],
        np.asarray(thetas_ss).ravel(),
        [(end_time - start) / 60],
    ))
    pd.DataFrame([test_results]).to_csv('test_results.csv', index=False, header=False)

    print('Time to solve model: {} min'.format(round((end_time - start) / 60, 2)))

mp_worker(inputs[input_index])
