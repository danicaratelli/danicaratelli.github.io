import numpy as np
import utils
#import multiprocessing as mp
import HHhelp_AOB as HH
from concurrent.futures import ThreadPoolExecutor
from scipy.optimize import least_squares
import time


def _profile_add(profiler, key, dt):
    if profiler is None:
        return
    slot = profiler.setdefault(key, {'time': 0.0, 'calls': 0})
    slot['time'] += dt
    slot['calls'] += 1


def _format_profile_summary(profiler):
    if not profiler:
        return "No profile stats recorded."
    rows = sorted(profiler.items(), key=lambda kv: kv[1]['time'], reverse=True)
    out = ["Runtime profile summary (seconds, cumulative):"]
    for name, stats in rows:
        out.append(f"  - {name:20s}: {stats['time']:.3f}s over {stats['calls']} calls")
    return "\n".join(out)

def matching_fnc_1(thetas, par):
    """Computes vacancy, job-finding, vacancy-filling rates given tightness"""
    # thetas here must be vacancies / (total population on previous rung)
    # vacancy-filling rate
    qs = par['chi'] * (1 / thetas) ** (par['eta'])
    lambdas = thetas * qs                           # job-finding rate
    return qs, lambdas

def matching_fnc_2(thetas, DUs, DEEs, par):
    """Computes total vacancies, total job searchers at each rung given job-finding and vacancy-positing rates"""
    # thetas here must be vacancies / (total population on previous rung)
    Utot = np.sum(DUs)
    Esearchers = np.sum(DEEs, axis=(0,1,2,3,4,6))
    searchers = par['gU'] * Utot + Esearchers
    vacancies = thetas * searchers

    return searchers, vacancies

def fiscal(tax, transfer, DEs, DUs, Z, rK, k_little, vacancies, par):
    """Computes residual from govt budget balance"""
    p_grid = par['p_grid']
    z_grid = par['z_grid']
    w_grid = par['w_grid']

    # firm vacancy cost and flow profits
    zeta_scale = (par['zeta'] * par['p_grid']) ** par['zeta_curv']
    v_cost = np.sum(vacancies * zeta_scale)  # aggregate vacancy cost
    effZ = z_grid[:, np.newaxis, np.newaxis, np.newaxis, np.newaxis, np.newaxis] * \
           p_grid[np.newaxis, np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]
    # compute flow profits
    pi_flow = (Z * effZ * (utils.f(k_little, par) - rK * k_little) -
               w_grid[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis, np.newaxis])
    pi_flow = np.sum(DEs * pi_flow) - v_cost

    tax_revenue = tax * np.sum(np.sum(DEs, axis=(0, 1, 3, 4, 5)) * w_grid)
    govt_expenditures = transfer + (1 - tax) * par['bUI'] * np.sum(DUs)

    return tax_revenue + pi_flow - govt_expenditures

def asset_mkt(DUs, DEs, Z, k_little, par):
    a_grid = par['a_grid']
    z_grid = par['z_grid']
    p_grid = par['p_grid']

    # asset supply (by HHs)
    assetS = np.sum(a_grid * (np.sum(DUs, axis=(0, 2)) + np.sum(DEs, axis=(0, 2, 3, 4, 5))))
    # value of the firm (= to total capital demanded by firms in SS)
    assetD = Z * np.sum(np.sum(DEs, axis=(1, 2, 4, 5)) * z_grid[:, np.newaxis] * p_grid[np.newaxis, :]) * k_little


    return assetS - assetD, assetD

def free_entry(JE0s, JU0s, DUEs, DEEs, qs, r, par):
    """Computes residual from vacancy-filling condition"""
    Dentrants = DUEs / np.sum(DUEs)
    Dswitchers = np.sum(DEEs, axis=(0, 1, 2, 3, 4, 6))
    # expected value to vacanct firms
    J0s_num = np.sum(JE0s * DEEs, axis=(0, 1, 2, 3, 4, 6))
    J0s = np.divide(J0s_num, Dswitchers, out=np.zeros_like(J0s_num), where=Dswitchers > 0)
    J0s += np.sum(JU0s * Dentrants, axis=(0, 1, 3))
    zeta_scale = (par['zeta'] * par['p_grid']) ** par['zeta_curv']
    vacancy_value = (qs * J0s) / (1 + r)
    res_vacancy = np.arcsinh((vacancy_value - zeta_scale) / zeta_scale)
    #v_cost = np.sum(vacancies * zeta_scale)  # aggregate vacancy cost
    #res_vacancy = (qs * J0s) / (1 + r) - (par['zeta'] * par['p_grid'])

    return res_vacancy

def check_clearing(thetas, r, tax, Z, DUs, DEs, DUEs, DEEs, JE0s, JU0s, par, transfer = 0):
    # initialize residual
    res = np.zeros(2 + par['nP'])   # 2 if no profits to HH, 3 if profits to HH
    # compute labor market variables
    qs, lambdas = matching_fnc_1(thetas, par)
    searchers, vacancies = matching_fnc_2(thetas, DUs, DEEs, par)
    # compute capital per efficiency unit of labor
    rK = r + par['drate']           # rental rate of capital
    k_little = (rK / (par['alpha'] * Z)) ** (1 / (par['alpha'] - 1))    # capital per effective unit of labor
    effZ = par['z_grid'][:, np.newaxis, np.newaxis, np.newaxis, np.newaxis, np.newaxis] * \
           par['p_grid'][np.newaxis, np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]
    Y = np.sum(Z * effZ * utils.f(k_little, par) * DEs)
    # asset market
    res[0], K = asset_mkt(DUs, DEs, Z, k_little, par)
    res[0] = res[0] / max(abs(K), 1.0)
    # fiscal policy
    res[1] = fiscal(tax, transfer, DEs, DUs, Z, rK, k_little, vacancies, par)
    res[1] = res[1] / max(abs(Y), 1.0)
    # free-entry at each rung
    res[2:] = free_entry(JE0s, JU0s, DUEs, DEEs, qs, r, par)
    # Walras' Law
    # total efficiency units of labor
    N = np.sum(effZ * DEs)
    zeta_scale = (par['zeta'] * par['p_grid']) ** par['zeta_curv']
    vcost = np.sum(vacancies * zeta_scale)

    return res, Y, K, vcost, N

def _theta_from_x(x_theta, theta_min):
    return theta_min * np.exp(x_theta)

def _x_from_theta(theta, theta_min):
    return np.log(theta / theta_min)

def _ss_x_from_guess(xguess, par):
    x0 = np.zeros(2 + par['nP'])
    x0[0] = utils.bound_map_inv(xguess[0], 0.001, 0.0075)
    x0[1] = utils.bound_map_inv(xguess[1], -0.7, 0.3)
    theta1_min = 0.005
    thetak_min = 0.005
    x0[2] = _x_from_theta(xguess[2], theta1_min)
    x0[3:] = _x_from_theta(xguess[3:], thetak_min)
    return x0

def _ss_values_from_x(x, par):
    r = utils.bound_map(x[0], 0.001, 0.0075)
    tax = utils.bound_map(x[1], -0.7, 0.3)
    theta1_min = 0.005
    thetak_min = 0.005
    thetas = np.zeros(par['nP'])
    thetas[0] = _theta_from_x(x[2], theta1_min)
    thetas[1:] = _theta_from_x(x[3:], thetak_min)
    if not np.all(np.isfinite(thetas)):
        raise ValueError('Non-finite market tightness')
    return r, tax, thetas

def _ss_hh_tolerances(par, resid_scale=np.inf):
    schedule = par.get('ss_hh_tol_schedule', (
        (1e-3, 1e-7, 1e-9),
        (1e-2, 1e-6, 1e-8),
        (np.inf, 1e-5, 1e-7),
    ))
    for threshold, bellman_tol, dist_tol in schedule:
        if resid_scale <= threshold:
            return bellman_tol, dist_tol
    return schedule[-1][1], schedule[-1][2]

def _evaluate_ss_residual(x, Z, par, smm_index, warm_cache=None, profiler=None, return_diagnostics=False,
                          resid_scale=np.inf):
    nZ = par['nZ']
    nP = par['nP']
    nW = par['nW']
    nA = par['nA']
    nT = par['nT']
    nB = par['nB']
    ibs = [0, 2]
    hh_cache = {ib: None for ib in ibs} if warm_cache is None else warm_cache

    JU0s = np.zeros((nZ, nA, nP, nB))
    JE0s = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))
    DUs = np.zeros((nZ, nA, nB))
    DEs = np.zeros((nZ, nA, nW, nP, nT, nB))
    DUEs = np.zeros((nZ, nA, nP, nB))
    DEEs = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))

    r, tax, thetas = _ss_values_from_x(x, par)
    qs, lambdas = matching_fnc_1(thetas, par)
    bellman_tol, dist_tol = _ss_hh_tolerances(par, resid_scale)
    utils.labor_market_cache(par)

    diagnostics = {
        'r': r,
        'tax': tax,
        'thetas': thetas.copy(),
        'bellman_tol': bellman_tol,
        'dist_tol': dist_tol,
        'policies': {},
    }
    max_workers = min(len(ibs), par.get('ss_hh_workers', len(ibs)))
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        def _solve_ib(ib):
            return HH.solveHH(
                (r, tax, Z, par, lambdas, ib, smm_index),
                warm_start=hh_cache[ib],
                profiler=profiler,
                bellman_tol=bellman_tol,
                dist_tol=dist_tol,
            )
        results = list(executor.map(_solve_ib, ibs))

    for ib, result in enumerate(results):
        U, E, E_bargaining, dU, dE, dE_bargaining, cU, cE, J, J_bargaining, JU0, JE0, DU, DE, DUE, DEE, qswitch, w_i, w_pi, Inew, warm_state = result
        ib_key = ibs[ib]
        hh_cache[ib_key] = warm_state

        JU0s[:, :, :, ib] = JU0
        JE0s[:, :, :, :, :, :, ib] = JE0
        DUs[:, :, ib] = DU / nB
        DEs[:, :, :, :, :, ib] = DE / nB
        DUEs[:, :, :, ib] = DUE / nB
        DEEs[:, :, :, :, :, :, ib] = DEE / nB

        if return_diagnostics:
            diagnostics['policies'][ib_key] = {
                'w_i': np.asarray(w_i).copy(),
                'Inew': np.asarray(Inew).copy(),
                'qswitch': np.asarray(qswitch).copy(),
            }

    xres, Y, K, vcost, N = check_clearing(thetas, r, tax, Z, DUs, DEs, DUEs, DEEs, JE0s, JU0s, par)
    diagnostics.update({'Y': Y, 'K': K, 'vcost': vcost, 'N': N})
    if return_diagnostics:
        return xres, hh_cache, diagnostics
    return xres, hh_cache

def diagnose_SS_smoothness(xguess, Z, par, smm_index, steps=(1e-3,), variables=None):
    """Local plus/minus residual diagnostic around the SS guess."""
    x0 = _ss_x_from_guess(xguess, par)
    names = ['r', 'tax'] + [f'theta[{i}]' for i in range(par['nP'])]
    if variables is None:
        variables = range(len(x0))

    profiler = {}
    t0 = time.perf_counter()
    y0, base_cache, base_diag = _evaluate_ss_residual(
        x0, Z, par, smm_index, profiler=profiler, return_diagnostics=True
    )
    base_time = time.perf_counter() - t0
    rows = []

    for i in variables:
        for h in steps:
            row = {'variable': names[i], 'index': i, 'h': h}
            evals = {}
            diags = {}
            for side, sign in [('-', -1.0), ('+', 1.0)]:
                xh = x0.copy()
                xh[i] += sign * h
                t_eval = time.perf_counter()
                yh, _, diag_h = _evaluate_ss_residual(
                    xh, Z, par, smm_index,
                    warm_cache={k: v for k, v in base_cache.items()},
                    profiler=profiler,
                    return_diagnostics=True
                )
                evals[side] = yh
                diags[side] = diag_h
                row[f'time_{side}'] = time.perf_counter() - t_eval

            fwd = (evals['+'] - y0) / h
            bwd = (y0 - evals['-']) / h
            denom = max(np.linalg.norm(fwd), np.linalg.norm(bwd), 1e-12)
            row['base_max_abs_resid'] = np.max(np.abs(y0))
            row['plus_max_abs_resid'] = np.max(np.abs(evals['+']))
            row['minus_max_abs_resid'] = np.max(np.abs(evals['-']))
            row['slope_asymmetry'] = np.linalg.norm(fwd - bwd) / denom
            row['slope_norm_fwd'] = np.linalg.norm(fwd)
            row['slope_norm_bwd'] = np.linalg.norm(bwd)
            row['max_abs_jump'] = max(np.max(np.abs(evals['+'] - y0)), np.max(np.abs(evals['-'] - y0)))

            for policy_name in ['w_i', 'Inew', 'qswitch']:
                changes = []
                for side in ['-', '+']:
                    for ib in base_diag['policies']:
                        base_pol = base_diag['policies'][ib][policy_name]
                        pol_h = diags[side]['policies'][ib][policy_name]
                        changes.append(np.mean(base_pol != pol_h))
                row[f'{policy_name}_change_rate'] = float(np.mean(changes))
            rows.append(row)

    return {
        'x0': x0,
        'base_residual': y0,
        'base_time': base_time,
        'rows': rows,
        'profile': profiler,
    }

def _clip_ss_guess(xguess, par):
    xguess = np.asarray(xguess, dtype=float).copy()
    eps = 1e-10
    xguess[0] = np.clip(xguess[0], 0.001 + eps, 0.0075 - eps)
    xguess[1] = np.clip(xguess[1], -0.7 + eps, 0.3 - eps)
    xguess[2:] = np.maximum(xguess[2:], 0.005 * (1 + eps))
    return xguess

def _initial_guess_candidates(xguess, par):
    xguess = _clip_ss_guess(xguess, par)
    candidates = [('baseline', xguess)]

    def add_candidate(name, r_scale=1.0, tax_shift=0.0, theta_slice=None, theta_scale=1.0):
        cand = xguess.copy()
        cand[0] *= r_scale
        cand[1] += tax_shift
        if theta_slice is None:
            cand[2:] *= theta_scale
        else:
            cand[2:][theta_slice] *= theta_scale
        candidates.append((name, _clip_ss_guess(cand, par)))

    add_candidate('r * 0.8', r_scale=0.8)
    add_candidate('r * 1.2', r_scale=1.2)
    add_candidate('tax - 0.05', tax_shift=-0.05)
    add_candidate('tax + 0.05', tax_shift=0.05)
    add_candidate('theta all * 0.75', theta_scale=0.75)
    add_candidate('theta all * 1.25', theta_scale=1.25)
    add_candidate('theta[0] * 0.5', theta_slice=slice(0, 1), theta_scale=0.75)
    add_candidate('theta[0] * 2.0', theta_slice=slice(0, 1), theta_scale=1.25)

    mid_stop = min(5, par['nP'])
    if mid_stop > 1:
        add_candidate('theta[1:5] * 0.7', theta_slice=slice(1, mid_stop), theta_scale=0.7)
        add_candidate('theta[1:5] * 1.4', theta_slice=slice(1, mid_stop), theta_scale=1.4)
    if par['nP'] > 5:
        add_candidate('theta[5:] * 0.7', theta_slice=slice(5, par['nP']), theta_scale=0.7)
        add_candidate('theta[5:] * 1.4', theta_slice=slice(5, par['nP']), theta_scale=1.4)

    return candidates

def _find_initial_ss_guess(xguess, Z, par, smm_index, profiler=None):
    verbose = par.get('verbose_ss', False)
    if verbose:
        print('Starting initial guess search...')
    candidates = _initial_guess_candidates(xguess, par)
    max_candidates = par.get('ss_initial_search_max_candidates', 1)
    search_threshold = par.get('ss_initial_search_skip_threshold', 0.1)
    resid_scale = par.get('ss_initial_search_resid_scale', np.inf)
    ibs = [0, 2]
    search_cache = {ib: None for ib in ibs}

    best_name = None
    best_x = None
    best_score = np.inf
    best_resid = None
    n_evals = 0

    for i, (name, cand_guess) in enumerate(candidates[:max_candidates]):
        try:
            x = _ss_x_from_guess(cand_guess, par)
            xres, search_cache = _evaluate_ss_residual(
                x, Z, par, smm_index,
                warm_cache=search_cache,
                profiler=profiler,
                resid_scale=resid_scale,
            )
            score = np.max(np.abs(xres))
            n_evals += 1
            if verbose:
                print(f'Initial guess candidate {i}: {name}, max residual = {score}')
        except (FloatingPointError, ValueError, OverflowError) as err:
            if verbose:
                print(f'Initial guess candidate {i}: {name}, failed with {err}')
            continue

        if np.isfinite(score) and score < best_score:
            best_name = name
            best_x = x
            best_score = score
            best_resid = xres

        if np.isfinite(score) and score <= search_threshold:
            if verbose:
                print('Initial guess candidate is good enough; stopping perturbation search.')
            break

    if best_x is None:
        if verbose:
            print('Initial guess search found no usable candidate; using the original guess.')
        return _ss_x_from_guess(xguess, par), None, np.inf, search_cache

    if verbose:
        print(f'Initial guess search complete after {n_evals} evaluations.')
        print(f'Best initial guess candidate: {best_name}, max residual = {best_score}')
        print('Best initial guess residual = ', best_resid)
    return best_x, best_resid, best_score, search_cache

def SS(xguess, Z, par, smm_index, tol = 1e-6):
    # extract useful parameters
    nP = par['nP']

    ibs = [0, 2]
    profile_enabled = par.get('profile_ss', False)
    profiler = {} if profile_enabled else None
    hh_cache = {ib: None for ib in ibs}

    last_resid_scale = np.inf
    force_tight_hh = False
    best_x = None
    best_y = None
    best_score = np.inf
    best_tight_x = None
    best_tight_y = None
    best_tight_score = np.inf

    def _record_best(x, y):
        nonlocal best_x, best_y, best_score, best_tight_x, best_tight_y, best_tight_score
        score = np.max(np.abs(y))
        if np.isfinite(score) and score < best_score:
            best_x = np.asarray(x, dtype=float).copy()
            best_y = np.asarray(y, dtype=float).copy()
            best_score = score
        if force_tight_hh and np.isfinite(score) and score < best_tight_score:
            best_tight_x = np.asarray(x, dtype=float).copy()
            best_tight_y = np.asarray(y, dtype=float).copy()
            best_tight_score = score

    def obj_fun(x):
        nonlocal last_resid_scale
        t_obj = time.perf_counter()
        resid_scale_for_tols = 0.0 if force_tight_hh else last_resid_scale
        hh_tolerances = _ss_hh_tolerances(par, resid_scale_for_tols)
        xres, _ = _evaluate_ss_residual(
            x, Z, par, smm_index,
            warm_cache=hh_cache,
            profiler=profiler,
            resid_scale=resid_scale_for_tols,
        )
        last_resid_scale = np.max(np.abs(xres))
        _record_best(x, xres)
        if par.get('verbose_ss', False):
            print('obj residual = ', xres)
            print('HH tolerances = ', hh_tolerances)
        _profile_add(profiler, 'SS.obj_fun', time.perf_counter() - t_obj)
        return xres

    def _run_broyden_stage(stage_name, x_start, y_start, stage_tol, maxcount, tight_hh):
        nonlocal force_tight_hh, last_resid_scale
        force_tight_hh = tight_hh
        if y_start is not None:
            last_resid_scale = np.max(np.abs(y_start))
            _record_best(x_start, y_start)
        if par.get('verbose_ss', False):
            print(f'Starting {stage_name}: tol = {stage_tol}, tight HH = {tight_hh}')
        return utils.broyden_solver(
            obj_fun, x_start, y0=y_start, tol=stage_tol,
            maxcount=maxcount, backtrack_c=par.get('ss_broyden_backtrack_c', 0.5),
            noisy=False, jac_h=par.get('ss_jac_h', 1e-3),
            require_improvement=True,
            improvement_tol=par.get('ss_broyden_improvement_tol', 0.05),
            max_backtracks=par.get('ss_broyden_max_backtracks', 10),
        )

    def _run_least_squares_fallback(x_start):
        nonlocal force_tight_hh
        force_tight_hh = True
        method = par.get('ss_least_squares_method', 'trf')
        max_nfev = par.get('ss_least_squares_max_nfev', 40)
        invalid_resid = par.get('ss_least_squares_invalid_resid', 1e6)

        def ls_obj_fun(x):
            try:
                y = obj_fun(x)
            except (FloatingPointError, OverflowError, ValueError):
                return np.full(2 + nP, invalid_resid)
            if not np.all(np.isfinite(y)):
                return np.full(2 + nP, invalid_resid)
            return y

        if par.get('verbose_ss', False):
            print(f'Starting least-squares fallback: method = {method}, max_nfev = {max_nfev}')
        result = least_squares(
            ls_obj_fun, x_start,
            method=method,
            max_nfev=max_nfev,
            xtol=par.get('ss_least_squares_xtol', 1e-8),
            ftol=par.get('ss_least_squares_ftol', 1e-8),
            gtol=par.get('ss_least_squares_gtol', 1e-8),
            x_scale=par.get('ss_least_squares_x_scale', 'jac'),
        )
        y_result = np.asarray(result.fun)
        _record_best(result.x, y_result)
        if par.get('verbose_ss', False):
            print('Least-squares fallback status = ', result.status, result.message)
            print('Least-squares fallback residual = ', y_result)
        if best_tight_x is not None and best_tight_score <= np.max(np.abs(y_result)):
            return best_tight_x.copy(), best_tight_y.copy()
        return result.x, y_result

    # bounds for tightnesses
    assert par['chi'] < 1, 'parameter chi in matching function must be < 1'
    theta1_min = 0.005 #par['chi'] ** (1 / par['eta'])
    thetak_min = 0.005 #par['s'] * (par['chi'] ** (1 / (par['eta'])))
    x0 = _ss_x_from_guess(xguess, par)
    y0 = None

    if par.get('ss_initial_search', True):
        x0, y0, _, hh_cache = _find_initial_ss_guess(xguess, Z, par, smm_index, profiler=profiler)
        if y0 is not None:
            last_resid_scale = np.max(np.abs(y0))
            _record_best(x0, y0)

    if par.get('verbose_ss', False):
        print('Starting true steady-state solver...')

    xstar, ystar = x0, y0
    coarse_tol = par.get('ss_coarse_tol', 1e-3)
    use_staged_solve = par.get('ss_staged_solve', True) and tol <= coarse_tol
    try:
        if use_staged_solve:
            xstar, ystar = _run_broyden_stage(
                'coarse Broyden stage', xstar, ystar, coarse_tol,
                par.get('ss_coarse_maxcount', 60), tight_hh=False
            )

        if par.get('ss_final_tight_check', True):
            force_tight_hh = True
            ystar = obj_fun(xstar)
        elif ystar is None:
            ystar = obj_fun(xstar)

        if np.max(np.abs(ystar)) >= tol:
            xstar, ystar = _run_broyden_stage(
                'tight Broyden restart', xstar, ystar, tol,
                par.get('ss_tight_maxcount', 60), tight_hh=True
            )
    except (ValueError, np.linalg.LinAlgError) as err:
        if not par.get('ss_least_squares_fallback', True):
            raise
        if par.get('verbose_ss', False):
            print(f'Broyden stage failed with: {err}')
            if best_tight_y is not None:
                print('Best tight residual before fallback = ', best_tight_y)
            elif best_y is not None:
                print('Best residual before fallback = ', best_y)
        x_fallback = best_tight_x if best_tight_x is not None else (best_x if best_x is not None else xstar)
        xstar, ystar = _run_least_squares_fallback(x_fallback)

    if np.max(np.abs(ystar)) >= tol and par.get('ss_least_squares_fallback', True):
        xstar, ystar = _run_least_squares_fallback(xstar)

    final_score = np.max(np.abs(ystar))
    if final_score >= tol:
        if profile_enabled:
            print(_format_profile_summary(profiler))
        raise ValueError(f'Steady-state solver did not reach tol={tol}. Best max residual = {final_score}')

    if profile_enabled:
        print(_format_profile_summary(profiler))

    # extract ss variables
    r_ss = utils.bound_map(xstar[0], 0.001, 0.0075)
    tax_ss = utils.bound_map(xstar[1], -0.7, 0.3)
    # thetas_ss = utils.bound_map(xstar[2:], 1e-2, 100)
    thetas_ss = np.zeros(nP)
    thetas_ss[0] = _theta_from_x(xstar[2], theta1_min)
    thetas_ss[1:] = _theta_from_x(xstar[3:], thetak_min)

    return r_ss, tax_ss, thetas_ss

def getSS(r_ss, tax_ss, thetas_ss, Z, par, smm_index, transfer=0):
    # extract useful parameters
    nZ = par['nZ']
    nP = par['nP']
    nW = par['nW']
    nA = par['nA']
    nT = par['nT']
    nB = par['nB']
    M = par['M']
    a_grid = par['a_grid']
    w_grid = par['w_grid']

    # initialize policy and value functions, and distribution matrices
    Us = np.zeros((nZ, nA, nB))
    dUs = np.zeros((nZ, nA, nB))
    cUs = np.zeros((nZ, nA, nB))
    Es = np.zeros((nZ, nA, nW, nP, nT, nB))
    Ebargainings = np.zeros((nZ, nA, nW, nP, M, nB))
    dEs = np.zeros((nZ, nA, nW, nP, nT, nB))
    dEbargainings = np.zeros((nZ, nA, nW, nP, M, nB))
    cEs = np.zeros((nZ, nA, nW, nP, nT, nB))
    Js = np.zeros((nZ, nA, nW, nP, nT, nB))
    Jbargainings = np.zeros((nZ, nA, nW, nP, M, nB))
    JU0s = np.zeros((nZ, nA, nP, nB))
    JE0s = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))
    DUs = np.zeros((nZ, nA, nB))
    DEs = np.zeros((nZ, nA, nW, nP, nT, nB))
    DUEs = np.zeros((nZ, nA, nP, nB))
    DEEs = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))
    qswitchs = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))
    Iwin = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))

    # wage policies
    WU_is = np.zeros((nZ, nA, nP, nB), dtype='uint32')
    WU_pis = np.zeros((nZ, nA, nP, nB))
    WEwin_is = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB), dtype='uint32')
    WEwin_pis = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))
    WElose_is = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB), dtype='uint32')
    WElose_pis = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))

    # vacancy posting and job-finding rates
    qs, lambdas = matching_fnc_1(thetas_ss, par)

    beta0 = par['beta']
    # loop over betas
    for ib in np.array([0, 2]):
        par['beta'] = beta0
        # solve iteration
        U, E, E_bargaining, dU, dE, dE_bargaining, cU, cE, J, J_bargaining, \
        JU0, JE0, DU, DE, DUE, DEE, qswitch, w_i, w_pi, Inew, _ = HH.solveHH((r_ss, tax_ss, Z, par, lambdas, ib, smm_index))
        bi = int(ib/2)
        # record in larger beta-matix
        Us[:, :, bi] = U
        dUs[:, :, bi] = dU
        cUs[:, :, bi] = cU
        Es[:, :, :, :, :, bi] = E
        Ebargainings[:, :, :, :, :, bi] = E_bargaining
        dEs[:, :, :, :, :, bi] = dE
        dEbargainings[:, :, :, :, :, bi] = dE_bargaining
        cEs[:, :, :, :, :, bi] = cE
        Js[:, :, :, :, :, bi] = J
        Jbargainings[:, :, :, :, :, bi] = J_bargaining
        JU0s[:, :, :, bi] = JU0
        JE0s[:, :, :, :, :, :, bi] = JE0
        # record distribution
        DUs[:, :, bi] = DU / nB
        DEs[:, :, :, :, :, bi] = DE / nB
        DUEs[:, :, :, bi] = DUE / nB
        DEEs[:, :, :, :, :, :, bi] = DEE / nB
        # record wages
        WU_is[:, :, :, bi] = w_i['U']
        WU_pis[:, :, :, bi] = w_pi['U']
        WEwin_is[:, :, :, :, :, :, bi] = w_i['Ewin']
        WEwin_pis[:, :, :, :, :, :, bi] = w_pi['Ewin']
        WElose_is[:, :, :, :, :, :, bi] = w_i['Elose']
        WElose_pis[:, :, :, :, :, :, bi] = w_pi['Elose']
        # record pr. of switching
        qswitchs[:, :, :, :, :, :, bi] = qswitch
        Iwin[:, :, :, :, :, :, bi] = Inew

    # Save steady state results for each batch
    for bi in range(nB):
        batch = 1 + bi * 2  # 1 for bi=0, 3 for bi=1
        with open('SS_b' + str(batch) + '_' + str(smm_index) + '.npy', 'wb') as f:
            np.save(f, cUs[:, :, bi])
            np.save(f, cEs[:, :, :, :, :, bi])
            np.save(f, Us[:, :, bi])
            np.save(f, Es[:, :, :, :, :, bi])
            np.save(f, Ebargainings[:, :, :, :, :, bi])
            np.save(f, dUs[:, :, bi])
            np.save(f, dEs[:, :, :, :, :, bi])
            np.save(f, dEbargainings[:, :, :, :, :, bi])
            np.save(f, Js[:, :, :, :, :, bi])
            np.save(f, Jbargainings[:, :, :, :, :, bi])

        with open('distributions_b' + str(batch) + '_' + str(smm_index) + '.npy', 'wb') as f:
            np.save(f, DUs[:, :, bi])
            np.save(f, DEs[:, :, :, :, :, bi])

    # Compute assets
    aUs = (1 + r_ss) * a_grid[np.newaxis, :, np.newaxis, ] + transfer + (1 - tax_ss) * par['bUI'] - cUs
    aEs = (1 + r_ss) * a_grid[np.newaxis, :, np.newaxis, np.newaxis, np.newaxis, np.newaxis] + transfer + \
          (1 - tax_ss) * w_grid[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis, np.newaxis] - cEs

    # Derive aggregates
    xres, Y, K, vcost, N = check_clearing(thetas_ss, r_ss, tax_ss, Z, DUs, DEs, DUEs, DEEs, JE0s, JU0s, par)
    print('residual = ', xres)
    # assert np.max(np.abs(xres))<1e-4, 'steady state is not correct'
    # assert np.max(np.abs(xres))<1e-1, 'steady state is not correct'
    C = np.sum(DUs * cUs) + np.sum(DEs * cEs)
    Umass = np.sum(DUs)
    # Walras
    walras = Y - par['drate'] * K - vcost - C
    # searchers and vacancies
    searchers, vacancies = matching_fnc_2(thetas_ss, DUs, DEEs, par)
    e0, e1, e2, e3, e4, e5, e6, e7 = searchers[0], searchers[1], searchers[2], searchers[3], searchers[4], searchers[5], searchers[6], searchers[7]
    v0, v1, v2, v3, v4, v5, v6, v7 = vacancies[0], vacancies[1], vacancies[2], vacancies[3], vacancies[4], vacancies[5], vacancies[6], vacancies[7]

    # Compute the labor flow rates
    EU_rate = np.sum(DEs * par['sigma'][np.newaxis, np.newaxis, np.newaxis, np.newaxis, :, np.newaxis]) / np.sum(DEs)
    EE_rate = np.sum(DEEs * qswitchs) / np.sum(DEs)

    # Expected values for vacant firms and flow-profits for active firms
    JU0_tmp = np.sum(JU0s * DUEs, axis=(0, 1, 3)) / np.sum(DUEs)
    Dswitchers = np.sum(DEEs, axis=(0, 1, 2, 3, 4, 6))
    JE0_tmp = np.sum(JE0s * DEEs, axis=(0, 1, 2, 3, 4, 6)) / Dswitchers
    if Dswitchers[0]==0:
        JE0_tmp[0] = 0
    J0_tmp = JU0_tmp + JE0_tmp
    J0_0 = J0_tmp[0]
    J0_1 = J0_tmp[1]
    J0_2 = J0_tmp[2]
    J0_3 = J0_tmp[3]
    J0_4 = J0_tmp[4]
    J0_5 = J0_tmp[5]
    J0_6 = J0_tmp[6]
    J0_7 = J0_tmp[7]
    Pi = Y - (r_ss + par['drate']) * K - np.sum(par['w_grid'] * np.sum(DEs, axis=(0, 1, 3, 4, 5)))

    # Fiscal policy
    Tax = np.sum(par['w_grid'] * np.sum(DEs, axis=(0, 1, 3, 4, 5))) * tax_ss
    Ubill = np.sum(DUs) * par['bUI']

    # Define steady state dictionary
    ss = {'Z': Z, 'alpha': par["alpha"], 'beta': par['beta'],  # parameters
          'drate': par['drate'], 'bUI': par['bUI'], 'transfer': transfer,
          'eis': par["eis"], 'Q': 1,
          'chi': par['chi'], 'eta': par['eta'],
          'r': r_ss, 'ra': r_ss, 'tax': tax_ss,  # unknowns
          'theta0': thetas_ss[0], 'theta1': thetas_ss[1], 'theta2': thetas_ss[2], 'theta3': thetas_ss[3],
          'theta4': thetas_ss[4], 'theta5': thetas_ss[5], 'theta6': thetas_ss[6], 'theta7': thetas_ss[7],
          'p': K, 'div': r_ss * K, 'epsI': par['epsI'],  # firm
          'JU0s' : JU0s, 'JE0s' : JE0s,
          'J0_0': J0_0, 'J0_1': J0_1, 'J0_2': J0_2, 'J0_3': J0_3,
          'J0_4': J0_4, 'J0_5': J0_5, 'J0_6': J0_6, 'J0_7': J0_7, 'Jss': Js, 'Jbargainingss': Jbargainings,  # firm values
          'Pi': Pi, 'vcost': vcost, 'zeta': par['zeta'],  'zeta_curv': par['zeta_curv'],
          'pgrid0': par['p_grid'][0], 'pgrid1': par['p_grid'][1], 'pgrid2': par['p_grid'][2],'pgrid3': par['p_grid'][3],
          'pgrid4': par['p_grid'][4], 'pgrid5': par['p_grid'][5], 'pgrid6': par['p_grid'][6], 'pgrid7': par['p_grid'][7],
          'rK': r_ss + par['drate'],  # factor prices
          'q0': qs[0], 'q1': qs[1], 'q2': qs[2], 'q3': qs[3], 'q4': qs[4], 'q5': qs[5], 'q6': qs[6], 'q7': qs[7], # labor market
          'lambdas': lambdas,
          'lambda0': lambdas[0], 'lambda1': lambdas[1], 'lambda2': lambdas[2], 'lambda3': lambdas[3],
          'lambda4': lambdas[4], 'lambda5': lambdas[5], 'lambda6': lambdas[6], 'lambda7': lambdas[7],
          'e0': e0, 'e1': e1, 'e2': e2, 'e3': e3, 'e4': e4, 'e5': e5, 'e6': e6, 'e7': e7,
          'v0': v0, 'v1': v1, 'v2': v2, 'v3': v3, 'v4': v4, 'v5': v5, 'v6': v6, 'v7': v7,
          'Iwins': Iwin, 's': par['s'], 'sigmaJ': par['sigma'][-1],
          'WUiss': WU_is, 'WUpiss': WU_pis,  # wage policies
          'WEwiniss': WEwin_is, 'WEwinpiss': WEwin_pis,
          'WEloseiss': WElose_is, 'WElosepiss': WElose_pis,
          'Y': Y, 'K': K, 'I': K * par['drate'], 'N': N, 'A': K, 'L': N, 'C': C,  # aggregates
          'CUss': cUs, 'CEss': cEs, 'AUss': aUs, 'AEss': aEs,  # consumption and savings policy
          'qss': qswitchs, 'EE_rate': EE_rate, 'EU_rate': EU_rate,  # job-switching
          'Uss': Us, 'Ess': Es, 'Ebargainingss' : Ebargainings, 'dEbargainingss' : dEbargainings,# value functions
          'QUss': DUs, 'QEss': DEs, 'QUEss': DUEs, 'QEEss': DEEs,  # distributions
          'U': Umass,
          'Tax': Tax, 'Ubill': Ubill, # fiscal policy
          'CU': np.sum(DUs * cUs), 'CE': np.sum(DEs * cEs), 'AU': np.sum(DUs * aUs), 'AE': np.sum(DEs * aEs),
          'A_pre': np.sum(np.sum(DUs, axis=(0,2)) + np.sum(DEs, axis=(0,2,3,4,5)) * par['a_grid']),
          'AU_pre': np.sum(np.sum(DUs, axis=(0,2)) * par['a_grid']),
          'AE_pre': np.sum(np.sum(DEs, axis=(0,2,3,4,5)) * par['a_grid']),
          'walras': walras, 'residuals': xres}

    ss['earnings'] = (ss['Tax'] / (ss['tax'] * (1 - ss['U'])))
    ss['sigmaslope'] = 0

    return ss
