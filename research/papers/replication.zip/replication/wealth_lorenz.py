import utils
import numpy as np

def get_wealth_dist(ss, par):
     wealth_dist = np.sum(ss['QEss'], axis=(0,2,3,4,5)) + np.sum(ss['QUss'], axis=(0,2))

     wealth_dist_cumsum = np.cumsum(wealth_dist)

     # Lorenz curve for quintiles
     Lz = np.zeros(5)
     Lz[-1] = 1
     for i in range(4):
          loci, pi = utils.simple_interpolation((i + 1) / 5, wealth_dist_cumsum)
          wi = np.sum((wealth_dist * par['a_grid'])[:loci]) + (wealth_dist[loci + 1] * par['a_grid'][loci+1]) * (1 - pi)
          Lz[i] = wi / ss['A']

     Lz_model = np.append(0, Lz)

     # Lorenz_diff = np.sum((Lz_model - np.array([0, -0.0085767, -0.0024243, 0.0580123, 0.2195998, 1.0])) ** 2) ** (1 / 2)
     # Empirical Lorenz Curves
     # Lz_liquidassets = np.array([0, 0.0011, 0.012, 0.045, 0.14, 1])
     # Lz_networthexhousing = np.array([0, -0.058, -0.056, -0.034, 0.051, 1])
     Lz_networth = np.array([0, -0.0104, -0.0036, 0.0649, 0.247, 1])
     Lorenz_diff = np.sum((Lz_model - Lz_networth) ** 2) ** (1 / 2)
     # print(Lorenz_diff)
     return Lz_networth, Lz_model, Lorenz_diff