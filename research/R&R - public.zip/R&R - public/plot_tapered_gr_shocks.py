"""Identify and plot shocks for original data plus a cosine target taper."""

from pathlib import Path
import pickle
import sys

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt

import jacobian as jac
import main_result_GreatRecession as gr
from nonlinear_ge_adapted import TARGETS, UNKNOWNS, construct_linear_system


OUTPUT_DIRECTORY = Path("results_adapted") / "great_recession"
SOURCE_FILE = OUTPUT_DIRECTORY / "linear_target_fit.csv"
OUTPUT_DATA_FILE = OUTPUT_DIRECTORY / "identified_shocks_tapered_targets.csv"
OUTPUT_FIGURE_FILE = OUTPUT_DIRECTORY / "identified_shocks_tapered_targets.png"


def load_pickle(path):
    """Load NumPy 2 pickles in either the production or legacy Python env."""
    if "numpy._core" not in sys.modules:
        sys.modules["numpy._core"] = np.core
        sys.modules["numpy._core.multiarray"] = np.core.multiarray
        sys.modules["numpy._core.numeric"] = np.core.numeric
    with Path(path).open("rb") as file:
        return pickle.load(file)


def main():
    ss = load_pickle(gr.STEADY_STATE_FILE)
    jacobian_payload = load_pickle(gr.JACOBIAN_FILE)
    J = jacobian_payload["J"]
    par = gr.reconstruct_parameters(ss)

    source = np.genfromtxt(SOURCE_FILE, delimiter=",", names=True)
    earnings_observed = np.asarray(
        source["earnings_target_deviation"], dtype=np.float64
    )[:gr.OBSERVED_PERIODS]
    unemployment_observed = np.asarray(
        source["unemployment_target_deviation"], dtype=np.float64
    )[:gr.OBSERVED_PERIODS]
    earnings_target = gr.append_cosine_taper(earnings_observed)
    unemployment_target = gr.append_cosine_taper(unemployment_observed)

    system = construct_linear_system(ss, J, par, gr.TT)
    G = jac.get_G(
        system["linear_blocks"], list(gr.SHOCK_NAMES), UNKNOWNS, TARGETS,
        gr.TT, ss=ss, outputs=["earnings", "U"],
        H_U_factored=system["H_U_factored"],
    )
    identified = gr.identify_bounded_shocks(
        G, earnings_target, unemployment_target,
        ss.get("chi", 0.0), ss.get("drate", 0.0),
        shock_names=gr.SHOCK_NAMES,
        shock_steady_states={name: ss.get(name, 0.0) for name in gr.SHOCK_NAMES},
        shock_level_bounds={
            name: gr.SHOCK_LEVEL_BOUNDS[name] for name in gr.SHOCK_NAMES
        },
        smoothness_penalty=gr.IDENTIFICATION_SMOOTHNESS_PENALTY,
    )

    time = np.arange(gr.TT)
    columns = [time]
    header = ["time"]
    for name in gr.SHOCK_NAMES:
        columns.extend((identified["deviations"][name], identified["levels"][name]))
        header.extend((name + "_deviation", name + "_level"))
    np.savetxt(
        OUTPUT_DATA_FILE, np.column_stack(columns), delimiter=",",
        header=",".join(header), comments="",
    )

    figure, axes = plt.subplots(2, 1, figsize=(9, 7), sharex=True)
    colors = ("#1565c0", "#d32f2f")
    for axis, name, color in zip(axes, gr.SHOCK_NAMES, colors):
        axis.plot(
            time, identified["deviations"][name], color=color,
            marker="o", markersize=3.5, linewidth=2.0,
        )
        axis.axhline(0.0, color="black", linewidth=0.8)
        axis.axvline(
            gr.OBSERVED_PERIODS - 1, color="0.35", linestyle="--",
            linewidth=1.2, label="last observed target",
        )
        axis.axvspan(
            gr.OBSERVED_PERIODS - 1, gr.ACTIVE_PERIODS - 1,
            color="#1565c0", alpha=0.06, label="target taper",
        )
        axis.axvline(
            gr.ACTIVE_PERIODS - 1, color="0.35", linestyle=":",
            linewidth=1.2, label="zero-shock endpoint",
        )
        axis.set_ylabel(f"{name} deviation")
        axis.grid(alpha=0.22)
        axis.legend(frameon=False, ncol=3)
    axes[-1].set_xlabel("Model quarter")
    axes[-1].set_xlim(0, 40)
    figure.suptitle("Identified shocks: original targets plus 8-quarter taper")
    figure.tight_layout()
    figure.savefig(OUTPUT_FIGURE_FILE, dpi=180, bbox_inches="tight")
    plt.close(figure)

    diagnostics = identified["diagnostics"]
    print(f"condition_number={diagnostics['condition_number']:.6g}")
    print(f"earnings_RMSE={diagnostics['earnings_RMSE']:.6g}")
    print(f"unemployment_RMSE={diagnostics['unemployment_RMSE']:.6g}")
    for name in gr.SHOCK_NAMES:
        path = identified["deviations"][name]
        print(f"{name}_max_step={np.max(np.abs(np.diff(path))):.6g}")


if __name__ == "__main__":
    main()
