"""Plot lightly smoothed Great Recession targets against the originals."""

from pathlib import Path

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt


OUTPUT_DIRECTORY = Path("results_adapted") / "great_recession"
INPUT_FILE = OUTPUT_DIRECTORY / "linear_target_fit.csv"
OUTPUT_DATA_FILE = OUTPUT_DIRECTORY / "smoothed_empirical_targets.csv"
OUTPUT_FIGURE_FILE = OUTPUT_DIRECTORY / "smoothed_empirical_targets_with_taper.png"
TAPER_PERIODS = 8


def centered_three_quarter_average(values):
    """Average each interior observation with its two neighbors.

    The endpoints are retained so the period-0 steady-state normalization and
    the final observed target do not move merely because of edge handling.
    """
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 1 or values.size < 3:
        raise ValueError("target path must be one-dimensional with 3+ values")
    smoothed = values.copy()
    smoothed[1:-1] = (
        values[:-2] + values[1:-1] + values[2:]
    ) / 3.0
    return smoothed


def append_cosine_taper(values, taper_periods=TAPER_PERIODS):
    """Append a cosine-weighted path that reaches exactly zero."""
    step = np.arange(1, taper_periods + 1, dtype=np.float64)
    weights = 0.5 * (1.0 + np.cos(np.pi * step / taper_periods))
    weights[-1] = 0.0
    return np.concatenate((values, values[-1] * weights))


def main():
    data = np.genfromtxt(INPUT_FILE, delimiter=",", names=True)
    observed_quarter = np.asarray(data["time"], dtype=np.int64)
    earnings_original = np.asarray(
        data["earnings_percent_deviation_capped"], dtype=np.float64
    )
    unemployment_original = 100.0 * np.asarray(
        data["unemployment_target_deviation"], dtype=np.float64
    )

    earnings_smoothed = append_cosine_taper(earnings_original)
    unemployment_smoothed = append_cosine_taper(unemployment_original)
    quarter = np.arange(earnings_smoothed.size, dtype=np.int64)
    observed_count = observed_quarter.size
    earnings_original_extended = np.pad(
        earnings_original, (0, TAPER_PERIODS), constant_values=np.nan
    )
    unemployment_original_extended = np.pad(
        unemployment_original, (0, TAPER_PERIODS), constant_values=np.nan
    )

    output = np.column_stack((
        quarter,
        earnings_original_extended,
        earnings_smoothed,
        earnings_smoothed - earnings_original_extended,
        unemployment_original_extended,
        unemployment_smoothed,
        unemployment_smoothed - unemployment_original_extended,
    ))
    header = (
        "quarter,earnings_original_percent,earnings_smoothed_percent,"
        "earnings_smoothing_change_pp,unemployment_original_pp,"
        "unemployment_smoothed_pp,unemployment_smoothing_change_pp"
    )
    np.savetxt(
        OUTPUT_DATA_FILE, output, delimiter=",", header=header, comments="",
        fmt=["%d", "%.10g", "%.10g", "%.10g", "%.10g", "%.10g", "%.10g"],
    )

    figure, axes = plt.subplots(2, 1, figsize=(9, 7), sharex=True)
    series = (
        (
            axes[0], earnings_original_extended, earnings_smoothed,
            "Earnings", "Percent deviation from steady state",
        ),
        (
            axes[1], unemployment_original_extended, unemployment_smoothed,
            "Unemployment", "Percentage-point deviation from steady state",
        ),
    )
    for axis, original, smoothed, title, ylabel in series:
        axis.plot(
            quarter, original, color="0.45", linestyle="--", marker="o",
            markersize=4, linewidth=1.4, label="Original",
        )
        axis.plot(
            quarter, smoothed, color="#1565c0", linewidth=2.3,
            label="Original + cosine taper",
        )
        axis.axhline(0.0, color="black", linewidth=0.8)
        axis.axvspan(
            observed_count - 1, quarter[-1], color="#1565c0", alpha=0.06,
            label="8-quarter taper",
        )
        axis.set_title(title)
        axis.set_ylabel(ylabel)
        axis.grid(alpha=0.22)
        axis.legend(frameon=False, ncol=3)

    axes[1].set_xlabel("Quarter")
    figure.suptitle("Great Recession empirical targets: original and smoothed")
    figure.tight_layout()
    figure.savefig(OUTPUT_FIGURE_FILE, dpi=180, bbox_inches="tight")
    plt.close(figure)


if __name__ == "__main__":
    main()
