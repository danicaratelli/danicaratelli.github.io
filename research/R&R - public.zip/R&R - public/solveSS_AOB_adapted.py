import numpy as np
import utils
#import multiprocessing as mp
import HHhelp_AOB_adapted as HH
from concurrent.futures import ThreadPoolExecutor
from scipy.optimize import least_squares
import time
import wealth_lorenz


class SteadyStateConvergenceError(ValueError):
    def __init__(self, message, x, residuals, cache, diagnostics):
        super().__init__(message)
        self.x = np.asarray(x, dtype=float).copy()
        self.residuals = np.asarray(residuals, dtype=float).copy()
        self.cache = _clone_cache(cache)
        self.diagnostics = diagnostics


def _clone_cache(value):
    """Copy nested household caches so trial evaluations cannot mutate a base."""
    if isinstance(value, dict):
        return {key: _clone_cache(item) for key, item in value.items()}
    if isinstance(value, np.ndarray):
        return value.copy()
    return value


def _profile_add(profiler, key, dt):
    if profiler is None:
        return
    slot = profiler.setdefault(key, {'time': 0.0, 'calls': 0})
    slot['time'] += dt
    slot['calls'] += 1


def _format_profile_summary(profiler):
    if not profiler:
        return "No profile stats recorded."
    rows = sorted(profiler.items(), key=lambda kv: kv[1]['time'], reverse=True)
    out = ["Runtime profile summary (seconds, cumulative):"]
    for name, stats in rows:
        out.append(f"  - {name:20s}: {stats['time']:.3f}s over {stats['calls']} calls")
    return "\n".join(out)

def matching_fnc_1(thetas, par):
    """Computes vacancy, job-finding, vacancy-filling rates given tightness"""
    # thetas here must be vacancies / (total population on previous rung)
    thetas = np.asarray(thetas, dtype=float)
    if not np.all(np.isfinite(thetas)) or np.any(thetas <= 0):
        raise ValueError('Market tightness must be finite and strictly positive')
    # vacancy-filling rate
    qs = par['chi'] * thetas ** (-par['eta'])
    lambdas = thetas * qs                       # job-finding rate
    if not np.all(np.isfinite(qs)) or not np.all(np.isfinite(lambdas)):
        raise ValueError('Matching rates are non-finite')
    if np.any(lambdas >= 1):
        raise ValueError('Job-finding probabilities must be below one')
    return qs, lambdas

def matching_fnc_2(thetas, DUs, DEEs, par):
    """Computes total vacancies, total job searchers at each rung given job-finding and vacancy-posting rates"""
    # thetas here must be vacancies / (total population on previous rung)
    Utot = np.sum(DUs)
    Esearchers = np.sum(DEEs, axis=(0,1,2,3,4,6))
    searchers = par['gU'] * Utot + Esearchers
    vacancies = thetas * searchers

    return searchers, vacancies

def fiscal(tax, transfer, DEs, DUs, Z, rK, k_little, vacancies, par):
    """Computes residual from govt budget balance"""
    p_grid = par['p_grid']
    z_grid = par['z_grid']
    w_grid = par['w_grid']

    # firm vacancy cost and flow profits
    zeta_scale = (par['zeta'] * par['p_grid']) ** par['zeta_curv']
    v_cost = np.sum(vacancies * zeta_scale)  # aggregate vacancy cost
    effZ = z_grid[:, np.newaxis, np.newaxis, np.newaxis, np.newaxis, np.newaxis] * \
           p_grid[np.newaxis, np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]
    # compute flow profits
    pi_flow = (Z * effZ * (utils.f(k_little, par) - rK * k_little) -
               w_grid[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis, np.newaxis])
    pi_flow = np.sum(DEs * pi_flow) - v_cost

    tax_revenue = tax * np.sum(np.sum(DEs, axis=(0, 1, 3, 4, 5)) * w_grid)
    govt_expenditures = transfer + (1 - tax) * np.sum(np.sum(DUs, axis=(0,1)) * par['bUI'])

    return tax_revenue + pi_flow - govt_expenditures

def asset_mkt(DUs, DEs, Z, k_little, par):
    a_grid = par['a_grid']
    z_grid = par['z_grid']
    p_grid = par['p_grid']

    # asset supply (by HHs)
    assetS, _, _ = aggregate_pre_assets(DUs, DEs, a_grid)
    # value of the firm (= to total capital demanded by firms in SS)
    assetD = Z * np.sum(np.sum(DEs, axis=(1, 2, 4, 5)) * z_grid[:, np.newaxis] * p_grid[np.newaxis, :]) * k_little


    return assetS - assetD, assetD


def aggregate_pre_assets(DUs, DEs, a_grid):
    """Aggregate beginning-of-period assets for all, U, and E households."""
    unemployed_by_asset = np.sum(DUs, axis=(0, 2))
    employed_by_asset = np.sum(DEs, axis=(0, 2, 3, 4, 5))
    AU_pre = np.sum(unemployed_by_asset * a_grid)
    AE_pre = np.sum(employed_by_asset * a_grid)
    return AU_pre + AE_pre, AU_pre, AE_pre


def validate_ss_residuals(residuals, tol):
    """Reject non-finite or materially uncleared steady-state solutions."""
    residuals = np.asarray(residuals)
    max_residual = np.max(np.abs(residuals))
    if not np.all(np.isfinite(residuals)) or max_residual > tol:
        raise ValueError(
            f'Steady-state residual check failed: max |residual|={max_residual:.3e}, '
            f'tolerance={tol:.3e}'
        )
    return max_residual

def free_entry(JE0s, JU0s, DUEs, DEEs, qs, r, par, return_raw=False):
    """Computes residual from vacancy-filling condition"""
    entrant_mass = np.sum(DUEs)
    if not np.isfinite(entrant_mass) or entrant_mass <= 0:
        raise ValueError('Entrant distribution has zero or non-finite mass')
    Dentrants = DUEs / entrant_mass
    Dswitchers = np.sum(DEEs, axis=(0, 1, 2, 3, 4, 6))
    # expected value to vacant firms
    J0s_num = np.sum(JE0s * DEEs, axis=(0, 1, 2, 3, 4, 6))
    J0s = np.divide(J0s_num, Dswitchers, out=np.zeros_like(J0s_num), where=Dswitchers > 0)
    J0s += np.sum(JU0s * Dentrants, axis=(0, 1, 3))
    zeta_scale = (par['zeta'] * par['p_grid']) ** par['zeta_curv']
    vacancy_value = (qs * J0s) / (1 + r)
    raw_gap = vacancy_value - zeta_scale
    res_vacancy = np.arcsinh(raw_gap / zeta_scale)
    #v_cost = np.sum(vacancies * zeta_scale)  # aggregate vacancy cost
    #res_vacancy = (qs * J0s) / (1 + r) - (par['zeta'] * par['p_grid'])

    if return_raw:
        return res_vacancy, raw_gap
    return res_vacancy

def check_clearing(thetas, r, tax, Z, DUs, DEs, DUEs, DEEs, JE0s, JU0s,
                   par, transfer=0, return_diagnostics=False):
    # initialize residual
    res = np.zeros(2 + par['nP'])    # 2 if no profits to HH, 3 if profits to HH
    # compute labor market variables
    qs, lambdas = matching_fnc_1(thetas, par)
    searchers, vacancies = matching_fnc_2(thetas, DUs, DEEs, par)
    # compute capital per efficiency unit of labor
    rK = r + par['drate']            # rental rate of capital
    k_little = (rK / (par['alpha'] * Z)) ** (1 / (par['alpha'] - 1))    # capital per effective unit of labor
    effZ = par['z_grid'][:, np.newaxis, np.newaxis, np.newaxis, np.newaxis, np.newaxis] * \
           par['p_grid'][np.newaxis, np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]
    Y = np.sum(Z * effZ * utils.f(k_little, par) * DEs)
    # asset market
    asset_gap, K = asset_mkt(DUs, DEs, Z, k_little, par)
    res[0] = asset_gap / max(abs(K), 1.0)
    # fiscal policy
    fiscal_gap = fiscal(tax, transfer, DEs, DUs, Z, rK, k_little, vacancies, par)
    res[1] = fiscal_gap / max(abs(Y), 1.0)
    # free-entry at each rung
    res[2:], free_entry_gaps = free_entry(
        JE0s, JU0s, DUEs, DEEs, qs, r, par, return_raw=True)
    # Walras' Law
    # total efficiency units of labor
    N = np.sum(effZ * DEs)
    zeta_scale = (par['zeta'] * par['p_grid']) ** par['zeta_curv']
    vcost = np.sum(vacancies * zeta_scale)

    if return_diagnostics:
        return res, Y, K, vcost, N, {
            'asset_gap': float(asset_gap),
            'fiscal_gap': float(fiscal_gap),
            'free_entry_gaps': np.asarray(free_entry_gaps).copy(),
            'searchers': np.asarray(searchers).copy(),
            'vacancies': np.asarray(vacancies).copy(),
        }
    return res, Y, K, vcost, N


def _theta_bounds(par):
    theta_min = par.get('ss_theta_min', 0.005)
    lambda_max = par.get('ss_lambda_max', 1 - 1e-8)
    theta_probability_max = (lambda_max / par['chi']) ** (1 / (1 - par['eta']))
    theta_max = min(par.get('ss_theta_max', 100.0), theta_probability_max)
    if not 0 < theta_min < theta_max:
        raise ValueError(
            f'Invalid tightness bounds: theta_min={theta_min}, theta_max={theta_max}'
        )
    return theta_min, theta_max

def _r_bounds(par):
    return par.get('ss_r_min', 0.001), par.get('ss_r_max', 0.01)

def _tax_bounds(par):
    return par.get('ss_tax_min', -0.7), par.get('ss_tax_max', 0.3)

def _theta_from_x(x_theta, theta_min, theta_max):
    return utils.bound_map(x_theta, theta_min, theta_max)

def _x_from_theta(theta, theta_min, theta_max):
    theta = np.clip(theta, theta_min + 1e-10, theta_max - 1e-10)
    return utils.bound_map_inv(theta, theta_min, theta_max)

def _ss_x_from_guess(xguess, par):
    x0 = np.zeros(2 + par['nP'])
    r_min, r_max = _r_bounds(par)
    tax_min, tax_max = _tax_bounds(par)
    x0[0] = utils.bound_map_inv(xguess[0], r_min, r_max)
    x0[1] = utils.bound_map_inv(xguess[1], tax_min, tax_max)
    theta_min, theta_max = _theta_bounds(par)
    x0[2:] = _x_from_theta(xguess[2:], theta_min, theta_max)
    return x0

def _ss_values_from_x(x, par):
    r_min, r_max = _r_bounds(par)
    tax_min, tax_max = _tax_bounds(par)
    r = utils.bound_map(x[0], r_min, r_max)
    tax = utils.bound_map(x[1], tax_min, tax_max)
    theta_min, theta_max = _theta_bounds(par)
    thetas = _theta_from_x(x[2:], theta_min, theta_max)
    if not np.all(np.isfinite(thetas)):
        raise ValueError('Non-finite market tightness')
    return r, tax, thetas

def _ss_hh_tolerances(par, resid_scale=np.inf):
    schedule = par.get('ss_hh_tol_schedule', (
        (1e-3, 1e-7, 1e-9),
        (1e-2, 1e-6, 1e-8),
        (np.inf, 1e-5, 1e-7),
    ))
    for threshold, bellman_tol, dist_tol in schedule:
        if resid_scale <= threshold:
            return bellman_tol, dist_tol
    return schedule[-1][1], schedule[-1][2]

def _ss_jacobian_steps(par, x):
    configured = par.get('ss_jac_abs_step', 3e-4)
    steps = np.broadcast_to(np.asarray(configured, dtype=float), np.shape(x)).copy()
    if np.any(~np.isfinite(steps)) or np.any(steps <= 0):
        raise ValueError('ss_jac_abs_step must contain finite positive values')
    return steps


def _finite_difference_ss_jacobian(x, y, Z, par, smm_index, base_cache,
                                   profiler=None, resid_scale=0.0):
    """Forward-difference Jacobian with isolated, common-cache columns."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    steps = _ss_jacobian_steps(par, x)
    jacobian = np.empty((y.size, x.size))
    for index, step in enumerate(steps):
        perturbed = x.copy()
        perturbed[index] += step
        y_perturbed, _ = _evaluate_ss_residual(
            perturbed, Z, par, smm_index,
            warm_cache=_clone_cache(base_cache),
            profiler=profiler,
            resid_scale=resid_scale,
        )
        jacobian[:, index] = (y_perturbed - y) / step
    if not np.all(np.isfinite(jacobian)):
        raise ValueError('Non-finite steady-state Jacobian')
    return jacobian

def _evaluate_ss_residual(x, Z, par, smm_index, warm_cache=None, profiler=None, return_diagnostics=False,
                          resid_scale=np.inf):
    nZ = par['nZ']
    nP = par['nP']
    nW = par['nW']
    nA = par['nA']
    nT = par['nT']
    nB = par['nB']
    ibs = [0, 2]
    hh_cache = ({ib: None for ib in ibs} if warm_cache is None
                else _clone_cache(warm_cache))

    JU0s = np.zeros((nZ, nA, nP, nB))
    JE0s = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))
    DUs = np.zeros((nZ, nA, nB))
    DEs = np.zeros((nZ, nA, nW, nP, nT, nB))
    DUEs = np.zeros((nZ, nA, nP, nB))
    DEEs = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))

    r, tax, thetas = _ss_values_from_x(x, par)
    qs, lambdas = matching_fnc_1(thetas, par)
    bellman_tol, dist_tol = _ss_hh_tolerances(par, resid_scale)

    diagnostics = {
        'r': r,
        'tax': tax,
        'thetas': thetas.copy(),
        'x': np.asarray(x, dtype=float).copy(),
        'bellman_tol': bellman_tol,
        'dist_tol': dist_tol,
        'policies': {},
        'households': {},
    }
    max_workers = min(len(ibs), par.get('ss_hh_workers', len(ibs)))
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        def _solve_ib(ib):
            return HH.solveHH(
                (r, tax, Z, par, lambdas, ib, smm_index),
                warm_start=hh_cache[ib],
                profiler=profiler,
                bellman_tol=bellman_tol,
                dist_tol=dist_tol,
            )
        results = list(executor.map(_solve_ib, ibs))

    for ib, result in enumerate(results):
        U, E, E_bargaining, dU, dE, dE_bargaining, cU, cE, J, J_bargaining, JU0, JE0, DU, DE, DUE, DEE, qswitch, w_i, w_pi, Inew, warm_state = result
        ib_key = ibs[ib]
        required_outputs = {
            'cU': cU, 'cE': cE, 'JU0': JU0, 'JE0': JE0,
            'DU': DU, 'DE': DE, 'DUE': DUE, 'DEE': DEE,
        }
        invalid_outputs = [
            name for name, value in required_outputs.items()
            if not np.all(np.isfinite(value))
        ]
        if invalid_outputs:
            raise ValueError(
                f'Household solve returned non-finite values for beta index '
                f'{ib_key}: {", ".join(invalid_outputs)}'
            )
        if np.any(cU <= 0) or np.any(cE <= 0):
            raise ValueError(
                f'Household solve returned non-positive consumption for beta index {ib_key}'
            )
        hh_cache[ib_key] = warm_state

        JU0s[:, :, :, ib] = JU0
        JE0s[:, :, :, :, :, :, ib] = JE0
        DUs[:, :, ib] = DU / nB
        DEs[:, :, :, :, :, ib] = DE / nB
        DUEs[:, :, :, ib] = DUE / nB
        DEEs[:, :, :, :, :, :, ib] = DEE / nB

        if return_diagnostics:
            diagnostics['policies'][ib_key] = {
                'w_i': _clone_cache(w_i),
                'w_pi': _clone_cache(w_pi),
                'Inew': np.asarray(Inew).copy(),
                'qswitch': np.asarray(qswitch).copy(),
            }
            if par.get('ss_diagnostic_arrays', False):
                diagnostics['policies'][ib_key].update({
                    'DEE': np.asarray(DEE).copy(),
                    'DE': np.asarray(DE).copy(),
                })
            diagnostics['households'][ib_key] = _clone_cache(
                warm_state.get('diagnostics', {}))

    xres, Y, K, vcost, N, clearing = check_clearing(
        thetas, r, tax, Z, DUs, DEs, DUEs, DEEs, JE0s, JU0s, par,
        return_diagnostics=True)
    diagnostics.update({
        'Y': Y,
        'K': K,
        'vcost': vcost,
        'N': N,
        'residuals': xres.copy(),
        'max_abs_residual': float(np.max(np.abs(xres))),
        'raw_clearing': clearing,
    })
    if return_diagnostics:
        return xres, hh_cache, diagnostics
    return xres, hh_cache

def diagnose_SS_smoothness(xguess, Z, par, smm_index,
                           steps=(1e-3, 3e-4, 1e-4), variables=None):
    """Local plus/minus residual diagnostic around the SS guess."""
    x0 = _ss_x_from_guess(xguess, par)
    names = ['r', 'tax'] + [f'theta[{i}]' for i in range(par['nP'])]
    if variables is None:
        variables = range(len(x0))

    profiler = {}
    t0 = time.perf_counter()
    y0, base_cache, base_diag = _evaluate_ss_residual(
        x0, Z, par, smm_index, profiler=profiler, return_diagnostics=True,
        resid_scale=0.0,
    )
    base_time = time.perf_counter() - t0
    rows = []

    for i in variables:
        for h in steps:
            row = {'variable': names[i], 'index': i, 'h': h}
            evals = {}
            diags = {}
            for side, sign in [('-', -1.0), ('+', 1.0)]:
                xh = x0.copy()
                xh[i] += sign * h
                t_eval = time.perf_counter()
                yh, _, diag_h = _evaluate_ss_residual(
                    xh, Z, par, smm_index,
                    warm_cache=_clone_cache(base_cache),
                    profiler=profiler,
                    return_diagnostics=True,
                    resid_scale=0.0,
                )
                evals[side] = yh
                diags[side] = diag_h
                row[f'time_{side}'] = time.perf_counter() - t_eval

            fwd = (evals['+'] - y0) / h
            bwd = (y0 - evals['-']) / h
            denom = max(np.linalg.norm(fwd), np.linalg.norm(bwd), 1e-12)
            row['base_max_abs_resid'] = np.max(np.abs(y0))
            row['plus_max_abs_resid'] = np.max(np.abs(evals['+']))
            row['minus_max_abs_resid'] = np.max(np.abs(evals['-']))
            row['slope_asymmetry'] = np.linalg.norm(fwd - bwd) / denom
            row['slope_norm_fwd'] = np.linalg.norm(fwd)
            row['slope_norm_bwd'] = np.linalg.norm(bwd)
            row['max_abs_jump'] = max(np.max(np.abs(evals['+'] - y0)), np.max(np.abs(evals['-'] - y0)))
            row['base_residual'] = y0.copy()
            row['plus_residual'] = evals['+'].copy()
            row['minus_residual'] = evals['-'].copy()
            row['forward_slope'] = fwd
            row['backward_slope'] = bwd
            physical_minus = np.array([
                diags['-']['r'], diags['-']['tax'],
                *diags['-']['thetas'],
            ])
            physical_base = np.array([
                base_diag['r'], base_diag['tax'], *base_diag['thetas'],
            ])
            physical_plus = np.array([
                diags['+']['r'], diags['+']['tax'],
                *diags['+']['thetas'],
            ])
            row['physical_delta_minus'] = physical_minus - physical_base
            row['physical_delta_plus'] = physical_plus - physical_base

            for policy_name in ['Inew', 'qswitch']:
                changes = []
                for side in ['-', '+']:
                    for ib in base_diag['policies']:
                        base_pol = base_diag['policies'][ib][policy_name]
                        pol_h = diags[side]['policies'][ib][policy_name]
                        changes.append(np.mean(base_pol != pol_h))
                row[f'{policy_name}_change_rate'] = float(np.mean(changes))
            wage_index_changes = []
            wage_level_changes = []
            for side in ['-', '+']:
                for ib in base_diag['policies']:
                    for wage_key in ['U', 'Ewin', 'Elose']:
                        base_i = base_diag['policies'][ib]['w_i'][wage_key]
                        base_pi = base_diag['policies'][ib]['w_pi'][wage_key]
                        side_i = diags[side]['policies'][ib]['w_i'][wage_key]
                        side_pi = diags[side]['policies'][ib]['w_pi'][wage_key]
                        wage_index_changes.append(np.mean(base_i != side_i))
                        base_hi = np.minimum(base_i + 1, par['nW'] - 1)
                        side_hi = np.minimum(side_i + 1, par['nW'] - 1)
                        base_wage = (
                            base_pi * par['w_grid'][base_i]
                            + (1 - base_pi) * par['w_grid'][base_hi])
                        side_wage = (
                            side_pi * par['w_grid'][side_i]
                            + (1 - side_pi) * par['w_grid'][side_hi])
                        wage_level_changes.append(
                            np.mean(np.abs(side_wage - base_wage)))
            row['w_i_change_rate'] = float(np.mean(wage_index_changes))
            row['mean_abs_reconstructed_wage_change'] = float(
                np.mean(wage_level_changes))
            rows.append(row)

    return {
        'x0': x0,
        'base_residual': y0,
        'base_time': base_time,
        'rows': rows,
        'profile': profiler,
    }

def _clip_ss_guess(xguess, par):
    xguess = np.asarray(xguess, dtype=float).copy()
    eps = 1e-10
    xguess[0] = np.clip(xguess[0], 0.001 + eps, 0.01 - eps)
    xguess[1] = np.clip(xguess[1], -0.7 + eps, 0.3 - eps)
    theta_min, theta_max = _theta_bounds(par)
    xguess[2:] = np.clip(
        xguess[2:],
        theta_min + eps,
        theta_max - eps,
    )
    return xguess

def _initial_guess_candidates(xguess, par):
    xguess = _clip_ss_guess(xguess, par)
    candidates = [('baseline', xguess)]

    def add_candidate(name, r_scale=1.0, tax_shift=0.0, theta_slice=None, theta_scale=1.0):
        cand = xguess.copy()
        cand[0] *= r_scale
        cand[1] += tax_shift
        if theta_slice is None:
            cand[2:] *= theta_scale
        else:
            cand[2:][theta_slice] *= theta_scale
        candidates.append((name, _clip_ss_guess(cand, par)))

    add_candidate('r * 0.8', r_scale=0.8)
    add_candidate('r * 1.2', r_scale=1.2)
    add_candidate('tax - 0.05', tax_shift=-0.05)
    add_candidate('tax + 0.05', tax_shift=0.05)
    add_candidate('theta all * 0.75', theta_scale=0.75)
    add_candidate('theta all * 1.25', theta_scale=1.25)
    add_candidate('theta[0] * 0.5', theta_slice=slice(0, 1), theta_scale=0.75)
    add_candidate('theta[0] * 2.0', theta_slice=slice(0, 1), theta_scale=1.25)

    mid_stop = min(5, par['nP'])
    if mid_stop > 1:
        add_candidate('theta[1:5] * 0.7', theta_slice=slice(1, mid_stop), theta_scale=0.7)
        add_candidate('theta[1:5] * 1.4', theta_slice=slice(1, mid_stop), theta_scale=1.4)
    if par['nP'] > 5:
        add_candidate('theta[5:] * 0.7', theta_slice=slice(5, par['nP']), theta_scale=0.7)
        add_candidate('theta[5:] * 1.4', theta_slice=slice(5, par['nP']), theta_scale=1.4)

    return candidates

def _find_initial_ss_guess(xguess, Z, par, smm_index, profiler=None):
    verbose = par.get('verbose_ss', False)
    if verbose:
        print('Starting initial guess search...')
    candidates = _initial_guess_candidates(xguess, par)
    max_candidates = par.get('ss_initial_search_max_candidates', 1)
    search_threshold = par.get('ss_initial_search_skip_threshold', 0.1)
    resid_scale = par.get('ss_initial_search_resid_scale', np.inf)
    ibs = [0, 2]
    search_cache = {ib: None for ib in ibs}

    best_name = None
    best_x = None
    best_score = np.inf
    best_resid = None
    n_evals = 0

    for i, (name, cand_guess) in enumerate(candidates[:max_candidates]):
        try:
            x = _ss_x_from_guess(cand_guess, par)
            xres, search_cache = _evaluate_ss_residual(
                x, Z, par, smm_index,
                warm_cache=search_cache,
                profiler=profiler,
                resid_scale=resid_scale,
            )
            score = np.max(np.abs(xres))
            n_evals += 1
            if verbose:
                print(f'Initial guess candidate {i}: {name}, max residual = {score}')
        except (FloatingPointError, ValueError, OverflowError) as err:
            if verbose:
                print(f'Initial guess candidate {i}: {name}, failed with {err}')
            continue

        if np.isfinite(score) and score < best_score:
            best_name = name
            best_x = x
            best_score = score
            best_resid = xres

        if np.isfinite(score) and score <= search_threshold:
            if verbose:
                print('Initial guess candidate is good enough; stopping perturbation search.')
            break

    if best_x is None:
        if verbose:
            print('Initial guess search found no usable candidate; using the original guess.')
        return _ss_x_from_guess(xguess, par), None, np.inf, search_cache

    if verbose:
        print(f'Initial guess search complete after {n_evals} evaluations.')
        print(f'Best initial guess candidate: {best_name}, max residual = {best_score}')
        print('Best initial guess residual = ', best_resid)
    return best_x, best_resid, best_score, search_cache

def SS(xguess, Z, par, smm_index, tol=1e-6, _return_cache=False,
       _initial_hh_cache=None, return_diagnostics=False):
    # extract useful parameters
    nP = par['nP']

    ibs = [0, 2]
    profile_enabled = par.get('profile_ss', False)
    profiler = {} if profile_enabled else None
    # Experimental hook: retain the public defaults while allowing a shadow
    # steady-state run to start from stored/adapted household solutions.
    hh_cache = ({ib: None for ib in ibs} if _initial_hh_cache is None
                else _clone_cache(_initial_hh_cache))

    last_resid_scale = np.inf
    force_tight_hh = False
    best_x = None
    best_y = None
    best_score = np.inf
    best_tight_x = None
    best_tight_y = None
    best_tight_score = np.inf
    best_cache = None
    best_tight_cache = None
    last_eval_x = None
    last_eval_cache = None
    solver_diagnostics = {
        'jac_init_requested': par.get('jac_init'),
        'jac_init_used': 'numerical_absolute_step',
        'jacobian_steps': _ss_jacobian_steps(
            par, np.zeros(2 + nP)).tolist(),
        'accepted_steps': 0,
        'rejected_steps': 0,
        'jacobian_refreshes': 0,
        'stages': [],
        'step_history': [],
    }

    def _record_best(x, y, cache):
        nonlocal best_x, best_y, best_score, best_cache
        nonlocal best_tight_x, best_tight_y, best_tight_score, best_tight_cache
        score = np.max(np.abs(y))
        if np.isfinite(score) and score < best_score:
            best_x = np.asarray(x, dtype=float).copy()
            best_y = np.asarray(y, dtype=float).copy()
            best_score = score
            best_cache = _clone_cache(cache)
        if force_tight_hh and np.isfinite(score) and score < best_tight_score:
            best_tight_x = np.asarray(x, dtype=float).copy()
            best_tight_y = np.asarray(y, dtype=float).copy()
            best_tight_score = score
            best_tight_cache = _clone_cache(cache)

    def obj_fun(x):
        nonlocal last_resid_scale, last_eval_x, last_eval_cache
        t_obj = time.perf_counter()
        resid_scale_for_tols = 0.0 if force_tight_hh else last_resid_scale
        hh_tolerances = _ss_hh_tolerances(par, resid_scale_for_tols)
        xres, evaluated_cache = _evaluate_ss_residual(
            x, Z, par, smm_index,
            warm_cache=_clone_cache(hh_cache),
            profiler=profiler,
            resid_scale=resid_scale_for_tols,
        )
        last_eval_x = np.asarray(x, dtype=float).copy()
        last_eval_cache = _clone_cache(evaluated_cache)
        last_resid_scale = np.max(np.abs(xres))
        _record_best(x, xres, evaluated_cache)
        if par.get('verbose_ss', False):
            print('obj residual = ', xres)
            print('HH tolerances = ', hh_tolerances)
        _profile_add(profiler, 'SS.obj_fun', time.perf_counter() - t_obj)
        return xres

    def _run_broyden_stage(stage_name, x_start, y_start, stage_tol, maxcount, tight_hh):
        nonlocal force_tight_hh, last_resid_scale, hh_cache
        force_tight_hh = tight_hh
        last_resid_scale = 0.0 if tight_hh else (
            np.max(np.abs(y_start)) if y_start is not None else np.inf)
        y_start, hh_cache = _evaluate_ss_residual(
            x_start, Z, par, smm_index,
            warm_cache=_clone_cache(hh_cache),
            profiler=profiler,
            resid_scale=0.0 if tight_hh else last_resid_scale,
        )
        last_resid_scale = np.max(np.abs(y_start))
        _record_best(x_start, y_start, hh_cache)

        def jacobian(x, y):
            nonlocal last_eval_x, last_eval_cache
            if last_eval_x is not None and np.array_equal(x, last_eval_x):
                base_cache = last_eval_cache
            else:
                y, base_cache = _evaluate_ss_residual(
                    x, Z, par, smm_index,
                    warm_cache=_clone_cache(hh_cache),
                    profiler=profiler,
                    resid_scale=0.0 if tight_hh else last_resid_scale,
                )
            return _finite_difference_ss_jacobian(
                x, y, Z, par, smm_index, base_cache,
                profiler=profiler,
                resid_scale=0.0 if tight_hh else last_resid_scale,
            )

        def event_callback(event, x_event, y_event):
            solver_diagnostics['jacobian_refreshes'] += 1
            if event == 'accepted_step':
                solver_diagnostics['accepted_steps'] += 1
            elif event == 'rejected_step':
                solver_diagnostics['rejected_steps'] += 1
            elif event == 'jacobian_refresh':
                solver_diagnostics['jacobian_refreshes'] += 1
            if len(solver_diagnostics['step_history']) < 500:
                solver_diagnostics['step_history'].append({
                    'stage': stage_name,
                    'event': event,
                    'x': np.asarray(x_event, dtype=float).copy(),
                    'max_abs_residual': (
                        None if y_event is None
                        else float(np.max(np.abs(y_event)))),
                })

        if par.get('verbose_ss', False):
            print(f'Starting {stage_name}: tol = {stage_tol}, tight HH = {tight_hh}')
        stage_record = {
            'name': stage_name,
            'start_max_abs_residual': float(np.max(np.abs(y_start))),
            'tight_household': bool(tight_hh),
        }
        try:
            x_result, y_result = utils.broyden_solver(
                obj_fun, x_start, y0=y_start, tol=stage_tol,
                maxcount=maxcount,
                backtrack_c=par.get('ss_broyden_backtrack_c', 0.5),
                noisy=False,
                require_improvement=True,
                improvement_tol=0.0,
                max_backtracks=par.get('ss_broyden_max_backtracks', 10),
                jacobian=jacobian,
                refresh_interval=par.get('ss_broyden_refresh_interval', 8),
                min_step_norm=par.get('ss_broyden_min_step_norm', 1e-12),
                event_callback=event_callback,
                minimum_decrease=par.get(
                    'ss_broyden_minimum_decrease', 0.0),
            )
            y_result, hh_cache = _evaluate_ss_residual(
                x_result, Z, par, smm_index,
                warm_cache=_clone_cache(
                    last_eval_cache if last_eval_cache is not None else hh_cache),
                profiler=profiler,
                resid_scale=0.0 if tight_hh else np.max(np.abs(y_result)),
            )
            _record_best(x_result, y_result, hh_cache)
            stage_record['termination'] = 'converged'
            stage_record['end_max_abs_residual'] = float(
                np.max(np.abs(y_result)))
            return x_result, y_result
        except (ValueError, np.linalg.LinAlgError) as err:
            stage_record['termination'] = f'{type(err).__name__}: {err}'
            raise
        finally:
            solver_diagnostics['stages'].append(stage_record)

    def _run_least_squares_fallback(x_start):
        nonlocal force_tight_hh, hh_cache, last_eval_x, last_eval_cache
        force_tight_hh = True
        method = par.get('ss_least_squares_method', 'trf')
        max_nfev = par.get('ss_least_squares_max_nfev', 40)

        def ls_obj_fun(x):
            y = obj_fun(x)
            if not np.all(np.isfinite(y)):
                raise ValueError('Non-finite residual in least-squares fallback')
            return y

        def ls_jacobian(x):
            nonlocal last_eval_x, last_eval_cache
            if last_eval_x is not None and np.array_equal(x, last_eval_x):
                y_base = ls_obj_fun(x)
                base_cache = last_eval_cache
            else:
                y_base = ls_obj_fun(x)
                base_cache = last_eval_cache
            solver_diagnostics['jacobian_refreshes'] += 1
            return _finite_difference_ss_jacobian(
                x, y_base, Z, par, smm_index, base_cache,
                profiler=profiler, resid_scale=0.0)

        if par.get('verbose_ss', False):
            print(f'Starting least-squares fallback: method = {method}, max_nfev = {max_nfev}')
        result = least_squares(
            ls_obj_fun, x_start,
            jac=ls_jacobian,
            method=method,
            max_nfev=max_nfev,
            xtol=par.get('ss_least_squares_xtol', 1e-8),
            ftol=par.get('ss_least_squares_ftol', 1e-8),
            gtol=par.get('ss_least_squares_gtol', 1e-8),
            x_scale=par.get('ss_least_squares_x_scale', 'jac'),
        )
        y_result = np.asarray(result.fun)
        y_result, result_cache = _evaluate_ss_residual(
            result.x, Z, par, smm_index,
            warm_cache=_clone_cache(
                last_eval_cache if last_eval_cache is not None else hh_cache),
            profiler=profiler, resid_scale=0.0)
        _record_best(result.x, y_result, result_cache)
        hh_cache = result_cache
        solver_diagnostics['stages'].append({
            'name': 'least_squares',
            'termination': result.message,
            'status': int(result.status),
            'nfev': int(result.nfev),
            'njev': int(result.njev) if result.njev is not None else None,
            'end_max_abs_residual': float(np.max(np.abs(y_result))),
        })
        if par.get('verbose_ss', False):
            print('Least-squares fallback status = ', result.status, result.message)
            print('Least-squares fallback residual = ', y_result)
        return result.x, y_result

    # Bounds for tightness also keep implied job-finding probabilities below one.
    assert par['chi'] < 1, 'parameter chi in matching function must be < 1'
    x0 = _ss_x_from_guess(xguess, par)
    y0 = None

    if par.get('ss_initial_search', True):
        x0, y0, _, hh_cache = _find_initial_ss_guess(xguess, Z, par, smm_index, profiler=profiler)
        if y0 is not None:
            last_resid_scale = np.max(np.abs(y0))
            _record_best(x0, y0, hh_cache)

    if par.get('verbose_ss', False):
        print('Starting true steady-state solver...')

    xstar, ystar = x0, y0
    coarse_tol = par.get('ss_coarse_tol', 1e-3)
    use_staged_solve = par.get('ss_staged_solve', True) and tol < coarse_tol
    try:
        if use_staged_solve:
            xstar, ystar = _run_broyden_stage(
                'coarse Broyden stage', xstar, ystar, coarse_tol,
                par.get('ss_coarse_maxcount', 60), tight_hh=False
            )

        if par.get('ss_final_tight_check', True):
            force_tight_hh = True
            ystar = obj_fun(xstar)
        elif ystar is None:
            ystar = obj_fun(xstar)

        if np.max(np.abs(ystar)) > tol:
            xstar, ystar = _run_broyden_stage(
                'tight Broyden restart', xstar, ystar, tol,
                par.get('ss_tight_maxcount', 60), tight_hh=True
            )
    except (ValueError, np.linalg.LinAlgError) as err:
        if not par.get('ss_least_squares_fallback', True):
            raise
        if par.get('verbose_ss', False):
            print(f'Broyden stage failed with: {err}')
            if best_tight_y is not None:
                print('Best tight residual before fallback = ', best_tight_y)
            elif best_y is not None:
                print('Best residual before fallback = ', best_y)
        x_fallback = best_tight_x if best_tight_x is not None else (best_x if best_x is not None else xstar)
        xstar, ystar = _run_least_squares_fallback(x_fallback)

    if np.max(np.abs(ystar)) > tol and par.get('ss_least_squares_fallback', True):
        xstar, ystar = _run_least_squares_fallback(xstar)

    final_score = np.max(np.abs(ystar))
    if final_score > tol:
        if best_tight_x is not None and best_tight_score < final_score:
            xstar = best_tight_x.copy()
            ystar, hh_cache = _evaluate_ss_residual(
                xstar, Z, par, smm_index,
                warm_cache=_clone_cache(best_tight_cache),
                profiler=profiler, resid_scale=0.0)
            final_score = np.max(np.abs(ystar))
        if profile_enabled:
            print(_format_profile_summary(profiler))
        solver_diagnostics.update({
            'termination': 'residual_tolerance_not_met',
            'best_residuals': np.asarray(ystar).copy(),
            'best_max_abs_residual': float(final_score),
            'profile': profiler,
        })
        raise SteadyStateConvergenceError(
            f'Steady-state solver did not reach tol={tol}. '
            f'Best max residual = {final_score}',
            xstar, ystar, hh_cache, solver_diagnostics)

    # extract ss variables
    r_min, r_max = _r_bounds(par)
    tax_min, tax_max = _tax_bounds(par)
    r_ss = utils.bound_map(xstar[0], r_min, r_max)
    tax_ss = utils.bound_map(xstar[1], tax_min, tax_max)
    theta_min, theta_max = _theta_bounds(par)
    thetas_ss = _theta_from_x(xstar[2:], theta_min, theta_max)

    # Re-solve at the accepted prices so the in-memory household cache does not
    # correspond to the last Broyden trial point.
    final_residual, hh_cache, final_diagnostics = _evaluate_ss_residual(
        xstar, Z, par, smm_index,
        warm_cache=_clone_cache(hh_cache),
        profiler=profiler,
        resid_scale=0.0,
        return_diagnostics=True,
    )
    validate_ss_residuals(final_residual, tol)
    solver_diagnostics.update({
        'termination': 'residual_tolerance',
        'final_residuals': final_residual.copy(),
        'final_max_abs_residual': float(np.max(np.abs(final_residual))),
        'final_evaluation': {
            key: value for key, value in final_diagnostics.items()
            if key != 'policies'
        },
        'profile': profiler,
    })

    if profile_enabled:
        print(_format_profile_summary(profiler))

    if _return_cache and return_diagnostics:
        return r_ss, tax_ss, thetas_ss, hh_cache, solver_diagnostics
    if _return_cache:
        return r_ss, tax_ss, thetas_ss, hh_cache
    if return_diagnostics:
        return r_ss, tax_ss, thetas_ss, solver_diagnostics
    return r_ss, tax_ss, thetas_ss

def getSS(r_ss, tax_ss, thetas_ss, Z, par, smm_index, transfer=0, warm_cache=None):
    # extract useful parameters
    nZ = par['nZ']
    nP = par['nP']
    nW = par['nW']
    nA = par['nA']
    nT = par['nT']
    nB = par['nB']
    M = par['M']
    a_grid = par['a_grid']
    w_grid = par['w_grid']
    warm_cache = {} if warm_cache is None else warm_cache

    # initialize policy and value functions, and distribution matrices
    Us = np.zeros((nZ, nA, nB))
    dUs = np.zeros((nZ, nA, nB))
    cUs = np.zeros((nZ, nA, nB))
    Es = np.zeros((nZ, nA, nW, nP, nT, nB))
    Ebargainings = np.zeros((nZ, nA, nW, nP, M, nB))
    dEs = np.zeros((nZ, nA, nW, nP, nT, nB))
    dEbargainings = np.zeros((nZ, nA, nW, nP, M, nB))
    cEs = np.zeros((nZ, nA, nW, nP, nT, nB))
    Js = np.zeros((nZ, nA, nW, nP, nT, nB))
    Jbargainings = np.zeros((nZ, nA, nW, nP, M, nB))
    JU0s = np.zeros((nZ, nA, nP, nB))
    JE0s = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))
    DUs = np.zeros((nZ, nA, nB))
    DEs = np.zeros((nZ, nA, nW, nP, nT, nB))
    DUEs = np.zeros((nZ, nA, nP, nB))
    DEEs = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))
    qswitchs = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))
    Iwin = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))

    # wage policies
    WU_is = np.zeros((nZ, nA, nP, nB), dtype='uint32')
    WU_pis = np.zeros((nZ, nA, nP, nB))
    WEwin_is = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB), dtype='uint32')
    WEwin_pis = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))
    WElose_is = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB), dtype='uint32')
    WElose_pis = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))

    # vacancy posting and job-finding rates
    qs, lambdas = matching_fnc_1(thetas_ss, par)

    beta0 = par['beta']
    # loop over betas
    for ib in np.array([0, 2]):
        par['beta'] = beta0
        # solve iteration
        U, E, E_bargaining, dU, dE, dE_bargaining, cU, cE, J, J_bargaining, \
        JU0, JE0, DU, DE, DUE, DEE, qswitch, w_i, w_pi, Inew, _ = HH.solveHH(
            (r_ss, tax_ss, Z, par, lambdas, ib, smm_index),
            warm_start=warm_cache.get(ib),
            bellman_tol=1e-7,
            dist_tol=1e-9,
        )
        bi = int(ib/2)
        # record in larger beta-matrix
        Us[:, :, bi] = U
        dUs[:, :, bi] = dU
        cUs[:, :, bi] = cU
        Es[:, :, :, :, :, bi] = E
        Ebargainings[:, :, :, :, :, bi] = E_bargaining
        dEs[:, :, :, :, :, bi] = dE
        dEbargainings[:, :, :, :, :, bi] = dE_bargaining
        cEs[:, :, :, :, :, bi] = cE
        Js[:, :, :, :, :, bi] = J
        Jbargainings[:, :, :, :, :, bi] = J_bargaining
        JU0s[:, :, :, bi] = JU0
        JE0s[:, :, :, :, :, :, bi] = JE0
        # record distribution
        DUs[:, :, bi] = DU / nB
        DEs[:, :, :, :, :, bi] = DE / nB
        DUEs[:, :, :, bi] = DUE / nB
        DEEs[:, :, :, :, :, :, bi] = DEE / nB
        # record wages
        WU_is[:, :, :, bi] = w_i['U']
        WU_pis[:, :, :, bi] = w_pi['U']
        WEwin_is[:, :, :, :, :, :, bi] = w_i['Ewin']
        WEwin_pis[:, :, :, :, :, :, bi] = w_pi['Ewin']
        WElose_is[:, :, :, :, :, :, bi] = w_i['Elose']
        WElose_pis[:, :, :, :, :, :, bi] = w_pi['Elose']
        # record pr. of switching
        qswitchs[:, :, :, :, :, :, bi] = qswitch
        Iwin[:, :, :, :, :, :, bi] = Inew

    # Compute assets
    aUs = (1 + r_ss) * a_grid[np.newaxis, :, np.newaxis] + transfer + (1 - tax_ss) * par['bUI'][np.newaxis, np.newaxis, :] - cUs
    aEs = (1 + r_ss) * a_grid[np.newaxis, :, np.newaxis, np.newaxis, np.newaxis, np.newaxis] + transfer + \
          (1 - tax_ss) * w_grid[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis, np.newaxis] - cEs

    # Derive aggregates
    xres, Y, K, vcost, N = check_clearing(thetas_ss, r_ss, tax_ss, Z, DUs, DEs, DUEs, DEEs, JE0s, JU0s, par)
    print('residual = ', xres)
    validate_ss_residuals(xres, par.get('ss_validation_tol', 1e-4))
    C = np.sum(DUs * cUs) + np.sum(DEs * cEs)
    Umass = np.sum(DUs)
    # Walras
    walras = Y - par['drate'] * K - vcost - C
    # searchers and vacancies
    searchers, vacancies = matching_fnc_2(thetas_ss, DUs, DEEs, par)
    e0, e1, e2, e3, e4, e5, e6, e7 = searchers[0], searchers[1], searchers[2], searchers[3], searchers[4], searchers[5], searchers[6], searchers[7]
    v0, v1, v2, v3, v4, v5, v6, v7 = vacancies[0], vacancies[1], vacancies[2], vacancies[3], vacancies[4], vacancies[5], vacancies[6], vacancies[7]

    # Compute the labor flow rates
    EU_rate = np.sum(DEs * par['sigma'][np.newaxis, np.newaxis, np.newaxis, np.newaxis, :, np.newaxis]) / np.sum(DEs)
    EE_rate = np.sum(DEEs * qswitchs) / np.sum(DEs)

    # Expected values for vacant firms and flow-profits for active firms
    JU0_tmp = np.sum(JU0s * DUEs, axis=(0, 1, 3)) / np.sum(DUEs)
    Dswitchers = np.sum(DEEs, axis=(0, 1, 2, 3, 4, 6))
    JE0_tmp = np.sum(JE0s * DEEs, axis=(0, 1, 2, 3, 4, 6)) / Dswitchers
    if Dswitchers[0]==0:
        JE0_tmp[0] = 0
    J0_tmp = JU0_tmp + JE0_tmp
    J0_0 = J0_tmp[0]
    J0_1 = J0_tmp[1]
    J0_2 = J0_tmp[2]
    J0_3 = J0_tmp[3]
    J0_4 = J0_tmp[4]
    J0_5 = J0_tmp[5]
    J0_6 = J0_tmp[6]
    J0_7 = J0_tmp[7]
    Pi = Y - (r_ss + par['drate']) * K - np.sum(par['w_grid'] * np.sum(DEs, axis=(0, 1, 3, 4, 5)))

    # Fiscal policy
    Tax = np.sum(par['w_grid'] * np.sum(DEs, axis=(0, 1, 3, 4, 5))) * tax_ss
    Ubill = np.sum(np.sum(DUs, axis=(0,1)) * par['bUI'])

    A_pre, AU_pre, AE_pre = aggregate_pre_assets(DUs, DEs, a_grid)

    # Define steady state dictionary
    ss = {'Z': Z, 'alpha': par["alpha"], 'beta': par['beta'],  # parameters
          'inputs': dict(par['inputs']),
          'drate': par['drate'], 'bUIL': par['bUI'][0], 'bUIH': par['bUI'][1], 'transfer': transfer,
          'eis': par["eis"], 'Q': 1,
          'chi': par['chi'], 'eta': par['eta'],
          'r': r_ss, 'ra': r_ss, 'tax': tax_ss,  # unknowns
          'theta0': thetas_ss[0], 'theta1': thetas_ss[1], 'theta2': thetas_ss[2], 'theta3': thetas_ss[3],
          'theta4': thetas_ss[4], 'theta5': thetas_ss[5], 'theta6': thetas_ss[6], 'theta7': thetas_ss[7],
          'p': K, 'div': r_ss * K, 'epsI': par['epsI'],  # firm
          'JU0s' : JU0s, 'JE0s' : JE0s,
          'J0_0': J0_0, 'J0_1': J0_1, 'J0_2': J0_2, 'J0_3': J0_3,
          'J0_4': J0_4, 'J0_5': J0_5, 'J0_6': J0_6, 'J0_7': J0_7, 'Jss': Js, 'Jbargainingss': Jbargainings,  # firm values
          'Pi': Pi, 'vcost': vcost, 'zeta': par['zeta'],  'zeta_curv': par['zeta_curv'],
          'pgrid0': par['p_grid'][0], 'pgrid1': par['p_grid'][1], 'pgrid2': par['p_grid'][2],'pgrid3': par['p_grid'][3],
          'pgrid4': par['p_grid'][4], 'pgrid5': par['p_grid'][5], 'pgrid6': par['p_grid'][6], 'pgrid7': par['p_grid'][7],
          'rK': r_ss + par['drate'],  # factor prices
          'q0': qs[0], 'q1': qs[1], 'q2': qs[2], 'q3': qs[3], 'q4': qs[4], 'q5': qs[5], 'q6': qs[6], 'q7': qs[7], # labor market
          'lambdas': lambdas,
          'lambda0': lambdas[0], 'lambda1': lambdas[1], 'lambda2': lambdas[2], 'lambda3': lambdas[3],
          'lambda4': lambdas[4], 'lambda5': lambdas[5], 'lambda6': lambdas[6], 'lambda7': lambdas[7],
          'e0': e0, 'e1': e1, 'e2': e2, 'e3': e3, 'e4': e4, 'e5': e5, 'e6': e6, 'e7': e7,
          'v0': v0, 'v1': v1, 'v2': v2, 'v3': v3, 'v4': v4, 'v5': v5, 'v6': v6, 'v7': v7,
          'Iwins': Iwin, 's': par['s'], 'sigmaJ': par['sigma'][-1],
          'WUiss': WU_is, 'WUpiss': WU_pis,  # wage policies
          'WEwiniss': WEwin_is, 'WEwinpiss': WEwin_pis,
          'WEloseiss': WElose_is, 'WElosepiss': WElose_pis,
          'Y': Y, 'K': K, 'I': K * par['drate'], 'N': N, 'A': K, 'L': N, 'C': C,  # aggregates
          'CUss': cUs, 'CEss': cEs, 'AUss': aUs, 'AEss': aEs,  # consumption and savings policy
          'qss': qswitchs, 'EE_rate': EE_rate, 'EU_rate': EU_rate,  # job-switching
          'Uss': Us, 'Ess': Es, 'Ebargainingss' : Ebargainings, 'dEbargainingss' : dEbargainings,# value functions
          'QUss': DUs, 'QEss': DEs, 'QUEss': DUEs, 'QEEss': DEEs,  # distributions
          'U': Umass,
          'Tax': Tax, 'Ubill': Ubill, # fiscal policy
          'CU': np.sum(DUs * cUs), 'CE': np.sum(DEs * cEs), 'AU': np.sum(DUs * aUs), 'AE': np.sum(DEs * aEs),
          'A_pre': A_pre,
          'AU_pre': AU_pre,
          'AE_pre': AE_pre,
          'walras': walras, 'residuals': xres}

    wage_bill = np.sum(par['w_grid'] * np.sum(DEs, axis=(0, 1, 3, 4, 5)))
    employed_mass = np.sum(DEs)
    ss['earnings'] = wage_bill / employed_mass
    ss['sigmaslope'] = 0

    return ss

def getSS_moments(r_ss, tax_ss, thetas_ss, Z, par, smm_index, transfer=0,
                  warm_cache=None, bellman_tol=1e-7, dist_tol=1e-9):
    """Compute only the steady-state moments used in calibration."""
    nZ = par['nZ']
    nP = par['nP']
    nW = par['nW']
    nA = par['nA']
    nT = par['nT']
    nB = par['nB']

    DUs = np.zeros((nZ, nA, nB))
    DEs = np.zeros((nZ, nA, nW, nP, nT, nB))
    DEEs = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))
    qswitchs = np.zeros((nZ, nA, nW, nP, nT - 1, nP, nB))

    qs, lambdas = matching_fnc_1(thetas_ss, par)
    ibs = [0, 2]
    warm_cache = {} if warm_cache is None else _clone_cache(warm_cache)

    def _solve_ib(ib):
        return HH.solveHH(
            (r_ss, tax_ss, Z, par, lambdas, ib, smm_index),
            warm_start=warm_cache.get(ib),
            bellman_tol=bellman_tol,
            dist_tol=dist_tol,
        )

    max_workers = min(len(ibs), par.get('ss_hh_workers', len(ibs)))
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        results = list(executor.map(_solve_ib, ibs))

    for i, result in enumerate(results):
        _, _, _, _, _, _, _, _, _, _, _, _, DU, DE, _, DEE, qswitch, _, _, _, _ = result
        bi = int(ibs[i] / 2)
        DUs[:, :, bi] = DU / nB
        DEs[:, :, :, :, :, bi] = DE / nB
        DEEs[:, :, :, :, :, :, bi] = DEE / nB
        qswitchs[:, :, :, :, :, :, bi] = qswitch

    average_UI_income_by_type = (1 - tax_ss) * par['bUI']

    separation_weights = par['sigma'][None, None, None, None, :, None]
    job_loser_weights = DEs * separation_weights

    job_loser_mass_by_type = np.sum(
        job_loser_weights,
        axis=(0, 1, 2, 3, 4),
    )

    job_loser_wage_bill_by_type = np.sum(
        job_loser_weights * (1 - tax_ss) * par['w_grid'][None, None, :, None, None, None],
        axis=(0, 1, 2, 3, 4),
    )

    wage_income_by_type = np.divide(
        job_loser_wage_bill_by_type,
        job_loser_mass_by_type,
        out=np.zeros_like(job_loser_wage_bill_by_type),
        where=job_loser_mass_by_type != 0,
    )

    UI_to_income_by_type = np.divide(
        average_UI_income_by_type,
        wage_income_by_type,
        out=np.zeros_like(average_UI_income_by_type),
        where=wage_income_by_type != 0,
    )

    # UI benefits paid relative to aggregate gross labor income.
    Ubill = np.sum(np.sum(DUs, axis=(0,1)) * par['bUI'])
    wage_bill = np.sum(
        par['w_grid'] * np.sum(DEs, axis=(0, 1, 3, 4, 5))
    )
    UI2GDI = Ubill / wage_bill

    urate = np.sum(DUs)
    EE_rate = np.sum(DEEs * qswitchs) / np.sum(DEs)

    wealth_total = np.sum(
        (np.sum(DUs, axis=(0, 2)) + np.sum(DEs, axis=(0, 2, 3, 4, 5))) * par['a_grid']
    )
    ss_lorenz = {'QUss': DUs, 'QEss': DEs, 'A': wealth_total}
    _, Lz_model, Lorenz_diff = wealth_lorenz.get_wealth_dist(ss_lorenz, par)
    Qs = np.diff(Lz_model)

    moments = np.concatenate((
        UI_to_income_by_type,
        np.array([lambdas[0], urate, EE_rate]),
        Qs,
    ))

    return {
        'UI_to_income_by_type': UI_to_income_by_type,
        'UI_to_income_L': UI_to_income_by_type[0],
        'UI_to_income_H': UI_to_income_by_type[1],
        'wage_income_by_type': wage_income_by_type,
        'job_finding': lambdas[0],
        'urate': urate,
        'EE_rate': EE_rate,
        'Q1': Qs[0],
        'Q2': Qs[1],
        'Q3': Qs[2],
        'Q4': Qs[3],
        'Q5': Qs[4],
        'Lorenz_diff': Lorenz_diff,
        'UI2GDI': UI2GDI,
        'moments': moments,
    }
