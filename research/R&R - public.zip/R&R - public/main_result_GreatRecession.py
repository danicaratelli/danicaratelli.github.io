"""Identify and solve the adapted Great Recession nonlinear transition."""

from __future__ import annotations

import json
import os
from pathlib import Path
import pickle
import platform
import sys
from datetime import datetime

import numpy as np
from scipy.optimize import lsq_linear

import jacobian as jac
from nonlinear_dmp_adapted import INPUTS as DMP_INPUTS, evaluate_dmp_transition
from nonlinear_ge_adapted import (
    NonlinearGEMap, TARGETS, UNKNOWNS, construct_linear_system,
    deviations_to_levels, linear_initial_guess, reconstruct_parameters,
    solve_nonlinear_transition, validate_temporary_shocks,
    validate_zero_shock_transition,
)


TT = 100
OBSERVED_PERIODS = 24
TARGET_TAPER_PERIODS = 8
ACTIVE_PERIODS = OBSERVED_PERIODS + TARGET_TAPER_PERIODS
TERMINAL_TAIL = TT - ACTIVE_PERIODS + 1
STEADY_STATE_FILE = Path("ss_calibration_adapted.pkl")
JACOBIAN_FILE = Path("Jacobians") / "Jac_fake_news_adapted.pkl"
EARNINGS_DATA_FILE = Path(
    r"C:\Users\danic\Dropbox\AEJmacro_review\repllication_package"
    r"\empirics\Julia\SIPP\GreatRecession_earnings_delta.csv"
)
UNEMPLOYMENT_DATA_FILE = Path(
    r"C:\Users\danic\Dropbox\research\solo_research\WagesTightness\data"
    r"\aggregate\UNRATE.csv"
)
OUTPUT_DIRECTORY = Path("results_adapted") / "great_recession"

SOLVER_TOLERANCE = 5e-5
TERMINAL_TOLERANCE = 1e-4
WALRAS_TOLERANCE = 5e-5
MAX_ITERATIONS = 60
MAX_LINE_SEARCH_TRIALS = 13
IDENTIFICATION_SMOOTHNESS_PENALTY = 0.05
HOMOTOPY_SCALES = (
    0.10, 0.15, 0.20, 0.25, 0.35, 0.50, 0.65, 0.80, 0.90, 1.00,
)

# Select exactly two supported exogenous shocks here.  The default preserves
# the original Great Recession specification.
SHOCK_NAMES = ("chi", "eta")
SHOCK_LEVEL_BOUNDS = {
    "chi": (1e-10, np.inf),
    "drate": (1e-10, 1.0 - 1e-10),
    "Z": (1e-10, np.inf),
    "sigmaJ": (1e-10, 0.10),
    "zeta": (1e-10, np.inf),
    "epsI": (1e-10, np.inf),
    "eta": (1e-10, np.inf),
    "transfer": (-np.inf, np.inf),
    "bUI": (-np.inf, np.inf),
}


class ShockIdentificationError(RuntimeError):
    """The Great Recession shock-identification system is not usable."""


def centered_three_quarter_average(values):
    """Smooth interior observations while preserving both endpoints."""
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 1 or values.size < 3:
        raise ValueError("target path must be one-dimensional with 3+ values")
    smoothed = values.copy()
    smoothed[1:-1] = (
        values[:-2] + values[1:-1] + values[2:]
    ) / 3.0
    return smoothed


def append_cosine_taper(values, taper_periods=TARGET_TAPER_PERIODS):
    """Append a smooth return from the final observation to exactly zero."""
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 1 or values.size == 0:
        raise ValueError("target path must be a nonempty one-dimensional array")
    if taper_periods < 1:
        raise ValueError("taper_periods must be positive")
    step = np.arange(1, taper_periods + 1, dtype=np.float64)
    weights = 0.5 * (1.0 + np.cos(np.pi * step / taper_periods))
    weights[-1] = 0.0
    return np.concatenate((values, values[-1] * weights))


def construct_quarterly_targets(
        months_since_peak, headline_percent_deviation,
        unemployment_dates, unemployment, steady_state_earnings):
    """Build smoothed observed targets followed by a cosine taper to zero."""
    months_since_peak = np.asarray(months_since_peak, dtype=np.float64)
    headline_percent_deviation = np.asarray(
        headline_percent_deviation, dtype=np.float64
    )
    unemployment_dates = np.asarray(unemployment_dates, dtype=str)
    unemployment = np.asarray(unemployment, dtype=np.float64)
    inputs = (
        months_since_peak, headline_percent_deviation,
        unemployment_dates, unemployment,
    )
    if any(value.ndim != 1 for value in inputs):
        raise ValueError("Great Recession source columns must be one-dimensional")
    if months_since_peak.shape != headline_percent_deviation.shape:
        raise ValueError("earnings source columns must have equal length")
    if unemployment_dates.shape != unemployment.shape:
        raise ValueError("unemployment source columns must have equal length")
    if not (np.isfinite(months_since_peak).all()
            and np.isfinite(unemployment).all()):
        raise ValueError("Great Recession source values must all be finite")
    if np.isinf(headline_percent_deviation).any():
        raise ValueError("headline earnings deviations must not be infinite")
    if not np.isfinite(steady_state_earnings):
        raise ValueError("steady-state earnings must be finite")

    desired_months = np.arange(0, 3 * OBSERVED_PERIODS, 3, dtype=np.int64)
    if not np.all(months_since_peak == np.floor(months_since_peak)):
        raise ValueError("months_since_peak must contain integer-valued months")
    integer_months = months_since_peak.astype(np.int64)
    if np.unique(integer_months).size != integer_months.size:
        raise ValueError("months_since_peak must not contain duplicate months")
    month_lookup = {month: index for index, month in enumerate(integer_months)}
    missing_months = [month for month in desired_months if month not in month_lookup]
    if missing_months:
        raise ValueError(
            "earnings data must provide exactly 24 quarterly observations at "
            f"months 0, 3, ..., 69; missing {missing_months}"
        )
    earnings_source_indices = np.array(
        [month_lookup[month] for month in desired_months], dtype=np.int64
    )
    earnings_percent_raw = headline_percent_deviation[earnings_source_indices]
    post_peak = integer_months >= 0
    positive_observed_months = integer_months[
        post_peak & np.isfinite(headline_percent_deviation)
        & (headline_percent_deviation > 0.0)
    ]
    if positive_observed_months.size == 0:
        recovery_month = None
    else:
        recovery_month = int(np.min(positive_observed_months))
    missing_selected = ~np.isfinite(earnings_percent_raw)
    if recovery_month is None:
        invalid_missing = missing_selected
    else:
        invalid_missing = missing_selected & (desired_months <= recovery_month)
    if np.any(invalid_missing):
        raise ValueError(
            "headline earnings deviations must be finite before observed recovery"
        )
    earnings_percent_prepared = np.where(
        missing_selected, 0.0, earnings_percent_raw
    )
    earnings_percent_capped = np.minimum(earnings_percent_prepared, 0.0)
    earnings_target_observed = (
        float(steady_state_earnings) * earnings_percent_capped / 100.0
    )

    try:
        parsed_dates = np.array([
            datetime.strptime(value, "%m/%d/%Y")
            for value in unemployment_dates
        ], dtype=object)
    except ValueError as exc:
        raise ValueError("unemployment DATE values must use M/D/YYYY format") from exc
    start = datetime(2008, 1, 1)
    start_matches = np.flatnonzero(parsed_dates == start)
    if start_matches.size != 1:
        raise ValueError("unemployment data must contain 1/1/2008 exactly once")
    unemployment_source_indices = np.arange(
        start_matches[0], start_matches[0] + OBSERVED_PERIODS, dtype=np.int64
    )
    if unemployment_source_indices[-1] >= unemployment.size:
        raise ValueError("unemployment data has fewer than 24 rows from 1/1/2008")
    selected_dates = parsed_dates[unemployment_source_indices]
    for previous, current in zip(selected_dates[:-1], selected_dates[1:]):
        expected_month = previous.month + 3
        expected_year = previous.year + (expected_month - 1) // 12
        expected_month = (expected_month - 1) % 12 + 1
        if current != datetime(expected_year, expected_month, 1):
            raise ValueError("unemployment dates must advance by one quarter")
    unemployment_quarterly = unemployment[unemployment_source_indices]
    unemployment_baseline = 5.0
    if not np.isclose(
            unemployment_quarterly[0], unemployment_baseline,
            rtol=0.0, atol=1e-12):
        raise ValueError("the 1/1/2008 unemployment rate must equal 5%")
    unemployment_target_observed = (
        unemployment_quarterly - unemployment_baseline
    ) / 100.0
    if not np.isclose(earnings_target_observed[0], 0.0, rtol=0.0, atol=1e-14):
        raise ValueError("time-0 earnings target is not zero")
    if not np.isclose(unemployment_target_observed[0], 0.0, rtol=0.0, atol=1e-14):
        raise ValueError("time-0 unemployment target is not zero")

    earnings_target = append_cosine_taper(earnings_target_observed)
    unemployment_target = append_cosine_taper(unemployment_target_observed)
    extended_months = np.arange(0, 3 * ACTIVE_PERIODS, 3, dtype=np.int64)
    extended_dates = list(selected_dates)
    for _ in range(TARGET_TAPER_PERIODS):
        previous = extended_dates[-1]
        month_index = previous.month - 1 + 3
        extended_dates.append(datetime(
            previous.year + month_index // 12, month_index % 12 + 1, 1
        ))
    earnings_percent_smoothed = (
        100.0 * earnings_target / float(steady_state_earnings)
    )
    unemployment_quarterly_extended = (
        unemployment_baseline + 100.0 * unemployment_target
    )
    return {
        "earnings_months_since_peak": extended_months,
        "earnings_source_indices": np.concatenate((
            earnings_source_indices,
            np.full(TARGET_TAPER_PERIODS, -1, dtype=np.int64),
        )),
        "earnings_percent_deviation_raw": np.concatenate((
            earnings_percent_raw, np.full(TARGET_TAPER_PERIODS, np.nan)
        )),
        "earnings_percent_deviation_prepared": earnings_percent_smoothed,
        "earnings_percent_deviation_capped": earnings_percent_smoothed,
        "earnings_percent_deviation_capped_observed": earnings_percent_capped,
        "earnings_source_value_available": np.concatenate((
            ~missing_selected,
            np.zeros(TARGET_TAPER_PERIODS, dtype=bool),
        )),
        "earnings_target_original_observed": earnings_target_observed,
        "earnings_target_smoothed_observed": earnings_target_observed.copy(),
        "earnings_missing_post_recovery_filled": int(np.count_nonzero(
            missing_selected
        )),
        "earnings_first_positive_observed_month": recovery_month,
        "earnings_positive_values_capped": int(np.count_nonzero(
            earnings_percent_raw > 0.0
        )),
        "unemployment_dates": np.array(
            [value.strftime("%Y-%m-%d") for value in extended_dates], dtype=str
        ),
        "unemployment_source_indices": np.concatenate((
            unemployment_source_indices,
            np.full(TARGET_TAPER_PERIODS, -1, dtype=np.int64),
        )),
        "unemployment_quarterly": unemployment_quarterly_extended,
        "unemployment_target_original_observed": unemployment_target_observed,
        "unemployment_target_smoothed_observed": (
            unemployment_target_observed.copy()
        ),
        "unemployment_baseline_percent": unemployment_baseline,
        "earnings_target": earnings_target,
        "unemployment_target": unemployment_target,
    }


def build_identification_system(G, earnings_target, unemployment_target,
                                active_periods=ACTIVE_PERIODS,
                                shock_names=SHOCK_NAMES, shock_periods=None):
    """Build the target equations for shocks ending within the active window.

    Both time-0 outcomes are predetermined. Shock values after shock_periods
    are fixed to zero, so an early cutoff makes the system overidentified.
    """
    shock_names = tuple(shock_names)
    if len(shock_names) != 2 or len(set(shock_names)) != 2:
        raise ValueError("identification requires exactly two distinct shocks")
    if shock_periods is None:
        shock_periods = active_periods - 1
    if not 1 <= shock_periods < active_periods:
        raise ValueError("shock_periods must lie within the active target window")
    required = tuple(
        (output, shock)
        for output in ("earnings", "U")
        for shock in shock_names
    )
    matrices = {}
    for output, shock in required:
        try:
            value = np.asarray(G[output][shock], dtype=np.float64)
        except KeyError as exc:
            raise ValueError(f"missing GE mapping {shock} -> {output}") from exc
        if value.ndim != 2 or min(value.shape) < active_periods:
            raise ValueError(
                f"GE mapping {shock} -> {output} cannot support "
                f"{active_periods} periods"
            )
        if not np.isfinite(value).all():
            raise ValueError(f"GE mapping {shock} -> {output} is nonfinite")
        matrices[(output, shock)] = value

    earnings_target = np.asarray(earnings_target, dtype=np.float64)
    unemployment_target = np.asarray(unemployment_target, dtype=np.float64)
    if (earnings_target.shape != (active_periods,)
            or unemployment_target.shape != (active_periods,)):
        raise ValueError("identification targets have the wrong shape")
    n = active_periods
    n_outcome = n - 1
    n_shock = shock_periods
    matrix = np.zeros((2 * n_outcome, 2 * n_shock), dtype=np.float64)
    vector = np.empty(2 * n_outcome, dtype=np.float64)
    for column, shock in enumerate(shock_names):
        matrix[:n_outcome, column * n_shock:(column + 1) * n_shock] = (
            matrices[("earnings", shock)][1:n, :n_shock]
        )
        matrix[n_outcome:, column * n_shock:(column + 1) * n_shock] = (
            matrices[("U", shock)][1:n, :n_shock]
        )
    vector[:n_outcome] = earnings_target[1:n]
    vector[n_outcome:] = unemployment_target[1:n]
    return matrix, vector


def identify_bounded_shocks(
        G, earnings_target, unemployment_target,
        chi_steady_state, drate_steady_state, horizon=TT,
        active_periods=ACTIVE_PERIODS, maximum_condition_number=1e12,
        level_epsilon=1e-10, shock_names=SHOCK_NAMES,
        shock_steady_states=None, shock_level_bounds=None,
        smoothness_penalty=0.0, shock_periods=None):
    """Identify shocks, optionally penalizing period-to-period changes."""
    shock_names = tuple(shock_names)
    if len(shock_names) != 2 or len(set(shock_names)) != 2:
        raise ValueError("identification requires exactly two distinct shocks")
    if horizon <= active_periods:
        raise ValueError("horizon must exceed the active data window")
    if shock_periods is None:
        shock_periods = active_periods - 1
    if shock_steady_states is None:
        if shock_names != ("chi", "drate"):
            raise ValueError("shock_steady_states is required for non-default shocks")
        shock_steady_states = {"chi": chi_steady_state, "drate": drate_steady_state}
    shock_steady_states = {
        name: float(shock_steady_states[name]) for name in shock_names
    }
    if shock_level_bounds is None:
        shock_level_bounds = SHOCK_LEVEL_BOUNDS
    smoothness_penalty = float(smoothness_penalty)
    if not np.isfinite(smoothness_penalty) or smoothness_penalty < 0.0:
        raise ValueError("smoothness_penalty must be finite and nonnegative")
    bounds = {
        name: tuple(shock_level_bounds[name]) for name in shock_names
    }
    matrix, vector = build_identification_system(
        G, earnings_target, unemployment_target, active_periods, shock_names,
        shock_periods,
    )
    rank = int(np.linalg.matrix_rank(matrix))
    condition = float(np.linalg.cond(matrix))
    if rank != matrix.shape[1]:
        raise ShockIdentificationError(
            f"identification matrix is rank deficient: shape={matrix.shape}, "
            f"rank={rank}, condition_number={condition:.6e}"
        )
    if not np.isfinite(condition) or condition > maximum_condition_number:
        raise ShockIdentificationError(
            f"identification matrix is numerically unusable: shape={matrix.shape}, "
            f"rank={rank}, condition_number={condition:.6e}, "
            f"limit={maximum_condition_number:.6e}"
        )
    if not 0.0 < level_epsilon < 0.5:
        raise ValueError("level_epsilon must lie strictly between zero and 0.5")
    n_shock = shock_periods
    lower = np.concatenate([
        np.full(n_shock, bounds[name][0] - shock_steady_states[name])
        for name in shock_names
    ])
    upper = np.concatenate([
        np.full(n_shock, bounds[name][1] - shock_steady_states[name])
        for name in shock_names
    ])
    if smoothness_penalty:
        penalize_endpoint = n_shock < active_periods - 1
        difference = np.zeros((n_shock - 1 + penalize_endpoint, n_shock),
                              dtype=np.float64)
        rows = np.arange(n_shock - 1)
        difference[rows, rows] = -1.0
        difference[rows, rows + 1] = 1.0
        if penalize_endpoint:
            difference[-1, -1] = -1.0
        penalty_matrix = np.zeros((2 * difference.shape[0], matrix.shape[1]))
        penalty_matrix[:difference.shape[0], :n_shock] = difference
        penalty_matrix[difference.shape[0]:, n_shock:] = difference
        optimizer_matrix = np.vstack((matrix, smoothness_penalty * penalty_matrix))
        optimizer_vector = np.concatenate((vector, np.zeros(penalty_matrix.shape[0])))
    else:
        optimizer_matrix = matrix
        optimizer_vector = vector
    unconstrained = np.linalg.lstsq(
        optimizer_matrix, optimizer_vector, rcond=None
    )[0]
    result = lsq_linear(
        optimizer_matrix, optimizer_vector, bounds=(lower, upper), method="trf",
        tol=1e-12, lsmr_tol="auto", max_iter=1000, verbose=0,
    )
    if not result.success:
        raise ShockIdentificationError(
            "bounded identification failed: "
            f"status={result.status}, message={result.message}, "
            f"optimality={result.optimality:.6e}"
        )
    active = np.asarray(result.x, dtype=np.float64)
    if not np.isfinite(active).all():
        raise ShockIdentificationError("bounded identification is nonfinite")

    deviations = {}
    levels = {}
    for index, name in enumerate(shock_names):
        deviation = np.zeros(horizon, dtype=np.float64)
        deviation[:n_shock] = active[index * n_shock:(index + 1) * n_shock]
        if not np.all(deviation[n_shock:] == 0.0):
            raise ShockIdentificationError(
                f"identified {name} tail is not exactly zero"
            )
        deviations[name] = deviation
        levels[name] = shock_steady_states[name] + deviation
        if not np.isfinite(levels[name]).all():
            raise ShockIdentificationError(f"implied {name} levels are nonfinite")
        lower_level, upper_level = bounds[name]
        if np.min(levels[name]) < lower_level or np.max(levels[name]) > upper_level:
            raise ShockIdentificationError(
                f"implied {name} leaves its valid domain: "
                f"range=[{np.min(levels[name]):.6e}, {np.max(levels[name]):.6e}], "
                f"bounds=[{lower_level:.6e}, {upper_level:.6e}]"
            )

    fitted_earnings = sum(
        np.asarray(G["earnings"][name]) @ deviations[name]
        for name in shock_names
    )[:active_periods]
    fitted_unemployment = sum(
        np.asarray(G["U"][name]) @ deviations[name]
        for name in shock_names
    )[:active_periods]
    earnings_target = np.asarray(earnings_target, dtype=np.float64)
    unemployment_target = np.asarray(unemployment_target, dtype=np.float64)
    earnings_residual = fitted_earnings - earnings_target
    unemployment_residual = fitted_unemployment - unemployment_target
    system_residual = matrix @ active - vector

    def fit_statistics(residual, target):
        absolute = float(np.max(np.abs(residual)))
        denominator = np.maximum(np.abs(target), 1e-12)
        relative = float(np.max(np.abs(residual) / denominator))
        rmse = float(np.sqrt(np.mean(residual ** 2)))
        return absolute, relative, rmse

    earnings_abs, earnings_rel, earnings_rmse = fit_statistics(
        earnings_residual[1:], earnings_target[1:]
    )
    unemployment_abs, unemployment_rel, unemployment_rmse = fit_statistics(
        unemployment_residual[1:], unemployment_target[1:]
    )
    diagnostics = {
        "matrix_shape": list(matrix.shape), "numerical_rank": rank,
        "condition_number": condition,
        "maximum_condition_number": float(maximum_condition_number),
        "method": "scipy.optimize.lsq_linear",
        "regularization": bool(smoothness_penalty),
        "smoothing": bool(smoothness_penalty),
        "smoothness_penalty": smoothness_penalty,
        "optimizer_matrix_shape": list(optimizer_matrix.shape),
        "shock_names": list(shock_names),
        "fit_outcome_periods": [1, active_periods - 1],
        "free_shock_periods": [0, n_shock - 1],
        "optimizer_status": int(result.status),
        "optimizer_message": str(result.message),
        "optimizer_cost": float(result.cost),
        "optimizer_optimality": float(result.optimality),
        "optimizer_iterations": int(result.nit),
        "active_bound_count": int(np.count_nonzero(result.active_mask)),
        "earnings_max_absolute_fit_error": earnings_abs,
        "earnings_max_relative_fit_error": earnings_rel,
        "earnings_RMSE": earnings_rmse,
        "unemployment_max_absolute_fit_error": unemployment_abs,
        "unemployment_max_relative_fit_error": unemployment_rel,
        "unemployment_RMSE": unemployment_rmse,
        "system_max_absolute_residual": float(np.max(np.abs(system_residual))),
        "zero_tail_length": int(horizon - n_shock),
        "zero_tail_start_period": int(n_shock),
    }
    for index, name in enumerate(shock_names):
        diagnostics[f"{name}_zero_from_endpoint_exact"] = bool(
            np.all(deviations[name][n_shock:] == 0.0)
        )
        diagnostics[f"{name}_level_minimum"] = float(np.min(levels[name]))
        diagnostics[f"{name}_level_maximum"] = float(np.max(levels[name]))
        diagnostics[f"unconstrained_{name}_level_minimum"] = float(
            shock_steady_states[name] + np.min(
                unconstrained[index * n_shock:(index + 1) * n_shock]
            )
        )
        diagnostics[f"unconstrained_{name}_level_maximum"] = float(
            shock_steady_states[name] + np.max(
                unconstrained[index * n_shock:(index + 1) * n_shock]
            )
        )
    return {
        "matrix": matrix, "vector": vector, "deviations": deviations,
        "levels": levels, "chi_deviation": deviations.get("chi"),
        "drate_deviation": deviations.get("drate"),
        "chi_levels": levels.get("chi"), "drate_levels": levels.get("drate"),
        "fitted_earnings": fitted_earnings,
        "fitted_unemployment": fitted_unemployment,
        "earnings_residual": earnings_residual,
        "unemployment_residual": unemployment_residual,
        "diagnostics": diagnostics,
    }


def _json_value(value):
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.floating):
        return float(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"Cannot JSON-encode {type(value).__name__}")


def _write_csv(path, columns):
    names = list(columns)
    values = [np.asarray(columns[name], dtype=np.float64) for name in names]
    lengths = {value.shape for value in values}
    if len(lengths) != 1 or any(value.ndim != 1 for value in values):
        raise ValueError(f"CSV columns for {path.name} must share one-dimensional shape")
    matrix = np.column_stack(values)
    if not np.isfinite(matrix).all():
        raise ValueError(f"refusing to save nonfinite values to {path}")
    np.savetxt(path, matrix, delimiter=",", header=",".join(names), comments="")


def _write_diagnostics(path, payload):
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True, default=_json_value),
        encoding="utf-8",
    )


def _load_pickle_compatible(path):
    """Load NumPy 2 pickles under either the production or legacy runtime."""
    if "numpy._core" not in sys.modules:
        sys.modules["numpy._core"] = np.core
        sys.modules["numpy._core.multiarray"] = np.core.multiarray
        sys.modules["numpy._core.numeric"] = np.core.numeric
    with Path(path).open("rb") as file:
        return pickle.load(file)


def _check_compatibility(Jac, ss_path, solver_tolerance):
    expected = {
        "bargaining_version": "wagesEE_AOB_adapted",
        "case4_derivative_mode": "partial",
        "flow_timing_version": "calendar_consistent_tplus1",
        "searcher_rung_axis": "destination",
    }
    for name, value in expected.items():
        if Jac.get(name) != value:
            raise ValueError(f"adapted Jacobian {name} must equal {value!r}")
    saved_ss_timestamp = Jac.get("steady_state_timestamp")
    if (saved_ss_timestamp is not None
            and abs(float(saved_ss_timestamp) - os.path.getmtime(ss_path)) > 1e-6):
        raise ValueError(
            "adapted Jacobian metadata points to a different steady-state file version"
        )
    if int(Jac.get("TT", 0)) < TT:
        raise ValueError(f"saved Jacobian horizon is shorter than TT={TT}")
    required_outputs = {
        "A", "C", "N", "U", "Tax", "Ubill", "Pi", "earnings",
        *(f"e{i}" for i in range(8)), *(f"J0_{i}" for i in range(8)),
    }
    missing = sorted(required_outputs - set(Jac["J"]))
    if missing:
        raise ValueError(f"adapted Jacobian is missing outputs {missing}")
    residual_floor = float(Jac.get("steady_state_max_abs_residual", 0.0))
    if solver_tolerance < residual_floor:
        raise ValueError(
            f"solver tolerance {solver_tolerance:.3e} is below the saved "
            f"steady-state residual floor {residual_floor:.3e}"
        )
    return residual_floor


def run_experiment(transition_solver=None, shock_periods=None,
                   fit_periods=ACTIVE_PERIODS):
    """Run the experiment with the standard or a supplied transition solver."""
    if shock_periods is None:
        shock_periods = fit_periods - 1
    if not 2 <= fit_periods <= ACTIVE_PERIODS:
        raise ValueError("fit_periods must lie within the active target window")
    if not 1 <= shock_periods < fit_periods:
        raise ValueError("shock_periods must end before the final fitted period")
    required_terminal_tail = TT - shock_periods
    if len(SHOCK_NAMES) != 2 or len(set(SHOCK_NAMES)) != 2:
        raise ValueError("SHOCK_NAMES must contain exactly two distinct shocks")
    unsupported = sorted(set(SHOCK_NAMES) - set(SHOCK_LEVEL_BOUNDS))
    if unsupported:
        raise ValueError(f"unsupported configurable shocks: {unsupported}")

    ss_path = STEADY_STATE_FILE.resolve()
    jacobian_path = JACOBIAN_FILE.resolve()
    output_path = OUTPUT_DIRECTORY.resolve()
    output_path.mkdir(parents=True, exist_ok=True)
    ss = _load_pickle_compatible(ss_path)
    Jac = _load_pickle_compatible(jacobian_path)
    residual_floor = _check_compatibility(Jac, ss_path, SOLVER_TOLERANCE)
    J = Jac["J"]
    par = reconstruct_parameters(ss)

    earnings_source = np.genfromtxt(
        EARNINGS_DATA_FILE, delimiter=",", names=True, encoding="utf-8"
    )
    unemployment_source = np.genfromtxt(
        UNEMPLOYMENT_DATA_FILE, delimiter=",", names=True, encoding="utf-8",
        dtype=None,
    )
    if earnings_source.dtype.names is None:
        raise ValueError("Great Recession earnings CSV has no named columns")
    if unemployment_source.dtype.names is None:
        raise ValueError("Great Recession unemployment CSV has no named columns")
    earnings_columns = {"months_since_peak", "headline_percent_deviation"}
    unemployment_columns = {"DATE", "UNRATE"}
    missing_earnings = sorted(earnings_columns - set(earnings_source.dtype.names))
    missing_unemployment = sorted(
        unemployment_columns - set(unemployment_source.dtype.names)
    )
    if missing_earnings:
        raise ValueError(f"Great Recession earnings CSV is missing {missing_earnings}")
    if missing_unemployment:
        raise ValueError(
            f"Great Recession unemployment CSV is missing {missing_unemployment}"
        )
    targets = construct_quarterly_targets(
        earnings_source["months_since_peak"],
        earnings_source["headline_percent_deviation"],
        unemployment_source["DATE"], unemployment_source["UNRATE"],
        ss["earnings"],
    )

    system = construct_linear_system(ss, J, par, TT)
    shock_level_bounds = {
        name: SHOCK_LEVEL_BOUNDS[name] for name in SHOCK_NAMES
    }
    if "sigmaJ" in SHOCK_NAMES:
        sigma_grid = np.asarray(par["sigma"], dtype=np.float64)
        shock_level_bounds["sigmaJ"] = (
            float(sigma_grid[-1] - np.min(sigma_grid) + 1e-10),
            float(1.0 + sigma_grid[-1] - np.max(sigma_grid) - 1e-10),
        )
    G = jac.get_G(
        system["linear_blocks"], list(SHOCK_NAMES), UNKNOWNS, TARGETS,
        TT, ss=ss, outputs=["earnings", "U"],
        H_U_factored=system["H_U_factored"],
    )
    try:
        identified = identify_bounded_shocks(
            G, targets["earnings_target"][:fit_periods],
            targets["unemployment_target"][:fit_periods],
            ss.get("chi", 0.0), ss.get("drate", 0.0),
            horizon=TT, active_periods=fit_periods,
            shock_periods=shock_periods,
            shock_names=SHOCK_NAMES,
            shock_steady_states={name: ss.get(name, 0.0) for name in SHOCK_NAMES},
            shock_level_bounds=shock_level_bounds,
            smoothness_penalty=IDENTIFICATION_SMOOTHNESS_PENALTY,
        )
    except ShockIdentificationError as exc:
        matrix, vector = build_identification_system(
            G, targets["earnings_target"][:fit_periods],
            targets["unemployment_target"][:fit_periods],
            active_periods=fit_periods, shock_names=SHOCK_NAMES,
            shock_periods=shock_periods,
        )
        row_norms = np.linalg.norm(matrix, axis=1)
        failure_diagnostics = {
            "metadata": {
                "steady_state_file": str(ss_path),
                "jacobian_file": str(jacobian_path),
                "earnings_data_file": str(EARNINGS_DATA_FILE),
                "unemployment_data_file": str(UNEMPLOYMENT_DATA_FILE),
                "T": TT,
                "observed_periods": OBSERVED_PERIODS,
                "target_taper_periods": TARGET_TAPER_PERIODS,
                "active_periods": ACTIVE_PERIODS,
                "terminal_tail": required_terminal_tail,
                "shock_names": list(SHOCK_NAMES),
                "python_version": platform.python_version(),
                "numpy_version": np.__version__,
            },
            "data": {
                "earnings_source_rows": int(np.asarray(earnings_source).size),
                "unemployment_source_rows": int(
                    np.asarray(unemployment_source).size
                ),
                "quarterly_observations": OBSERVED_PERIODS,
                "earnings_time0_target": float(targets["earnings_target"][0]),
                "unemployment_time0_target": float(
                    targets["unemployment_target"][0]
                ),
                "earnings_used_columns": [
                    "months_since_peak", "headline_percent_deviation"
                ],
                "unemployment_used_columns": ["DATE", "UNRATE"],
                "calendars_aligned": False,
                "earnings_months_since_peak": targets[
                    "earnings_months_since_peak"
                ],
                "earnings_percent_deviation_raw": targets[
                    "earnings_percent_deviation_raw"
                ],
                "earnings_percent_deviation_capped": targets[
                    "earnings_percent_deviation_capped"
                ],
                "earnings_positive_values_capped": targets[
                    "earnings_positive_values_capped"
                ],
                "earnings_missing_post_recovery_filled": targets[
                    "earnings_missing_post_recovery_filled"
                ],
                "unemployment_dates": targets["unemployment_dates"],
                "unemployment_rates_percent": targets[
                    "unemployment_quarterly"
                ],
                "unemployment_baseline_percent": targets[
                    "unemployment_baseline_percent"
                ],
            },
            "identification": {
                "passed": False,
                "failure_reason": str(exc),
                "matrix_shape": list(matrix.shape),
                "numerical_rank": int(np.linalg.matrix_rank(matrix)),
                "condition_number": float(np.linalg.cond(matrix)),
                "zero_norm_equation_rows": np.flatnonzero(row_norms == 0.0),
                "row_norms": row_norms,
            },
            "zero_shock": None,
            "solver": None,
            "mass": None,
            "walras": None,
            "terminal": None,
        }
        _write_diagnostics(
            output_path / "great_recession_diagnostics.json",
            failure_diagnostics,
        )
        with (output_path / "great_recession_failure.pkl").open("wb") as file:
            pickle.dump({
                "diagnostics": failure_diagnostics,
                "targets": targets,
                "identification_matrix": matrix,
                "identification_vector": vector,
                "general_equilibrium_mappings": G,
            }, file)
        raise
    shock_deviations = {
        name: identified["deviations"][name] for name in SHOCK_NAMES
    }
    shock_cutoff = validate_temporary_shocks(
        shock_deviations, TT, terminal_tail=required_terminal_tail
    )
    if shock_cutoff > shock_periods - 1:
        raise RuntimeError(
            f"identified shock cutoff {shock_cutoff} exceeds period "
            f"{shock_periods - 1}"
        )

    metadata = {
        "steady_state_file": str(ss_path),
        "steady_state_timestamp": os.path.getmtime(ss_path),
        "jacobian_file": str(jacobian_path),
        "jacobian_timestamp": os.path.getmtime(jacobian_path),
        "earnings_data_file": str(EARNINGS_DATA_FILE),
        "unemployment_data_file": str(UNEMPLOYMENT_DATA_FILE),
        "T": TT,
        "observed_periods": OBSERVED_PERIODS,
        "target_taper_periods": TARGET_TAPER_PERIODS,
        "target_smoothing": "none_within_observed_sample",
        "target_taper": "cosine_to_zero",
        "active_periods": ACTIVE_PERIODS,
        "fit_periods": fit_periods,
        "terminal_tail": required_terminal_tail,
        "shock_names": list(SHOCK_NAMES),
        "shock_level_bounds": {
            name: list(shock_level_bounds[name]) for name in SHOCK_NAMES
        },
        "identification_method": "bounded_least_squares_with_optional_smoothing",
        "identification_smoothness_penalty": IDENTIFICATION_SMOOTHNESS_PENALTY,
        "fit_outcome_periods": [1, fit_periods - 1],
        "free_shock_periods": [0, shock_periods - 1],
        "shock_endpoint_period": shock_periods,
        "solver_tolerance": SOLVER_TOLERANCE,
        "max_line_search_trials": MAX_LINE_SEARCH_TRIALS,
        "terminal_tolerance": TERMINAL_TOLERANCE,
        "walras_tolerance": WALRAS_TOLERANCE,
        "homotopy_scales": (
            list(HOMOTOPY_SCALES) if transition_solver is None else []
        ),
        "solver_method": (
            "fixed_homotopy" if transition_solver is None
            else "adaptive_shock_continuation"
        ),
        "steady_state_residual_floor": residual_floor,
        "python_version": platform.python_version(),
        "numpy_version": np.__version__,
    }
    data_diagnostics = {
        "earnings_source_rows": int(np.asarray(earnings_source).size),
        "unemployment_source_rows": int(np.asarray(unemployment_source).size),
        "quarterly_observations": OBSERVED_PERIODS,
        "earnings_source_row_indices": targets["earnings_source_indices"],
        "earnings_months_since_peak": targets["earnings_months_since_peak"],
        "earnings_percent_deviation_raw": targets[
            "earnings_percent_deviation_raw"
        ],
        "earnings_percent_deviation_capped": targets[
            "earnings_percent_deviation_capped"
        ],
        "earnings_source_value_available": targets[
            "earnings_source_value_available"
        ],
        "earnings_missing_post_recovery_filled": targets[
            "earnings_missing_post_recovery_filled"
        ],
        "earnings_first_positive_observed_month": targets[
            "earnings_first_positive_observed_month"
        ],
        "earnings_positive_values_capped": targets[
            "earnings_positive_values_capped"
        ],
        "earnings_positive_cap": 0.0,
        "unemployment_source_row_indices": targets[
            "unemployment_source_indices"
        ],
        "unemployment_dates": targets["unemployment_dates"],
        "unemployment_rates_percent": targets["unemployment_quarterly"],
        "unemployment_baseline_percent": targets[
            "unemployment_baseline_percent"
        ],
        "earnings_time0_target": float(targets["earnings_target"][0]),
        "unemployment_time0_target": float(targets["unemployment_target"][0]),
        "earnings_used_columns": [
            "months_since_peak", "headline_percent_deviation"
        ],
        "unemployment_used_columns": ["DATE", "UNRATE"],
        "calendars_aligned": False,
        "calendar_alignment_note": (
            "Earnings and unemployment are paired by model-period index; "
            "their source calendars are intentionally not aligned."
        ),
    }
    diagnostics_payload = {
        "metadata": metadata,
        "data": data_diagnostics,
        "identification": identified["diagnostics"],
        "zero_shock": None,
        "solver": None,
        "mass": None,
        "walras": None,
        "terminal": None,
    }
    diagnostics_path = output_path / "great_recession_diagnostics.json"

    shock_columns = {"time": np.arange(TT)}
    for name in SHOCK_NAMES:
        shock_columns[name + "_deviation"] = identified["deviations"][name]
        shock_columns[name + "_level"] = identified["levels"][name]
    _write_csv(output_path / "identified_shocks.csv", shock_columns)
    _write_csv(output_path / "linear_target_fit.csv", {
        "time": np.arange(fit_periods),
        "earnings_months_since_peak": targets["earnings_months_since_peak"][:fit_periods],
        "earnings_percent_deviation_source_or_recovery_zero": targets[
        "earnings_percent_deviation_prepared"
        ][:fit_periods],
        "earnings_percent_deviation_capped": targets[
        "earnings_percent_deviation_capped"
        ][:fit_periods],
        "earnings_source_value_available": targets[
        "earnings_source_value_available"
        ][:fit_periods],
        "unemployment_date_yyyymmdd": np.array([
            int(value.replace("-", ""))
            for value in targets["unemployment_dates"][:fit_periods]
        ]),
        "unemployment_rate_percent": targets["unemployment_quarterly"][:fit_periods],
        "earnings_target_deviation": targets["earnings_target"][:fit_periods],
        "earnings_fitted_deviation": identified["fitted_earnings"],
        "earnings_residual": identified["earnings_residual"],
        "unemployment_target_deviation": targets["unemployment_target"][:fit_periods],
        "unemployment_fitted_deviation": identified["fitted_unemployment"],
        "unemployment_residual": identified["unemployment_residual"],
    })
    _write_diagnostics(diagnostics_path, diagnostics_payload)

    zero_validation = validate_zero_shock_transition(
        ss, par, J, TT, residual_tolerance=max(SOLVER_TOLERANCE, 5e-5)
    )
    diagnostics_payload["zero_shock"] = zero_validation
    _write_diagnostics(diagnostics_path, diagnostics_payload)
    if not zero_validation["passed"]:
        partial = {
            "metadata": metadata, "targets": targets,
            "identification": identified, "zero_shock_validation": zero_validation,
        }
        with (output_path / "great_recession_failure.pkl").open("wb") as file:
            pickle.dump(partial, file)
        raise RuntimeError(
            "zero-shock validation failed: " + ", ".join(zero_validation["failures"])
        )

    linear_unknowns, linear_responses = linear_initial_guess(
        ss, system, shock_deviations, TT
    )
    shock_levels = deviations_to_levels(ss, shock_deviations, TT)
    linear_initial_failure = None
    linear_scaled_residual = {}
    if transition_solver is None:
        ge_map = NonlinearGEMap(ss, par, J, TT)
        try:
            linear_evaluation = ge_map.evaluate(linear_unknowns, shock_levels)
            linear_scaled_residual = {
                name: float(np.max(np.abs(
                    linear_evaluation["scaled_residuals"][name]
                )))
                for name in TARGETS
            }
        except Exception as exc:
            linear_initial_failure = f"{type(exc).__name__}: {exc}"

    try:
        solver = (solve_nonlinear_transition if transition_solver is None
                  else transition_solver)
        solution = solver(
            ss, par, J, shock_deviations, TT, initial_guess=linear_unknowns,
            tolerance=SOLVER_TOLERANCE, max_iterations=MAX_ITERATIONS,
            max_line_search_trials=MAX_LINE_SEARCH_TRIALS,
            homotopy_scales=HOMOTOPY_SCALES,
            terminal_tail=required_terminal_tail,
            terminal_tolerance=TERMINAL_TOLERANCE,
            walras_tolerance=WALRAS_TOLERANCE,
        )
    except Exception as exc:
        diagnostics_payload["solver"] = {
            "converged": False,
            "failure_reason": f"{type(exc).__name__}: {exc}",
            "linear_initial_scaled_residual_by_target": linear_scaled_residual,
        }
        _write_diagnostics(diagnostics_path, diagnostics_payload)
        partial = {
            "metadata": metadata, "targets": targets,
            "identification": identified, "zero_shock_validation": zero_validation,
            "linear_initial_guess": linear_unknowns,
            "linear_responses": linear_responses,
            "exception": repr(exc),
        }
        with (output_path / "great_recession_failure.pkl").open("wb") as file:
            pickle.dump(partial, file)
        raise

    solution["diagnostics"]["linear_initial_scaled_residual_by_target"] = (
        linear_scaled_residual
    )
    solution["diagnostics"]["linear_initial_evaluation_failure"] = (
        linear_initial_failure
    )
    diagnostics_payload["solver"] = solution["diagnostics"]
    diagnostics_payload["walras"] = {
        "maximum_absolute_residual": solution["diagnostics"].get(
            "terminal_diagnostics", {}
        ).get("walras_max_residual"),
        "tolerance": WALRAS_TOLERANCE,
    }
    diagnostics_payload["terminal"] = solution["diagnostics"].get(
        "terminal_diagnostics", {}
    )
    _write_diagnostics(diagnostics_path, diagnostics_payload)
    if not solution["converged"]:
        partial = {
            "metadata": metadata, "targets": targets,
            "identification": identified, "zero_shock_validation": zero_validation,
            "solution": solution,
        }
        with (output_path / "great_recession_failure.pkl").open("wb") as file:
            pickle.dump(partial, file)
        raise RuntimeError(
            "nonlinear transition did not converge; diagnostics and partial state "
            f"saved under {output_path}"
        )

    dmp_paths = {
        name: solution["paths"][name]
        for name in DMP_INPUTS if name in solution["paths"]
    }
    try:
        final_dmp = evaluate_dmp_transition(
            ss, par, dmp_paths, compute_distributional=True,
            retain_distribution=False,
        )
    except Exception as exc:
        diagnostics_payload["solver"]["postsolve_distributional_failure"] = (
            f"{type(exc).__name__}: {exc}"
        )
        _write_diagnostics(diagnostics_path, diagnostics_payload)
        with (output_path / "great_recession_failure.pkl").open("wb") as file:
            pickle.dump({
                "metadata": metadata, "targets": targets,
                "identification": identified, "zero_shock_validation": zero_validation,
                "solution": solution, "exception": repr(exc),
            }, file)
        raise

    mass_diagnostics = final_dmp["diagnostics"]
    terminal_distribution = final_dmp["terminal_distribution"]
    distributions_finite = all(
        np.isfinite(value).all() for value in terminal_distribution.values()
    )
    distributions_nonnegative = all(
        float(np.min(value)) >= -1e-12 for value in terminal_distribution.values()
    )
    mass_valid = mass_diagnostics["maximum_distribution_mass_error"] <= 1e-9
    terminal_distribution_valid = (
        mass_diagnostics["terminal_distribution_L1_distance"]
        <= TERMINAL_TOLERANCE
    )
    diagnostics_payload["mass"] = {
        **mass_diagnostics,
        "mass_preserved": bool(mass_valid),
        "terminal_distribution_finite": bool(distributions_finite),
        "terminal_distribution_nonnegative": bool(distributions_nonnegative),
        "wealth_low_target_mass_max_error": float(np.max(
            final_dmp["distributional"]["wealth_low_target_mass_error"]
        )),
        "wealth_high_target_mass_max_error": float(np.max(
            final_dmp["distributional"]["wealth_high_target_mass_error"]
        )),
        "wealth_employment_mass_aggregation_max_error": float(np.max(
            final_dmp["distributional"][
                "wealth_employment_mass_aggregation_error"
            ]
        )),
        "wealth_wage_bill_aggregation_max_error": float(np.max(
            final_dmp["distributional"]["wealth_wage_bill_aggregation_error"]
        )),
        "wealth_EE_flow_aggregation_max_error": float(np.max(
            final_dmp["distributional"]["wealth_EE_flow_aggregation_error"]
        )),
    }
    diagnostics_payload["terminal"]["postsolve_distribution_valid"] = bool(
        terminal_distribution_valid
    )
    diagnostics_payload["terminal"]["shock_cutoff"] = int(shock_cutoff)
    diagnostics_payload["terminal"]["exact_zero_tail"] = bool(
        all(np.all(path[shock_periods:] == 0.0)
            for path in shock_deviations.values())
    )
    _write_diagnostics(diagnostics_path, diagnostics_payload)
    if not (mass_valid and distributions_finite and distributions_nonnegative
            and terminal_distribution_valid
            and diagnostics_payload["terminal"]["exact_zero_tail"]):
        with (output_path / "great_recession_failure.pkl").open("wb") as file:
            pickle.dump({
                "metadata": metadata, "targets": targets,
                "identification": identified, "zero_shock_validation": zero_validation,
                "solution": solution, "final_dmp": final_dmp,
            }, file)
        raise RuntimeError(
            "postsolve distribution, terminal, or exact-tail validation failed"
        )

    aggregate_columns = {
        "time": np.arange(TT),
    }
    for name in SHOCK_NAMES:
        aggregate_columns[name + "_deviation"] = identified["deviations"][name]
        aggregate_columns[name + "_level"] = identified["levels"][name]
    for name in UNKNOWNS:
        aggregate_columns[name] = solution["unknowns"][name]
    for name in ("ra", "rK", "K", "p", "A", "N", "U", "EE_rate",
                 "EU_rate", "earnings", *TARGETS):
        aggregate_columns[name] = solution["paths"][name]
    aggregate_columns["walras_residual"] = solution["paths"]["walras_res"]
    _write_csv(output_path / "nonlinear_aggregate_paths.csv", aggregate_columns)

    distributional = final_dmp["distributional"]
    wealth_series = {
        "below_median_wealth_mean_earnings": distributional[
            "mean_earnings_low_wealth"
        ],
        "above_median_wealth_mean_earnings": distributional[
            "mean_earnings_high_wealth"
        ],
        "below_median_wealth_EE_rate": distributional["EE_rate_low_wealth"],
        "above_median_wealth_EE_rate": distributional["EE_rate_high_wealth"],
    }
    moment_columns = {"time": np.arange(TT)}
    for name, values in wealth_series.items():
        values = np.asarray(values)
        moment_columns[name] = values
        moment_columns[name + "_change_from_time0"] = values - values[0]
    for name in (
        "median_asset_index", "median_asset_value",
        "median_asset_boundary_fraction", "wealth_worker_mass_low",
        "wealth_worker_mass_high", "wealth_employment_mass_low",
        "wealth_employment_mass_high", "wealth_wage_bill_aggregation_error",
        "wealth_EE_flow_aggregation_error",
    ):
        moment_columns[name] = distributional[name]
    _write_csv(
        output_path / "nonlinear_wealth_distributional_moments.csv",
        moment_columns,
    )

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(2, 2, figsize=(9, 6), constrained_layout=True)
    active_time = np.arange(fit_periods)
    axes[0, 0].plot(active_time, targets["earnings_target"][:fit_periods], label="target")
    axes[0, 0].plot(active_time, identified["fitted_earnings"], "--", label="fit")
    axes[0, 0].set_title("Linear earnings deviation")
    axes[0, 1].plot(active_time, targets["unemployment_target"][:fit_periods], label="target")
    axes[0, 1].plot(active_time, identified["fitted_unemployment"], "--", label="fit")
    axes[0, 1].set_title("Linear unemployment deviation")
    axes[0, 0].legend()
    axes[0, 1].legend()
    axes[1, 0].plot(wealth_series["below_median_wealth_mean_earnings"]
                    - wealth_series["below_median_wealth_mean_earnings"][0],
                    label="below median")
    axes[1, 0].plot(wealth_series["above_median_wealth_mean_earnings"]
                    - wealth_series["above_median_wealth_mean_earnings"][0],
                    label="above median")
    axes[1, 0].set_title("Nonlinear mean-earnings change")
    axes[1, 1].plot(wealth_series["below_median_wealth_EE_rate"]
                    - wealth_series["below_median_wealth_EE_rate"][0],
                    label="below median")
    axes[1, 1].plot(wealth_series["above_median_wealth_EE_rate"]
                    - wealth_series["above_median_wealth_EE_rate"][0],
                    label="above median")
    axes[1, 1].set_title("Nonlinear EE-rate change")
    axes[1, 0].legend()
    axes[1, 1].legend()
    for axis in axes.flat:
        axis.set_xlabel("quarter")
        axis.axhline(0.0, color="0.75", linewidth=0.7)
    fig.savefig(output_path / "great_recession_results.png", dpi=180)
    plt.close(fig)

    solution["distributional"] = distributional
    solution["terminal_distribution"] = terminal_distribution
    solution["metadata"] = metadata
    solution["targets"] = targets
    solution["identification"] = identified
    solution["zero_shock_validation"] = zero_validation
    solution["postsolve_dmp_diagnostics"] = mass_diagnostics
    with (output_path / "great_recession_solution.pkl").open("wb") as file:
        pickle.dump(solution, file)
    failure_path = output_path / "great_recession_failure.pkl"
    if failure_path.exists():
        failure_path.unlink()
    return solution


if __name__ == "__main__":
    run_experiment()
