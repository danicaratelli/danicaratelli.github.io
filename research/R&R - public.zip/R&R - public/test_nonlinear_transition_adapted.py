"""Tests for the adapted nonlinear transition implementation."""

from __future__ import annotations

import copy
import os
import pickle
import tempfile
import unittest
from unittest import mock

import numpy as np

import Jac_fake_news_adapted as fake_news
from distributional_moments_adapted import (
    current_earnings_moments, employed_wage_quantile_weights,
)
import nonlinear_ge_adapted as nge
from nonlinear_dmp_adapted import evaluate_dmp_transition
import utils


class DistributionalMomentTests(unittest.TestCase):
    def setUp(self):
        self.DE = np.zeros((1, 1, 3, 1, 2, 1))
        self.DE[0, 0, :, 0, 0, 0] = (1.0, 3.0, 1.0)
        self.DE[0, 0, :, 0, 1, 0] = (0.0, 3.0, 2.0)
        self.DEE = np.array([1.0, 4.0, 5.0]).reshape(1, 1, 3, 1, 1, 1, 1)
        self.q = np.array([0.2, 0.4, 0.8]).reshape(self.DEE.shape)
        self.sigma = np.array([0.1, 0.3])
        self.wages = np.array([1.0, 2.0, 4.0])

    def test_fractional_median_split(self):
        split = employed_wage_quantile_weights(self.DE)
        np.testing.assert_allclose(split["low"] + split["high"], 1.0)
        self.assertTrue(np.all((split["low"] >= 0) & (split["low"] <= 1)))
        self.assertEqual(split["median_wage_index"], 1)
        self.assertAlmostEqual(split["median_boundary_fraction"], 4.0 / 6.0)
        self.assertAlmostEqual(split["low"] @ split["mass_by_wage"], 5.0)
        self.assertAlmostEqual(split["high"] @ split["mass_by_wage"], 5.0)

    def test_aggregation_identities_and_ee_weight_once(self):
        m = current_earnings_moments(
            self.DE, self.DEE, self.q, self.sigma, self.wages
        )
        self.assertAlmostEqual(m["employment_mass_low"], 5.0)
        self.assertAlmostEqual(m["employment_mass_high"], 5.0)
        aggregate_bill = float(np.sum(
            self.DE * self.wages[None, None, :, None, None, None]
        ))
        self.assertAlmostEqual(m["wage_bill_low"] + m["wage_bill_high"],
                               aggregate_bill)
        self.assertAlmostEqual(
            m["mean_earnings_low"] * 5 + m["mean_earnings_high"] * 5,
            aggregate_bill,
        )
        aggregate_ee = float(np.sum(self.q * self.DEE))
        self.assertAlmostEqual(
            m["EE_rate_low"] * 5 + m["EE_rate_high"] * 5, aggregate_ee
        )
        expected_low_ee = 0.2 * 1.0 + (4.0 / 6.0) * 0.4 * 4.0
        self.assertAlmostEqual(m["EE_rate_low"] * 5, expected_low_ee)
        aggregate_eu = float(np.sum(
            self.DE * self.sigma[None, None, None, None, :, None]
        ))
        self.assertAlmostEqual(
            m["EU_rate_low"] * 5 + m["EU_rate_high"] * 5, aggregate_eu
        )


class TemporaryShockValidationTests(unittest.TestCase):
    def test_temporary_cutoff(self):
        self.assertEqual(nge.validate_temporary_shocks(
            {"Z": np.array([0.1, 0.0, 0.0, 0.0])}, 4, terminal_tail=2
        ), 0)
        with self.assertRaises(ValueError):
            nge.validate_temporary_shocks(
                {"Z": np.array([0.1, 0.0, 0.0, 0.1])}, 4
            )

    def test_jacobian_truncation(self):
        J = {"x": {"z": np.arange(25.0).reshape(5, 5)}}
        cut = nge.truncate_jacobian(J, 3)
        self.assertEqual(cut["x"]["z"].shape, (3, 3))
        self.assertEqual(J["x"]["z"].shape, (5, 5))


class SolverAlgorithmTests(unittest.TestCase):
    def test_invalid_full_theta_step_backtracks(self):
        class FakeMap:
            T = 1

            def evaluate(self, unknowns, shock_levels):
                if unknowns["theta0"][0] <= 0.0:
                    raise ValueError("theta is nonpositive")
                residuals = {name: np.zeros(1) for name in nge.TARGETS}
                residuals["h1"][0] = unknowns["theta0"][0] / 0.1
                return {
                    "raw_residuals": residuals,
                    "scaled_residuals": {k: v.copy()
                                         for k, v in residuals.items()},
                    "diagnostics": {}, "terminal_distribution": {},
                    "paths": {},
                }

        initial = {name: np.ones(1) for name in nge.UNKNOWNS}
        initial["theta0"][0] = 0.1
        converged, _, _, diagnostics, _ = nge._solve_stage(
            FakeMap(), utils.factor(np.eye(len(nge.UNKNOWNS))), initial, {},
            tolerance=0.01, max_iterations=1,
        )
        self.assertFalse(converged)
        self.assertEqual(diagnostics["accepted_step_sizes"], [0.0625])


@unittest.skipUnless(os.environ.get("RUN_ADAPTED_SLOW_TESTS") == "1",
                     "set RUN_ADAPTED_SLOW_TESTS=1 for the real adapted pickle")
class AdaptedPickleParityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with open("ss_calibration_adapted.pkl", "rb") as file:
            cls.ss = pickle.load(file)
        cls.par = nge.reconstruct_parameters(cls.ss)

    def constant_paths(self, T):
        names = ["ra", "rK", "Z", "tax", "transfer", "sigmaJ",
                 "sigmaslope", *(f"lambda{i}" for i in range(8))]
        paths = {name: np.full(T, self.ss[name]) for name in names}
        paths["bUI"] = np.zeros(T)
        return paths

    def test_one_period_backward_forward_and_reports(self):
        original_beta = self.par["beta"]
        with tempfile.TemporaryDirectory(dir=".") as scratch:
            result = evaluate_dmp_transition(
                self.ss, self.par, self.constant_paths(1),
                scratch_dir=scratch, compute_distributional=True,
            )
            self.assertEqual(os.listdir(scratch), [])
        self.assertEqual(self.par["beta"], original_beta)
        d = result["diagnostics"]
        self.assertLess(d["steady_state_policy_max_error"], 3e-7)
        self.assertLess(d["maximum_distribution_mass_error"], 1e-12)
        self.assertLess(d["terminal_distribution_L1_distance"], 1e-6)
        for key, path in result["aggregates"].items():
            expected = self.ss["AU"] + self.ss["AE"] if key == "A" else self.ss[key]
            self.assertLess(abs(path[0] - expected), 2e-5)

    def test_zero_shock_market_map_and_nonmutation(self):
        with open("Jacobians/Jac_fake_news_adapted.pkl", "rb") as file:
            J = pickle.load(file)["J"]
        ss_keys = set(self.ss)
        par_beta = self.par["beta"]
        ge = nge.NonlinearGEMap(self.ss, self.par, J, 1, scratch_dir=".")
        U = {name: np.full(1, self.ss[name]) for name in nge.UNKNOWNS}
        result = ge.evaluate(U, {})
        self.assertLess(max(nge._max_by_target(
            result["scaled_residuals"]).values()), 5e-5)
        self.assertLess(float(np.max(np.abs(result["paths"]["walras_res"]))),
                        2e-5)
        self.assertEqual(set(self.ss), ss_keys)
        self.assertEqual(self.par["beta"], par_beta)

    def test_two_period_stationarity_and_distributional_constancy(self):
        with tempfile.TemporaryDirectory(dir=".") as scratch:
            result = evaluate_dmp_transition(
                self.ss, self.par, self.constant_paths(2),
                scratch_dir=scratch, compute_distributional=True,
            )
        self.assertLess(max(np.ptp(path) for path in result["aggregates"].values()),
                        5e-5)
        self.assertLess(max(np.ptp(path) for path in result["distributional"].values()),
                        5e-7)

    def test_scratch_cleanup_after_household_exception(self):
        import nonlinear_dmp_adapted as ndmp
        with tempfile.TemporaryDirectory(dir=".") as scratch:
            with mock.patch.object(
                ndmp.Jac_help_adapted, "backward_iterate",
                side_effect=RuntimeError("deliberate test failure"),
            ):
                with self.assertRaises(RuntimeError):
                    evaluate_dmp_transition(
                        self.ss, self.par, self.constant_paths(1),
                        scratch_dir=scratch,
                    )
            self.assertEqual(os.listdir(scratch), [])

    def test_searcher_seed_uses_destination_rung(self):
        cache = fake_news.DmpSteadyStateCache(self.par, self.ss)
        try:
            rung = 3
            XUnew = np.empty_like(self.ss["QUss"])
            XUnew[:] = self.par["gU"][rung]
            XDEE = np.zeros(cache.baseline_flow_reports[2].shape)
            XDEE[:, :, :, :, :, rung, :] = 1.0
            expected = cache.flow_report_transpose(XUnew=XUnew, XDEE=XDEE)
            np.testing.assert_allclose(
                cache.output_functions[f"e{rung}"], expected,
                rtol=0.0, atol=1e-14,
            )

            wrong_origin_seed = np.zeros_like(XDEE)
            wrong_origin_seed[:, :, :, rung, :] = 1.0
            wrong = cache.flow_report_transpose(
                XUnew=XUnew, XDEE=wrong_origin_seed
            )
            self.assertGreater(float(np.max(np.abs(expected - wrong))), 1e-3)
        finally:
            cache.invalidate_expectations()
            cache._expectation_directory.cleanup()

    def test_flow_shock_calendar_timing(self):
        cache = fake_news.DmpSteadyStateCache(self.par, self.ss)
        try:
            h = 1e-5
            curlyY, curlyD = fake_news._backward_news_flow(
                cache, "lambda0", 2, h
            )
            direct_distribution = cache.transition_shock_forward("lambda0")
            np.testing.assert_allclose(
                curlyD[0], direct_distribution, rtol=0.0, atol=1e-14
            )
            for output in fake_news.STOCK_OUTPUTS:
                self.assertAlmostEqual(curlyY[output][0], 0.0, places=14)
            direct_reports = fake_news._flow_reporting_direct_derivatives(
                cache, "lambda0", h
            )
            for output, expected in direct_reports.items():
                self.assertAlmostEqual(
                    curlyY[output][0], expected,
                    delta=max(1e-12, abs(expected) * 1e-12),
                )
        finally:
            cache.invalidate_expectations()
            cache._expectation_directory.cleanup()


@unittest.skipUnless(os.environ.get("RUN_ADAPTED_INTEGRATION_TESTS") == "1",
                     "set RUN_ADAPTED_INTEGRATION_TESTS=1 for transition solves")
class AdaptedTransitionIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with open("ss_calibration_adapted.pkl", "rb") as file:
            cls.ss = pickle.load(file)
        with open("Jacobians/Jac_fake_news_adapted.pkl", "rb") as file:
            cls.J = pickle.load(file)["J"]
        cls.par = nge.reconstruct_parameters(cls.ss)

    def test_four_small_shock_channels(self):
        for shock in ("Z", "transfer", "bUI", "sigmaJ"):
            deviation = np.zeros(4)
            deviation[0] = 1e-6
            result = nge.solve_nonlinear_transition(
                self.ss, self.par, self.J, {shock: deviation}, 4,
                max_iterations=2, homotopy_scales=(), scratch_dir=".",
            )
            self.assertTrue(result["converged"], result["diagnostics"])
            nonlinear_linear_gap = max(
                np.max(np.abs(result["unknowns"][name]
                              - result["linear_initial_guess"][name]))
                for name in nge.UNKNOWNS
            )
            self.assertLess(nonlinear_linear_gap, 2e-5)

    def test_chord_step_reduces_merit_and_failure_is_explicit(self):
        deviation = np.array([0.01, 0.0])
        result = nge.solve_nonlinear_transition(
            self.ss, self.par, self.J, {"Z": deviation}, 2,
            max_iterations=4, homotopy_scales=(), scratch_dir=".",
            terminal_tolerance=0.1, walras_tolerance=0.01,
        )
        self.assertTrue(result["converged"], result["diagnostics"])
        merits = [row["scaled_merit"]
                  for row in result["diagnostics"]["residual_history"]]
        self.assertTrue(all(b < a for a, b in zip(merits, merits[1:])))

        invalid = {name: np.full(2, self.ss[name]) for name in nge.UNKNOWNS}
        invalid["theta0"][:] = -1.0
        failed = nge.solve_nonlinear_transition(
            self.ss, self.par, self.J, {}, 2, initial_guess=invalid,
            max_iterations=1, homotopy_scales=(), scratch_dir=".",
        )
        self.assertFalse(failed["converged"])
        self.assertIn("invalid", failed["diagnostics"]["failure_reason"])

    def test_early_window_horizon_comparison(self):
        shock = np.zeros(3)
        shock[0] = 1e-6
        comparison = nge.compare_horizons(
            self.ss, self.par, self.J, {"Z": shock}, 2, 3, 1,
            max_iterations=2, homotopy_scales=(), scratch_dir=".",
        )
        self.assertTrue(comparison["T1"]["converged"])
        self.assertTrue(comparison["T2"]["converged"])
        self.assertLess(comparison["maximum_reporting_window_error"], 2e-5)


if __name__ == "__main__":
    unittest.main(verbosity=2)
