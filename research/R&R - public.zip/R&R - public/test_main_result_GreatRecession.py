"""Focused tests for the adapted Great Recession experiment."""

from __future__ import annotations

import os
from pathlib import Path
import pickle
import sys
import tempfile
import unittest
from datetime import datetime

import numpy as np

from distributional_moments_adapted import (
    current_wealth_moments, worker_asset_quantile_weights,
)
import main_result_GreatRecession as gr
import nonlinear_ge_adapted as nge
from nonlinear_dmp_adapted import INPUTS as DMP_INPUTS, evaluate_dmp_transition


def synthetic_mappings():
    horizon = gr.TT
    active = gr.ACTIVE_PERIODS
    earnings_chi = np.zeros((horizon, horizon))
    earnings_drate = np.zeros((horizon, horizon))
    unemployment_chi = np.zeros((horizon, horizon))
    unemployment_drate = np.zeros((horizon, horizon))
    earnings_chi[1:active, :active - 1] = np.eye(active - 1)
    unemployment_drate[1:active, :active - 1] = np.eye(active - 1)
    return {
        "earnings": {"chi": earnings_chi, "drate": earnings_drate},
        "U": {"chi": unemployment_chi, "drate": unemployment_drate},
    }


class GreatRecessionDataTests(unittest.TestCase):
    @staticmethod
    def quarterly_dates(count=24):
        dates = []
        for offset in range(count):
            month_index = offset * 3
            value = datetime(
                2008 + month_index // 12, month_index % 12 + 1, 1
            )
            dates.append(f"{value.month}/{value.day}/{value.year}")
        return np.array(dates)

    def test_targets_use_requested_sources_scaling_and_cap(self):
        months = np.arange(-12, 77)
        earnings_percent = -months.astype(float) / 10.0
        earnings_percent[months == 0] = 0.0
        earnings_percent[months == 6] = 2.0
        unemployment = np.linspace(5.0, 10.0, 24)
        result = gr.construct_quarterly_targets(
            months, earnings_percent, self.quarterly_dates(), unemployment, 2.5
        )
        self.assertEqual(result["earnings_target"].shape, (gr.ACTIVE_PERIODS,))
        self.assertEqual(result["unemployment_target"].shape, (gr.ACTIVE_PERIODS,))
        self.assertEqual(result["earnings_target"][0], 0.0)
        self.assertEqual(result["unemployment_target"][0], 0.0)
        np.testing.assert_array_equal(
            result["earnings_months_since_peak"],
            np.arange(0, 3 * gr.ACTIVE_PERIODS, 3),
        )
        self.assertEqual(result["earnings_percent_deviation_raw"][2], 2.0)
        self.assertEqual(
            result["earnings_percent_deviation_capped_observed"][2], 0.0
        )
        self.assertAlmostEqual(result["earnings_target"][1], 2.5 * -0.3 / 100.0)
        self.assertEqual(result["unemployment_target_original_observed"][-1], 0.05)
        self.assertEqual(result["earnings_target"][-1], 0.0)
        self.assertEqual(result["unemployment_target"][-1], 0.0)
        self.assertTrue(np.all(np.diff(result["unemployment_target"][23:]) <= 0.0))
        self.assertEqual(result["earnings_positive_values_capped"], 1)
        self.assertEqual(result["unemployment_dates"][0], "2008-01-01")

    def test_earnings_selection_rejects_missing_month_or_nonfinite(self):
        months = np.arange(70)
        with self.assertRaisesRegex(ValueError, "exactly 24"):
            gr.construct_quarterly_targets(
                months[months != 69], np.zeros(69), self.quarterly_dates(),
                np.full(24, 5.0), 1.0,
            )
        earnings = np.zeros(70)
        earnings[6] = np.nan
        with self.assertRaisesRegex(ValueError, "finite"):
            gr.construct_quarterly_targets(
                months, earnings, self.quarterly_dates(),
                np.full(24, 5.0), 1.0,
            )

    def test_unemployment_rejects_bad_baseline_and_nonquarterly_dates(self):
        months = np.arange(70)
        with self.assertRaisesRegex(ValueError, "must equal 5%"):
            gr.construct_quarterly_targets(
                months, np.zeros(70), self.quarterly_dates(),
                np.full(24, 5.1), 1.0,
            )
        dates = self.quarterly_dates()
        dates[3] = "11/1/2008"
        with self.assertRaisesRegex(ValueError, "advance by one quarter"):
            gr.construct_quarterly_targets(
                months, np.zeros(70), dates, np.full(24, 5.0), 1.0,
            )

    def test_missing_post_recovery_earnings_are_filled_at_steady_state(self):
        months = np.arange(70)
        earnings = np.full(70, -1.0)
        earnings[0] = 0.0
        earnings[37:49] = 0.1
        earnings[49:] = np.nan
        result = gr.construct_quarterly_targets(
            months, earnings, self.quarterly_dates(),
            np.full(24, 5.0), 1.0,
        )
        self.assertEqual(result["earnings_first_positive_observed_month"], 37)
        self.assertEqual(result["earnings_missing_post_recovery_filled"], 7)
        np.testing.assert_array_equal(
            result["earnings_target_smoothed_observed"][17:], 0.0
        )


class GreatRecessionIdentificationTests(unittest.TestCase):
    def test_shorter_shock_window_has_an_exact_zero_tail(self):
        G = synthetic_mappings()
        shock_periods = 24
        earnings = np.zeros(gr.ACTIVE_PERIODS)
        unemployment = np.zeros(gr.ACTIVE_PERIODS)
        earnings[1:shock_periods + 1] = -0.01
        unemployment[shock_periods + 1:] = 0.01
        matrix, vector = gr.build_identification_system(
            G, earnings, unemployment, shock_names=("chi", "drate"),
            shock_periods=shock_periods,
        )
        self.assertEqual(matrix.shape, (62, 48))
        self.assertEqual(vector.shape, (62,))
        identified = gr.identify_bounded_shocks(
            G, earnings, unemployment, 0.2, 0.025,
            shock_names=("chi", "drate"), shock_periods=shock_periods,
        )
        for path in identified["deviations"].values():
            self.assertTrue(np.all(path[shock_periods:] == 0.0))
        self.assertGreater(
            identified["diagnostics"]["unemployment_max_absolute_fit_error"],
            0.0,
        )

    def test_square_equation_layout_omits_both_time_zero_outcomes(self):
        G = synthetic_mappings()
        active = gr.ACTIVE_PERIODS
        n_shock = active - 1
        G["U"]["chi"][0, :] = 777.0
        G["earnings"]["drate"][0, :] = 888.0
        earnings = np.arange(float(active))
        unemployment = np.arange(float(active)) / 100.0
        matrix, vector = gr.build_identification_system(
            G, earnings, unemployment, shock_names=("chi", "drate")
        )
        self.assertEqual(matrix.shape, (2 * n_shock, 2 * n_shock))
        self.assertEqual(vector.shape, (2 * n_shock,))
        np.testing.assert_array_equal(
            matrix[0], np.concatenate((
                G["earnings"]["chi"][1:active, :n_shock][0],
                G["earnings"]["drate"][1:active, :n_shock][0],
            ))
        )
        np.testing.assert_array_equal(
            matrix[n_shock], np.concatenate((
                G["U"]["chi"][1, :n_shock], G["U"]["drate"][1, :n_shock]
            ))
        )
        self.assertFalse(np.any(matrix == 777.0))
        self.assertFalse(np.any(matrix == 888.0))
        np.testing.assert_array_equal(vector[:n_shock], earnings[1:])
        np.testing.assert_array_equal(vector[n_shock:], unemployment[1:])

    def test_exact_synthetic_recovery_and_exact_zero_tail(self):
        G = synthetic_mappings()
        n_shock = gr.ACTIVE_PERIODS - 1
        chi = np.linspace(-0.02, 0.02, n_shock)
        drate = np.linspace(-0.005, 0.005, n_shock)
        earnings = np.zeros(gr.ACTIVE_PERIODS)
        earnings[1:] = chi
        unemployment = np.zeros(gr.ACTIVE_PERIODS)
        unemployment[1:] = drate
        result = gr.identify_bounded_shocks(
            G, earnings, unemployment, chi_steady_state=0.2,
            drate_steady_state=0.025,
            shock_names=("chi", "drate"),
        )
        np.testing.assert_allclose(result["chi_deviation"][:n_shock], chi,
                                   rtol=0.0, atol=1e-12)
        np.testing.assert_allclose(result["drate_deviation"][:n_shock], drate,
                                   rtol=0.0, atol=1e-12)
        self.assertTrue(np.all(result["chi_deviation"][n_shock:] == 0.0))
        self.assertTrue(np.all(result["drate_deviation"][n_shock:] == 0.0))
        self.assertEqual(result["chi_deviation"][n_shock], 0.0)
        self.assertEqual(result["drate_deviation"][n_shock], 0.0)
        self.assertLess(result["diagnostics"]["earnings_max_absolute_fit_error"],
                        1e-14)
        self.assertLess(
            result["diagnostics"]["unemployment_max_absolute_fit_error"], 1e-14
        )

    def test_rank_deficiency_fails_without_regularization(self):
        G = synthetic_mappings()
        G["earnings"]["chi"][:] = 0.0
        with self.assertRaisesRegex(gr.ShockIdentificationError,
                                    "rank deficient"):
            gr.identify_bounded_shocks(
                G, np.zeros(gr.ACTIVE_PERIODS), np.zeros(gr.ACTIVE_PERIODS),
                chi_steady_state=0.2, drate_steady_state=0.025,
                shock_names=("chi", "drate"),
            )

    def test_infeasible_exact_fit_respects_economic_bounds(self):
        G = synthetic_mappings()
        earnings = np.zeros(gr.ACTIVE_PERIODS)
        unemployment = np.zeros(gr.ACTIVE_PERIODS)
        unemployment[1:] = 2.0
        result = gr.identify_bounded_shocks(
            G, earnings, unemployment, chi_steady_state=0.2,
            drate_steady_state=0.025,
            shock_names=("chi", "drate"),
        )
        self.assertGreater(np.min(result["chi_levels"]), 0.0)
        self.assertGreater(np.min(result["drate_levels"]), 0.0)
        self.assertLess(np.max(result["drate_levels"]), 1.0)
        self.assertGreater(
            result["diagnostics"]["unemployment_max_absolute_fit_error"],
            0.0,
        )
        self.assertGreater(result["diagnostics"]["active_bound_count"], 0)

    def test_configurable_shock_pair_uses_named_paths(self):
        G = synthetic_mappings()
        for output in ("earnings", "U"):
            G[output]["Z"] = G[output]["chi"].copy()
            G[output]["sigmaJ"] = G[output]["drate"].copy()
        n_shock = gr.ACTIVE_PERIODS - 1
        chi = np.linspace(-0.01, 0.01, n_shock)
        sep = np.linspace(-0.005, 0.005, n_shock)
        earnings = np.zeros(gr.ACTIVE_PERIODS)
        unemployment = np.zeros(gr.ACTIVE_PERIODS)
        earnings[1:] = chi
        unemployment[1:] = sep
        result = gr.identify_bounded_shocks(
            G, earnings, unemployment, 1.0, 0.02,
            shock_names=("Z", "sigmaJ"),
            shock_steady_states={"Z": 1.0, "sigmaJ": 0.02},
            shock_level_bounds={"Z": (1e-10, np.inf), "sigmaJ": (1e-10, 1.0)},
        )
        self.assertEqual(set(result["deviations"]), {"Z", "sigmaJ"})
        self.assertTrue(np.all(result["deviations"]["Z"][n_shock:] == 0.0))
        self.assertTrue(np.all(result["deviations"]["sigmaJ"][n_shock:] == 0.0))


class WealthMomentTests(unittest.TestCase):
    def setUp(self):
        self.DU = np.zeros((1, 3, 1))
        self.DU[0, 2, 0] = 2.0
        self.DE = np.zeros((1, 3, 2, 1, 1, 1))
        self.DE[0, 0, :, 0, 0, 0] = (1.0, 3.0)
        self.DE[0, 1, :, 0, 0, 0] = (2.0, 2.0)
        self.DEE = np.zeros((1, 3, 2, 1, 1, 1, 1))
        self.DEE[0, 0, :, 0, 0, 0, 0] = (1.0, 3.0)
        self.DEE[0, 1, :, 0, 0, 0, 0] = (2.0, 6.0)
        self.q = np.full(self.DEE.shape, 0.5)
        self.wages = np.array([1.0, 4.0])
        self.assets = np.array([0.0, 5.0, 10.0])

    def test_median_uses_employed_plus_unemployed_and_splits_boundary(self):
        split = worker_asset_quantile_weights(self.DU, self.DE)
        np.testing.assert_allclose(split["mass_by_asset"], (4.0, 4.0, 2.0))
        self.assertEqual(split["median_asset_index"], 1)
        self.assertAlmostEqual(split["median_boundary_fraction"], 0.25)
        self.assertAlmostEqual(split["low"] @ split["mass_by_asset"], 5.0)
        self.assertAlmostEqual(split["high"] @ split["mass_by_asset"], 5.0)

    def test_employment_wage_bill_and_ee_flow_aggregate(self):
        moments = current_wealth_moments(
            self.DU, self.DE, self.DEE, self.q, self.wages, self.assets
        )
        self.assertAlmostEqual(moments["wealth_worker_mass_low"], 5.0)
        self.assertAlmostEqual(moments["wealth_worker_mass_high"], 5.0)
        self.assertAlmostEqual(moments["wealth_employment_mass_low"], 5.0)
        self.assertAlmostEqual(moments["wealth_employment_mass_high"], 3.0)
        self.assertAlmostEqual(moments["wealth_wage_bill_low"], 15.5)
        self.assertAlmostEqual(moments["wealth_wage_bill_high"], 7.5)
        self.assertAlmostEqual(
            moments["wealth_wage_bill_low"] + moments["wealth_wage_bill_high"],
            moments["wealth_aggregate_wage_bill"],
        )
        self.assertAlmostEqual(moments["wealth_EE_flow_low"], 3.0)
        self.assertAlmostEqual(moments["wealth_EE_flow_high"], 3.0)
        self.assertAlmostEqual(
            moments["wealth_EE_flow_low"] + moments["wealth_EE_flow_high"],
            moments["wealth_aggregate_EE_flow"],
        )
        self.assertAlmostEqual(
            moments["EE_rate_low_wealth"]
            * moments["wealth_employment_mass_low"],
            3.0,
        )
        self.assertNotAlmostEqual(moments["wealth_EE_flow_low"], 2.25)
        self.assertLessEqual(moments["wealth_wage_bill_aggregation_error"], 1e-14)
        self.assertLessEqual(moments["wealth_EE_flow_aggregation_error"], 1e-14)


RUN_REAL = (
    os.environ.get("RUN_GREAT_RECESSION_INTEGRATION_TESTS") == "1"
    and sys.version_info >= (3, 14)
    and Path("ss_calibration_adapted.pkl").exists()
    and Path("Jacobians/Jac_fake_news_adapted.pkl").exists()
)


@unittest.skipUnless(
    RUN_REAL,
    "set RUN_GREAT_RECESSION_INTEGRATION_TESTS=1 under Python 3.14",
)
class GreatRecessionRealIntegrationTests(unittest.TestCase):
    def test_real_transition_convergence_and_validity(self):
        with open("ss_calibration_adapted.pkl", "rb") as file:
            ss = pickle.load(file)
        with open("Jacobians/Jac_fake_news_adapted.pkl", "rb") as file:
            J = pickle.load(file)["J"]
        par = nge.reconstruct_parameters(ss)
        shocks = {"chi": np.zeros(2), "drate": np.zeros(2)}
        with tempfile.TemporaryDirectory(dir=".") as scratch:
            solution = nge.solve_nonlinear_transition(
                ss, par, J, shocks, 2, scratch_dir=scratch,
                terminal_tail=1, tolerance=gr.SOLVER_TOLERANCE,
                terminal_tolerance=gr.TERMINAL_TOLERANCE,
                walras_tolerance=gr.WALRAS_TOLERANCE,
            )
        diagnostics = solution["diagnostics"]
        self.assertTrue(solution["converged"], diagnostics)
        self.assertTrue(diagnostics["market_converged"])
        self.assertLessEqual(
            diagnostics["terminal_diagnostics"]["walras_max_residual"],
            gr.WALRAS_TOLERANCE,
        )
        dmp_paths = {
            name: solution["paths"][name]
            for name in DMP_INPUTS if name in solution["paths"]
        }
        with tempfile.TemporaryDirectory(dir=".") as scratch:
            dmp = evaluate_dmp_transition(
                ss, par, dmp_paths, scratch_dir=scratch,
                compute_distributional=True,
            )
        household = dmp["diagnostics"]
        self.assertLessEqual(household["maximum_distribution_mass_error"], 1e-9)
        self.assertGreaterEqual(household["minimum_distribution_entry"], -1e-12)
        self.assertLessEqual(
            household["terminal_distribution_L1_distance"],
            gr.TERMINAL_TOLERANCE,
        )
        for shock in shocks.values():
            self.assertEqual(shock[-1], 0.0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
