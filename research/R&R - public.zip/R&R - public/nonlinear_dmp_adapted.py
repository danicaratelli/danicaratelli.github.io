"""Exact nonlinear perfect-foresight evaluator for the adapted DMP block."""

from __future__ import annotations

import os
from contextlib import ExitStack
from pathlib import Path
import shutil
import tempfile
import time

import numpy as np
from numpy.lib.format import open_memmap

import Jac_help_adapted
import utils
from distributional_moments_adapted import (
    current_earnings_moments,
    current_wealth_moments,
    stack_moment_history,
)


INPUTS = (
    "ra", "rK", "Z", "tax", "transfer", "bUI",
    *(f"lambda{i}" for i in range(8)), "sigmaJ", "sigmaslope",
)
OUTPUTS = (
    "A", "C", "U", "N", "EE_rate", "EU_rate", "Tax", "earnings",
    "Ubill", "Pi", "A_pre", "AU", "AE", "AU_pre", "AE_pre", "CU",
    "CE", *(f"e{i}" for i in range(8)), *(f"J0_{i}" for i in range(8)),
)
CONTINUATIONS = ("cU", "cE", "U", "E", "Eb", "dEb", "J", "Jb")
STORED_POLICIES = (
    "cU", "cE", "aU", "aE", "JU0", "JE0", "q", "wU_i", "wU_pi",
    "wEwin_i", "wEwin_pi", "wElose_i", "wElose_pi", "Iwin",
)
BACKWARD_NAMES = (
    "cU", "cE", "U", "E", "Eb", "dEb", "aU", "aE", "J", "Jb",
    "JU0", "JE0", "q", "wU_i", "wU_pi", "wEwin_i", "wEwin_pi",
    "wElose_i", "wElose_pi", "Iwin",
)


class DMPTransitionError(RuntimeError):
    """A transition candidate failed household or distribution feasibility."""


def _path(value, name, T, default):
    if value is None:
        out = np.full(T, default, dtype=np.float64)
    else:
        out = np.asarray(value, dtype=np.float64)
        if out.shape != (T,):
            raise ValueError(f"{name} must have shape {(T,)}, got {out.shape}")
        out = out.copy()
    if not np.isfinite(out).all():
        raise ValueError(f"{name} contains nonfinite values")
    return out


def _infer_T(paths):
    lengths = {np.asarray(value).shape for value in paths.values()
               if value is not None}
    if not lengths:
        raise ValueError("at least one input path is required to infer T")
    if len(lengths) != 1:
        raise ValueError(f"all DMP paths must have a common shape, got {lengths}")
    shape = lengths.pop()
    if len(shape) != 1 or shape[0] <= 0:
        raise ValueError("DMP inputs must be nonempty one-dimensional paths")
    return shape[0]


def _prepare_paths(ss, paths, T):
    prepared = {}
    for name in ("ra", "rK", "Z", "tax", "transfer", "sigmaJ"):
        prepared[name] = _path(paths.get(name), name, T, float(ss[name]))
    prepared["sigmaslope"] = _path(
        paths.get("sigmaslope"), "sigmaslope", T,
        float(ss.get("sigmaslope", 0.0)),
    )
    prepared["bUI"] = _path(paths.get("bUI"), "bUI", T, 0.0)
    for i in range(8):
        name = f"lambda{i}"
        prepared[name] = _path(paths.get(name), name, T, float(ss[name]))
    prepared["lambdas"] = np.column_stack(
        [prepared[f"lambda{i}"] for i in range(8)]
    )
    prepared["bUI_by_type"] = (
        np.asarray([ss["bUIL"], ss["bUIH"]], dtype=np.float64)[None, :]
        + prepared["bUI"][:, None]
    )
    return prepared


def _append_terminal(path, terminal):
    return np.concatenate((np.asarray(path, dtype=np.float64),
                           np.asarray(terminal, dtype=np.float64).reshape(1, *np.shape(terminal))))


def _stored_examples(ss):
    return {
        "cU": np.asarray(ss["CUss"])[..., 0],
        "cE": np.asarray(ss["CEss"])[..., 0],
        "aU": np.asarray(ss["AUss"])[..., 0],
        "aE": np.asarray(ss["AEss"])[..., 0],
        "JU0": np.asarray(ss["JU0s"])[..., 0],
        "JE0": np.asarray(ss["JE0s"])[..., 0],
        "q": np.asarray(ss["qss"])[..., 0],
        "wU_i": np.asarray(ss["WUiss"])[..., 0],
        "wU_pi": np.asarray(ss["WUpiss"])[..., 0],
        "wEwin_i": np.asarray(ss["WEwiniss"])[..., 0],
        "wEwin_pi": np.asarray(ss["WEwinpiss"])[..., 0],
        "wElose_i": np.asarray(ss["WEloseiss"])[..., 0],
        "wElose_pi": np.asarray(ss["WElosepiss"])[..., 0],
        "Iwin": np.asarray(ss["Iwins"])[..., 0],
    }


def _estimate_policy_bytes(T, ss):
    examples = _stored_examples(ss)
    bytes_per_type_period = 0
    for name, value in examples.items():
        if name == "Iwin":
            itemsize = np.dtype(np.bool_).itemsize
        elif name.endswith("_i"):
            itemsize = value.dtype.itemsize
        else:
            itemsize = np.dtype(np.float64).itemsize
        bytes_per_type_period += int(value.size) * itemsize
    return T * int(np.asarray(ss["QUss"]).shape[-1]) * bytes_per_type_period


class _PolicyStore:
    def __init__(self, directory, T, ss):
        self.arrays = {}
        nB = np.asarray(ss["QUss"]).shape[-1]
        try:
            for name, sample in _stored_examples(ss).items():
                if name == "Iwin":
                    dtype = np.bool_
                elif name.endswith("_i"):
                    dtype = sample.dtype
                else:
                    dtype = np.float64
                self.arrays[name] = open_memmap(
                    Path(directory) / f"{name}.npy", mode="w+", dtype=dtype,
                    shape=(T, nB, *sample.shape),
                )
        except Exception:
            self.close()
            raise

    def put(self, t, ib, output):
        for name, mmap in self.arrays.items():
            value = np.asarray(output[name])
            if value.shape != mmap.shape[2:]:
                raise DMPTransitionError(
                    f"policy {name} has shape {value.shape}, expected {mmap.shape[2:]}"
                )
            if name == "Iwin":
                # The adapted calibration uses -1 as a legacy sentinel for the
                # same branch as zero; forward_step_dmp_td only tests ``== 1``.
                # Canonicalize that on disk so the transition store is Boolean.
                if not np.all((value == -1) | (value == 0) | (value == 1)):
                    raise DMPTransitionError(
                        "Iwin contains values outside the adapted {-1,0,1} encoding"
                    )
                value = value == 1
            elif name.endswith("_i"):
                if not np.issubdtype(value.dtype, np.integer):
                    raise DMPTransitionError(
                        f"wage index {name} must have an integer dtype"
                    )
                if np.min(value) < 0 or np.max(value) > np.iinfo(mmap.dtype).max:
                    raise DMPTransitionError(f"wage index {name} is out of range")
            mmap[t, ib] = value

    def get(self, t, ib):
        return {name: mmap[t, ib] for name, mmap in self.arrays.items()}

    def flush(self):
        for mmap in self.arrays.values():
            mmap.flush()

    def close(self):
        for mmap in self.arrays.values():
            mmap.flush()
            if getattr(mmap, "_mmap", None) is not None:
                mmap._mmap.close()
        self.arrays.clear()


def _sigma(par, sigmaJ, sigmaslope):
    base = np.asarray(par["sigma"], dtype=np.float64)
    return (base + (sigmaJ - base[-1])) * (1.0 + sigmaslope)


def _probability_violation(x):
    x = np.asarray(x)
    if not np.isfinite(x).all():
        raise DMPTransitionError("probability array contains nonfinite values")
    return float(max(0.0, -np.min(x), np.max(x) - 1.0))


def _profit_weight(par, Z, rK):
    k_little = (rK / (par["alpha"] * Z)) ** (1.0 / (par["alpha"] - 1.0))
    efficiency = par["z_grid"][:, None, None] * par["p_grid"][None, None, :]
    flow = (efficiency * (Z * utils.f(k_little, par) - rK * k_little)
            - par["w_grid"][None, :, None])
    return flow[:, None, :, :, None, None]


def evaluate_dmp_transition(ss, par, paths, scratch_dir=None,
                            compute_distributional=False,
                            retain_distribution=False):
    """Evaluate the exact adapted household problem backward and forward."""
    T = _infer_T(paths)
    pth = _prepare_paths(ss, paths, T)
    nB = int(par["nB"])
    if nB != 2:
        raise ValueError("adapted transition currently requires two beta types")
    if par.get("case4_derivative_mode") != "partial":
        raise ValueError("par['case4_derivative_mode'] must equal 'partial'")
    if np.min(1.0 + pth["ra"]) <= 0.0:
        raise DMPTransitionError("1 + ra must be strictly positive")
    if np.min(pth["Z"]) <= 0.0:
        raise DMPTransitionError("Z must be strictly positive")

    extended = {
        name: _append_terminal(pth[name], ss[name])
        for name in ("ra", "rK", "Z", "tax", "transfer", "sigmaJ", "sigmaslope")
    }
    extended["lambdas"] = np.vstack((pth["lambdas"], np.asarray(ss["lambdas"])))
    extended["bUI_by_type"] = np.vstack((
        pth["bUI_by_type"], np.asarray([ss["bUIL"], ss["bUIH"]])
    ))

    prob_violation = max(
        _probability_violation(pth["lambdas"]),
        *(_probability_violation(_sigma(par, pth["sigmaJ"][t],
                                       pth["sigmaslope"][t])) for t in range(T)),
    )
    if prob_violation > 1e-10:
        raise DMPTransitionError(
            f"exogenous transition probability violation is {prob_violation:.3e}"
        )
    required_bytes = _estimate_policy_bytes(T, ss)
    parent = Path(scratch_dir) if scratch_dir is not None else None
    if parent is not None:
        parent.mkdir(parents=True, exist_ok=True)
    disk_root = parent if parent is not None else Path(tempfile.gettempdir())
    free_bytes = shutil.disk_usage(disk_root).free
    if required_bytes > 0.9 * free_bytes:
        raise OSError(
            f"adapted policy store needs about {required_bytes / 2**30:.2f} GiB "
            f"but only {free_bytes / 2**30:.2f} GiB is free in {disk_root}"
        )

    start_backward = time.perf_counter()
    minimum_consumption = np.inf
    policy_ss_max_error = 0.0
    policy_ss_path_max_error = 0.0
    iwin_legacy_sentinel_count = 0
    is_steady_input_path = (
        all(np.array_equal(pth[name], np.full(T, ss[name]))
            for name in ("ra", "rK", "Z", "tax", "transfer", "sigmaJ",
                         "sigmaslope"))
        and np.array_equal(pth["lambdas"],
                           np.broadcast_to(ss["lambdas"], (T, 8)))
        and np.array_equal(pth["bUI"], np.zeros(T))
    )
    with ExitStack() as resources:
        tmp = resources.enter_context(tempfile.TemporaryDirectory(
            prefix="nonlinear-dmp-adapted-", dir=parent
        ))
        store = _PolicyStore(tmp, T, ss)
        resources.callback(store.close)
        continuation = []
        for ib in range(nB):
            continuation.append({
                "cU": np.asarray(ss["CUss"])[..., ib].copy(),
                "cE": np.asarray(ss["CEss"])[..., ib].copy(),
                "U": np.asarray(ss["Uss"])[..., ib].copy(),
                "E": np.asarray(ss["Ess"])[..., ib].copy(),
                "Eb": np.asarray(ss["Ebargainingss"])[..., ib].copy(),
                "dEb": np.asarray(ss["dEbargainingss"])[..., ib].copy(),
                "J": np.asarray(ss["Jss"])[..., ib].copy(),
                "Jb": np.asarray(ss["Jbargainingss"])[..., ib].copy(),
            })

        for t in range(T - 1, -1, -1):
            for ib in range(nB):
                local_par = par.copy()
                local_par["beta"] = par["beta"] + (2 * ib - 1) * par["dbeta"]
                c = continuation[ib]
                values = Jac_help_adapted.backward_iterate(
                    extended["ra"][t + 1], extended["ra"][t],
                    extended["rK"][t], extended["Z"][t],
                    extended["tax"][t], extended["lambdas"][t + 1],
                    extended["bUI_by_type"][t, ib],
                    extended["sigmaJ"][t + 1], extended["sigmaslope"][t + 1],
                    extended["transfer"][t], c["cU"], c["cE"], c["U"],
                    c["E"], c["Eb"], c["dEb"], c["J"], c["Jb"], local_par,
                )
                output = dict(zip(BACKWARD_NAMES, values))
                if not all(np.isfinite(np.asarray(value)).all()
                           for value in output.values()):
                    raise DMPTransitionError(
                        f"nonfinite household output at t={t}, beta type={ib}"
                    )
                iwin_legacy_sentinel_count += int(np.count_nonzero(
                    np.asarray(output["Iwin"]) == -1
                ))
                minimum_consumption = min(
                    minimum_consumption, float(np.min(output["cU"])),
                    float(np.min(output["cE"])),
                )
                for name in ("q", "wU_pi", "wEwin_pi", "wElose_pi"):
                    prob_violation = max(prob_violation,
                                         _probability_violation(output[name]))
                if minimum_consumption <= 0.0:
                    raise DMPTransitionError("household consumption is nonpositive")
                if prob_violation > 1e-8:
                    raise DMPTransitionError(
                        f"household probability violation is {prob_violation:.3e}"
                    )
                store.put(t, ib, output)
                continuation[ib] = {name: np.asarray(output[name]).copy()
                                    for name in CONTINUATIONS}
                if is_steady_input_path:
                    ss_keys = {"cU": "CUss", "cE": "CEss", "aU": "AUss",
                               "aE": "AEss", "JU0": "JU0s", "JE0": "JE0s",
                               "q": "qss", "wU_i": "WUiss", "wU_pi": "WUpiss",
                               "wEwin_i": "WEwiniss", "wEwin_pi": "WEwinpiss",
                               "wElose_i": "WEloseiss", "wElose_pi": "WElosepiss",
                               "Iwin": "Iwins"}
                    for name, key in ss_keys.items():
                        current_value = (np.asarray(output[name]) == 1
                                         if name == "Iwin"
                                         else np.asarray(output[name]))
                        stored_value = (np.asarray(ss[key])[..., ib] == 1
                                        if name == "Iwin"
                                        else np.asarray(ss[key])[..., ib])
                        if name == "Iwin":
                            difference = np.not_equal(current_value, stored_value)
                        else:
                            difference = np.abs(current_value - stored_value)
                        error = float(np.max(difference))
                        policy_ss_path_max_error = max(policy_ss_path_max_error,
                                                       error)
                        if t == T - 1:
                            policy_ss_max_error = max(policy_ss_max_error, error)
        store.flush()
        backward_runtime = time.perf_counter() - start_backward

        start_forward = time.perf_counter()
        DU = np.asarray(ss["QUss"], dtype=np.float64).copy()
        DE = np.asarray(ss["QEss"], dtype=np.float64).copy()
        initial_DU, initial_DE = DU.copy(), DE.copy()
        aggregates = {name: np.empty(T) for name in OUTPUTS}
        moment_history = []
        retained = [] if retain_distribution else None
        max_mass_error = abs(float(DU.sum() + DE.sum()) - 1.0)
        min_distribution = min(float(DU.min()), float(DE.min()))

        asset_u = par["a_grid"][None, :, None]
        asset_e = par["a_grid"][None, :, None, None, None, None]
        wage_e = par["w_grid"][None, None, :, None, None, None]
        efficiency = (par["z_grid"][:, None, None, None, None, None]
                      * par["p_grid"][None, None, None, :, None, None])

        for t in range(T):
            policies = [store.get(t, ib) for ib in range(nB)]
            aU = np.stack([x["aU"] for x in policies], axis=-1)
            aE = np.stack([x["aE"] for x in policies], axis=-1)
            cU = np.stack([x["cU"] for x in policies], axis=-1)
            cE = np.stack([x["cE"] for x in policies], axis=-1)
            q = np.stack([x["q"] for x in policies], axis=-1)
            JU0 = np.stack([x["JU0"] for x in policies], axis=-1)
            JE0 = np.stack([x["JE0"] for x in policies], axis=-1)
            employed_mass = float(DE.sum())
            wage_bill = float(np.sum(DE * wage_e))
            aggregates["AU"][t] = np.sum(DU * aU)
            aggregates["AE"][t] = np.sum(DE * aE)
            aggregates["CU"][t] = np.sum(DU * cU)
            aggregates["CE"][t] = np.sum(DE * cE)
            aggregates["A"][t] = aggregates["AU"][t] + aggregates["AE"][t]
            aggregates["C"][t] = aggregates["CU"][t] + aggregates["CE"][t]
            aggregates["U"][t] = DU.sum()
            aggregates["N"][t] = np.sum(DE * efficiency)
            aggregates["AU_pre"][t] = np.sum(DU * asset_u)
            aggregates["AE_pre"][t] = np.sum(DE * asset_e)
            aggregates["A_pre"][t] = (aggregates["AU_pre"][t]
                                        + aggregates["AE_pre"][t])
            aggregates["Tax"][t] = pth["tax"][t] * wage_bill
            aggregates["earnings"][t] = wage_bill / employed_mass
            aggregates["Ubill"][t] = (
                DU.sum(axis=(0, 1)) @ pth["bUI_by_type"][t]
            )
            aggregates["Pi"][t] = np.sum(
                DE * _profit_weight(par, pth["Z"][t], pth["rK"][t])
            )
            sigma_t = _sigma(par, pth["sigmaJ"][t], pth["sigmaslope"][t])
            aggregates["EU_rate"][t] = np.sum(
                DE * sigma_t[None, None, None, None, :, None]
            ) / employed_mass

            DU_next = np.empty_like(DU)
            DE_next = np.empty_like(DE)
            DUE = np.empty((par["nZ"], par["nA"], par["nP"], nB))
            DEE = np.empty((*q.shape[:-1], nB))
            for ib, policy in enumerate(policies):
                pol_i, pol_pi = {}, {}
                pol_i["aU"], pol_pi["aU"] = utils.interpolate_coord_robust(
                    par["a_grid"], policy["aU"])
                pol_i["aE"], pol_pi["aE"] = utils.interpolate_coord_robust(
                    par["a_grid"], policy["aE"])
                w_i = {"U": policy["wU_i"], "Ewin": policy["wEwin_i"],
                       "Elose": policy["wElose_i"]}
                w_pi = {"U": policy["wU_pi"], "Ewin": policy["wEwin_pi"],
                        "Elose": policy["wElose_pi"]}
                prob_violation = max(
                    prob_violation, _probability_violation(pol_pi["aU"]),
                    _probability_violation(pol_pi["aE"]),
                )
                result = utils.forward_step_dmp_td(
                    DU[..., ib], DE[..., ib], pol_i, pol_pi, w_i, w_pi,
                    policy["Iwin"], policy["q"], pth["lambdas"][t],
                    pth["sigmaJ"][t], pth["sigmaslope"][t], par,
                )
                DU_next[..., ib], DE_next[..., ib], DUE[..., ib], DEE[..., ib] = result

            aggregates["EE_rate"][t] = np.sum(DEE * q) / employed_mass
            searchers = (par["gU"] * DU_next.sum()
                         + DEE.sum(axis=(0, 1, 2, 3, 4, 6)))
            due_total = float(DUE.sum())
            if due_total <= 0.0:
                raise DMPTransitionError("U-to-E flow denominator is nonpositive")
            for rung in range(8):
                aggregates[f"e{rung}"][t] = searchers[rung]
                ju = np.sum(JU0[:, :, rung, :] * DUE[:, :, rung, :]) / due_total
                switch = DEE[:, :, :, :, :, rung, :]
                switch_mass = float(switch.sum())
                if switch_mass == 0.0 and rung != 0:
                    raise DMPTransitionError(
                        f"structurally absent switch denominator for J0_{rung}"
                    )
                je = (np.sum(JE0[:, :, :, :, :, rung, :] * switch) / switch_mass
                      if switch_mass else 0.0)
                aggregates[f"J0_{rung}"][t] = ju + je

            if compute_distributional:
                wage_moments = current_earnings_moments(
                    DE, DEE, q, sigma_t, par["w_grid"]
                )
                wealth_moments = current_wealth_moments(
                    DU, DE, DEE, q, par["w_grid"], par["a_grid"]
                )
                overlap = set(wage_moments) & set(wealth_moments)
                if overlap:
                    raise DMPTransitionError(
                        "wage and wealth moment names overlap: "
                        + ", ".join(sorted(overlap))
                    )
                moment_history.append({**wage_moments, **wealth_moments})
            if retain_distribution:
                retained.append({
                    "mass_by_wage": DE.sum(axis=(0, 1, 3, 4, 5)),
                    "mass_by_asset_wage": DE.sum(axis=(0, 3, 4, 5)),
                })
            DU, DE = DU_next, DE_next
            if not np.isfinite(DU).all() or not np.isfinite(DE).all():
                raise DMPTransitionError(
                    f"nonfinite distribution after forward period t={t}"
                )
            mass_error = abs(float(DU.sum() + DE.sum()) - 1.0)
            max_mass_error = max(max_mass_error, mass_error)
            min_distribution = min(min_distribution, float(DU.min()), float(DE.min()))
            if min_distribution < -1e-12:
                raise DMPTransitionError(
                    f"distribution contains negative entry {min_distribution:.3e}"
                )
            if mass_error > 1e-9:
                raise DMPTransitionError(
                    f"distribution mass error {mass_error:.3e} exceeds tolerance"
                )

        forward_runtime = time.perf_counter() - start_forward
        distributional = stack_moment_history(moment_history)
        if retain_distribution:
            distributional["DE_marginals"] = retained
        terminal = {"DU": DU.copy(), "DE": DE.copy()}

        if not all(np.isfinite(path).all() for path in aggregates.values()):
            raise DMPTransitionError("aggregate report contains nonfinite values")

    diagnostics = {
        "maximum_distribution_mass_error": float(max_mass_error),
        "minimum_distribution_entry": float(min_distribution),
        "maximum_probability_violation": float(prob_violation),
        "minimum_consumption": float(minimum_consumption),
        "terminal_distribution_L1_distance": float(
            np.sum(np.abs(DU - initial_DU)) + np.sum(np.abs(DE - initial_DE))
        ),
        "terminal_distribution_max_distance": float(max(
            np.max(np.abs(DU - initial_DU)), np.max(np.abs(DE - initial_DE))
        )),
        "backward_runtime": float(backward_runtime),
        "forward_runtime": float(forward_runtime),
        "scratch_disk_bytes": int(required_bytes),
        "steady_state_policy_max_error": float(policy_ss_max_error),
        "steady_state_policy_path_max_error": float(policy_ss_path_max_error),
        "iwin_legacy_sentinel_count": int(iwin_legacy_sentinel_count),
    }
    return {
        "aggregates": aggregates,
        "distributional": distributional,
        "terminal_distribution": terminal,
        "diagnostics": diagnostics,
    }


class NonlinearDMPBlock:
    """Adapter exposing the DMP transition to ``nonlinear.td_map``."""
    inputs = set(INPUTS)
    outputs = set(OUTPUTS)

    def __init__(self, par, scratch_dir=None):
        self.par = par
        self.scratch_dir = scratch_dir
        self.last_result = None

    def __repr__(self):
        return "<NonlinearDMPBlock adapted>"

    def td(self, ss, **paths):
        self.last_result = evaluate_dmp_transition(
            ss, self.par, paths, scratch_dir=self.scratch_dir
        )
        return self.last_result["aggregates"]
