"""Backward household helper for the adapted job-switcher wage rules.

This module intentionally exposes only the helper used by the fake-news
Jacobian code.  Keeping it separate prevents an adapted Jacobian run from
silently falling back to the legacy ``wagesEE_AOB`` implementation.
"""

import numpy as np

import HHhelp_AOB_adapted as HH
import utils


def backward_iterate(r_ante, r_post, rK, Z, tax, lambdas, bUI, sigmaJ,
                     sigmaslope, transfer, cU_p, cE_p, U_p, E_p,
                     E_bargaining_p, dE_bargaining_p, J_p,
                     J_bargaining_p, par):
    """Apply one adapted household backward step.

    The argument and return conventions match ``Jac_help.backward_iterate``
    exactly so the generic fake-news machinery can remain unchanged.
    """
    dU_p = (1 + r_ante) * utils.du(cU_p, par["eis"])
    dE_p = (1 + r_ante) * utils.du(cE_p, par["eis"])
    (E, E_bargaining, dE_bargaining, U, cE, cU, J, J_bargaining,
     JU0, JE0, qswitch, w_idx, w_pi, Iswitch) = HH.agent_step_td(
        r_post, rK, r_ante, tax, Z, lambdas, bUI, sigmaJ, sigmaslope,
        U_p, E_p, E_bargaining_p, dE_bargaining_p, dU_p, dE_p,
        J_p, J_bargaining_p, par, transfer,
    )

    aU = ((1 + r_post) * par["a_grid"][np.newaxis, :] + transfer
          + (1 - tax) * bUI - cU)
    aE = (
        (1 + r_post)
        * par["a_grid"][np.newaxis, :, np.newaxis, np.newaxis, np.newaxis]
        + transfer
        + (1 - tax)
        * par["w_grid"][np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]
        - cE
    )

    return (
        cU, cE, U, E, E_bargaining, dE_bargaining, aU, aE, J,
        J_bargaining, JU0, JE0, qswitch, w_idx["U"], w_pi["U"],
        w_idx["Ewin"], w_pi["Ewin"], w_idx["Elose"], w_pi["Elose"],
        Iswitch,
    )
