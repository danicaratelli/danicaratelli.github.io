"""Run the Great Recession experiment with a shorter shock."""

from pathlib import Path

import numpy as np

import main_result_GreatRecession as gr
import main_result_GreatRecession_iterative as experiment


# Keep the original fit window and anchors; shorten only the shock duration.
TT = 120
FIT_PERIODS = 9
SHOCK_PERIODS = 7  # Four through six quarters cannot fit the anchor targets.
OUTPUT_DIRECTORY = (
    Path("results_adapted")
    / f"great_recession_iterative_T{TT}_short{SHOCK_PERIODS}"
)
SCALE_STAGES = (0.002, 0.01, 0.05)  # Compare terminal errors with the TT=80 run.


if __name__ == "__main__":
    shock_time = np.arange(SHOCK_PERIODS, dtype=np.float64)
    shock_envelope = np.sin(
        np.pi * (shock_time + 1.0) / (SHOCK_PERIODS + 1.0)
    ) ** 2

    experiment.TT = TT
    experiment.SHOCK_PERIODS = SHOCK_PERIODS
    experiment.SHOCK_PROFILES = {
        "chi": shock_envelope,
        "eta": shock_envelope * (
            2.0 * shock_time / (SHOCK_PERIODS - 1) - 1.0
        ),
    }
    experiment.OUTPUT_DIRECTORY = OUTPUT_DIRECTORY
    experiment.PROGRESS_FILE = OUTPUT_DIRECTORY / "continuation_progress.json"
    experiment.LAST_CONVERGED_FILE = (
        OUTPUT_DIRECTORY / "last_market_converged_paths.csv"
    )
    experiment.SCALE_STAGES = SCALE_STAGES

    gr.TT = TT
    gr.TERMINAL_TAIL = TT - SHOCK_PERIODS
    gr.SHOCK_NAMES = experiment.SHOCK_NAMES
    gr.WALRAS_TOLERANCE = experiment.WALRAS_TOLERANCE
    gr.MAX_ITERATIONS = experiment.MAX_ITERATIONS
    gr.MAX_LINE_SEARCH_TRIALS = experiment.MAX_LINE_SEARCH_TRIALS
    gr.IDENTIFICATION_SMOOTHNESS_PENALTY = 0.0
    gr.OUTPUT_DIRECTORY = OUTPUT_DIRECTORY

    original_identifier = gr.identify_bounded_shocks
    gr.identify_bounded_shocks = experiment.identify_smooth_shocks
    try:
        gr.run_experiment(
            transition_solver=experiment.solve_transition_adaptively,
            shock_periods=SHOCK_PERIODS,
            fit_periods=FIT_PERIODS,
        )
    finally:
        gr.identify_bounded_shocks = original_identifier
