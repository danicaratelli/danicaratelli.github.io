"""Nonlinear aggregate equilibrium map and solver for temporary adapted shocks."""

from __future__ import annotations

import time

import numpy as np

import jacobian as jac
import load_params_SS
import model_blocks as blocks
import nonlinear
import utils
from nonlinear_dmp_adapted import (
    DMPTransitionError, INPUTS as DMP_INPUTS, NonlinearDMPBlock,
    evaluate_dmp_transition,
)


UNKNOWNS = [
    "theta0", "theta1", "theta2", "theta3",
    "theta4", "theta5", "theta6", "theta7", "Y", "r", "tax",
]
TARGETS = ["h1", "h2", "h3", *(f"h{i}" for i in range(4, 12))]


def truncate_jacobian(J, T):
    """Copy a nested Jacobian dictionary, slicing every dense matrix to T."""
    out = {}
    for output, inner in J.items():
        out[output] = {}
        for inp, value in inner.items():
            if isinstance(value, np.ndarray):
                if value.ndim != 2 or value.shape[0] < T or value.shape[1] < T:
                    raise ValueError(
                        f"Jacobian {output}<-{inp} has shape {value.shape}, "
                        f"which cannot support T={T}"
                    )
                out[output][inp] = np.asarray(value[:T, :T], dtype=np.float64).copy()
            else:
                out[output][inp] = value
    return out


def build_block_lists(J, par, T, scratch_dir=None):
    """Build the linear and exact-nonlinear versions of the aggregate DAG."""
    J_T = truncate_jacobian(J, T)
    tail = [
        blocks.labor_flows, blocks.matching_tech, blocks.dividend,
        blocks.intermediaries, blocks.production, blocks.capitalist,
        blocks.earnings_posttax, blocks.asset_mkt, blocks.labor_mkt,
        blocks.fiscal, blocks.free_entry, blocks.walras,
    ]
    dmp = NonlinearDMPBlock(par, scratch_dir=scratch_dir)
    return [J_T, *tail], [dmp, *tail], dmp


def residual_scales(ss):
    """Steady-state economic units for the eleven market equations."""
    vacancy_cost = sum(
        abs(float(ss[f"v{i}"]))
        * abs(float((ss["zeta"] * ss[f"pgrid{i}"]) ** ss["zeta_curv"]))
        for i in range(8)
    )
    fiscal_scale = max(
        abs(float(ss["Tax"])), abs(float(ss["Pi"])),
        abs(float((1.0 - ss["tax"]) * ss["Ubill"])), vacancy_cost, 1e-8,
    )
    scales = {
        "h1": max(abs(float(ss["A"])), abs(float(ss["p"])), 1e-8),
        "h2": max(abs(float(ss["N"])), abs(float(ss["L"])), 1e-8),
        "h3": fiscal_scale,
    }
    for rung in range(8):
        scales[f"h{rung + 4}"] = max(abs(float(ss[f"q{rung}"])), 1e-8)
    return scales


def deviations_to_levels(ss, shock_deviations, T):
    """Convert ordinary shocks to levels while preserving bUI as a deviation."""
    levels = {}
    for name, deviation in shock_deviations.items():
        deviation = np.asarray(deviation, dtype=np.float64)
        if deviation.shape != (T,):
            raise ValueError(f"shock {name} must have shape {(T,)}")
        if not np.isfinite(deviation).all():
            raise ValueError(f"shock {name} contains nonfinite values")
        levels[name] = deviation.copy() if name == "bUI" else float(ss[name]) + deviation
    return levels


def validate_temporary_shocks(shock_deviations, T, terminal_tail=1):
    if not shock_deviations:
        return -1
    if terminal_tail < 1 or terminal_tail >= T:
        raise ValueError("terminal_tail must satisfy 1 <= terminal_tail < T")
    last_nonzero = -1
    for name, path in shock_deviations.items():
        if name in UNKNOWNS or name in TARGETS:
            raise ValueError(f"shock {name} cannot also be an unknown or target")
        if name not in ss_exogenous_names():
            raise ValueError(f"unsupported exogenous shock {name}")
        path = np.asarray(path, dtype=np.float64)
        if path.shape != (T,) or not np.isfinite(path).all():
            raise ValueError(f"shock {name} must be a finite length-{T} deviation")
        if not np.all(path[-terminal_tail:] == 0.0):
            raise ValueError(
                f"temporary shock {name} must be exactly zero for the final "
                f"{terminal_tail} periods"
            )
        nz = np.flatnonzero(path != 0.0)
        if nz.size:
            last_nonzero = max(last_nonzero, int(nz[-1]))
    if last_nonzero >= T - 1:
        raise ValueError("shock cutoff must satisfy T_shock < T")
    return last_nonzero


def ss_exogenous_names():
    """Exogenous inputs admitted by the adapted aggregate graph."""
    return {
        "Z", "transfer", "sigmaJ", "sigmaslope", "bUI", "zeta",
        "drate", "chi", "eta", "epsI",
    }


def _precheck_unknowns(ss, par, unknown_paths, shock_levels, T):
    for name in UNKNOWNS:
        value = np.asarray(unknown_paths[name])
        if value.shape != (T,) or not np.isfinite(value).all():
            raise DMPTransitionError(f"unknown path {name} is invalid")
    theta = np.column_stack([unknown_paths[f"theta{i}"] for i in range(8)])
    if np.min(theta) <= 0.0:
        raise DMPTransitionError("theta paths must be strictly positive")
    if np.min(unknown_paths["Y"]) <= 0.0:
        raise DMPTransitionError("Y must be strictly positive")
    if np.min(1.0 + unknown_paths["r"]) <= 0.0:
        raise DMPTransitionError("1 + r must be strictly positive")
    lambdas = par["chi"] * theta ** (1.0 - par["eta"])
    if np.min(lambdas) < -1e-10 or np.max(lambdas) > 1.0 + 1e-10:
        raise DMPTransitionError("implied job-finding probabilities are infeasible")
    sigmaJ = shock_levels.get("sigmaJ", np.full(T, ss["sigmaJ"]))
    slope = shock_levels.get("sigmaslope", np.full(T, ss.get("sigmaslope", 0.0)))
    sigma = ((np.asarray(par["sigma"])[None, :]
              + (np.asarray(sigmaJ)[:, None] - par["sigma"][-1]))
             * (1.0 + np.asarray(slope)[:, None]))
    if np.min(sigma) < -1e-10 or np.max(sigma) > 1.0 + 1e-10:
        raise DMPTransitionError("implied separation probabilities are infeasible")


class NonlinearGEMap:
    def __init__(self, ss, par, J, T, scratch_dir=None):
        self.ss = ss
        self.par = par
        self.T = T
        self.linear_blocks, self.nonlinear_blocks, self.dmp_block = (
            build_block_lists(J, par, T, scratch_dir=scratch_dir)
        )
        self.sort = utils.block_sort(self.nonlinear_blocks)
        self.scales = residual_scales(ss)

    def evaluate(self, unknown_paths, shock_levels):
        _precheck_unknowns(self.ss, self.par, unknown_paths, shock_levels, self.T)
        supplied = {**{k: np.asarray(v, dtype=np.float64).copy()
                       for k, v in shock_levels.items()},
                    **{k: np.asarray(v, dtype=np.float64).copy()
                       for k, v in unknown_paths.items()}}
        results = nonlinear.td_map(
            self.ss, self.nonlinear_blocks, sort=self.sort, **supplied
        )
        if np.min(1.0 + np.asarray(results["ra"])) <= 0.0:
            raise DMPTransitionError("1 + ra must be strictly positive")
        raw = {name: np.asarray(results[name], dtype=np.float64) for name in TARGETS}
        scaled = {name: raw[name] / self.scales[name] for name in TARGETS}
        if not all(np.isfinite(value).all() for value in raw.values()):
            raise DMPTransitionError("aggregate residual contains nonfinite values")
        return {
            "raw_residuals": raw,
            "scaled_residuals": scaled,
            "paths": results,
            "diagnostics": dict(self.dmp_block.last_result["diagnostics"]),
            "terminal_distribution": self.dmp_block.last_result["terminal_distribution"],
        }


def construct_linear_system(ss, J, par, T, scratch_dir=None):
    linear_blocks, nonlinear_blocks, dmp = build_block_lists(
        J, par, T, scratch_dir=scratch_dir
    )
    H_U = jac.get_H_U(linear_blocks, UNKNOWNS, TARGETS, T, ss=ss)
    scales = residual_scales(ss)
    row_scale = np.concatenate([np.full(T, 1.0 / scales[name]) for name in TARGETS])
    H_scaled = row_scale[:, None] * H_U
    return {
        "linear_blocks": linear_blocks,
        "nonlinear_blocks": nonlinear_blocks,
        "dmp_block": dmp,
        "H_U": H_U,
        "H_U_factored": utils.factor(H_U),
        "H_U_scaled": H_scaled,
        "H_U_scaled_factored": utils.factor(H_scaled),
        "scales": scales,
    }


def linear_initial_guess(ss, system, shock_deviations, T):
    dU = jac.get_impulse(
        system["linear_blocks"], shock_deviations, UNKNOWNS, TARGETS,
        T=T, ss=ss, outputs=UNKNOWNS,
        H_U_factored=system["H_U_factored"],
    )
    return ({name: float(ss[name]) + np.asarray(dU[name]) for name in UNKNOWNS},
            dU)


def _max_by_target(residuals):
    return {name: float(np.max(np.abs(residuals[name]))) for name in TARGETS}


def _merit(scaled):
    vector = jac.pack_vectors(scaled, TARGETS, len(next(iter(scaled.values()))))
    return 0.5 * float(vector @ vector)


def _solve_stage(ge_map, factored, initial, shock_levels, tolerance,
                 max_iterations, minimum_step=2.0 ** -12,
                 max_line_search_trials=13):
    U = {name: np.asarray(initial[name], dtype=np.float64).copy()
         for name in UNKNOWNS}
    diagnostics = {
        "accepted_step_sizes": [], "residual_history": [],
        "unknown_path_changes": [], "runtime_by_iteration": [],
        "household_diagnostics_by_iteration": [],
    }
    final = None
    failure = None
    pending_evaluation = None
    for iteration in range(max_iterations + 1):
        tic = time.perf_counter()
        try:
            if pending_evaluation is None:
                current = ge_map.evaluate(U, shock_levels)
            else:
                current = pending_evaluation
                pending_evaluation = None
        except Exception as exc:
            failure = f"current iterate invalid: {type(exc).__name__}: {exc}"
            diagnostics["runtime_by_iteration"].append(time.perf_counter() - tic)
            break
        raw_max = _max_by_target(current["raw_residuals"])
        scaled_max = _max_by_target(current["scaled_residuals"])
        merit = _merit(current["scaled_residuals"])
        diagnostics["residual_history"].append({
            "iteration": iteration, "raw_max": raw_max,
            "scaled_max": scaled_max, "scaled_merit": merit,
            "scaled_l2_norm": float(np.sqrt(2.0 * merit)),
        })
        diagnostics["household_diagnostics_by_iteration"].append(
            current["diagnostics"]
        )
        final = current
        if max(scaled_max.values()) <= tolerance:
            diagnostics["runtime_by_iteration"].append(time.perf_counter() - tic)
            return True, U, final, diagnostics, None
        if iteration == max_iterations:
            failure = f"maximum iteration count {max_iterations} reached"
            diagnostics["runtime_by_iteration"].append(time.perf_counter() - tic)
            break

        residual_vector = jac.pack_vectors(
            current["scaled_residuals"], TARGETS, ge_map.T
        )
        direction_vector = -utils.factored_solve(factored, residual_vector)
        direction = jac.unpack_vectors(direction_vector, UNKNOWNS, ge_map.T)
        accepted = False
        step = 1.0
        for _ in range(max_line_search_trials):
            if step < minimum_step:
                break
            trial_U = {name: U[name] + step * direction[name] for name in UNKNOWNS}
            try:
                trial = ge_map.evaluate(trial_U, shock_levels)
                trial_merit = _merit(trial["scaled_residuals"])
                improving = trial_merit < merit
            except Exception:
                improving = False
            if improving:
                change = max(float(np.max(np.abs(trial_U[name] - U[name])))
                             for name in UNKNOWNS)
                U = trial_U
                pending_evaluation = trial
                diagnostics["accepted_step_sizes"].append(step)
                diagnostics["unknown_path_changes"].append(change)
                accepted = True
                break
            step *= 0.5
        if not accepted:
            failure = "line search failed to find a valid improving step"
        diagnostics["runtime_by_iteration"].append(time.perf_counter() - tic)
        if not accepted:
            break
    return False, U, final, diagnostics, failure


def solve_nonlinear_transition(
    ss, par, J, shock_deviations, T, initial_guess="linear",
    tolerance=5e-5, max_iterations=20,
    homotopy_scales=(0.10, 0.25, 0.50, 0.75, 1.00),
    scratch_dir=None, terminal_tail=1, terminal_tolerance=1e-4,
    walras_tolerance=5e-5, max_line_search_trials=13,
):
    """Solve all eleven exact nonlinear equilibrium conditions.

    A failed solve is returned with ``converged=False`` and full diagnostics;
    it is never mislabeled as a solution.
    """
    if par.get("case4_derivative_mode") != "partial":
        raise ValueError("par['case4_derivative_mode'] must equal 'partial'")
    if homotopy_scales and float(homotopy_scales[-1]) != 1.0:
        raise ValueError("homotopy_scales must end at 1.0")
    if max_line_search_trials < 1:
        raise ValueError("max_line_search_trials must be positive")
    T_shock = validate_temporary_shocks(shock_deviations, T, terminal_tail)
    system = construct_linear_system(ss, J, par, T, scratch_dir=scratch_dir)
    ge_map = NonlinearGEMap(ss, par, J, T, scratch_dir=scratch_dir)
    linear_U, linear_dU = linear_initial_guess(ss, system, shock_deviations, T)
    if isinstance(initial_guess, str):
        if initial_guess == "linear":
            initial = linear_U
        elif initial_guess in ("steady_state", "flat"):
            initial = {name: np.full(T, ss[name], dtype=np.float64)
                       for name in UNKNOWNS}
        else:
            raise ValueError("initial_guess must be 'linear', 'steady_state', or paths")
    else:
        initial = {name: np.asarray(initial_guess[name], dtype=np.float64).copy()
                   for name in UNKNOWNS}

    full_levels = deviations_to_levels(ss, shock_deviations, T)
    converged, U, final, diag, failure = _solve_stage(
        ge_map, system["H_U_scaled_factored"], initial, full_levels,
        tolerance, max_iterations,
        max_line_search_trials=max_line_search_trials,
    )
    stage_records = [{"scale": 1.0, "converged": converged,
                      "failure": failure, **diag}]
    homotopy_stage = None

    if not converged and homotopy_scales:
        previous_scale = 0.0
        U = {name: np.full(T, ss[name], dtype=np.float64) for name in UNKNOWNS}
        for stage, scale in enumerate(homotopy_scales):
            scale = float(scale)
            if not previous_scale < scale <= 1.0:
                raise ValueError("homotopy_scales must be strictly increasing and <= 1")
            scaled_deviations = {name: scale * np.asarray(value)
                                 for name, value in shock_deviations.items()}
            stage_levels = deviations_to_levels(ss, scaled_deviations, T)
            stage_initial = {
                name: U[name] + (scale - previous_scale) * linear_dU[name]
                for name in UNKNOWNS
            }
            ok, stage_U, stage_final, stage_diag, stage_failure = _solve_stage(
                ge_map, system["H_U_scaled_factored"], stage_initial,
                stage_levels, tolerance, max_iterations,
                max_line_search_trials=max_line_search_trials,
            )
            stage_records.append({"scale": scale, "converged": ok,
                                  "failure": stage_failure, **stage_diag})
            U, final, failure = stage_U, stage_final, stage_failure
            homotopy_stage = stage
            if not ok:
                converged = False
                break
            converged = scale == 1.0
            previous_scale = scale

    market_converged = bool(converged)
    if final is None:
        raw_by_target = {}
        scaled_by_target = {}
        terminal_diagnostics = {}
        paths = {**U, **full_levels}
    else:
        raw_by_target = _max_by_target(final["raw_residuals"])
        scaled_by_target = _max_by_target(final["scaled_residuals"])
        terminal_diagnostics = {
            **final["diagnostics"],
            "endogenous_terminal_max_deviation": max(
                float(abs(U[name][-1] - ss[name])) for name in UNKNOWNS
            ),
            "endogenous_terminal_max_scaled_deviation": max(
                float(abs(U[name][-1] - ss[name]) / max(abs(ss[name]), 1.0))
                for name in UNKNOWNS
            ),
        }
        paths = final["paths"]
        terminal_valid = (
            terminal_diagnostics["endogenous_terminal_max_scaled_deviation"]
            <= terminal_tolerance
            and terminal_diagnostics["terminal_distribution_L1_distance"]
            <= terminal_tolerance
        )
        if converged and not terminal_valid:
            converged = False
            failure = (
                "market residuals converged but terminal truncation exceeds "
                f"terminal_tolerance={terminal_tolerance:.3e}; increase T"
            )
        walras_max = float(np.max(np.abs(paths["walras_res"])))
        terminal_diagnostics["walras_max_residual"] = walras_max
        if converged and walras_max > walras_tolerance:
            converged = False
            failure = (
                f"target markets converged but Walras residual {walras_max:.3e} "
                f"exceeds walras_tolerance={walras_tolerance:.3e}"
            )
    all_steps = [step for record in stage_records
                 for step in record["accepted_step_sizes"]]
    all_history = [row for record in stage_records
                   for row in record["residual_history"]]
    diagnostics = {
        "converged": bool(converged),
        "market_converged": market_converged,
        "iterations": len(all_steps),
        "homotopy_stage": homotopy_stage,
        "accepted_step_sizes": all_steps,
        "residual_history": all_history,
        "raw_max_residual_by_target": raw_by_target,
        "scaled_max_residual_by_target": scaled_by_target,
        "raw_residuals_by_target": (
            {} if final is None else
            {name: value.copy() for name, value in final["raw_residuals"].items()}
        ),
        "scaled_residuals_by_target": (
            {} if final is None else
            {name: value.copy() for name, value in final["scaled_residuals"].items()}
        ),
        "unknown_path_changes": [x for record in stage_records
                                 for x in record["unknown_path_changes"]],
        "runtime_by_iteration": [x for record in stage_records
                                 for x in record["runtime_by_iteration"]],
        "household_diagnostics_by_iteration": [x for record in stage_records
                                                for x in record["household_diagnostics_by_iteration"]],
        "terminal_diagnostics": terminal_diagnostics,
        "homotopy_records": stage_records,
        "failure_reason": None if converged else failure,
        "T_shock": T_shock,
        "residual_scales": system["scales"],
        "terminal_tolerance": float(terminal_tolerance),
        "walras_tolerance": float(walras_tolerance),
        "max_line_search_trials": int(max_line_search_trials),
    }
    return {
        "converged": bool(converged), "unknowns": U, "paths": paths,
        "diagnostics": diagnostics, "linear_initial_guess": linear_U,
        "linear_responses": linear_dU,
        "terminal_distribution": (None if final is None
                                  else final["terminal_distribution"]),
    }


def compare_horizons(ss, par, J, shock_deviations, T1, T2, report_periods,
                     **solver_options):
    """Solve two horizons and compare their common reporting window."""
    if not 0 < report_periods <= T1 < T2:
        raise ValueError("require 0 < report_periods <= T1 < T2")
    short_shocks = {name: np.asarray(path)[:T1] for name, path in shock_deviations.items()}
    long_shocks = {}
    for name, path in shock_deviations.items():
        path = np.asarray(path, dtype=np.float64)
        if path.size == T2:
            long_shocks[name] = path
        elif path.size == T1:
            long_shocks[name] = np.pad(path, (0, T2 - T1))
        else:
            raise ValueError(f"shock {name} must have length T1 or T2")
    short = solve_nonlinear_transition(ss, par, J, short_shocks, T1,
                                       **solver_options)
    long = solve_nonlinear_transition(ss, par, J, long_shocks, T2,
                                      **solver_options)
    shared = set(short["paths"]) & set(long["paths"])
    errors = {}
    for name in shared:
        a, b = np.asarray(short["paths"][name]), np.asarray(long["paths"][name])
        if a.ndim == b.ndim == 1:
            errors[name] = float(np.max(np.abs(a[:report_periods]
                                               - b[:report_periods])))
    terminal_metrics = {
        "T1_distribution_L1": short["diagnostics"].get(
            "terminal_diagnostics", {}
        ).get("terminal_distribution_L1_distance", np.nan),
        "T2_distribution_L1": long["diagnostics"].get(
            "terminal_diagnostics", {}
        ).get("terminal_distribution_L1_distance", np.nan),
        "T1_endogenous_scaled": short["diagnostics"].get(
            "terminal_diagnostics", {}
        ).get("endogenous_terminal_max_scaled_deviation", np.nan),
        "T2_endogenous_scaled": long["diagnostics"].get(
            "terminal_diagnostics", {}
        ).get("endogenous_terminal_max_scaled_deviation", np.nan),
    }
    return {"T1": short, "T2": long, "reporting_window_max_errors": errors,
            "maximum_reporting_window_error": max(errors.values(), default=0.0),
            "terminal_metrics": terminal_metrics}


def reconstruct_parameters(ss):
    par = load_params_SS.get_par(ss["inputs"])
    par["case4_derivative_mode"] = "partial"
    return par


def validate_zero_shock_transition(ss, par, J, T, scratch_dir=None,
                                   residual_tolerance=5e-5,
                                   stationarity_tolerance=5e-5):
    """Run all steady-state parity gates before a counterfactual solve."""
    dmp_paths = {}
    for name in DMP_INPUTS:
        if name == "bUI":
            dmp_paths[name] = np.zeros(T)
        else:
            dmp_paths[name] = np.full(T, ss.get(name, 0.0))
    evaluated = evaluate_dmp_transition(
        ss, par, dmp_paths, scratch_dir=scratch_dir,
        compute_distributional=True,
    )
    _, nonlinear_blocks, _ = build_block_lists(J, par, T,
                                                scratch_dir=scratch_dir)
    aggregate_blocks = nonlinear_blocks[1:]
    supplied = {
        **{name: np.full(T, ss[name], dtype=np.float64) for name in UNKNOWNS},
        **evaluated["aggregates"],
    }
    aggregate_results = nonlinear.td_map(
        ss, aggregate_blocks, sort=utils.block_sort(aggregate_blocks),
        **supplied,
    )
    scales = residual_scales(ss)
    raw = {name: np.asarray(aggregate_results[name]) for name in TARGETS}
    scaled = {name: raw[name] / scales[name] for name in TARGETS}
    aggregate_flatness_raw = max(
        float(np.ptp(path)) for path in evaluated["aggregates"].values()
    )
    aggregate_flatness = max(
        float(np.ptp(path)) / max(abs(float(ss[name])), 1.0)
        for name, path in evaluated["aggregates"].items()
    )
    moment_flatness = max(
        (float(np.ptp(path)) for path in evaluated["distributional"].values()
         if np.asarray(path).ndim == 1), default=0.0,
    )
    diagnostics = {
        **evaluated["diagnostics"],
        "raw_max_residual_by_target": _max_by_target(raw),
        "scaled_max_residual_by_target": _max_by_target(scaled),
        "maximum_scaled_market_residual": max(_max_by_target(scaled).values()),
        "walras_max_residual": float(np.max(np.abs(aggregate_results["walras_res"]))),
        "aggregate_path_flatness_raw": aggregate_flatness_raw,
        "aggregate_path_flatness": aggregate_flatness,
        "distributional_moment_flatness": moment_flatness,
    }
    failures = []
    if diagnostics["maximum_scaled_market_residual"] > residual_tolerance:
        failures.append("market residual")
    if diagnostics["maximum_distribution_mass_error"] > 1e-9:
        failures.append("distribution mass")
    if diagnostics["steady_state_policy_max_error"] > 3e-7:
        failures.append("stored policy parity")
    if aggregate_flatness > stationarity_tolerance:
        failures.append("aggregate stationarity")
    if moment_flatness > stationarity_tolerance:
        failures.append("distributional stationarity")
    diagnostics["passed"] = not failures
    diagnostics["failures"] = failures
    return diagnostics
