"""Run the Great Recession experiment with staged shock continuation."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.optimize import lsq_linear

import main_result_GreatRecession as gr
from nonlinear_ge_adapted import TARGETS, UNKNOWNS, solve_nonlinear_transition


# First establish market convergence on a shorter horizon. Recheck the
# terminal distribution at longer horizons after the shock scale is solved.
TT = 80
FIT_PERIODS = 9  # Fit empirical quarters 0 through 8, including the earnings trough.
SHOCK_PERIODS = 8  # Shocks are exactly zero from quarter 8 onward.
SHOCK_NAMES = ("chi", "eta")
ANCHOR_PERIODS = {"earnings": 8, "U": 7}
WALRAS_TOLERANCE = 2e-3
OUTPUT_DIRECTORY = Path("results_adapted") / "great_recession_iterative_T80_smooth2"
SCALE_STAGES = (0.002, 0.005, 0.01, 0.02, 0.05)
MAX_ITERATIONS = 8
MAX_LINE_SEARCH_TRIALS = 4  # Bound costly evaluations while diagnosing a stage.
PROGRESS_FILE = OUTPUT_DIRECTORY / "continuation_progress.json"
LAST_CONVERGED_FILE = OUTPUT_DIRECTORY / "last_market_converged_paths.csv"
MAXIMUM_ANCHOR_RELATIVE_ERROR = 0.05

# Two smooth profiles replace sixteen unrelated quarterly shock values.
SHOCK_TIME = np.arange(SHOCK_PERIODS, dtype=np.float64)
SHOCK_ENVELOPE = np.sin(
    np.pi * (SHOCK_TIME + 1.0) / (SHOCK_PERIODS + 1.0)
) ** 2
SHOCK_PROFILES = {
    "chi": SHOCK_ENVELOPE,
    "eta": SHOCK_ENVELOPE * (2.0 * SHOCK_TIME / (SHOCK_PERIODS - 1) - 1.0),
}


def save_attempt_paths(path, scale, shocks, initial_unknowns, solution, T):
    """Save every available one-period path and market residual for a trial."""
    columns = [np.arange(T), np.full(T, scale)]
    names = ["time", "shock_scale"]
    for name, values in shocks.items():
        columns.append(np.asarray(values, dtype=np.float64))
        names.append("shock_" + name)
    for name in UNKNOWNS:
        columns.append(np.asarray(initial_unknowns[name], dtype=np.float64))
        names.append("initial_" + name)

    if solution is not None:
        for name in UNKNOWNS:
            columns.append(np.asarray(solution["unknowns"][name], dtype=np.float64))
            names.append("solved_" + name)
        used_names = {name.casefold() for name in names}
        for name, values in sorted(solution["paths"].items()):
            values = np.asarray(values)
            if values.shape == (T,) and np.issubdtype(values.dtype, np.number):
                columns.append(values.astype(np.float64))
                column_name = "path_" + name
                if column_name.casefold() in used_names:
                    column_name += "_2"
                names.append(column_name)
                used_names.add(column_name.casefold())

    diagnostics = {} if solution is None else solution["diagnostics"]
    for label, key in (("raw", "raw_residuals_by_target"),
                       ("scaled", "scaled_residuals_by_target")):
        residuals = diagnostics.get(key, {})
        for name in TARGETS:
            columns.append(np.asarray(
                residuals.get(name, np.full(T, np.nan)), dtype=np.float64
            ))
            names.append(label + "_residual_" + name)
    np.savetxt(
        path, np.column_stack(columns), delimiter=",",
        header=",".join(names), comments="",
    )
    return bool(diagnostics.get("raw_residuals_by_target"))


def identify_smooth_shocks(
        G, earnings_target, unemployment_target,
        chi_steady_state, drate_steady_state, horizon=TT,
        active_periods=FIT_PERIODS, shock_names=SHOCK_NAMES,
        shock_steady_states=None, shock_level_bounds=None,
        smoothness_penalty=0.0, shock_periods=SHOCK_PERIODS):
    """Fit two smooth shock amplitudes to the trough and unemployment peak."""
    shock_names = tuple(shock_names)
    if set(shock_names) != set(SHOCK_PROFILES) or shock_periods != SHOCK_PERIODS:
        raise ValueError("smooth shock settings do not match the experiment")
    if smoothness_penalty != 0.0:
        raise ValueError("smooth profiles do not use a roughness penalty")
    if shock_steady_states is None or shock_level_bounds is None:
        raise ValueError("smooth identification requires shock levels and bounds")
    if horizon <= shock_periods or active_periods <= max(ANCHOR_PERIODS.values()):
        raise ValueError("horizon or target window is too short")
    targets = {
        "earnings": np.asarray(earnings_target, dtype=np.float64),
        "U": np.asarray(unemployment_target, dtype=np.float64),
    }
    if any(target.shape != (active_periods,) for target in targets.values()):
        raise ValueError("smooth identification targets have the wrong shape")

    matrix = np.empty((2, 2), dtype=np.float64)
    vector = np.empty(2, dtype=np.float64)
    for row, output in enumerate(("earnings", "U")):
        period = ANCHOR_PERIODS[output]
        vector[row] = targets[output][period]
        for column, name in enumerate(shock_names):
            mapping = np.asarray(G[output][name], dtype=np.float64)
            profile = SHOCK_PROFILES[name]
            if mapping.shape != (horizon, horizon):
                raise ValueError(f"{output} mapping for {name} has wrong horizon")
            matrix[row, column] = mapping[period, :shock_periods] @ profile
    rank = int(np.linalg.matrix_rank(matrix))
    condition = float(np.linalg.cond(matrix))
    if rank != 2 or not np.isfinite(condition) or condition > 1e12:
        raise gr.ShockIdentificationError(
            f"smooth anchor system is unusable: rank={rank}, "
            f"condition_number={condition:.6e}"
        )

    lower = np.full(2, -np.inf)
    upper = np.full(2, np.inf)
    for index, name in enumerate(shock_names):
        steady_state = float(shock_steady_states[name])
        lower_level, upper_level = shock_level_bounds[name]
        if not lower_level <= steady_state <= upper_level:
            raise ValueError(f"steady-state {name} violates its level bounds")
        for weight in SHOCK_PROFILES[name]:
            if weight > 0.0:
                lower[index] = max(lower[index],
                                   (lower_level - steady_state) / weight)
                upper[index] = min(upper[index],
                                   (upper_level - steady_state) / weight)
            elif weight < 0.0:
                lower[index] = max(lower[index],
                                   (upper_level - steady_state) / weight)
                upper[index] = min(upper[index],
                                   (lower_level - steady_state) / weight)
        if lower[index] >= upper[index]:
            raise gr.ShockIdentificationError(
                f"smooth {name} amplitude has no feasible level range"
            )
    result = lsq_linear(
        matrix, vector, bounds=(lower, upper), method="trf",
        tol=1e-12, max_iter=1000,
    )
    if not result.success:
        raise gr.ShockIdentificationError(
            f"smooth anchor fit failed: status={result.status}, "
            f"message={result.message}"
        )
    anchor_residual = matrix @ result.x - vector
    relative_error = np.abs(anchor_residual) / np.maximum(np.abs(vector), 1e-12)
    if np.max(relative_error) > MAXIMUM_ANCHOR_RELATIVE_ERROR:
        raise gr.ShockIdentificationError(
            "smooth shocks cannot match the two anchor targets within "
            f"{MAXIMUM_ANCHOR_RELATIVE_ERROR:.0%}: "
            f"relative errors={relative_error.tolist()}"
        )

    deviations = {}
    levels = {}
    for index, name in enumerate(shock_names):
        path = np.zeros(horizon, dtype=np.float64)
        path[:shock_periods] = result.x[index] * SHOCK_PROFILES[name]
        deviations[name] = path
        levels[name] = float(shock_steady_states[name]) + path
    fitted_earnings = sum(
        np.asarray(G["earnings"][name]) @ deviations[name]
        for name in shock_names
    )[:active_periods]
    fitted_unemployment = sum(
        np.asarray(G["U"][name]) @ deviations[name]
        for name in shock_names
    )[:active_periods]
    earnings_residual = fitted_earnings - targets["earnings"]
    unemployment_residual = fitted_unemployment - targets["U"]
    diagnostics = {
        "method": "two_smooth_profiles_fitted_to_two_anchors",
        "matrix_shape": list(matrix.shape),
        "numerical_rank": rank,
        "condition_number": condition,
        "anchor_periods": ANCHOR_PERIODS,
        "anchor_fit_residuals": anchor_residual,
        "anchor_relative_errors": relative_error,
        "shock_amplitudes": {
            name: float(result.x[index])
            for index, name in enumerate(shock_names)
        },
        "shock_profiles": SHOCK_PROFILES,
        "active_bound_count": int(np.count_nonzero(result.active_mask)),
        "earnings_max_absolute_fit_error": float(np.max(np.abs(
            earnings_residual[1:]
        ))),
        "unemployment_max_absolute_fit_error": float(np.max(np.abs(
            unemployment_residual[1:]
        ))),
        "zero_tail_start_period": shock_periods,
        "zero_tail_length": horizon - shock_periods,
    }
    return {
        "deviations": deviations,
        "levels": levels,
        "fitted_earnings": fitted_earnings,
        "fitted_unemployment": fitted_unemployment,
        "earnings_residual": earnings_residual,
        "unemployment_residual": unemployment_residual,
        "diagnostics": diagnostics,
    }


def solve_transition_adaptively(ss, par, J, shock_deviations, T,
                                **solver_options):
    """Solve a fixed sequence of shock scales, stopping at a market failure."""
    if not SCALE_STAGES or not all(
            0.0 < current <= 1.0
            and (index == 0 or SCALE_STAGES[index - 1] < current)
            for index, current in enumerate(SCALE_STAGES)):
        raise ValueError("SCALE_STAGES must increase strictly within (0, 1]")

    full_linear_guess = solver_options.pop("initial_guess", None)
    if full_linear_guess is None:
        raise ValueError("adaptive continuation requires a linear initial guess")
    linear_deviation = {
        name: np.asarray(full_linear_guess[name], dtype=np.float64) - ss[name]
        for name in UNKNOWNS
    }

    # The zero-shock validation in run_experiment establishes this starting point.
    previous_unknowns = {
        name: np.full(T, ss[name], dtype=np.float64) for name in UNKNOWNS
    }
    previous_scale = 0.0
    last_solution = None
    attempts = []
    solver_options["homotopy_scales"] = ()
    OUTPUT_DIRECTORY.mkdir(parents=True, exist_ok=True)

    for trial_scale in SCALE_STAGES:
        trial_shocks = {
            name: trial_scale * np.asarray(path, dtype=np.float64)
            for name, path in shock_deviations.items()
        }
        trial_initial = {
            name: (
                previous_unknowns[name]
                + (trial_scale - previous_scale) * linear_deviation[name]
            )
            for name in UNKNOWNS
        }
        print(
            f"Continuation: solving shock scale {trial_scale:.4f} "
            f"from {previous_scale:.4f}", flush=True,
        )
        try:
            trial_solution = solve_nonlinear_transition(
                ss, par, J, trial_shocks, T,
                initial_guess=trial_initial, **solver_options,
            )
            trial_diagnostics = trial_solution["diagnostics"]
            converged = bool(trial_solution["converged"])
            market_converged = bool(trial_diagnostics["market_converged"])
            failure = trial_diagnostics.get("failure_reason")
            terminal = trial_diagnostics.get("terminal_diagnostics", {})
            walras_max = terminal.get("walras_max_residual", np.inf)
            walras_valid = walras_max <= solver_options["walras_tolerance"]
            terminal_valid = (
                terminal.get("endogenous_terminal_max_scaled_deviation", np.inf)
                <= solver_options["terminal_tolerance"]
                and terminal.get("terminal_distribution_L1_distance", np.inf)
                <= solver_options["terminal_tolerance"]
            )
            accepted = market_converged and walras_valid
            attempt = {
                "scale": trial_scale,
                "step": trial_scale - previous_scale,
                "converged": converged,
                "market_converged": market_converged,
                "walras_valid": walras_valid,
                "terminal_valid": terminal_valid,
                "accepted_for_continuation": accepted,
                "iterations": trial_diagnostics.get("iterations"),
                "failure_reason": failure,
                "scaled_max_residual_by_target": trial_diagnostics.get(
                    "scaled_max_residual_by_target", {}
                ),
                "walras_max_residual": terminal.get("walras_max_residual"),
                "endogenous_terminal_max_scaled_deviation": terminal.get(
                    "endogenous_terminal_max_scaled_deviation"
                ),
                "terminal_distribution_L1_distance": terminal.get(
                    "terminal_distribution_L1_distance"
                ),
            }
        except Exception as exc:
            converged = False
            accepted = False
            trial_solution = None
            attempt = {
                "scale": trial_scale,
                "step": trial_scale - previous_scale,
                "converged": False,
                "failure_reason": f"{type(exc).__name__}: {exc}",
            }
        attempt_path = OUTPUT_DIRECTORY / (
            f"attempt_{len(attempts) + 1:03d}_scale_{trial_scale:.4f}.csv"
        )
        attempt["paths_file"] = str(attempt_path)
        attempt["residuals_available"] = save_attempt_paths(
            attempt_path, trial_scale, trial_shocks, trial_initial,
            trial_solution, T,
        )
        attempts.append(attempt)

        if accepted:
            previous_scale = trial_scale
            previous_unknowns = {
                name: np.asarray(trial_solution["unknowns"][name]).copy()
                for name in UNKNOWNS
            }
            last_solution = trial_solution
            columns = [
                np.arange(T),
                np.full(T, previous_scale),
                trial_solution["paths"]["earnings"] - ss["earnings"],
                trial_solution["paths"]["U"] - ss["U"],
            ]
            names = ["time", "shock_scale", "earnings_deviation", "U_deviation"]
            for name in shock_deviations:
                columns.append(trial_shocks[name])
                names.append(name + "_deviation")
            np.savetxt(
                LAST_CONVERGED_FILE, np.column_stack(columns), delimiter=",",
                header=",".join(names), comments="",
            )
        progress = {
            "full_shocks_reached": previous_scale == 1.0,
            "largest_market_converged_scale": previous_scale,
            "largest_fully_converged_scale": max(
                (row["scale"] for row in attempts if row["converged"]),
                default=0.0,
            ),
            "next_scale": (
                SCALE_STAGES[len(attempts)]
                if accepted and len(attempts) < len(SCALE_STAGES) else None
            ),
            "stopped_at_failed_scale": None if accepted else trial_scale,
            "attempts": attempts,
        }
        PROGRESS_FILE.write_text(
            json.dumps(progress, indent=2), encoding="utf-8"
        )
        print(
            f"Continuation: {'accepted' if accepted else 'rejected'}; "
            f"largest market-converged scale {previous_scale:.4f}", flush=True,
        )
        if not accepted:
            break

    if last_solution is None:
        raise RuntimeError(
            "adaptive continuation could not solve its first shock step; "
            f"see {PROGRESS_FILE}"
        )

    last_solution["solved_shock_scale"] = previous_scale
    last_solution["solved_shock_deviations"] = {
        name: previous_scale * np.asarray(path, dtype=np.float64)
        for name, path in shock_deviations.items()
    }
    last_solution["diagnostics"]["continuation"] = progress
    if previous_scale < 1.0:
        reason = (
            f"adaptive continuation stopped at shock scale {previous_scale:.4f}; "
            f"see {PROGRESS_FILE}"
        )
        last_solution["converged"] = False
        last_solution["diagnostics"]["converged"] = False
        last_solution["diagnostics"]["failure_reason"] = reason
    return last_solution


if __name__ == "__main__":
    gr.TT = TT
    gr.TERMINAL_TAIL = TT - SHOCK_PERIODS
    gr.SHOCK_NAMES = SHOCK_NAMES
    gr.WALRAS_TOLERANCE = WALRAS_TOLERANCE
    gr.MAX_ITERATIONS = MAX_ITERATIONS
    gr.MAX_LINE_SEARCH_TRIALS = MAX_LINE_SEARCH_TRIALS
    gr.IDENTIFICATION_SMOOTHNESS_PENALTY = 0.0
    gr.OUTPUT_DIRECTORY = OUTPUT_DIRECTORY
    # The shared experiment has no identifier callback, so swap it for this run.
    original_identifier = gr.identify_bounded_shocks
    gr.identify_bounded_shocks = identify_smooth_shocks
    try:
        gr.run_experiment(
            transition_solver=solve_transition_adaptively,
            shock_periods=SHOCK_PERIODS,
            fit_periods=FIT_PERIODS,
        )
    finally:
        gr.identify_bounded_shocks = original_identifier
