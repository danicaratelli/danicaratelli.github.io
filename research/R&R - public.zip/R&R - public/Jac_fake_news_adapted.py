"""Initial fake-news Jacobian implementation for the DMP household block.

The distribution state at the start of a period is the pair ``(DU, DE)``.
Current policies and output functions are evaluated against that state. The
same policies then map it to next period's ``(DU, DE)`` distribution.
"""

from dataclasses import dataclass
from pathlib import Path
import tempfile
import time

import numpy as np
from numba import njit

import Jac_help_adapted as Jac_help
from het_block import HetBlock
import utils

import pdb


STOCK_OUTPUTS = ("U", "N", "A_pre", "AU_pre", "AE_pre")
POLICY_OUTPUTS = ("A", "C", "AU", "AE", "CU", "CE")
FLOW_RATE_OUTPUTS = ("EE_rate", "EU_rate")
FISCAL_OUTPUTS = ("Tax", "earnings", "Ubill", "Pi")
WALRAS_OUTPUTS = ("walrasU", "walrasE", "walras")
RUNG_OUTPUTS = tuple(f"e{i}" for i in range(8))
FIRM_OUTPUTS = tuple(f"J0_{i}" for i in range(8))
PRIMITIVE_OUTPUTS = (
    STOCK_OUTPUTS + POLICY_OUTPUTS + FLOW_RATE_OUTPUTS + FISCAL_OUTPUTS
    + RUNG_OUTPUTS + FIRM_OUTPUTS
)
DEFAULT_OUTPUTS = PRIMITIVE_OUTPUTS + WALRAS_OUTPUTS
FLOW_SHOCKS = tuple(f"lambda{i}" for i in range(8)) + ("sigmaJ", "sigmaslope")
LEVEL_SHOCKS = ("Z", "tax", "transfer", "rK", "bUI")
SUPPORTED_SHOCKS = ("ra",) + FLOW_SHOCKS + LEVEL_SHOCKS
FLOW_BACKWARD_NEWS_OFFSET = 1
BACKWARD_NAMES = (
    "cU", "cE", "U", "E", "Eb", "dEb", "aU", "aE", "J", "Jb",
    "JU0", "JE0", "q", "wU_i", "wU_pi", "wEwin_i", "wEwin_pi",
    "wElose_i", "wElose_pi", "Iwin",
)
CONTINUATION_NAMES = ("cU", "cE", "U", "E", "Eb", "dEb", "J", "Jb")


@dataclass(frozen=True)
class DmpStateLayout:
    """Packing convention for both beta types in one float64 state vector."""

    du_shape: tuple
    de_shape: tuple

    @property
    def du_size(self):
        return int(np.prod(self.du_shape))

    @property
    def de_size(self):
        return int(np.prod(self.de_shape))

    @property
    def size(self):
        return self.du_size + self.de_size

    def pack(self, DU, DE):
        DU = np.asarray(DU, dtype=np.float64)
        DE = np.asarray(DE, dtype=np.float64)
        if DU.shape != self.du_shape or DE.shape != self.de_shape:
            raise ValueError(
                f"State shapes must be {self.du_shape} and {self.de_shape}; "
                f"received {DU.shape} and {DE.shape}"
            )
        return np.concatenate((DU.ravel(), DE.ravel()))

    def unpack(self, state):
        state = np.asarray(state, dtype=np.float64)
        if state.shape != (self.size,):
            raise ValueError(f"Packed state must have shape {(self.size,)}")
        DU = state[:self.du_size].reshape(self.du_shape)
        DE = state[self.du_size:].reshape(self.de_shape)
        return DU, DE


@dataclass
class FakeNewsResult:
    jacobian: dict
    curlyY: dict
    curlyD: object
    fake_news: dict
    timings: dict
    diagnostics: dict
    cache: "DmpSteadyStateCache"


def _validate_inputs(par, ss):
    required_par = (
        "nZ", "nA", "nW", "nP", "nT", "nB", "M", "a_grid", "w_grid",
        "z_grid", "p_grid", "Pi", "sigma", "gU", "gE", "s", "dbeta",
    )
    required_ss = (
        "inputs", "r", "rK", "Z", "tax", "transfer", "lambdas", "sigmaJ",
        "sigmaslope", "bUIH", "CUss", "CEss", "Uss", "Ess",
        "Ebargainingss", "dEbargainingss", "AUss", "AEss", "Jss",
        "Jbargainingss", "qss", "WUiss", "WUpiss", "WEwiniss",
        "WEwinpiss", "WEloseiss", "WElosepiss", "Iwins", "QUss", "QEss",
    )
    missing_par = [key for key in required_par if key not in par]
    missing_ss = [key for key in required_ss if key not in ss]
    if missing_par or missing_ss:
        raise KeyError(
            f"Missing fake-news inputs: par={missing_par}, ss={missing_ss}"
        )
    if par["nB"] != 2:
        raise ValueError("The initial prototype requires exactly two beta types")

    nZ, nA, nW, nP, nT, nB = (
        par["nZ"], par["nA"], par["nW"], par["nP"], par["nT"], par["nB"]
    )
    expected = {
        "QUss": (nZ, nA, nB),
        "QEss": (nZ, nA, nW, nP, nT, nB),
        "CUss": (nZ, nA, nB),
        "CEss": (nZ, nA, nW, nP, nT, nB),
        "AUss": (nZ, nA, nB),
        "AEss": (nZ, nA, nW, nP, nT, nB),
    }
    for key, shape in expected.items():
        if np.asarray(ss[key]).shape != shape:
            raise ValueError(f"{key} must have shape {shape}, got {ss[key].shape}")
        if np.asarray(ss[key]).dtype != np.float64:
            raise TypeError(f"{key} must use float64")


def _policy_dict(output):
    q = np.asarray(output["q"])
    iwin_shape = np.asarray(output["Iwin"]).shape
    if q.shape != iwin_shape:
        raise ValueError(
            "Adapted switching probabilities must retain the full current-wage "
            f"dimension: q has shape {q.shape}, Iwin has shape {iwin_shape}"
        )
    return {
        "aU": output["aU"],
        "aE": output["aE"],
        "wU_i": output["wU_i"],
        "wU_pi": output["wU_pi"],
        "wEwin_i": output["wEwin_i"],
        "wEwin_pi": output["wEwin_pi"],
        "wElose_i": output["wElose_i"],
        "wElose_pi": output["wElose_pi"],
        "q": q,
        "Iwin": output["Iwin"],
    }


def _forward_one_type(DU, DE, policy, par, ss):
    pol_i = {}
    pol_pi = {}
    pol_i["aU"], pol_pi["aU"] = utils.interpolate_coord_robust(
        par["a_grid"], policy["aU"]
    )
    pol_i["aE"], pol_pi["aE"] = utils.interpolate_coord_robust(
        par["a_grid"], policy["aE"]
    )
    w_i = {
        "U": policy["wU_i"],
        "Ewin": policy["wEwin_i"],
        "Elose": policy["wElose_i"],
    }
    w_pi = {
        "U": policy["wU_pi"],
        "Ewin": policy["wEwin_pi"],
        "Elose": policy["wElose_pi"],
    }
    def apply_nonnegative(DU_part, DE_part):
        DUnew, DEnew, _, _ = utils.forward_step_dmp_td(
            DU_part, DE_part, pol_i, pol_pi, w_i, w_pi,
            policy["Iwin"], policy["q"], ss["lambdas"], ss["sigmaJ"],
            ss["sigmaslope"], par,
        )
        return DUnew, DEnew

    if np.any(DU < 0.0) or np.any(DE < 0.0):
        DU_pos, DE_pos = apply_nonnegative(
            np.maximum(DU, 0.0), np.maximum(DE, 0.0)
        )
        DU_neg, DE_neg = apply_nonnegative(
            np.maximum(-DU, 0.0), np.maximum(-DE, 0.0)
        )
        return DU_pos - DU_neg, DE_pos - DE_neg
    return apply_nonnegative(DU, DE)


def _forward_one_type_full(DU, DE, policy, par, ss):
    pol_i = {}
    pol_pi = {}
    pol_i["aU"], pol_pi["aU"] = utils.interpolate_coord_robust(
        par["a_grid"], policy["aU"]
    )
    pol_i["aE"], pol_pi["aE"] = utils.interpolate_coord_robust(
        par["a_grid"], policy["aE"]
    )
    w_i = {
        "U": policy["wU_i"],
        "Ewin": policy["wEwin_i"],
        "Elose": policy["wElose_i"],
    }
    w_pi = {
        "U": policy["wU_pi"],
        "Ewin": policy["wEwin_pi"],
        "Elose": policy["wElose_pi"],
    }
    return utils.forward_step_dmp_td(
        DU, DE, pol_i, pol_pi, w_i, w_pi, policy["Iwin"], policy["q"],
        ss["lambdas"], ss["sigmaJ"], ss["sigmaslope"], par,
    )


@njit(cache=True)
def _flow_report_transpose_one_type(
    XDUE, XDEE, aU_i, aU_pi, aE_i, aE_pi, lambdas, sigma,
    gU, lmsU, gE, lmsE, s, Pi,
):
    """Transpose of the one-period DUE/DEE reporting map."""
    nZ, nA, nP = XDUE.shape
    _, _, nW, _, nTminus1, _ = XDEE.shape
    nT = nTminus1 + 1
    YU = np.zeros((nZ, nA))
    YE = np.zeros((nZ, nA, nW, nP, nT))

    for iz in range(nZ):
        for ia in range(nA):
            ia0 = aU_i[iz, ia]
            ia1 = min(ia0 + 1, nA - 1)
            wa0 = aU_pi[iz, ia]
            value = 0.0
            for ip_d in lmsU:
                find = lambdas[ip_d] * gU[ip_d]
                for zi in range(nZ):
                    value += Pi[iz, zi] * find * (
                        wa0 * XDUE[zi, ia0, ip_d]
                        + (1.0 - wa0) * XDUE[zi, ia1, ip_d]
                    )
            YU[iz, ia] = value

            for iw in range(nW):
                for ip_o in range(nP):
                    for it in range(nT):
                        ia0 = aE_i[iz, ia, iw, ip_o, it]
                        ia1 = min(ia0 + 1, nA - 1)
                        wa0 = aE_pi[iz, ia, iw, ip_o, it]
                        tnext = min(it + 1, nT - 1)
                        flow_tenure = tnext - 1
                        value = 0.0
                        for ip_d in lmsE[ip_o]:
                            offer = (
                                (1.0 - sigma[it]) * s * lambdas[ip_d]
                                * gE[ip_o, ip_d]
                            )
                            for zi in range(nZ):
                                value += Pi[iz, zi] * offer * (
                                    wa0 * XDEE[
                                        zi, ia0, iw, ip_o, flow_tenure, ip_d
                                    ]
                                    + (1.0 - wa0) * XDEE[
                                        zi, ia1, iw, ip_o, flow_tenure, ip_d
                                    ]
                                )
                        YE[iz, ia, iw, ip_o, it] = value
    return YU, YE


@njit(cache=True)
def _flow_shock_reports_one_type(
    DU, DE, aU_i, aU_pi, aE_i, aE_pi, lambda_index, dsigma,
    lambdas, sigma, gU, lmsU, gE, lmsE, s, Pi,
):
    """Analytical direct derivatives of the staged DUE and DEE reports."""
    nZ, nA = DU.shape
    _, _, nW, nP, nT = DE.shape
    dDUE_pre = np.zeros((nZ, nA, nP))
    dDEE_pre = np.zeros((nZ, nA, nW, nP, nT, nP))

    if lambda_index >= 0:
        for iz in range(nZ):
            for ia in range(nA):
                du = DU[iz, ia]
                ia0 = aU_i[iz, ia]
                ia1 = min(ia0 + 1, nA - 1)
                wa0 = aU_pi[iz, ia]
                for ip_d in lmsU:
                    if ip_d == lambda_index:
                        dDUE_pre[iz, ia0, ip_d] += wa0 * du * gU[ip_d]
                        dDUE_pre[iz, ia1, ip_d] += (
                            (1.0 - wa0) * du * gU[ip_d]
                        )

    for iz in range(nZ):
        for ia in range(nA):
            for iw in range(nW):
                for ip_o in range(nP):
                    for it in range(nT):
                        de = DE[iz, ia, iw, ip_o, it]
                        ia0 = aE_i[iz, ia, iw, ip_o, it]
                        ia1 = min(ia0 + 1, nA - 1)
                        wa0 = aE_pi[iz, ia, iw, ip_o, it]
                        tnext = min(it + 1, nT - 1)
                        for ip_d in lmsE[ip_o]:
                            lfind = s * lambdas[ip_d] * gE[ip_o, ip_d]
                            if lambda_index >= 0:
                                dflow = (
                                    (1.0 - sigma[it]) * s * gE[ip_o, ip_d]
                                    if ip_d == lambda_index else 0.0
                                )
                            else:
                                dflow = -dsigma[it] * lfind
                            dDEE_pre[iz, ia0, iw, ip_o, tnext, ip_d] += (
                                wa0 * de * dflow
                            )
                            dDEE_pre[iz, ia1, iw, ip_o, tnext, ip_d] += (
                                (1.0 - wa0) * de * dflow
                            )

    dDUE = np.zeros_like(dDUE_pre)
    dDEE = np.zeros((nZ, nA, nW, nP, nT - 1, nP))
    for iz in range(nZ):
        for zi in range(nZ):
            probability = Pi[iz, zi]
            for ia in range(nA):
                for ip_d in range(nP):
                    dDUE[zi, ia, ip_d] += (
                        probability * dDUE_pre[iz, ia, ip_d]
                    )
                for iw in range(nW):
                    for ip_o in range(nP):
                        for it in range(1, nT):
                            for ip_d in range(nP):
                                dDEE[zi, ia, iw, ip_o, it - 1, ip_d] += (
                                    probability
                                    * dDEE_pre[iz, ia, iw, ip_o, it, ip_d]
                                )
    return dDUE, dDEE


@njit(cache=True)
def _transition_shock_forward_one_type(
    DU, DE, aU_i, aU_pi, aE_i, aE_pi, wU_i, wU_pi,
    wEwin_i, wEwin_pi, wElose_i, wElose_pi, Iwin, qswitch,
    lambda_index, dsigma, lambdas, sigma, gU, lmsU, gE, lmsE, s, Pi,
):
    """Apply the analytical probability derivative dL to one DU/DE state."""
    nZ, nA = DU.shape
    _, _, nW, nP, nT = DE.shape
    dDU = np.zeros_like(DU)
    dDE = np.zeros_like(DE)

    if lambda_index >= 0:
        for iz in range(nZ):
            for ia in range(nA):
                du = DU[iz, ia]
                if du == 0.0:
                    continue
                ia0 = aU_i[iz, ia]
                ia1 = min(ia0 + 1, nA - 1)
                wa0 = aU_pi[iz, ia]
                for ip_d in lmsU:
                    if ip_d != lambda_index:
                        continue
                    rate = gU[ip_d]
                    for zi in range(nZ):
                        prob = du * Pi[iz, zi] * rate
                        dDU[zi, ia0] -= wa0 * prob
                        dDU[zi, ia1] -= (1.0 - wa0) * prob

                        iw00 = wU_i[zi, ia0, ip_d]
                        iw01 = min(iw00 + 1, nW - 1)
                        ww00 = wU_pi[zi, ia0, ip_d]
                        iw10 = wU_i[zi, ia1, ip_d]
                        iw11 = min(iw10 + 1, nW - 1)
                        ww10 = wU_pi[zi, ia1, ip_d]
                        dDE[zi, ia0, iw00, ip_d, 0] += wa0 * ww00 * prob
                        dDE[zi, ia0, iw01, ip_d, 0] += wa0 * (1.0 - ww00) * prob
                        dDE[zi, ia1, iw10, ip_d, 0] += (1.0 - wa0) * ww10 * prob
                        dDE[zi, ia1, iw11, ip_d, 0] += (
                            (1.0 - wa0) * (1.0 - ww10) * prob
                        )

    for iz in range(nZ):
        for ia in range(nA):
            for iw in range(nW):
                for ip_o in range(nP):
                    for it in range(nT):
                        de_home = DE[iz, ia, iw, ip_o, it]
                        if de_home == 0.0:
                            continue
                        ia0 = aE_i[iz, ia, iw, ip_o, it]
                        ia1 = min(ia0 + 1, nA - 1)
                        wa0 = aE_pi[iz, ia, iw, ip_o, it]
                        tnext = min(it + 1, nT - 1)
                        itnew = tnext - 1

                        for ip_d in lmsE[ip_o]:
                            dlfind = 0.0
                            if lambda_index == ip_d:
                                dlfind = s * gE[ip_o, ip_d]
                            lfind = s * lambdas[ip_d] * gE[ip_o, ip_d]

                            if lambda_index >= 0:
                                dsep = 0.0
                                dno_offer = -(1.0 - sigma[it]) * dlfind
                                doffer = (1.0 - sigma[it]) * dlfind
                            else:
                                dsep = dsigma[it]
                                dno_offer = -(1.0 - lfind) * dsigma[it]
                                doffer = -lfind * dsigma[it]

                            for zi in range(nZ):
                                base = de_home * Pi[iz, zi]
                                if dsep != 0.0:
                                    dDU[zi, ia0] += wa0 * base * dsep
                                    dDU[zi, ia1] += (1.0 - wa0) * base * dsep

                                if dno_offer != 0.0:
                                    dDE[zi, ia0, iw, ip_o, tnext] += (
                                        wa0 * base * dno_offer
                                    )
                                    dDE[zi, ia1, iw, ip_o, tnext] += (
                                        (1.0 - wa0) * base * dno_offer
                                    )

                                if doffer == 0.0:
                                    continue
                                for asset_case in range(2):
                                    if asset_case == 0:
                                        iad = ia0
                                        asset_weight = wa0
                                    else:
                                        iad = ia1
                                        asset_weight = 1.0 - wa0
                                    iw_win = wEwin_i[zi, iad, iw, ip_o, itnew, ip_d]
                                    iw_win1 = min(iw_win + 1, nW - 1)
                                    ww_win = wEwin_pi[zi, iad, iw, ip_o, itnew, ip_d]
                                    iw_lose = wElose_i[zi, iad, iw, ip_o, itnew, ip_d]
                                    iw_lose1 = min(iw_lose + 1, nW - 1)
                                    ww_lose = wElose_pi[zi, iad, iw, ip_o, itnew, ip_d]
                                    switch = qswitch[zi, iad, iw, ip_o, itnew, ip_d]
                                    wins = Iwin[zi, iad, iw, ip_o, itnew, ip_d] == 1
                                    move_rung = ip_d
                                    move_tenure = 0
                                    stay_rung = ip_o
                                    stay_tenure = tnext

                                    if wins:
                                        dDE[zi, iad, iw_win, move_rung, move_tenure] += (
                                            asset_weight * base * doffer * switch * ww_win
                                        )
                                        dDE[zi, iad, iw_win1, move_rung, move_tenure] += (
                                            asset_weight * base * doffer * switch
                                            * (1.0 - ww_win)
                                        )
                                        dDE[zi, iad, iw_win, stay_rung, stay_tenure] += (
                                            asset_weight * base * doffer
                                            * (1.0 - switch) * ww_win
                                        )
                                        dDE[zi, iad, iw_win1, stay_rung, stay_tenure] += (
                                            asset_weight * base * doffer
                                            * (1.0 - switch) * (1.0 - ww_win)
                                        )
                                    else:
                                        dDE[zi, iad, iw_lose, move_rung, move_tenure] += (
                                            asset_weight * base * doffer * switch * ww_lose
                                        )
                                        dDE[zi, iad, iw_lose1, move_rung, move_tenure] += (
                                            asset_weight * base * doffer * switch
                                            * (1.0 - ww_lose)
                                        )
                                        dDE[zi, iad, iw_lose, stay_rung, stay_tenure] += (
                                            asset_weight * base * doffer
                                            * (1.0 - switch) * ww_lose
                                        )
                                        dDE[zi, iad, iw_lose1, stay_rung, stay_tenure] += (
                                            asset_weight * base * doffer
                                            * (1.0 - switch) * (1.0 - ww_lose)
                                        )
    return dDU, dDE


@njit(cache=True)
def _transpose_one_type(
    XU, XE, aU_i, aU_pi, aE_i, aE_pi, wU_i, wU_pi,
    wEwin_i, wEwin_pi, wElose_i, wElose_pi, Iwin, qswitch,
    lambdas, sigma, gU, lmsU, gE, lmsE, s, Pi,
):
    nZ, nA = XU.shape
    _, _, nW, nP, nT = XE.shape
    YU = np.zeros_like(XU)
    YE = np.zeros_like(XE)

    for iz in range(nZ):
        for ia in range(nA):
            ia0 = aU_i[iz, ia]
            ia1 = min(ia0 + 1, nA - 1)
            wa0 = aU_pi[iz, ia]
            value = 0.0
            for ip_d in lmsU:
                find = lambdas[ip_d] * gU[ip_d]
                for zi in range(nZ):
                    prob_z = Pi[iz, zi]
                    value += prob_z * (1.0 - find) * (
                        wa0 * XU[zi, ia0] + (1.0 - wa0) * XU[zi, ia1]
                    )

                    iw00 = wU_i[zi, ia0, ip_d]
                    iw01 = min(iw00 + 1, nW - 1)
                    ww00 = wU_pi[zi, ia0, ip_d]
                    iw10 = wU_i[zi, ia1, ip_d]
                    iw11 = min(iw10 + 1, nW - 1)
                    ww10 = wU_pi[zi, ia1, ip_d]
                    value += prob_z * find * (
                        wa0 * (
                            ww00 * XE[zi, ia0, iw00, ip_d, 0]
                            + (1.0 - ww00) * XE[zi, ia0, iw01, ip_d, 0]
                        )
                        + (1.0 - wa0) * (
                            ww10 * XE[zi, ia1, iw10, ip_d, 0]
                            + (1.0 - ww10) * XE[zi, ia1, iw11, ip_d, 0]
                        )
                    )
            YU[iz, ia] = value

            for iw in range(nW):
                for ip_o in range(nP):
                    for it in range(nT):
                        ia0 = aE_i[iz, ia, iw, ip_o, it]
                        ia1 = min(ia0 + 1, nA - 1)
                        wa0 = aE_pi[iz, ia, iw, ip_o, it]
                        tnext = min(it + 1, nT - 1)
                        itnew = tnext - 1
                        prsep = sigma[it]
                        value = 0.0

                        for ip_d in lmsE[ip_o]:
                            lfind = s * lambdas[ip_d] * gE[ip_o, ip_d]
                            no_offer = (1.0 - prsep) * (1.0 - lfind)
                            offer = (1.0 - prsep) * lfind

                            for zi in range(nZ):
                                prob_z = Pi[iz, zi]
                                value += prob_z * prsep * (
                                    wa0 * XU[zi, ia0]
                                    + (1.0 - wa0) * XU[zi, ia1]
                                )
                                value += prob_z * no_offer * (
                                    wa0 * XE[zi, ia0, iw, ip_o, tnext]
                                    + (1.0 - wa0) * XE[zi, ia1, iw, ip_o, tnext]
                                )

                                for asset_case in range(2):
                                    if asset_case == 0:
                                        iad = ia0
                                        asset_weight = wa0
                                    else:
                                        iad = ia1
                                        asset_weight = 1.0 - wa0

                                    iw_win = wEwin_i[
                                        zi, iad, iw, ip_o, itnew, ip_d
                                    ]
                                    iw_win1 = min(iw_win + 1, nW - 1)
                                    ww_win = wEwin_pi[
                                        zi, iad, iw, ip_o, itnew, ip_d
                                    ]
                                    iw_lose = wElose_i[
                                        zi, iad, iw, ip_o, itnew, ip_d
                                    ]
                                    iw_lose1 = min(iw_lose + 1, nW - 1)
                                    ww_lose = wElose_pi[
                                        zi, iad, iw, ip_o, itnew, ip_d
                                    ]
                                    wins = Iwin[
                                        zi, iad, iw, ip_o, itnew, ip_d
                                    ] == 1
                                    switch = qswitch[
                                        zi, iad, iw, ip_o, itnew, ip_d
                                    ]

                                    if wins:
                                        p_win_switch = switch
                                        p_win_stay = 1.0 - switch
                                        p_lose_switch = 0.0
                                        p_lose_stay = 0.0
                                    else:
                                        p_win_switch = 0.0
                                        p_win_stay = 0.0
                                        p_lose_switch = switch
                                        p_lose_stay = 1.0 - switch

                                    win_move = (
                                        ww_win * XE[zi, iad, iw_win, ip_d, 0]
                                        + (1.0 - ww_win)
                                        * XE[zi, iad, iw_win1, ip_d, 0]
                                    )
                                    win_stay = (
                                        ww_win
                                        * XE[zi, iad, iw_win, ip_o, tnext]
                                        + (1.0 - ww_win)
                                        * XE[zi, iad, iw_win1, ip_o, tnext]
                                    )
                                    lose_move = (
                                        ww_lose
                                        * XE[zi, iad, iw_lose, ip_d, 0]
                                        + (1.0 - ww_lose)
                                        * XE[zi, iad, iw_lose1, ip_d, 0]
                                    )
                                    lose_stay = (
                                        ww_lose
                                        * XE[zi, iad, iw_lose, ip_o, tnext]
                                        + (1.0 - ww_lose)
                                        * XE[zi, iad, iw_lose1, ip_o, tnext]
                                    )
                                    value += (
                                        prob_z * offer * asset_weight
                                        * (
                                            p_win_switch * win_move
                                            + p_win_stay * win_stay
                                            + p_lose_switch * lose_move
                                            + p_lose_stay * lose_stay
                                        )
                                    )
                        YE[iz, ia, iw, ip_o, it] = value
    return YU, YE


@njit(cache=True)
def _transition_shock_transpose_one_type(
    XU, XE, aU_i, aU_pi, aE_i, aE_pi, wU_i, wU_pi,
    wEwin_i, wEwin_pi, wElose_i, wElose_pi, Iwin, qswitch,
    lambda_index, dsigma, lambdas, sigma, gU, lmsU, gE, lmsE, s, Pi,
):
    """Apply dL.T without constructing either L or dL."""
    nZ, nA = XU.shape
    _, _, nW, nP, nT = XE.shape
    YU = np.zeros_like(XU)
    YE = np.zeros_like(XE)

    if lambda_index >= 0:
        for iz in range(nZ):
            for ia in range(nA):
                ia0 = aU_i[iz, ia]
                ia1 = min(ia0 + 1, nA - 1)
                wa0 = aU_pi[iz, ia]
                value = 0.0
                for ip_d in lmsU:
                    if ip_d != lambda_index:
                        continue
                    rate = gU[ip_d]
                    for zi in range(nZ):
                        iw00 = wU_i[zi, ia0, ip_d]
                        iw01 = min(iw00 + 1, nW - 1)
                        ww00 = wU_pi[zi, ia0, ip_d]
                        iw10 = wU_i[zi, ia1, ip_d]
                        iw11 = min(iw10 + 1, nW - 1)
                        ww10 = wU_pi[zi, ia1, ip_d]
                        employed = (
                            wa0 * (
                                ww00 * XE[zi, ia0, iw00, ip_d, 0]
                                + (1.0 - ww00) * XE[zi, ia0, iw01, ip_d, 0]
                            )
                            + (1.0 - wa0) * (
                                ww10 * XE[zi, ia1, iw10, ip_d, 0]
                                + (1.0 - ww10) * XE[zi, ia1, iw11, ip_d, 0]
                            )
                        )
                        unemployed = (
                            wa0 * XU[zi, ia0] + (1.0 - wa0) * XU[zi, ia1]
                        )
                        value += Pi[iz, zi] * rate * (employed - unemployed)
                YU[iz, ia] = value

    for iz in range(nZ):
        for ia in range(nA):
            for iw in range(nW):
                for ip_o in range(nP):
                    for it in range(nT):
                        ia0 = aE_i[iz, ia, iw, ip_o, it]
                        ia1 = min(ia0 + 1, nA - 1)
                        wa0 = aE_pi[iz, ia, iw, ip_o, it]
                        tnext = min(it + 1, nT - 1)
                        itnew = tnext - 1
                        value = 0.0
                        for ip_d in lmsE[ip_o]:
                            lfind = s * lambdas[ip_d] * gE[ip_o, ip_d]
                            if lambda_index >= 0:
                                dlfind = (
                                    s * gE[ip_o, ip_d]
                                    if lambda_index == ip_d else 0.0
                                )
                                dsep = 0.0
                                dno_offer = -(1.0 - sigma[it]) * dlfind
                                doffer = (1.0 - sigma[it]) * dlfind
                            else:
                                dsep = dsigma[it]
                                dno_offer = -(1.0 - lfind) * dsigma[it]
                                doffer = -lfind * dsigma[it]

                            for zi in range(nZ):
                                unemployed = (
                                    wa0 * XU[zi, ia0]
                                    + (1.0 - wa0) * XU[zi, ia1]
                                )
                                no_offer = (
                                    wa0 * XE[zi, ia0, iw, ip_o, tnext]
                                    + (1.0 - wa0)
                                    * XE[zi, ia1, iw, ip_o, tnext]
                                )
                                offer = 0.0
                                for asset_case in range(2):
                                    if asset_case == 0:
                                        iad = ia0
                                        asset_weight = wa0
                                    else:
                                        iad = ia1
                                        asset_weight = 1.0 - wa0
                                    iw_win = wEwin_i[
                                        zi, iad, iw, ip_o, itnew, ip_d
                                    ]
                                    iw_win1 = min(iw_win + 1, nW - 1)
                                    ww_win = wEwin_pi[
                                        zi, iad, iw, ip_o, itnew, ip_d
                                    ]
                                    iw_lose = wElose_i[
                                        zi, iad, iw, ip_o, itnew, ip_d
                                    ]
                                    iw_lose1 = min(iw_lose + 1, nW - 1)
                                    ww_lose = wElose_pi[
                                        zi, iad, iw, ip_o, itnew, ip_d
                                    ]
                                    switch = qswitch[
                                        zi, iad, iw, ip_o, itnew, ip_d
                                    ]
                                    if Iwin[
                                        zi, iad, iw, ip_o, itnew, ip_d
                                    ] == 1:
                                        move = (
                                            ww_win * XE[zi, iad, iw_win, ip_d, 0]
                                            + (1.0 - ww_win)
                                            * XE[zi, iad, iw_win1, ip_d, 0]
                                        )
                                        stay = (
                                            ww_win
                                            * XE[zi, iad, iw_win, ip_o, tnext]
                                            + (1.0 - ww_win)
                                            * XE[zi, iad, iw_win1, ip_o, tnext]
                                        )
                                    else:
                                        move = (
                                            ww_lose
                                            * XE[zi, iad, iw_lose, ip_d, 0]
                                            + (1.0 - ww_lose)
                                            * XE[zi, iad, iw_lose1, ip_d, 0]
                                        )
                                        stay = (
                                            ww_lose
                                            * XE[zi, iad, iw_lose, ip_o, tnext]
                                            + (1.0 - ww_lose)
                                            * XE[zi, iad, iw_lose1, ip_o, tnext]
                                        )
                                    offer += asset_weight * (
                                        switch * move + (1.0 - switch) * stay
                                    )
                                value += Pi[iz, zi] * (
                                    dsep * unemployed
                                    + dno_offer * no_offer
                                    + doffer * offer
                                )
                        YE[iz, ia, iw, ip_o, it] = value
    return YU, YE


class DmpSteadyStateCache:
    """Reusable steady-state transition, transpose, and output metadata."""

    def __init__(self, par, ss):
        _validate_inputs(par, ss)
        self.par = par.copy()
        self.ss = ss
        self._source_par = par
        self._source_ss = ss
        self.layout = DmpStateLayout(ss["QUss"].shape, ss["QEss"].shape)
        self.Dss = self.layout.pack(ss["QUss"], ss["QEss"])
        self.baseline_outputs = []
        self.baseline_policies = []
        self.shock_timing = {
            "ra": {
                "backward": "current budget at news 0; ante return at news 1",
                "forward": "policy-induced DU/DE transition",
                "direct": "current Walras asset-return term",
            },
            **{
                shock: {
                    "backward": "current agent_step_td input at news 0",
                    "forward": "policy-induced DU/DE transition",
                    "direct": (
                        "current Pi"
                        if shock in ("Z", "rK")
                        else "current fiscal/reporting term"
                    ),
                }
                for shock in LEVEL_SHOCKS
            },
            **{
                shock: {
                    "backward": (
                        f"agent_step_td transition input at news "
                        f"{FLOW_BACKWARD_NEWS_OFFSET}"
                    ),
                    "forward": "analytical dry-run dL@Dss at news 0",
                    "direct": "current DUE/DEE reporting at news 0",
                }
                for shock in FLOW_SHOCKS
            },
        }
        self.output_timing = {
            **{output: "beginning DU/DE stock" for output in STOCK_OUTPUTS},
            **{output: "current policy weighted by beginning DU/DE"
               for output in POLICY_OUTPUTS},
            "EU_rate": "beginning DE with current separation probabilities",
            "earnings": "beginning DE wage ratio",
            "Tax": "beginning DE wage bill with current tax",
            "Ubill": "beginning DU by type with current benefits",
            "Pi": "beginning DE with current Z and rK flow profits",
            "EE_rate": "end-of-transition DEE flow with current switch policy",
            **{output: "end-of-transition DOU/DUE/DEE report"
               for output in RUNG_OUTPUTS + FIRM_OUTPUTS},
            **{output: "identity assembled from primitive Jacobians"
               for output in WALRAS_OUTPUTS},
        }
        self._expectation_cache = {}
        self._expectation_directory = tempfile.TemporaryDirectory(
            prefix="dmp-fake-news-expectations-",
            dir=self.par.get("fake_news_tmpdir"),
        )

        for ib in range(par["nB"]):
            output = self._backward_call(ib, {}, 0.0)
            self.baseline_outputs.append(output)
            self.baseline_policies.append(_policy_dict(output))

        self.transition_metadata = self._make_transition_metadata()
        self.baseline_flow_reports = self.flow_reports(self.Dss)
        self.output_functions = self._make_output_functions()
        self.grid_spacing = np.diff(np.asarray(par["a_grid"], dtype=np.float64))
        self.baseline_next = self.forward(self.Dss)
        self.stationarity_error = np.max(np.abs(self.baseline_next - self.Dss))

    def _make_transition_metadata(self):
        metadata = []
        lmsU, lmsE, tnext = utils.labor_market_cache(self.par)
        for policy in self.baseline_policies:
            aU_i, aU_pi = utils.interpolate_coord_robust(
                self.par["a_grid"], policy["aU"]
            )
            aE_i, aE_pi = utils.interpolate_coord_robust(
                self.par["a_grid"], policy["aE"]
            )
            metadata.append({
                "aU_i": aU_i,
                "aU_pi": aU_pi,
                "aE_i": aE_i,
                "aE_pi": aE_pi,
                "lmsU": lmsU,
                "lmsE": lmsE,
                "tnext": tnext,
            })
        return metadata

    def _make_output_functions(self):
        DU_zero = np.zeros_like(self.ss["QUss"], dtype=np.float64)
        DE_zero = np.zeros_like(self.ss["QEss"], dtype=np.float64)
        DU_one = np.ones_like(self.ss["QUss"], dtype=np.float64)
        DE_one = np.ones_like(self.ss["QEss"], dtype=np.float64)
        aU = np.stack([output["aU"] for output in self.baseline_outputs], axis=-1)
        aE = np.stack([output["aE"] for output in self.baseline_outputs], axis=-1)
        cU = np.stack([output["cU"] for output in self.baseline_outputs], axis=-1)
        cE = np.stack([output["cE"] for output in self.baseline_outputs], axis=-1)
        asset_u = np.broadcast_to(
            self.par["a_grid"][np.newaxis, :, np.newaxis],
            self.ss["QUss"].shape,
        ).copy()
        asset_e = np.broadcast_to(
            self.par["a_grid"][
                np.newaxis, :, np.newaxis, np.newaxis, np.newaxis, np.newaxis
            ],
            self.ss["QEss"].shape,
        ).copy()
        wage_e = np.broadcast_to(
            self.par["w_grid"][
                np.newaxis, np.newaxis, :, np.newaxis, np.newaxis, np.newaxis
            ],
            self.ss["QEss"].shape,
        ).copy()
        nE = (
            self.par["z_grid"][:, np.newaxis, np.newaxis, np.newaxis, np.newaxis, np.newaxis]
            * self.par["p_grid"][np.newaxis, np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]
        )
        nE = np.broadcast_to(nE, self.ss["QEss"].shape).copy()
        functions = {
            "A": self.layout.pack(aU, aE),
            "C": self.layout.pack(cU, cE),
            "AU": self.layout.pack(aU, DE_zero),
            "AE": self.layout.pack(DU_zero, aE),
            "CU": self.layout.pack(cU, DE_zero),
            "CE": self.layout.pack(DU_zero, cE),
            "U": self.layout.pack(DU_one, DE_zero),
            "N": self.layout.pack(DU_zero, nE),
            "A_pre": self.layout.pack(asset_u, asset_e),
            "AU_pre": self.layout.pack(asset_u, DE_zero),
            "AE_pre": self.layout.pack(DU_zero, asset_e),
        }
        employed_mass = float(self.ss["QEss"].sum())
        if employed_mass <= 0:
            raise ValueError("Steady-state employed mass must be positive")
        wage_bill = float(np.vdot(self.ss["QEss"], wage_e))
        functions["Tax"] = self.layout.pack(
            DU_zero, self.ss["tax"] * wage_e
        )
        functions["earnings"] = self.layout.pack(
            DU_zero,
            wage_e / employed_mass - wage_bill * DE_one / employed_mass**2,
        )
        benefit_u = np.empty_like(self.ss["QUss"])
        benefit_u[..., 0] = self.ss["bUIL"]
        benefit_u[..., 1] = self.ss["bUIH"]
        functions["Ubill"] = self.layout.pack(benefit_u, DE_zero)

        pi_weight = self._profit_weight(self.ss["Z"], self.ss["rK"])
        functions["Pi"] = self.layout.pack(DU_zero, pi_weight)

        sigma = self._sigma(self.ss["sigmaJ"], self.ss["sigmaslope"])
        sigma_e = np.broadcast_to(
            sigma[np.newaxis, np.newaxis, np.newaxis, :, np.newaxis],
            self.ss["QEss"].shape,
        )
        eu_numerator = float(np.vdot(self.ss["QEss"], sigma_e))
        functions["EU_rate"] = self.layout.pack(
            DU_zero,
            sigma_e / employed_mass - eu_numerator * DE_one / employed_mass**2,
        )

        for output in FLOW_RATE_OUTPUTS[0:1] + RUNG_OUTPUTS + FIRM_OUTPUTS:
            functions[output] = self._flow_output_seed(output)
        return functions

    def _sigma(self, sigmaJ, sigmaslope):
        sigma = np.asarray(self.par["sigma"], dtype=np.float64)
        return (sigma + (sigmaJ - sigma[-1])) * (1.0 + sigmaslope)

    def _profit_weight(self, Z, rK):
        k_little = (
            rK / (self.par["alpha"] * Z)
        ) ** (1.0 / (self.par["alpha"] - 1.0))
        eff = (
            self.par["z_grid"][:, np.newaxis, np.newaxis]
            * self.par["p_grid"][np.newaxis, np.newaxis, :]
        )
        flow = (
            eff
            * (Z * utils.f(k_little, self.par) - rK * k_little)
            - self.par["w_grid"][np.newaxis, :, np.newaxis]
        )
        return np.broadcast_to(
            flow[
                :, np.newaxis, :, :, np.newaxis, np.newaxis
            ],
            self.ss["QEss"].shape,
        ).copy()

    def flow_reports(self, state, policies=None, flow_values=None):
        """Return end-of-transition DU plus one-period DUE and DEE reports."""
        DU, DE = self.layout.unpack(state)
        if policies is None:
            policies = self.baseline_policies
        if flow_values is None:
            flow_values = {
                "lambdas": self.ss["lambdas"],
                "sigmaJ": self.ss["sigmaJ"],
                "sigmaslope": self.ss["sigmaslope"],
            }
        flow_ss = dict(self.ss)
        flow_ss.update(flow_values)
        DUnew = np.empty_like(DU)
        DUE = np.empty_like(self.ss["QUEss"])
        DEE = np.empty_like(self.ss["QEEss"])
        for ib in range(self.par["nB"]):
            DUnew_i, _, DUE_i, DEE_i = _forward_one_type_full(
                DU[:, :, ib], DE[:, :, :, :, :, ib], policies[ib],
                self.par, flow_ss,
            )
            DUnew[:, :, ib] = DUnew_i
            DUE[:, :, :, ib] = DUE_i
            DEE[:, :, :, :, :, :, ib] = DEE_i
        return DUnew, DUE, DEE

    def flow_report_transpose(self, XUnew=None, XDUE=None, XDEE=None):
        """Map staged DU/DUE/DEE report weights to beginning DU/DE states."""
        if XUnew is None:
            XUnew = np.zeros_like(self.ss["QUss"])
        if XDUE is None:
            XDUE = np.zeros_like(self.ss["QUEss"])
        if XDEE is None:
            XDEE = np.zeros_like(self.ss["QEEss"])
        YU = np.empty_like(self.ss["QUss"])
        YE = np.empty_like(self.ss["QEss"])
        sigma = self._sigma(self.ss["sigmaJ"], self.ss["sigmaslope"])
        for ib, policy in enumerate(self.baseline_policies):
            metadata = self.transition_metadata[ib]
            zero_e = np.zeros_like(self.ss["QEss"][:, :, :, :, :, ib])
            stock_u, stock_e = _transpose_one_type(
                XUnew[:, :, ib], zero_e,
                metadata["aU_i"], metadata["aU_pi"],
                metadata["aE_i"], metadata["aE_pi"],
                policy["wU_i"], policy["wU_pi"],
                policy["wEwin_i"], policy["wEwin_pi"],
                policy["wElose_i"], policy["wElose_pi"],
                policy["Iwin"], policy["q"], self.ss["lambdas"], sigma,
                self.par["gU"], metadata["lmsU"], self.par["gE"],
                metadata["lmsE"], self.par["s"], self.par["Pi"],
            )
            flow_u, flow_e = _flow_report_transpose_one_type(
                XDUE[:, :, :, ib], XDEE[:, :, :, :, :, :, ib],
                metadata["aU_i"], metadata["aU_pi"],
                metadata["aE_i"], metadata["aE_pi"],
                self.ss["lambdas"], sigma, self.par["gU"],
                metadata["lmsU"], self.par["gE"], metadata["lmsE"],
                self.par["s"], self.par["Pi"],
            )
            YU[:, :, ib] = stock_u + flow_u
            YE[:, :, :, :, :, ib] = stock_e + flow_e
        return self.layout.pack(YU, YE)

    def flow_shock_reports(self, shock):
        """Return analytical direct derivatives of DUnew, DUE, and DEE."""
        direct_state = self.transition_shock_forward(shock)
        dDUnew, _ = self.layout.unpack(direct_state)
        dDUE = np.empty_like(self.ss["QUEss"])
        dDEE = np.empty_like(self.ss["QEEss"])
        lambda_index, dsigma, sigma = self._flow_derivative_parameters(shock)
        for ib in range(self.par["nB"]):
            metadata = self.transition_metadata[ib]
            due, dee = _flow_shock_reports_one_type(
                self.ss["QUss"][:, :, ib],
                self.ss["QEss"][:, :, :, :, :, ib],
                metadata["aU_i"], metadata["aU_pi"],
                metadata["aE_i"], metadata["aE_pi"],
                lambda_index, dsigma, self.ss["lambdas"], sigma,
                self.par["gU"], metadata["lmsU"], self.par["gE"],
                metadata["lmsE"], self.par["s"], self.par["Pi"],
            )
            dDUE[:, :, :, ib] = due
            dDEE[:, :, :, :, :, :, ib] = dee
        return dDUnew, dDUE, dDEE

    def _flow_output_seed(self, output):
        DU_zero = np.zeros_like(self.ss["QUss"])
        DE_zero = np.zeros_like(self.ss["QEss"])
        XDUE = np.zeros_like(self.ss["QUEss"])
        XDEE = np.zeros_like(self.ss["QEEss"])
        XUnew = np.zeros_like(self.ss["QUss"])
        employed_mass = float(self.ss["QEss"].sum())

        if output == "EE_rate":
            baseline_dee = self.baseline_flow_reports[2]
            q = np.stack(
                [policy["q"] for policy in self.baseline_policies], axis=-1
            )
            numerator = float(np.vdot(baseline_dee, q))
            XDEE[:] = q / employed_mass
            base = self.flow_report_transpose(XDEE=XDEE)
            denominator = self.layout.pack(
                DU_zero,
                -numerator * np.ones_like(self.ss["QEss"]) / employed_mass**2,
            )
            return base + denominator

        if output.startswith("e"):
            rung = int(output[1:])
            XUnew[:] = self.par["gU"][rung]
            # Searchers are classified by the destination-rung axis of DEE
            # (axis 5), consistently with report_levels().
            XDEE[:, :, :, :, :, rung, :] = 1.0
            return self.flow_report_transpose(
                XUnew=XUnew, XDEE=XDEE
            )

        rung = int(output[3:])
        baseline_due = self.baseline_flow_reports[1]
        baseline_dee = self.baseline_flow_reports[2]
        due_total = float(baseline_due.sum())
        if due_total <= 0:
            raise ValueError("Steady-state U-to-E flow mass must be positive")
        due_numerator = float(
            np.vdot(
                self.ss["JU0s"][:, :, rung, :],
                baseline_due[:, :, rung, :],
            )
        )
        XDUE[:] = -due_numerator / due_total**2
        XDUE[:, :, rung, :] += self.ss["JU0s"][:, :, rung, :] / due_total

        switch_mass = float(baseline_dee[:, :, :, :, :, rung, :].sum())
        if switch_mass == 0.0:
            if rung != 0:
                raise ValueError(
                    f"Structurally absent switch denominator for J0_{rung}"
                )
        else:
            switch_numerator = float(
                np.vdot(
                    self.ss["JE0s"][:, :, :, :, :, rung, :],
                    baseline_dee[:, :, :, :, :, rung, :],
                )
            )
            XDEE[:, :, :, :, :, rung, :] = (
                self.ss["JE0s"][:, :, :, :, :, rung, :] / switch_mass
                - switch_numerator / switch_mass**2
            )
        return self.flow_report_transpose(XDUE=XDUE, XDEE=XDEE)

    def _backward_call(
        self, ib, continuation_shocks, h,
        ra_post_shock=0.0, ra_ante_shock=0.0, continuation_levels=None,
        flow_shock=None, flow_scale=0.0, level_shock=None, level_scale=0.0,
    ):
        ss = self.ss
        local_par = self.par.copy()
        local_par["beta"] = self.par["beta"] + (2 * ib - 1) * self.par["dbeta"]

        if continuation_levels is None:
            continuation = {
                "cU": ss["CUss"][:, :, ib],
                "cE": ss["CEss"][:, :, :, :, :, ib],
                "U": ss["Uss"][:, :, ib],
                "E": ss["Ess"][:, :, :, :, :, ib],
                "Eb": ss["Ebargainingss"][:, :, :, :, :, ib],
                "dEb": ss["dEbargainingss"][:, :, :, :, :, ib],
                "J": ss["Jss"][:, :, :, :, :, ib],
                "Jb": ss["Jbargainingss"][:, :, :, :, :, ib],
            }
        else:
            continuation = {
                key: continuation_levels[key] for key in CONTINUATION_NAMES
            }
        for key, shock in continuation_shocks.items():
            continuation[key] = continuation[key] + h * shock

        lambdas = np.array(ss["lambdas"], dtype=np.float64, copy=True)
        sigmaJ = float(ss["sigmaJ"])
        sigmaslope = float(ss["sigmaslope"])
        if flow_shock is not None:
            if flow_shock.startswith("lambda"):
                lambdas[int(flow_shock[6:])] += h * flow_scale
            elif flow_shock == "sigmaJ":
                sigmaJ += h * flow_scale
            elif flow_shock == "sigmaslope":
                sigmaslope += h * flow_scale
            else:
                raise ValueError(f"Unsupported flow shock {flow_shock!r}")

        rK = float(ss["rK"])
        Z = float(ss["Z"])
        tax = float(ss["tax"])
        transfer = float(ss["transfer"])
        bUI = float((ss["bUIL"], ss["bUIH"])[ib])
        if level_shock is not None:
            if level_shock == "rK":
                rK += h * level_scale
            elif level_shock == "Z":
                Z += h * level_scale
            elif level_shock == "tax":
                tax += h * level_scale
            elif level_shock == "transfer":
                transfer += h * level_scale
            elif level_shock == "bUI":
                bUI += h * level_scale
            else:
                raise ValueError(f"Unsupported level shock {level_shock!r}")

        values = Jac_help.backward_iterate(
            ss["r"] + h * ra_ante_shock,
            ss["r"] + h * ra_post_shock, rK, Z, tax,
            lambdas, bUI, sigmaJ,
            sigmaslope, transfer, continuation["cU"],
            continuation["cE"], continuation["U"], continuation["E"],
            continuation["Eb"], continuation["dEb"], continuation["J"],
            continuation["Jb"], local_par,
        )
        return dict(zip(BACKWARD_NAMES, values))

    def forward(
        self, state, policies=None, lambdas=None, sigmaJ=None, sigmaslope=None
    ):
        DU, DE = self.layout.unpack(state)
        if policies is None:
            policies = self.baseline_policies
        flow_ss = self.ss
        if lambdas is not None or sigmaJ is not None or sigmaslope is not None:
            flow_ss = dict(self.ss)
            flow_ss["lambdas"] = (
                self.ss["lambdas"] if lambdas is None else lambdas
            )
            flow_ss["sigmaJ"] = self.ss["sigmaJ"] if sigmaJ is None else sigmaJ
            flow_ss["sigmaslope"] = (
                self.ss["sigmaslope"] if sigmaslope is None else sigmaslope
            )
        DUnew = np.empty_like(DU)
        DEnew = np.empty_like(DE)
        for ib in range(self.par["nB"]):
            DUnew[:, :, ib], DEnew[:, :, :, :, :, ib] = _forward_one_type(
                DU[:, :, ib], DE[:, :, :, :, :, ib], policies[ib],
                self.par, flow_ss,
            )
        return self.layout.pack(DUnew, DEnew)

    def report_levels(
        self, state=None, backward_outputs=None, policies=None, inputs=None
    ):
        """Evaluate all primitive serial-reference reports at their exact stage."""
        if state is None:
            state = self.Dss
        if backward_outputs is None:
            backward_outputs = self.baseline_outputs
        if policies is None:
            policies = [_policy_dict(output) for output in backward_outputs]
        if inputs is None:
            inputs = {}
        Z = float(inputs.get("Z", self.ss["Z"]))
        rK = float(inputs.get("rK", self.ss["rK"]))
        tax = float(inputs.get("tax", self.ss["tax"]))
        transfer = float(inputs.get("transfer", self.ss["transfer"]))
        del transfer
        bUI = np.asarray(
            inputs.get("bUI", (self.ss["bUIL"], self.ss["bUIH"])),
            dtype=np.float64,
        )
        if bUI.shape != (self.par["nB"],):
            raise ValueError(f"bUI levels must have shape {(self.par['nB'],)}")
        flow_values = {
            "lambdas": np.asarray(
                inputs.get("lambdas", self.ss["lambdas"]), dtype=np.float64
            ),
            "sigmaJ": float(inputs.get("sigmaJ", self.ss["sigmaJ"])),
            "sigmaslope": float(
                inputs.get("sigmaslope", self.ss["sigmaslope"])
            ),
        }

        DU, DE = self.layout.unpack(state)
        aU = np.stack([output["aU"] for output in backward_outputs], axis=-1)
        aE = np.stack([output["aE"] for output in backward_outputs], axis=-1)
        cU = np.stack([output["cU"] for output in backward_outputs], axis=-1)
        cE = np.stack([output["cE"] for output in backward_outputs], axis=-1)
        wage = np.broadcast_to(
            self.par["w_grid"][
                np.newaxis, np.newaxis, :, np.newaxis, np.newaxis, np.newaxis
            ],
            DE.shape,
        )
        asset_u = np.broadcast_to(
            self.par["a_grid"][np.newaxis, :, np.newaxis], DU.shape
        )
        asset_e = np.broadcast_to(
            self.par["a_grid"][
                np.newaxis, :, np.newaxis, np.newaxis, np.newaxis, np.newaxis
            ],
            DE.shape,
        )
        efficiency = np.broadcast_to(
            (
                self.par["z_grid"][
                    :, np.newaxis, np.newaxis, np.newaxis, np.newaxis, np.newaxis
                ]
                * self.par["p_grid"][
                    np.newaxis, np.newaxis, np.newaxis, :, np.newaxis, np.newaxis
                ]
            ),
            DE.shape,
        )
        employed_mass = float(DE.sum())
        if employed_mass <= 0:
            raise ValueError("Employed mass must be positive")
        wage_bill = float(np.vdot(DE, wage))
        unemployed_by_type = DU.sum(axis=(0, 1))
        DUnew, DUE, DEE = self.flow_reports(
            state, policies=policies, flow_values=flow_values
        )

        values = {
            "AU": float(np.vdot(DU, aU)),
            "AE": float(np.vdot(DE, aE)),
            "CU": float(np.vdot(DU, cU)),
            "CE": float(np.vdot(DE, cE)),
            "U": float(DU.sum()),
            "N": float(np.vdot(DE, efficiency)),
            "AU_pre": float(np.vdot(DU, asset_u)),
            "AE_pre": float(np.vdot(DE, asset_e)),
            "Tax": tax * wage_bill,
            "earnings": wage_bill / employed_mass,
            "Ubill": float(unemployed_by_type @ bUI),
            "Pi": float(np.vdot(DE, self._profit_weight(Z, rK))),
        }
        values["A"] = values["AU"] + values["AE"]
        values["C"] = values["CU"] + values["CE"]
        values["A_pre"] = values["AU_pre"] + values["AE_pre"]

        sigma = self._sigma(
            flow_values["sigmaJ"], flow_values["sigmaslope"]
        )
        sigma_weight = np.broadcast_to(
            sigma[
                np.newaxis, np.newaxis, np.newaxis, np.newaxis, :, np.newaxis
            ],
            DE.shape,
        )
        values["EU_rate"] = float(np.vdot(DE, sigma_weight)) / employed_mass
        values["EE_rate"] = float(
            np.vdot(
                DEE,
                np.stack([policy["q"] for policy in policies], axis=-1),
            )
        ) / employed_mass

        searchers = self.par["gU"] * DUnew.sum() + DEE.sum(
            axis=(0, 1, 2, 3, 4, 6)
        )
        due_total = float(DUE.sum())
        if due_total <= 0:
            raise ValueError("U-to-E flow denominator must be positive")
        JU0 = np.stack(
            [output["JU0"] for output in backward_outputs], axis=-1
        )
        JE0 = np.stack(
            [output["JE0"] for output in backward_outputs], axis=-1
        )
        for rung in range(self.par["nP"]):
            values[f"e{rung}"] = float(searchers[rung])
            ju = float(np.vdot(JU0[:, :, rung, :], DUE[:, :, rung, :]))
            switch = DEE[:, :, :, :, :, rung, :]
            switch_mass = float(switch.sum())
            if switch_mass == 0.0:
                if rung != 0:
                    raise ValueError(
                        f"Structurally absent switch denominator for J0_{rung}"
                    )
                je = 0.0
            else:
                je = float(
                    np.vdot(JE0[:, :, :, :, :, rung, :], switch)
                ) / switch_mass
            values[f"J0_{rung}"] = ju / due_total + je
        return values

    def _flow_derivative_parameters(self, shock):
        if shock not in FLOW_SHOCKS:
            raise ValueError(f"Unsupported labor-flow shock {shock!r}")
        sigma = np.asarray(self.par["sigma"], dtype=np.float64)
        shifted_sigma = sigma + (self.ss["sigmaJ"] - sigma[-1])
        baseline_sigma = shifted_sigma * (1.0 + self.ss["sigmaslope"])
        if shock.startswith("lambda"):
            return int(shock[6:]), np.zeros_like(sigma), baseline_sigma
        if shock == "sigmaJ":
            dsigma = np.full_like(sigma, 1.0 + self.ss["sigmaslope"])
        else:
            if self.ss["sigmaslope"] != 0:
                raise ValueError(
                    "sigmaslope derivative is defined at steady-state "
                    "sigmaslope = 0"
                )
            dsigma = shifted_sigma
        return -1, dsigma, baseline_sigma

    def transition_shock_forward(self, shock, state=None):
        """Return dL_shock @ state using analytical sparse transition actions."""
        if state is None:
            state = self.Dss
        DU, DE = self.layout.unpack(state)
        dDU = np.empty_like(DU)
        dDE = np.empty_like(DE)
        lambda_index, dsigma, sigma = self._flow_derivative_parameters(shock)
        for ib, policy in enumerate(self.baseline_policies):
            metadata = self.transition_metadata[ib]
            dDU[:, :, ib], dDE[:, :, :, :, :, ib] = (
                _transition_shock_forward_one_type(
                    DU[:, :, ib], DE[:, :, :, :, :, ib],
                    metadata["aU_i"], metadata["aU_pi"],
                    metadata["aE_i"], metadata["aE_pi"],
                    policy["wU_i"], policy["wU_pi"],
                    policy["wEwin_i"], policy["wEwin_pi"],
                    policy["wElose_i"], policy["wElose_pi"],
                    policy["Iwin"], policy["q"], lambda_index, dsigma,
                    self.ss["lambdas"], sigma, self.par["gU"],
                    metadata["lmsU"], self.par["gE"], metadata["lmsE"],
                    self.par["s"], self.par["Pi"],
                )
            )
        return self.layout.pack(dDU, dDE)

    def transition_shock_transpose(self, shock, expectation):
        """Return dL_shock.T @ expectation using the matching sparse action."""
        XU, XE = self.layout.unpack(expectation)
        YU = np.empty_like(XU)
        YE = np.empty_like(XE)
        lambda_index, dsigma, sigma = self._flow_derivative_parameters(shock)
        for ib, policy in enumerate(self.baseline_policies):
            metadata = self.transition_metadata[ib]
            YU[:, :, ib], YE[:, :, :, :, :, ib] = (
                _transition_shock_transpose_one_type(
                    XU[:, :, ib], XE[:, :, :, :, :, ib],
                    metadata["aU_i"], metadata["aU_pi"],
                    metadata["aE_i"], metadata["aE_pi"],
                    policy["wU_i"], policy["wU_pi"],
                    policy["wEwin_i"], policy["wEwin_pi"],
                    policy["wElose_i"], policy["wElose_pi"],
                    policy["Iwin"], policy["q"], lambda_index, dsigma,
                    self.ss["lambdas"], sigma, self.par["gU"],
                    metadata["lmsU"], self.par["gE"], metadata["lmsE"],
                    self.par["s"], self.par["Pi"],
                )
            )
        return self.layout.pack(YU, YE)

    def transpose(self, expectation):
        XU, XE = self.layout.unpack(expectation)
        YU = np.empty_like(XU)
        YE = np.empty_like(XE)
        sigma = self.par["sigma"]
        sigma = sigma + (self.ss["sigmaJ"] - sigma[-1])
        sigma = sigma * (1.0 + self.ss["sigmaslope"])
        for ib, policy in enumerate(self.baseline_policies):
            metadata = self.transition_metadata[ib]
            YU[:, :, ib], YE[:, :, :, :, :, ib] = _transpose_one_type(
                XU[:, :, ib], XE[:, :, :, :, :, ib],
                metadata["aU_i"], metadata["aU_pi"],
                metadata["aE_i"], metadata["aE_pi"],
                policy["wU_i"], policy["wU_pi"],
                policy["wEwin_i"], policy["wEwin_pi"],
                policy["wElose_i"], policy["wElose_pi"],
                policy["Iwin"], policy["q"], self.ss["lambdas"], sigma,
                self.par["gU"], metadata["lmsU"], self.par["gE"],
                metadata["lmsE"], self.par["s"], self.par["Pi"],
            )
        return self.layout.pack(YU, YE)

    def adjoint_error(self, seed=1234):
        rng = np.random.default_rng(seed)
        D = rng.normal(size=self.layout.size)
        X = rng.normal(size=self.layout.size)
        left = np.vdot(X, self.forward(D))
        right = np.vdot(self.transpose(X), D)
        return float(abs(left - right)), float(abs(left)), float(abs(right))

    def expectation_vectors(self, output, T):
        if output not in self.output_functions:
            raise KeyError(f"Unsupported output {output!r}")
        if T < 1:
            raise ValueError("T must be positive")
        key = (output, T)
        if key in self._expectation_cache:
            return self._expectation_cache[key], True
        nbytes = T * self.layout.size * np.dtype(np.float64).itemsize
        memory_threshold = self.par.get(
            "fake_news_memmap_threshold", 512 * 1024**2
        )
        if nbytes <= memory_threshold:
            vectors = np.empty((T, self.layout.size), dtype=np.float64)
        else:
            path = Path(self._expectation_directory.name) / f"{output}-{T}.dat"
            vectors = np.memmap(
                path, mode="w+", dtype=np.float64, shape=(T, self.layout.size)
            )
        vectors[0] = utils.demean(self.output_functions[output])
        for t in range(1, T):
            vectors[t] = utils.demean(self.transpose(vectors[t - 1]))
        if isinstance(vectors, np.memmap):
            vectors.flush()
        self._expectation_cache[key] = vectors
        return vectors, False

    def release_expectation_vectors(self, output, T):
        """Release one cached expectation block and remove its backing file."""
        key = (output, T)
        vectors = self._expectation_cache.pop(key, None)
        if vectors is None:
            return
        if isinstance(vectors, np.memmap):
            path = Path(vectors.filename)
            vectors.flush()
            del vectors
            if path.exists():
                path.unlink()

    def invalidate_expectations(self):
        """Explicitly clear horizon/output expectation data after SS changes."""
        for output, horizon in tuple(self._expectation_cache):
            self.release_expectation_vectors(output, horizon)


def _assemble_walras(J, shock_list, T, ss):
    identity = np.eye(T, dtype=np.float64)
    tax = float(ss["tax"])
    if tax == 0.0:
        raise ValueError("Walras formulas require a nonzero steady-state tax")
    transfer = float(ss["transfer"])
    for shock in shock_list:
        direct_ra = identity if shock == "ra" else 0.0
        direct_tax = identity if shock == "tax" else 0.0
        direct_transfer = identity if shock == "transfer" else 0.0

        J["walrasU"][shock] = (
            J["CU"][shock] + J["AU"][shock]
            - (1.0 + ss["r"]) * J["AU_pre"][shock]
            - (1.0 - tax) * J["Ubill"][shock]
            - transfer * J["U"][shock]
            - ss["AU_pre"] * direct_ra
            + ss["Ubill"] * direct_tax
            - ss["U"] * direct_transfer
        )
        J["walrasE"][shock] = (
            J["CE"][shock] + J["AE"][shock]
            - (1.0 + ss["r"]) * J["AE_pre"][shock]
            - ((1.0 - tax) / tax) * J["Tax"][shock]
            + transfer * J["U"][shock]
            - ss["AE_pre"] * direct_ra
            + (
                ss["Tax"] / tax
                + (1.0 - tax) * ss["Tax"] / tax**2
            ) * direct_tax
            - (1.0 - ss["U"]) * direct_transfer
        )
        J["walras"][shock] = (
            J["C"][shock] + J["A"][shock]
            - (1.0 + ss["r"]) * J["A_pre"][shock]
            - (1.0 - tax) * (
                J["Ubill"][shock] + J["Tax"][shock] / tax
            )
            - ss["A_pre"] * direct_ra
            + (
                ss["Ubill"] + ss["Tax"] / tax
                + (1.0 - tax) * ss["Tax"] / tax**2
            ) * direct_tax
            - direct_transfer
        )


def _report_inputs(cache, shock=None, scale=0.0, h=0.0):
    inputs = {}
    if shock in LEVEL_SHOCKS and scale != 0.0:
        if shock == "bUI":
            inputs["bUI"] = np.array(
                [cache.ss["bUIL"], cache.ss["bUIH"]], dtype=np.float64
            ) + h * scale
        else:
            inputs[shock] = cache.ss[shock] + h * scale
    return inputs


def _output_derivatives(
    cache, perturbed_outputs, baseline_outputs, h, shock=None, scale=0.0
):
    perturbed = cache.report_levels(
        backward_outputs=perturbed_outputs,
        inputs=_report_inputs(cache, shock, scale, h),
    )
    baseline = cache.report_levels(backward_outputs=baseline_outputs)
    return {
        output: (perturbed[output] - baseline[output]) / h
        for output in PRIMITIVE_OUTPUTS
    }


def _flow_reporting_direct_derivatives(cache, shock, h):
    del h
    dDUnew, dDUE, dDEE = cache.flow_shock_reports(shock)
    employed_mass = float(cache.ss["QEss"].sum())
    q = np.stack(
        [policy["q"] for policy in cache.baseline_policies], axis=-1
    )
    derivatives = {
        "EE_rate": float(np.vdot(q, dDEE)) / employed_mass,
    }
    dsearchers = (
        cache.par["gU"] * dDUnew.sum()
        + dDEE.sum(axis=(0, 1, 2, 3, 4, 6))
    )
    baseline_due = cache.baseline_flow_reports[1]
    baseline_dee = cache.baseline_flow_reports[2]
    due_total = float(baseline_due.sum())
    ddue_total = float(dDUE.sum())
    JU0 = np.stack(
        [output["JU0"] for output in cache.baseline_outputs], axis=-1
    )
    JE0 = np.stack(
        [output["JE0"] for output in cache.baseline_outputs], axis=-1
    )
    for rung in range(cache.par["nP"]):
        derivatives[f"e{rung}"] = float(dsearchers[rung])
        due = baseline_due[:, :, rung, :]
        ddue = dDUE[:, :, rung, :]
        due_numerator = float(np.vdot(JU0[:, :, rung, :], due))
        dju = (
            float(np.vdot(JU0[:, :, rung, :], ddue)) / due_total
            - due_numerator * ddue_total / due_total**2
        )
        switch = baseline_dee[:, :, :, :, :, rung, :]
        dswitch = dDEE[:, :, :, :, :, rung, :]
        switch_mass = float(switch.sum())
        if switch_mass == 0.0:
            if rung != 0:
                raise ValueError(
                    f"Structurally absent switch denominator for J0_{rung}"
                )
            dje = 0.0
        else:
            numerator = float(
                np.vdot(JE0[:, :, :, :, :, rung, :], switch)
            )
            dje = (
                float(
                    np.vdot(JE0[:, :, :, :, :, rung, :], dswitch)
                ) / switch_mass
                - numerator * float(dswitch.sum()) / switch_mass**2
            )
        derivatives[f"J0_{rung}"] = dju + dje
    return derivatives


def _backward_news_standard(cache, shock, T, h, shock_scale=1.0):
    curlyD = np.empty((T, cache.layout.size), dtype=np.float64)
    curlyY = {
        output: np.zeros(T, dtype=np.float64) for output in PRIMITIVE_OUTPUTS
    }
    actual_levels = [
        {
            "cU": cache.ss["CUss"][:, :, ib],
            "cE": cache.ss["CEss"][:, :, :, :, :, ib],
            "U": cache.ss["Uss"][:, :, ib],
            "E": cache.ss["Ess"][:, :, :, :, :, ib],
            "Eb": cache.ss["Ebargainingss"][:, :, :, :, :, ib],
            "dEb": cache.ss["dEbargainingss"][:, :, :, :, :, ib],
            "J": cache.ss["Jss"][:, :, :, :, :, ib],
            "Jb": cache.ss["Jbargainingss"][:, :, :, :, :, ib],
        }
        for ib in range(cache.par["nB"])
    ]
    ghost_levels = [
        {key: value for key, value in levels.items()} for levels in actual_levels
    ]

    for horizon in range(T):
        policies = []
        baseline_policies = []
        perturbed_outputs = []
        baseline_outputs = []
        next_actual_levels = []
        next_ghost_levels = []
        for ib in range(cache.par["nB"]):
            baseline = cache._backward_call(
                ib, {}, 0.0, continuation_levels=ghost_levels[ib]
            )
            perturbed = cache._backward_call(
                ib, {}, h,
                ra_post_shock=(
                    shock_scale if shock == "ra" and horizon == 0 else 0.0
                ),
                ra_ante_shock=(
                    shock_scale if shock == "ra" and horizon == 1 else 0.0
                ),
                level_shock=shock if shock in LEVEL_SHOCKS else None,
                level_scale=shock_scale if horizon == 0 else 0.0,
                continuation_levels=actual_levels[ib],
            )
            policies.append(_policy_dict(perturbed))
            baseline_policies.append(_policy_dict(baseline))
            perturbed_outputs.append(perturbed)
            baseline_outputs.append(baseline)
            next_actual_levels.append({
                key: perturbed[key] for key in CONTINUATION_NAMES
            })
            next_ghost_levels.append({
                key: baseline[key] for key in CONTINUATION_NAMES
            })
        direct = _output_derivatives(
            cache, perturbed_outputs, baseline_outputs, h, shock,
            shock_scale if horizon == 0 else 0.0,
        )
        for output, value in direct.items():
            curlyY[output][horizon] = value

        curlyD[horizon] = (
            cache.forward(cache.Dss, policies)
            - cache.forward(cache.Dss, baseline_policies)
        ) / h
        actual_levels = next_actual_levels
        ghost_levels = next_ghost_levels

    return curlyY, curlyD


def _backward_news_flow(cache, shock, T, h):
    """Fake-news objects for flow inputs used at t+1 in the backward step.

    A date-t flow shock changes current DUE/DEE reports and maps the
    beginning-of-period distribution into the date-(t+1) distribution.  It
    does not change date-t stock reports.  Because the Bellman step reads the
    flow input at t+1, its first policy effect is at news horizon one.
    """
    curlyD = np.empty((T, cache.layout.size), dtype=np.float64)
    curlyY = {
        output: np.zeros(T, dtype=np.float64) for output in PRIMITIVE_OUTPUTS
    }
    actual_levels = [
        {
            "cU": cache.ss["CUss"][:, :, ib],
            "cE": cache.ss["CEss"][:, :, :, :, :, ib],
            "U": cache.ss["Uss"][:, :, ib],
            "E": cache.ss["Ess"][:, :, :, :, :, ib],
            "Eb": cache.ss["Ebargainingss"][:, :, :, :, :, ib],
            "dEb": cache.ss["dEbargainingss"][:, :, :, :, :, ib],
            "J": cache.ss["Jss"][:, :, :, :, :, ib],
            "Jb": cache.ss["Jbargainingss"][:, :, :, :, :, ib],
        }
        for ib in range(cache.par["nB"])
    ]
    ghost_levels = [
        {key: value for key, value in levels.items()} for levels in actual_levels
    ]

    direct_distribution = cache.transition_shock_forward(shock)
    curlyD[0] = direct_distribution
    direct_flow_reports = _flow_reporting_direct_derivatives(cache, shock, h)
    for output, value in direct_flow_reports.items():
        curlyY[output][0] += value
    if shock in ("sigmaJ", "sigmaslope"):
        _, DEss = cache.layout.unpack(cache.Dss)
        employed_mass = float(DEss.sum())
        _, dsigma, _ = cache._flow_derivative_parameters(shock)
        tenure_mass = DEss.sum(axis=(0, 1, 2, 3, 5))
        curlyY["EU_rate"][0] += float(tenure_mass @ dsigma) / employed_mass

    for horizon in range(1, T):
        policies = []
        baseline_policies = []
        perturbed_outputs = []
        baseline_outputs = []
        next_actual_levels = []
        next_ghost_levels = []
        for ib in range(cache.par["nB"]):
            baseline = cache._backward_call(
                ib, {}, 0.0, continuation_levels=ghost_levels[ib]
            )
            perturbed = cache._backward_call(
                ib, {}, h, continuation_levels=actual_levels[ib],
                flow_shock=shock,
                flow_scale=(
                    1.0 if horizon == FLOW_BACKWARD_NEWS_OFFSET else 0.0
                ),
            )
            policies.append(_policy_dict(perturbed))
            baseline_policies.append(_policy_dict(baseline))
            perturbed_outputs.append(perturbed)
            baseline_outputs.append(baseline)
            next_actual_levels.append({
                key: perturbed[key] for key in CONTINUATION_NAMES
            })
            next_ghost_levels.append({
                key: baseline[key] for key in CONTINUATION_NAMES
            })
        direct = _output_derivatives(
            cache, perturbed_outputs, baseline_outputs, h
        )
        for output, value in direct.items():
            curlyY[output][horizon] = value

        curlyD[horizon] = (
            cache.forward(cache.Dss, policies)
            - cache.forward(cache.Dss, baseline_policies)
        ) / h
        actual_levels = next_actual_levels
        ghost_levels = next_ghost_levels

    return curlyY, curlyD


def get_jacobians_fake_news(
    T, par, ss, shock_list, h=1e-4, outputs=None, cache=None,
    return_details=False,
):
    """Compute one or more DMP fake-news Jacobians with shared preliminaries.

    Shock derivatives are written one at a time to temporary memory maps.
    Output expectation sequences are then built and released one output at a
    time. This bounds resident memory by one curlyD plus one expectation block
    and avoids recomputing either expensive object for output/shock pairs.
    """
    if T < 2:
        raise ValueError("T must be at least 2")
    if h <= 0:
        raise ValueError("h must be positive")
    shock_list = tuple(shock_list)
    if not shock_list:
        raise ValueError("shock_list must contain at least one shock")
    if len(set(shock_list)) != len(shock_list):
        raise ValueError("shock_list must not contain duplicates")
    unsupported_shocks = sorted(set(shock_list) - set(SUPPORTED_SHOCKS))
    if unsupported_shocks:
        raise ValueError(f"Unsupported shocks: {unsupported_shocks}")
    lambda_indices = [
        int(shock[6:]) for shock in shock_list if shock.startswith("lambda")
    ]
    if lambda_indices and max(lambda_indices) >= par["nP"]:
        raise ValueError(
            f"Requested lambda rung exceeds par['nP']={par['nP']}"
        )
    if any(shock in FLOW_SHOCKS for shock in shock_list) and T <= (
        FLOW_BACKWARD_NEWS_OFFSET
    ):
        raise ValueError(
            f"Labor-flow shocks require T >= {FLOW_BACKWARD_NEWS_OFFSET + 1}"
        )
    if outputs is None:
        outputs = DEFAULT_OUTPUTS
    outputs = tuple(outputs)
    unsupported_outputs = sorted(set(outputs) - set(DEFAULT_OUTPUTS))
    if unsupported_outputs:
        raise ValueError(f"Unsupported outputs: {unsupported_outputs}")

    timings = {"by_shock": {}}
    total_start = time.perf_counter()
    start = time.perf_counter()
    if cache is None:
        cache = DmpSteadyStateCache(par, ss)
    elif cache._source_par is not par or cache._source_ss is not ss:
        raise ValueError("cache was constructed from different par or ss objects")
    timings["prelim"] = time.perf_counter() - start

    primitive_outputs = tuple(
        output for output in outputs if output not in WALRAS_OUTPUTS
    )
    required_primitives = set(primitive_outputs)
    if any(output in outputs for output in WALRAS_OUTPUTS):
        required_primitives.update(
            ("A", "C", "U", "A_pre", "AU", "AE", "AU_pre", "AE_pre",
             "CU", "CE", "Tax", "Ubill")
        )
    assembly_outputs = tuple(
        output for output in PRIMITIVE_OUTPUTS if output in required_primitives
    )

    expectation_reused = {}
    expectation_seconds = {}
    expectation_storage = {}
    result_names = set(outputs) | set(assembly_outputs)
    if any(output in outputs for output in WALRAS_OUTPUTS):
        result_names.update(WALRAS_OUTPUTS)
    J = {output: {} for output in result_names}
    F = {output: {} for output in outputs if output not in WALRAS_OUTPUTS}
    all_curlyY = {}
    retained_curlyD = {}
    mass_errors = {}
    assembly_seconds = 0.0
    backward_seconds = 0.0
    temporary_peak = 0
    tmp_parent = par.get("fake_news_tmpdir")
    with tempfile.TemporaryDirectory(
        prefix="dmp-fake-news-curlyd-", dir=tmp_parent
    ) as tmpdir:
        curlyD_paths = {}
        for shock in shock_list:
            shock_start = time.perf_counter()
            start = time.perf_counter()
            if shock in FLOW_SHOCKS:
                curlyY, curlyD = _backward_news_flow(cache, shock, T, h)
            else:
                curlyY, curlyD = _backward_news_standard(cache, shock, T, h)
            shock_backward = time.perf_counter() - start
            backward_seconds += shock_backward
            mass_errors[shock] = np.abs(curlyD.sum(axis=1))
            all_curlyY[shock] = {
                output: curlyY[output] for output in assembly_outputs
            }
            path = Path(tmpdir) / f"{shock}-curlyD.dat"
            stored = np.memmap(
                path, mode="w+", dtype=np.float64,
                shape=(T, cache.layout.size),
            )
            stored[:] = curlyD
            stored.flush()
            curlyD_paths[shock] = path
            temporary_peak += stored.nbytes
            if len(shock_list) == 1 and return_details:
                retained_curlyD[shock] = curlyD
            else:
                del curlyD
            del stored
            timings["by_shock"][shock] = {
                "backward": shock_backward,
                "assembly": 0.0,
                "total": time.perf_counter() - shock_start,
            }

        timings["expectations"] = 0.0
        for output in assembly_outputs:
            start = time.perf_counter()
            expectation_vectors, reused = cache.expectation_vectors(
                output, T - 1
            )
            elapsed = time.perf_counter() - start
            expectation_seconds[output] = elapsed
            timings["expectations"] += elapsed
            expectation_reused[output] = reused
            expectation_storage[output] = (
                "memmap"
                if isinstance(expectation_vectors, np.memmap)
                else "memory"
            )
            temporary_peak = max(
                temporary_peak,
                sum(path.stat().st_size for path in curlyD_paths.values())
                + (
                    expectation_vectors.nbytes
                    if isinstance(expectation_vectors, np.memmap) else 0
                ),
            )
            for shock in shock_list:
                start = time.perf_counter()
                curlyD = np.memmap(
                    curlyD_paths[shock], mode="r", dtype=np.float64,
                    shape=(T, cache.layout.size),
                )
                fake_news = HetBlock.build_F(
                    all_curlyY[shock][output], curlyD, expectation_vectors
                )
                jacobian = HetBlock.J_from_F(fake_news)
                if output in F:
                    F[output][shock] = fake_news
                J[output][shock] = jacobian
                elapsed = time.perf_counter() - start
                assembly_seconds += elapsed
                timings["by_shock"][shock]["assembly"] += elapsed
                del curlyD
            del expectation_vectors
            cache.release_expectation_vectors(output, T - 1)

        if any(output in outputs for output in WALRAS_OUTPUTS):
            _assemble_walras(J, shock_list, T, ss)
        J = {output: J[output] for output in outputs}
        F = {output: F[output] for output in F}
        for shock in shock_list:
            timings["by_shock"][shock]["total"] = (
                timings["by_shock"][shock]["backward"]
                + timings["by_shock"][shock]["assembly"]
            )

    timings["backward"] = backward_seconds
    timings["assembly"] = assembly_seconds
    timings["total"] = time.perf_counter() - total_start
    adjoint_abs, adjoint_left, adjoint_right = cache.adjoint_error()
    diagnostics = {
        "max_distribution_mass_error": max(
            float(errors.max()) for errors in mass_errors.values()
        ),
        "distribution_mass_errors": mass_errors,
        "adjoint_absolute_error": adjoint_abs,
        "adjoint_left": adjoint_left,
        "adjoint_right": adjoint_right,
        "stationarity_error": float(cache.stationarity_error),
        "state_size": cache.layout.size,
        "curlyD_bytes_per_shock": int(T * cache.layout.size * 8),
        "peak_expectation_bytes_per_output": int((T - 1) * cache.layout.size * 8),
        "peak_temporary_disk_bytes": int(temporary_peak),
        "expectation_seconds_by_output": expectation_seconds,
        "expectation_vector_cache_hits": expectation_reused,
        "expectation_vectors_reused_across_shocks": len(shock_list) > 1,
        "expectation_storage": expectation_storage,
        "curlyD_retention": (
            "one in RAM during backward news; all shock blocks are temporary "
            "memory maps during output-blocked assembly"
        ),
        "transient_memory_per_shock": int(T * cache.layout.size * 8),
        "transient_memory_per_output_batch": int(
            (T - 1) * cache.layout.size * 8
        ),
        "shock_independent_cache": (
            "state layout", "baseline backward outputs", "baseline policies",
            "asset interpolation coordinates", "wage interpolation coordinates",
            "labor-market accessibility", "tenure metadata",
            "steady-state distribution", "output functions",
            "steady-state forward operator", "steady-state transpose operator",
        ),
        "shock_independent_reusable": (
            "transpose expectation vectors by output and horizon",
        ),
        "shock_timing": cache.shock_timing,
        "output_timing": cache.output_timing,
    }
    result = FakeNewsResult(
        jacobian=J,
        curlyY=all_curlyY,
        curlyD=retained_curlyD,
        fake_news=F,
        timings=timings,
        diagnostics=diagnostics,
        cache=cache,
    )
    return result if return_details else J


def get_jacobian_ra_fake_news(
    T, par, ss, h=1e-4, outputs=None, shock_scale=1.0,
    cache=None, return_details=False,
):
    """Backward-compatible wrapper for the validated ``ra`` Jacobian.

    ``shock_scale=0`` is useful for the explicit zero-direction validation.
    """
    if shock_scale not in (0.0, 1.0):
        raise ValueError("shock_scale is only supported as 0.0 or 1.0")
    if cache is None:
        cache = DmpSteadyStateCache(par, ss)
    if shock_scale == 0.0:
        if outputs is None:
            outputs = DEFAULT_OUTPUTS
        outputs = tuple(outputs)
        size = cache.layout.size
        J = {output: {"ra": np.zeros((T, T))} for output in outputs}
        if not return_details:
            return J
        zeros_D = np.zeros((T, size), dtype=np.float64)
        return FakeNewsResult(
            jacobian=J,
            curlyY={output: np.zeros(T) for output in outputs},
            curlyD=zeros_D,
            fake_news={output: np.zeros((T, T)) for output in outputs},
            timings={"prelim": 0.0, "backward": 0.0, "expectations": 0.0,
                     "assembly": 0.0, "total": 0.0},
            diagnostics={
                "max_distribution_mass_error": 0.0,
                "distribution_mass_errors": np.zeros(T),
                "adjoint_absolute_error": cache.adjoint_error()[0],
                "stationarity_error": float(cache.stationarity_error),
                "state_size": size,
                "curlyD_bytes": int(zeros_D.nbytes),
            },
            cache=cache,
        )
    result = get_jacobians_fake_news(
        T, par, ss, ["ra"], h=h, outputs=outputs, cache=cache,
        return_details=True,
    )
    legacy = FakeNewsResult(
        jacobian=result.jacobian,
        curlyY=result.curlyY["ra"],
        curlyD=result.curlyD["ra"],
        fake_news={
            output: (
                result.fake_news[output]["ra"]
                if output in result.fake_news
                else result.jacobian[output]["ra"]
            )
            for output in result.jacobian
        },
        timings=result.timings,
        diagnostics=dict(result.diagnostics),
        cache=result.cache,
    )
    legacy.diagnostics["curlyD_bytes"] = int(legacy.curlyD.nbytes)
    legacy.diagnostics["distribution_mass_errors"] = (
        result.diagnostics["distribution_mass_errors"]["ra"]
    )
    return legacy if return_details else legacy.jacobian
