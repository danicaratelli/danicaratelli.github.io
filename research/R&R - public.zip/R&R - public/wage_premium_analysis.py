import os
# set current director as working directory
import numpy as np
import load_params_SS as load_params
import matplotlib.pyplot as plt
import pickle
import pandas as pd
import statsmodels.formula.api as smf
import sys
import utils
import statsmodels.formula.api as smf

# **** Benchmark model **** #
# Load Steady State
with open("ss_calibration_adapted.pkl", 'rb') as file:
    ss = pickle.load(file)
# Load 
input = ss['inputs']
par = load_params.get_par(input, inaive=False)


# Simulate workers' and the regress the log(wage at rung {z+1}) - log(wage at z) on wealth + wealth x tenure
Nsim = 10000  # Number of simulated workers
Tsim = 50  # Number of time periods to simulate for each worker

# Simulate workers
def simulate_workers(ss, K, H, par, rng=None):
    if rng is None:
        rng = np.random.default_rng()

    # Vectorize distributions and draw initial states
    Dist = np.reshape(ss['QEss'], -1)
    Dist = Dist / np.sum(Dist)
    draws = rng.choice(len(Dist), size=K, p=Dist)

    # Variables to keep track of
    EE = np.nan * np.ones((H, K))
    Assets = np.nan * np.ones((H, K))
    Income = np.nan * np.ones((H, K))
    Tenure = np.nan * np.ones((H, K))
    Plevel = np.nan * np.ones((H, K))
    Btype = np.nan * np.ones((H, K))
    Empstat = np.nan * np.ones((H, K))
    Empstat[0, :] = 1


    for k in range(K):        
        # Draw random numbers one worker at a time to limit memory use
        realizations = rng.random((8, H))        
        idx_k = np.unravel_index(draws[k], ss['QEss'].shape)
        for h in range(H-1):
            if Empstat[h, k] == 1:
                # Current state
                iz, ia, iw, ip, it, ib = idx_k
                Assets[h, k] = par['a_grid'][ia]
                Income[h, k] = par['w_grid'][iw]
                Tenure[h, k] = it
                Empstat[h, k] = 1
                Plevel[h, k] = ip
                Btype[h, k] = ib

                # Assets and productivity tomorrow
                anew = ss['AEss'][iz, ia, iw, ip, it, ib]
                ai, aw = utils.simple_interpolation(anew, par['a_grid'])
                if realizations[0, h] < aw:
                    a_next = ai
                else:
                    a_next = np.minimum(ai + 1, par['nA'] - 1)
                eps_next = np.searchsorted(np.cumsum(par['Pi'][iz, :]), realizations[1, h], side='right')
                eps_next = np.minimum(eps_next, par['nZ'] - 1)

                # Lose the job or remain employed
                if realizations[3, h] < par['sigma'][it]:
                    Empstat[h+1, k] = 0
                else:
                    Empstat[h+1, k] = 1
                    tnext = np.minimum(it + 1, par['nT'] - 1)
                    # Receive an outside offer
                    if ip == par['nP'] - 1:
                        ee = 0
                    else:
                        ee = realizations[4, h] < par['s'] * ss['lambdas'][ip + 1]
                    if ee == 0:
                        idx_k = (eps_next, a_next, iw, ip, tnext, ib)
                    else:
                        # Policies use tenure after it has advanced, as in the forward law
                        ipnext = ip + 1
                        it_offer = tnext - 1
                        iwin = ss['Iwins'][eps_next, a_next, iw, ip, it_offer, ipnext, ib]
                        qswitch = ss['qss'][eps_next, a_next, iw, ip, it_offer, ipnext, ib]
                        # The bargaining outcome determines the new wage
                        if iwin == 1:
                            wE_i = ss['WEwiniss'][eps_next, a_next, iw, ip, it_offer, ipnext, ib]
                            wE_pi = ss['WEwinpiss'][eps_next, a_next, iw, ip, it_offer, ipnext, ib]
                        else:
                            wE_i = ss['WEloseiss'][eps_next, a_next, iw, ip, it_offer, ipnext, ib]
                            wE_pi = ss['WElosepiss'][eps_next, a_next, iw, ip, it_offer, ipnext, ib]
                        if realizations[6, h] < wE_pi:
                            wnext = wE_i
                        else:
                            wnext = np.minimum(wE_i + 1, par['nW'] - 1)
                        # Switch employers or remain with the current employer
                        if realizations[7, h] < qswitch:
                            EE[h, k] = 1
                            idx_k = (eps_next, a_next, wnext, ipnext, 0, ib)
                        else:
                            idx_k = (eps_next, a_next, wnext, ip, tnext, ib)

    return Assets, Income, Tenure, EE, Empstat, Plevel, Btype

Assets, Income, Tenure, EE, Empstat, Plevel, Btype = simulate_workers(ss, Nsim, Tsim, par)

# Extract income changes and pre-event states for each EE event at period h.
ee_h, ee_worker = np.where(EE[:-1, :] == 1)
Income_change_EE = np.log(Income[ee_h + 1, ee_worker]) - np.log(Income[ee_h, ee_worker])
Assets_before_EE = Assets[ee_h, ee_worker]
Tenure_before_EE = Tenure[ee_h, ee_worker]

# Regress income changes on wealth, tenure, their interaction, and tenure fixed effects.
valid = (np.isfinite(Income_change_EE) & np.isfinite(Assets_before_EE) &
         np.isfinite(Tenure_before_EE))
regression_data = pd.DataFrame({
    'income_change': 100 * Income_change_EE[valid],
    'wealth': Assets_before_EE[valid],
    'tenure': Tenure_before_EE[valid],
})
regression = smf.ols(
    'income_change ~ wealth + tenure + wealth:tenure',
    data=regression_data,
).fit()

# Show regression coefficients
print(regression.params)


# Log wage premium at a job switch, using wealth and tenure before the switch
keep = (np.isfinite(Income_change_EE) &
        np.isfinite(Assets_before_EE) &
        np.isfinite(Tenure_before_EE) &
        (Assets_before_EE > 0))

data_log = pd.DataFrame({
    'wage_premium_ln': Income_change_EE[keep],
    'ln_wealth': np.log(Assets_before_EE[keep]),
    'tenure': Tenure_before_EE[keep],
    'worker_id': ee_worker[keep],
})

model_log = smf.ols(
    'wage_premium_ln ~ ln_wealth * tenure',
    data=data_log,
).fit(cov_type='cluster', cov_kwds={'groups': data_log['worker_id']})

print(model_log.summary())

# Marginal effect of log wealth at each log-tenure value
tenure_grid = np.linspace(data_log['tenure'].min(),
                          data_log['tenure'].max(), 100)
effect = (model_log.params['ln_wealth'] +
          model_log.params['ln_wealth:tenure'] * tenure_grid)

terms = ['ln_wealth', 'ln_wealth:tenure']
covariance = model_log.cov_params().loc[terms, terms].to_numpy()
design = np.column_stack((np.ones(len(tenure_grid)), tenure_grid))
standard_error = np.sqrt(np.einsum('ij,jk,ik->i',
                                   design, covariance, design))

fig, ax = plt.subplots()
ax.plot(tenure_grid, 100 * effect, color='tab:blue')
ax.fill_between(tenure_grid,
                100 * (effect - 1.645 * standard_error),
                100 * (effect + 1.645 * standard_error),
                color='tab:blue', alpha=0.25)
ax.axhline(0, color='black', linewidth=0.8)
ax.set_xlabel('Tenure bucket)')
ax.set_ylabel('Effect of log wealth on log wage change (%)')
fig.tight_layout()
fig.savefig('wage_premium_wealth_by_tenure.png', dpi=200)
plt.show()

