import numpy as np
import utils
from numba import njit


def wageEE_AOB(E_bargaining_p, dE_bargaining_p, E_p, dE_p,
               J_bargaining_p, J_p, lms, par):
    # Extract relevant parameters
    M = par['M']
    nZ = par['nZ']
    nA = par['nA']
    nP = par['nP']
    nW = par['nW']
    nT = par['nT']
    EValpha = par['EValpha']

    # Flip firm values
    J_flip = np.flip(J_p, axis=2)
    J_bargaining_p_flip = np.flip(J_bargaining_p, axis=2)

    # Dimensions: idiosyncratic shock, assets, current wage, incumbent rung,
    # current tenure (excluding zero), and poacher rung.
    wage_i = np.ones((nZ, nA, nW, nP, nT - 1, nP), dtype='uint32')
    wage_pi = np.ones((nZ, nA, nW, nP, nT - 1, nP))

    Vpoacher_max, dVpoacher_max, Vincumbent_max, dVincumbent_max, \
        w_idx, w_pi, iscase = get_case(
            E_p, dE_p, E_bargaining_p, dE_bargaining_p, J_flip,
            J_bargaining_p_flip, lms, nZ, nA, nW, nP, nT, M)

    # Paper allocation: cases 1/2 stay, cases 3/4 switch; zero is sentinel.
    Iswitch = ((iscase == 0) * -1 +
               ((iscase >= 1) & (iscase <= 2)) * 0 +
               (iscase > 2) * 1.0)

    # In cases 2/3 the logit is only a reduced-form noisy allocation rule. It
    # smooths who receives the worker; it is not a utility shock and therefore
    # creates no EV/log-sum inclusive-value bonus for the household.
    exponent = EValpha * (
        Vincumbent_max[:, :, :, :, np.newaxis] -
        Vpoacher_max[:, :, np.newaxis, np.newaxis, :, 0])
    exponent = np.clip(exponent, -50.0, 50.0)
    qbase = 1.0 / (1.0 + np.exp(exponent))
    qswitch = np.broadcast_to(
        qbase[:, :, np.newaxis, :, :, :], iscase.shape).copy()
    qswitch[iscase == 1] = 0.0
    qswitch[iscase == 4] = 1.0
    qswitch[iscase == 0] = 0.0

    # Case 1 starts from the existing contract and keeps both its wage index
    # and interpolation weight (one on that wage).
    wage_i = wage_i * np.arange(nW, dtype=np.uint32)[
        np.newaxis, np.newaxis, :, np.newaxis, np.newaxis, np.newaxis]
    V = np.repeat(E_p[:, :, :, :, 1:, np.newaxis], nP, axis=5)
    dV = np.repeat(dE_p[:, :, :, :, 1:, np.newaxis], nP, axis=5)
    Pi = np.repeat(J_p[:, :, :, :, 1:, np.newaxis], nP, axis=5)

    wage_i, wage_pi, V, dV, Pi = get_wE_23(
        wage_i, wage_pi, V, dV, Pi, Vpoacher_max, dVpoacher_max,
        Vincumbent_max, dVincumbent_max, iscase, E_p, J_p, lms,
        nZ, nA, nW, nP, nT)

    wage_i, wage_pi, V, dV, Pi = get_wE_4(
        iscase, wage_i, wage_pi, V, dV, Pi, Vpoacher_max,
        Vincumbent_max, E_bargaining_p, dE_bargaining_p,
        J_bargaining_p, J_bargaining_p_flip, lms, nZ, nA, nW,
        nP, nT, M)

    Vfinal, dVfinal, J_incumbent, J_poacher, wage_i_loser, \
        wage_pi_loser = finalize_wageEE(
            iscase, qswitch, V, dV, Pi, Vpoacher_max,
            dVpoacher_max, Vincumbent_max, dVincumbent_max,
            w_idx, w_pi, par['gE'], nZ, nA, nW, nP, nT)

    # Optional second-stage diagnostics. The default retains the first-stage
    # partial-derivative convention. ``full_fd`` can cross case boundaries;
    # ``regime_fd`` uses central/one-sided differences only within case-4 runs.
    derivative_mode = par.get('case4_derivative_mode', 'partial')
    if derivative_mode == 'full_fd':
        dVtotal = _asset_finite_difference(Vfinal, par['a_grid'])
        dVfinal[iscase == 4] = dVtotal[iscase == 4]
    elif derivative_mode == 'regime_fd':
        dVfinal = _case4_regime_finite_difference(
            Vfinal, dVfinal, iscase, par['a_grid'])
    elif derivative_mode != 'partial':
        raise ValueError(
            "case4_derivative_mode must be 'partial', 'full_fd', or 'regime_fd'")

    return (Vfinal, dVfinal, J_incumbent, J_poacher,
            wage_i, wage_i_loser, wage_pi, wage_pi_loser,
            iscase, Iswitch, qswitch)


def _asset_finite_difference(values, asset_grid):
    """Finite differences along assets, without regard to bargaining cases."""
    derivative = np.empty_like(values)
    derivative[:, 0] = ((values[:, 1] - values[:, 0]) /
                        (asset_grid[1] - asset_grid[0]))
    derivative[:, -1] = ((values[:, -1] - values[:, -2]) /
                         (asset_grid[-1] - asset_grid[-2]))
    derivative[:, 1:-1] = (
        (values[:, 2:] - values[:, :-2]) /
        (asset_grid[2:] - asset_grid[:-2])[
            np.newaxis, :, np.newaxis, np.newaxis, np.newaxis, np.newaxis])
    return derivative


def _case4_regime_finite_difference(values, partial, iscase, asset_grid):
    """Case-4 total derivative without differencing across regime changes."""
    derivative = partial.copy()
    adjacent = (iscase[:, :-1] == 4) & (iscase[:, 1:] == 4)
    slopes = ((values[:, 1:] - values[:, :-1]) /
              (asset_grid[1:] - asset_grid[:-1])[
                  np.newaxis, :, np.newaxis, np.newaxis, np.newaxis,
                  np.newaxis])

    derivative[:, :-1] = np.where(adjacent, slopes, derivative[:, :-1])
    derivative[:, 1:] = np.where(adjacent, slopes, derivative[:, 1:])

    central = adjacent[:, :-1] & adjacent[:, 1:]
    central_slopes = (
        (values[:, 2:] - values[:, :-2]) /
        (asset_grid[2:] - asset_grid[:-2])[
            np.newaxis, :, np.newaxis, np.newaxis, np.newaxis, np.newaxis])
    derivative[:, 1:-1] = np.where(
        central, central_slopes, derivative[:, 1:-1])
    return derivative


@njit
def finalize_wageEE(iscase, qswitch, V, dV, Pi, Vpoacher_max,
                    dVpoacher_max, Vincumbent_max, dVincumbent_max,
                    w_idx, w_pi, gE, nZ, nA, nW, nP, nT):
    Vfinal = np.empty_like(V)
    dVfinal = np.empty_like(dV)
    J_incumbent = np.zeros_like(Pi)
    J_poacher = np.zeros_like(Pi)
    wage_i_loser = np.ones(
        (nZ, nA, nW, nP, nT - 1, nP), dtype=np.uint32)
    wage_pi_loser = np.ones((nZ, nA, nW, nP, nT - 1, nP))

    for iz in range(nZ):
        for ia in range(nA):
            for iw in range(nW):
                for ip_o in range(nP):
                    for it in range(nT - 1):
                        for ip_d in range(nP):
                            case = iscase[iz, ia, iw, ip_o, it, ip_d]
                            accessible = (gE[ip_o, ip_d] > 0 or
                                          (ip_o == nP - 1 and
                                           ip_d == nP - 1))

                            if case == 1 or case == 2:
                                if accessible:
                                    wage_i_loser[iz, ia, iw, ip_o, it, ip_d] = \
                                        w_idx[iz, ia, ip_d, 0, 0]
                                    wage_pi_loser[iz, ia, iw, ip_o, it, ip_d] = \
                                        w_pi[iz, ia, ip_d, 0, 0]
                            elif case == 3 or case == 4:
                                if accessible:
                                    wage_i_loser[iz, ia, iw, ip_o, it, ip_d] = \
                                        w_idx[iz, ia, ip_o, it + 1, 0]
                                    wage_pi_loser[iz, ia, iw, ip_o, it, ip_d] = \
                                        w_pi[iz, ia, ip_o, it + 1, 0]
                            elif accessible:
                                wage_i_loser[iz, ia, iw, ip_o, it, ip_d] = 0
                                wage_pi_loser[iz, ia, iw, ip_o, it, ip_d] = 0.0

                            # No inclusive-value adjustment: the piecewise
                            # bargaining outcome itself is the household value.
                            if case == 1:
                                Vfinal[iz, ia, iw, ip_o, it, ip_d] = \
                                    V[iz, ia, iw, ip_o, it, ip_d]
                                dVfinal[iz, ia, iw, ip_o, it, ip_d] = \
                                    dV[iz, ia, iw, ip_o, it, ip_d]
                            elif case == 2:
                                Vfinal[iz, ia, iw, ip_o, it, ip_d] = \
                                    Vpoacher_max[iz, ia, ip_d, 0]
                                dVfinal[iz, ia, iw, ip_o, it, ip_d] = \
                                    dVpoacher_max[iz, ia, ip_d, 0]
                            elif case == 3:
                                Vfinal[iz, ia, iw, ip_o, it, ip_d] = \
                                    Vincumbent_max[iz, ia, ip_o, it]
                                dVfinal[iz, ia, iw, ip_o, it, ip_d] = \
                                    dVincumbent_max[iz, ia, ip_o, it]
                            else:
                                Vfinal[iz, ia, iw, ip_o, it, ip_d] = \
                                    V[iz, ia, iw, ip_o, it, ip_d]
                                dVfinal[iz, ia, iw, ip_o, it, ip_d] = \
                                    dV[iz, ia, iw, ip_o, it, ip_d]

                            q = qswitch[iz, ia, iw, ip_o, it, ip_d]
                            if case == 1 or case == 2:
                                J_incumbent[iz, ia, iw, ip_o, it, ip_d] = \
                                    (1.0 - q) * Pi[iz, ia, iw, ip_o, it, ip_d]
                            elif case == 3 or case == 4:
                                J_poacher[iz, ia, iw, ip_o, it, ip_d] = \
                                    q * Pi[iz, ia, iw, ip_o, it, ip_d]

    return (Vfinal, dVfinal, J_incumbent, J_poacher,
            wage_i_loser, wage_pi_loser)


@njit
def get_case(E_p, dE_p, E_bargaining_p, dE_bargaining_p, J_flip,
             J_bargaining_p_flip, lms, nZ, nA, nW, nP, nT, M):
    # Maximum wage that leaves a firm indifferent to posting a vacancy.
    w_idx = np.zeros((nZ, nA, nP, nT, M), dtype='uint32')
    w_pi = np.zeros((nZ, nA, nP, nT, M))
    for ip in range(nP):
        for iz in range(nZ):
            for it in range(nT):
                for ia in range(nA):
                    idx_tmp, pi_tmp = utils.simple_interpolation(
                        0, J_flip[iz, ia, :, ip, it])
                    w_idx[iz, ia, ip, it, 0] = max(
                        nW - (idx_tmp + 2), 0)
                    w_pi[iz, ia, ip, it, 0] = 1 - pi_tmp
                    if it == 0:
                        for im in range(1, M):
                            idx_tmp, pi_tmp = utils.simple_interpolation(
                                0, J_bargaining_p_flip[
                                    iz, ia, :, ip, im])
                            w_idx[iz, ia, ip, it, im] = max(
                                nW - (idx_tmp + 2), 0)
                            w_pi[iz, ia, ip, it, im] = 1 - pi_tmp

    Vincumbent_max = np.zeros((nZ, nA, nP, nT - 1))
    dVincumbent_max = np.zeros((nZ, nA, nP, nT - 1))
    Vpoacher_max = np.zeros((nZ, nA, nP, M))
    dVpoacher_max = np.zeros((nZ, nA, nP, M))
    for ip in range(nP):
        for iz in range(nZ):
            for ia in range(nA):
                for im in range(M):
                    wi = w_idx[iz, ia, ip, 0, im]
                    wp = w_pi[iz, ia, ip, 0, im]
                    wi1 = np.minimum(wi + 1, nW - 1)
                    Vpoacher_max[iz, ia, ip, im] = (
                        E_bargaining_p[iz, ia, wi, ip, im] * wp +
                        E_bargaining_p[iz, ia, wi1, ip, im] * (1 - wp))
                    dVpoacher_max[iz, ia, ip, im] = (
                        dE_bargaining_p[iz, ia, wi, ip, im] * wp +
                        dE_bargaining_p[iz, ia, wi1, ip, im] * (1 - wp))
                for it in range(1, nT):
                    wi = w_idx[iz, ia, ip, it, 0]
                    wp = w_pi[iz, ia, ip, it, 0]
                    wi1 = np.minimum(wi + 1, nW - 1)
                    Vincumbent_max[iz, ia, ip, it - 1] = (
                        E_p[iz, ia, wi, ip, it] * wp +
                        E_p[iz, ia, wi1, ip, it] * (1 - wp))
                    dVincumbent_max[iz, ia, ip, it - 1] = (
                        dE_p[iz, ia, wi, ip, it] * wp +
                        dE_p[iz, ia, wi1, ip, it] * (1 - wp))

    # Sequential classification is exhaustive for accessible transitions.
    # Weak ties go to the incumbent, consistent with the paper allocation.
    iscase = np.zeros((nZ, nA, nW, nP, nT - 1, nP))
    for iz in range(nZ):
        for ia in range(nA):
            for iw in range(nW):
                for ip_o in range(nP):
                    for it in range(1, nT):
                        for ip_d in lms[ip_o]:
                            vp1 = Vpoacher_max[iz, ia, ip_d, 0]
                            vi = Vincumbent_max[iz, ia, ip_o, it - 1]
                            current = E_p[iz, ia, iw, ip_o, it]
                            if vp1 <= current:
                                case = 1
                            elif vp1 <= vi:
                                case = 2
                            elif Vpoacher_max[iz, ia, ip_d, 1] <= vi:
                                case = 3
                            else:
                                case = 4
                            iscase[iz, ia, iw, ip_o, it - 1, ip_d] = case

    return (Vpoacher_max, dVpoacher_max, Vincumbent_max,
            dVincumbent_max, w_idx, w_pi, iscase)


@njit
def get_wE_23(wage_i, wage_pi, V, dV, Pi, Vpoacher_max,
               dVpoacher_max, Vincumbent_max, dVincumbent_max, iscase,
               E_p, J_p, lms, nZ, nA, nW, nP, nT):
    for iz in range(nZ):
        for ia in range(nA):
            for iw in range(nW):
                for ip_o in range(nP):
                    for it in range(1, nT):
                        for ip_d in lms[ip_o]:
                            case = iscase[iz, ia, iw, ip_o, it - 1, ip_d]
                            if case == 2:
                                target = Vpoacher_max[iz, ia, ip_d, 0]
                                wi, wp = utils.simple_interpolation(
                                    target, E_p[iz, ia, :, ip_o, it])
                                wage_i[iz, ia, iw, ip_o, it - 1, ip_d] = wi
                                wage_pi[iz, ia, iw, ip_o, it - 1, ip_d] = wp
                                V[iz, ia, iw, ip_o, it - 1, ip_d] = target
                                dV[iz, ia, iw, ip_o, it - 1, ip_d] = \
                                    dVpoacher_max[iz, ia, ip_d, 0]
                                Pi[iz, ia, iw, ip_o, it - 1, ip_d] = (
                                    J_p[iz, ia, wi, ip_o, it] * wp +
                                    J_p[iz, ia, np.minimum(wi + 1, nW - 1),
                                        ip_o, it] * (1 - wp))
                            elif case == 3:
                                target = Vincumbent_max[
                                    iz, ia, ip_o, it - 1]
                                wi, wp = utils.simple_interpolation(
                                    target, E_p[iz, ia, :, ip_d, 0])
                                wage_i[iz, ia, iw, ip_o, it - 1, ip_d] = wi
                                wage_pi[iz, ia, iw, ip_o, it - 1, ip_d] = wp
                                V[iz, ia, iw, ip_o, it - 1, ip_d] = target
                                dV[iz, ia, iw, ip_o, it - 1, ip_d] = \
                                    dVincumbent_max[iz, ia, ip_o, it - 1]
                                Pi[iz, ia, iw, ip_o, it - 1, ip_d] = (
                                    J_p[iz, ia, wi, ip_d, 0] * wp +
                                    J_p[iz, ia, np.minimum(wi + 1, nW - 1),
                                        ip_d, 0] * (1 - wp))

    return wage_i, wage_pi, V, dV, Pi


@njit
def get_wE_4(iscase, wage_i, wage_pi, V, dV, Pi, Vpoacher_max,
             Vincumbent_max, E_bargaining_p, dE_bargaining_p,
             J_bargaining_p, J_bargaining_p_flip, lms, nZ, nA, nW,
             nP, nT, M):
    # Solve the one-on-one poacher/worker negotiation backwards. Paper odd
    # subperiods map to even zero-based m, so the firm proposes when m is even.
    for iz in range(nZ):
        for ia in range(nA):
            for iw in range(nW):
                for ip_o in range(nP):
                    for it in range(1, nT):
                        for ip_d in lms[ip_o]:
                            if iscase[iz, ia, iw, ip_o, it - 1, ip_d] == 4:
                                Wwait = Vincumbent_max[
                                    iz, ia, ip_o, it - 1]
                                Jwait = 0.0

                                # Last subperiod with strict poacher dominance;
                                # equality is not part of the AOB recursion.
                                mend = M - 1
                                while (mend >= 0 and
                                       Vpoacher_max[iz, ia, ip_d, mend] <= Wwait):
                                    mend -= 1
                                if mend < 0:
                                    raise ValueError(
                                        "case 4 has no strictly dominant poacher subperiod")

                                for m in range(mend, -1, -1):
                                    if ((m + 1) % 2) == 1:
                                        wi, wp = utils.simple_interpolation(
                                            Wwait, E_bargaining_p[
                                                iz, ia, :, ip_d, m])
                                        wage_i[iz, ia, iw, ip_o, it - 1, ip_d] = wi
                                        wage_pi[iz, ia, iw, ip_o, it - 1, ip_d] = wp
                                        Jwait = (
                                            J_bargaining_p[
                                                iz, ia, wi, ip_d, m] * wp +
                                            J_bargaining_p[
                                                iz, ia,
                                                np.minimum(wi + 1, nW - 1),
                                                ip_d, m] * (1 - wp))
                                        if m == 0:
                                            V[iz, ia, iw, ip_o, it - 1, ip_d] = Wwait
                                            # Current convention: this is a
                                            # wage-interpolated partial derivative.
                                            # Case-4 total asset derivatives may
                                            # require refinement in a later stage.
                                            dV[iz, ia, iw, ip_o, it - 1, ip_d] = (
                                                dE_bargaining_p[
                                                    iz, ia, wi, ip_d, m] * wp +
                                                dE_bargaining_p[
                                                    iz, ia,
                                                    np.minimum(wi + 1, nW - 1),
                                                    ip_d, m] * (1 - wp))
                                            Pi[iz, ia, iw, ip_o, it - 1, ip_d] = Jwait
                                    else:
                                        idx_tmp, pi_tmp = utils.simple_interpolation(
                                            Jwait, J_bargaining_p_flip[
                                                iz, ia, :, ip_d, m])
                                        wi = max(nW - (idx_tmp + 2), 0)
                                        wp = 1 - pi_tmp
                                        wage_i[iz, ia, iw, ip_o, it - 1, ip_d] = wi
                                        wage_pi[iz, ia, iw, ip_o, it - 1, ip_d] = wp
                                        Wwait = (
                                            E_bargaining_p[
                                                iz, ia, wi, ip_d, m] * wp +
                                            E_bargaining_p[
                                                iz, ia,
                                                np.minimum(wi + 1, nW - 1),
                                                ip_d, m] * (1 - wp))

    return wage_i, wage_pi, V, dV, Pi


@njit
def get_V_4(iscase, wage_i, wage_pi, V, dV, Pi, E_p, dE_p, J_p,
            lms, nZ, nA, nW, nP, nT):
    # Retained for API parity with the original helper module.
    for iz in range(nZ):
        for ia in range(nA):
            for iw in range(nW):
                for ip_o in range(nP):
                    for it in range(1, nT):
                        for ip_d in lms[ip_o]:
                            if iscase[iz, ia, iw, ip_o, it - 1, ip_d] == 4:
                                wi = wage_i[iz, ia, iw, ip_o, it - 1, ip_d]
                                wp = wage_pi[iz, ia, iw, ip_o, it - 1, ip_d]
                                wi1 = min(wi + 1, nW - 1)
                                V[iz, ia, iw, ip_o, it - 1, ip_d] = (
                                    E_p[iz, ia, wi, ip_d, 0] * wp +
                                    E_p[iz, ia, wi1, ip_d, 0] * (1 - wp))
                                dV[iz, ia, iw, ip_o, it - 1, ip_d] = (
                                    dE_p[iz, ia, wi, ip_d, 0] * wp +
                                    dE_p[iz, ia, wi1, ip_d, 0] * (1 - wp))
                                Pi[iz, ia, iw, ip_o, it - 1, ip_d] = (
                                    J_p[iz, ia, wi, ip_d, 0] * wp +
                                    J_p[iz, ia, wi1, ip_d, 0] * (1 - wp))

    return V, dV, Pi
