import os
import pickle

import load_params_SS as load_params
import Jac_fake_news


# Options
ss_file_name = "ss_calibration.pkl"
output_file_name = os.path.join("Jacobians", "Jac_fake_news.pkl")
TT = 250
h = 1e-4
shock_list = [
    "ra", "Z", "tax", "transfer", "rK", "bUI",
    "lambda0", "lambda1", "lambda2", "lambda3",
    "lambda4", "lambda5", "lambda6", "lambda7",
    "sigmaJ", "sigmaslope",
]
# shock_list = ["ra"]
output_list = list(Jac_fake_news.DEFAULT_OUTPUTS)

# Load steady state
with open(ss_file_name, "rb") as file:
    ss = pickle.load(file)

# Load parameters
input = ss["inputs"]
par = load_params.get_par(input)


# Compute fake-news Jacobian
result = Jac_fake_news.get_jacobians_fake_news(
    TT, par, ss, shock_list=shock_list, outputs=output_list, h=h,
    return_details=True
)

J = result.jacobian


# Save results
path_name = os.path.dirname(output_file_name)
if path_name and not os.path.isdir(path_name):
    os.mkdir(path_name)

output = {
    "J": J,
    "shocks": shock_list,
    "outputs": list(J.keys()),
    "TT": TT,
    "h": h,
    "timings": result.timings,
    "diagnostics": result.diagnostics,
}

with open(output_file_name, "wb") as file:
    pickle.dump(output, file)


# Print summary
print("Saved fake-news Jacobian to " + output_file_name)
print("T = " + str(TT))
print("h = " + str(h))
print("Total runtime = " + str(round(result.timings["total"], 2)) + " seconds")
for shock in shock_list:
    print(
        shock + " runtime = "
        + str(round(result.timings["by_shock"][shock]["total"], 2))
        + " seconds"
    )
print("Adjoint error = " + str(result.diagnostics["adjoint_absolute_error"]))
print("Distribution mass error = " + str(result.diagnostics["max_distribution_mass_error"]))
