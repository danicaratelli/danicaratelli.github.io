"""Run the adapted nonlinear transition and distributional dynamics."""

from __future__ import annotations

import json
import os
from pathlib import Path
import pickle
import platform
import sys

import numpy as np

from nonlinear_dmp_adapted import INPUTS as DMP_INPUTS, evaluate_dmp_transition
from nonlinear_ge_adapted import (
    NonlinearGEMap, UNKNOWNS, TARGETS, deviations_to_levels,
    linear_initial_guess, reconstruct_parameters, solve_nonlinear_transition,
    construct_linear_system, validate_temporary_shocks,
    validate_zero_shock_transition,
)


# Options
steady_state_file = "ss_calibration_adapted.pkl"
jacobian_file = os.path.join("Jacobians", "Jac_fake_news_adapted.pkl")
output_directory = os.path.join("results_adapted", "nonlinear")
scratch_directory = None

TT = 40
T_shock = 4                 # last period with a nonzero shock (period 0 is first)
terminal_tail = 4           # number of zero-shock periods required at the end

shock = "Z"
amplitude = 0.1             # deviation from the steady-state value
persistence = 0.8

solver_tolerance = 5e-5
terminal_tolerance = 1e-4
walras_tolerance = 5e-5
max_iterations = 20

# If True, save the wage and asset-by-wage distribution paths in the pickle.
retain_marginals = False


# The adapted steady-state pickle requires the Python 3.14 NumPy environment.
if sys.version_info < (3, 14):
    raise RuntimeError(
        "The adapted NumPy pickle requires Python 3.14. "
        "Select the Python 3.14 interpreter in VS Code."
    )


# Load steady state and Jacobian
ss_path = Path(steady_state_file).resolve()
jac_path = Path(jacobian_file).resolve()
outpath = Path(output_directory).resolve()
outpath.mkdir(parents=True, exist_ok=True)

with ss_path.open("rb") as file:
    ss = pickle.load(file)

with jac_path.open("rb") as file:
    Jac = pickle.load(file)


# Check that the adapted steady state and Jacobian are compatible
if Jac.get("bargaining_version") != "wagesEE_AOB_adapted":
    raise ValueError("Jacobian was not built with wagesEE_AOB_adapted")

if Jac.get("case4_derivative_mode") != "partial":
    raise ValueError("Jacobian does not use the adapted partial derivative mode")

if Jac.get("flow_timing_version") != "calendar_consistent_tplus1":
    raise ValueError(
        "Adapted Jacobian predates the corrected flow-shock calendar timing"
    )

if Jac.get("searcher_rung_axis") != "destination":
    raise ValueError(
        "Adapted Jacobian predates the destination-rung searcher correction"
    )

saved_ss_timestamp = Jac.get("steady_state_timestamp")
if (saved_ss_timestamp is not None
        and abs(float(saved_ss_timestamp) - os.path.getmtime(ss_path)) > 1e-6):
    raise ValueError(
        "Adapted Jacobian metadata points to a different steady-state file version"
    )

if int(Jac.get("TT", 0)) < TT:
    raise ValueError("Saved Jacobian horizon is shorter than TT")

required_outputs = {
    "A", "C", "N", "U", "Tax", "Ubill", "Pi", "earnings",
    *(f"e{i}" for i in range(8)),
    *(f"J0_{i}" for i in range(8)),
}
missing_outputs = sorted(required_outputs - set(Jac["J"]))
if missing_outputs:
    raise ValueError(f"Adapted Jacobian is missing outputs {missing_outputs}")

baseline_floor = float(Jac.get("steady_state_max_abs_residual", 0.0))
if solver_tolerance < baseline_floor:
    raise ValueError(
        f"Solver tolerance {solver_tolerance:.3e} is below the saved steady-state "
        f"residual floor {baseline_floor:.3e}; numerically refine the same "
        "steady state before a production run"
    )

J = Jac["J"]
par = reconstruct_parameters(ss)


# Check that a zero-shock transition reproduces the steady state
zero_validation = validate_zero_shock_transition(
    ss, par, J, TT,
    scratch_dir=scratch_directory,
    residual_tolerance=max(solver_tolerance, 5e-5),
)

if not zero_validation["passed"]:
    raise RuntimeError(
        "Zero-shock validation failed: "
        + ", ".join(zero_validation["failures"])
    )


# Construct the temporary shock path
if not 0 <= T_shock < TT:
    raise ValueError("T_shock must satisfy 0 <= T_shock < TT")

shock_path = np.zeros(TT)
if amplitude != 0.0:
    shock_path[:T_shock + 1] = (
        amplitude * persistence ** np.arange(T_shock + 1)
    )

shock_deviations = {shock: shock_path}

validate_temporary_shocks(
    shock_deviations, TT, terminal_tail=terminal_tail
)


# Construct the linear solution used as the nonlinear initial guess
system = construct_linear_system(
    ss, J, par, TT, scratch_dir=scratch_directory
)

linear_U, _ = linear_initial_guess(
    ss, system, shock_deviations, TT
)

shock_levels = deviations_to_levels(ss, shock_deviations, TT)


# Compare the flat and linear initial guesses
ge_map = NonlinearGEMap(
    ss, par, J, TT, scratch_dir=scratch_directory
)

flat_U = {
    name: np.full(TT, ss[name], dtype=np.float64)
    for name in UNKNOWNS
}

flat_evaluation = ge_map.evaluate(flat_U, shock_levels)
linear_evaluation = ge_map.evaluate(linear_U, shock_levels)

linear_scaled_residual = {
    name: float(np.max(np.abs(linear_evaluation["scaled_residuals"][name])))
    for name in TARGETS
}

linear_raw_residual = {
    name: float(np.max(np.abs(linear_evaluation["raw_residuals"][name])))
    for name in TARGETS
}

flat_scaled_merit = 0.5 * sum(
    float(np.sum(value ** 2))
    for value in flat_evaluation["scaled_residuals"].values()
)

linear_scaled_merit = 0.5 * sum(
    float(np.sum(value ** 2))
    for value in linear_evaluation["scaled_residuals"].values()
)


# Solve the nonlinear transition
solution = solve_nonlinear_transition(
    ss, par, J, shock_deviations, TT,
    tolerance=solver_tolerance,
    max_iterations=max_iterations,
    scratch_dir=scratch_directory,
    terminal_tail=terminal_tail,
    terminal_tolerance=terminal_tolerance,
    walras_tolerance=walras_tolerance,
)

solution["diagnostics"]["linear_initial_raw_residual_by_target"] = (
    linear_raw_residual
)
solution["diagnostics"]["linear_initial_scaled_residual_by_target"] = (
    linear_scaled_residual
)
solution["diagnostics"]["flat_initial_scaled_merit"] = flat_scaled_merit
solution["diagnostics"]["linear_initial_scaled_merit"] = linear_scaled_merit
solution["diagnostics"]["linear_initializer_improves"] = bool(
    amplitude == 0.0 or linear_scaled_merit < flat_scaled_merit
)
solution["linear_initial_residuals"] = {
    "raw": linear_evaluation["raw_residuals"],
    "scaled": linear_evaluation["scaled_residuals"],
}


# Save solver diagnostics even when the transition does not converge
metadata = {
    "steady_state_file": str(ss_path),
    "steady_state_timestamp": os.path.getmtime(ss_path),
    "jacobian_file": str(jac_path),
    "jacobian_timestamp": os.path.getmtime(jac_path),
    "T": TT,
    "T_shock": T_shock,
    "shock_definition": {
        "name": shock,
        "amplitude_deviation": amplitude,
        "persistence": persistence,
    },
    "solver_tolerance": solver_tolerance,
    "terminal_tolerance": terminal_tolerance,
    "case4_derivative_mode": "partial",
    "python_version": platform.python_version(),
    "numpy_version": np.__version__,
}

diagnostics_payload = {
    "metadata": metadata,
    "zero_shock_validation": zero_validation,
    **solution["diagnostics"],
}


# json.dumps needs this small conversion for NumPy values in the diagnostics.
def json_value(value):
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.floating):
        return float(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"Cannot JSON-encode {type(value).__name__}")


diagnostics_path = outpath / "nonlinear_solver_diagnostics.json"
diagnostics_path.write_text(
    json.dumps(diagnostics_payload, indent=2, default=json_value),
    encoding="utf-8",
)

if not solution["converged"]:
    raise RuntimeError(
        "Nonlinear transition did not converge; diagnostics saved to "
        + str(diagnostics_path)
    )


# Recompute the household block at the solution and obtain distributions
dmp_paths = {
    name: solution["paths"][name]
    for name in DMP_INPUTS
    if name in solution["paths"]
}

final_dmp = evaluate_dmp_transition(
    ss, par, dmp_paths,
    scratch_dir=scratch_directory,
    compute_distributional=True,
    retain_distribution=retain_marginals,
)

solution["distributional"] = final_dmp["distributional"]
solution["terminal_distribution"] = final_dmp["terminal_distribution"]
solution["metadata"] = metadata


# Save aggregate transition paths
path_columns = {"time": np.arange(TT)}

for name in shock_deviations:
    path_columns[name] = shock_levels[name]

for name in UNKNOWNS:
    path_columns[name] = solution["unknowns"][name]

for name in (
    "ra", "rK", "K", "p", "A", "N", "U", "EE_rate",
    "EU_rate", "earnings",
):
    path_columns[name] = solution["paths"][name]

for name in TARGETS:
    path_columns[name] = solution["paths"][name]

path_columns["walras_residual"] = solution["paths"]["walras_res"]

path_names = list(path_columns)
path_matrix = np.column_stack([path_columns[name] for name in path_names])

if not np.isfinite(path_matrix).all():
    raise ValueError("Refusing to save nonfinite aggregate transition paths")

np.savetxt(
    outpath / "nonlinear_transition_paths.csv",
    path_matrix,
    delimiter=",",
    header=",".join(path_names),
    comments="",
)


# Save distributional moments
wanted_moments = (
    "mean_earnings_low", "mean_earnings_high",
    "EE_rate_low", "EE_rate_high",
    "EU_rate_low", "EU_rate_high",
    "wage_bill_share_low", "median_wage_value",
    "median_boundary_fraction",
)

moment_columns = {"time": np.arange(TT)}
for name in wanted_moments:
    moment_columns[name] = final_dmp["distributional"][name]

moment_names = list(moment_columns)
moment_matrix = np.column_stack([
    moment_columns[name] for name in moment_names
])

if not np.isfinite(moment_matrix).all():
    raise ValueError("Refusing to save nonfinite distributional moments")

np.savetxt(
    outpath / "nonlinear_distributional_moments.csv",
    moment_matrix,
    delimiter=",",
    header=",".join(moment_names),
    comments="",
)


# Save the complete transition solution
with (outpath / "nonlinear_transition_results.pkl").open("wb") as file:
    pickle.dump(solution, file)
