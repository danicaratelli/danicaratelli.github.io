"""Distributional statistics for the adapted nonlinear DMP transition."""

from __future__ import annotations

import numpy as np


def employed_wage_quantile_weights(DE, quantile=0.5):
    """Return low/high wage-bin weights for an employed-population quantile.

    ``DE`` has axes ``(z, a, wage, rung, tenure, beta)``.  The result is a
    pair of one-dimensional weights, plus useful cutoff metadata.
    """
    DE = np.asarray(DE, dtype=np.float64)
    if DE.ndim != 6:
        raise ValueError("DE must have axes (z, a, wage, rung, tenure, beta)")
    if not np.isfinite(DE).all() or np.min(DE) < -1e-14:
        raise ValueError("DE must be finite and nonnegative")
    if not 0.0 < quantile < 1.0:
        raise ValueError("quantile must lie strictly between zero and one")

    mass_by_wage = DE.sum(axis=(0, 1, 3, 4, 5))
    employed_mass = float(mass_by_wage.sum())
    if employed_mass <= 0.0:
        raise ValueError("employed mass must be positive")
    target_mass = quantile * employed_mass
    median_index = int(np.searchsorted(np.cumsum(mass_by_wage), target_mass,
                                       side="left"))
    mass_before = float(mass_by_wage[:median_index].sum())
    boundary_mass = float(mass_by_wage[median_index])
    if boundary_mass <= 0.0:
        raise ValueError("quantile boundary wage bin has zero mass")
    boundary_fraction = np.clip(
        (target_mass - mass_before) / boundary_mass, 0.0, 1.0
    )
    low = np.zeros_like(mass_by_wage)
    low[:median_index] = 1.0
    low[median_index] = boundary_fraction
    high = 1.0 - low
    return {
        "low": low,
        "high": high,
        "mass_by_wage": mass_by_wage,
        "employed_mass": employed_mass,
        "target_mass_low": target_mass,
        "target_mass_high": (1.0 - quantile) * employed_mass,
        "median_wage_index": median_index,
        "median_boundary_fraction": float(boundary_fraction),
    }


def current_earnings_moments(DE, DEE, q, sigma, wage_grid, quantile=0.5):
    """Compute current-gross-earnings groups and conditional transition rates.

    ``DEE`` and ``q`` have axes
    ``(z, a, origin_wage, origin_rung, tenure_without_last, destination_rung,
    beta)``.  Classification therefore uses the origin-wage axis.  The
    fractional boundary weight is applied once to the product ``q * DEE``.
    """
    DE = np.asarray(DE, dtype=np.float64)
    DEE = np.asarray(DEE, dtype=np.float64)
    q = np.asarray(q, dtype=np.float64)
    sigma = np.asarray(sigma, dtype=np.float64)
    wage_grid = np.asarray(wage_grid, dtype=np.float64)
    if DE.ndim != 6 or DEE.ndim != 7 or q.shape != DEE.shape:
        raise ValueError("invalid DE/DEE/q dimensions")
    if wage_grid.shape != (DE.shape[2],):
        raise ValueError("wage_grid length must match the DE wage axis")
    if sigma.shape != (DE.shape[4],):
        raise ValueError("sigma length must match the DE tenure axis")
    if not all(np.isfinite(x).all() for x in (DE, DEE, q, sigma, wage_grid)):
        raise ValueError("moment inputs must be finite")

    split = employed_wage_quantile_weights(DE, quantile=quantile)
    wage = wage_grid[None, None, :, None, None, None]
    sigma_de = sigma[None, None, None, None, :, None]
    result = {
        "median_wage_index": split["median_wage_index"],
        "median_wage_value": float(wage_grid[split["median_wage_index"]]),
        "median_boundary_fraction": split["median_boundary_fraction"],
    }
    for label in ("low", "high"):
        weight = split[label][None, None, :, None, None, None]
        mass = float(np.sum(weight * DE))
        wage_bill = float(np.sum(weight * wage * DE))
        ee_weight = split[label][None, None, :, None, None, None, None]
        ee_flow = float(np.sum(ee_weight * (q * DEE)))
        eu_flow = float(np.sum(weight * sigma_de * DE))
        result[f"employment_mass_{label}"] = mass
        result[f"mean_earnings_{label}"] = wage_bill / mass
        result[f"wage_bill_{label}"] = wage_bill
        result[f"EE_rate_{label}"] = ee_flow / mass
        result[f"EU_rate_{label}"] = eu_flow / mass

    aggregate_wage_bill = result["wage_bill_low"] + result["wage_bill_high"]
    result["wage_bill_share_low"] = (
        result["wage_bill_low"] / aggregate_wage_bill
        if aggregate_wage_bill > 0.0 else np.nan
    )
    return result


def worker_asset_quantile_weights(DU, DE, quantile=0.5):
    """Split all workers at an asset quantile, including its boundary bin.

    ``DU`` has axes ``(z, asset, beta)`` and ``DE`` has axes
    ``(z, asset, wage, rung, tenure, beta)``.  The returned weights are
    applied to employed stocks and origin-worker EE flows without changing
    their asset axis.
    """
    DU = np.asarray(DU, dtype=np.float64)
    DE = np.asarray(DE, dtype=np.float64)
    if DU.ndim != 3 or DE.ndim != 6:
        raise ValueError("invalid DU/DE dimensions")
    if DU.shape[1] != DE.shape[1]:
        raise ValueError("DU and DE must share the asset axis")
    if not np.isfinite(DU).all() or not np.isfinite(DE).all():
        raise ValueError("worker distributions must be finite")
    if min(float(DU.min()), float(DE.min())) < -1e-14:
        raise ValueError("worker distributions must be nonnegative")
    if not 0.0 < quantile < 1.0:
        raise ValueError("quantile must lie strictly between zero and one")

    mass_by_asset = (
        DU.sum(axis=(0, 2)) + DE.sum(axis=(0, 2, 3, 4, 5))
    )
    worker_mass = float(mass_by_asset.sum())
    if worker_mass <= 0.0:
        raise ValueError("worker mass must be positive")
    target_mass = quantile * worker_mass
    median_index = int(np.searchsorted(
        np.cumsum(mass_by_asset), target_mass, side="left"
    ))
    mass_before = float(mass_by_asset[:median_index].sum())
    boundary_mass = float(mass_by_asset[median_index])
    if boundary_mass <= 0.0:
        raise ValueError("quantile boundary asset bin has zero mass")
    boundary_fraction = float(np.clip(
        (target_mass - mass_before) / boundary_mass, 0.0, 1.0
    ))
    low = np.zeros_like(mass_by_asset)
    low[:median_index] = 1.0
    low[median_index] = boundary_fraction
    high = 1.0 - low
    return {
        "low": low,
        "high": high,
        "mass_by_asset": mass_by_asset,
        "worker_mass": worker_mass,
        "target_mass_low": target_mass,
        "target_mass_high": (1.0 - quantile) * worker_mass,
        "median_asset_index": median_index,
        "median_boundary_fraction": boundary_fraction,
    }


def current_wealth_moments(DU, DE, DEE, q, wage_grid, asset_grid,
                           quantile=0.5, aggregation_tolerance=1e-12):
    """Compute employed earnings and EE rates by current-worker wealth.

    The wealth split uses employed and unemployed workers together.  EE
    classification uses the origin worker's asset (axis 1), and its weight is
    applied once to the already formed flow ``q * DEE``.
    """
    DU = np.asarray(DU, dtype=np.float64)
    DE = np.asarray(DE, dtype=np.float64)
    DEE = np.asarray(DEE, dtype=np.float64)
    q = np.asarray(q, dtype=np.float64)
    wage_grid = np.asarray(wage_grid, dtype=np.float64)
    asset_grid = np.asarray(asset_grid, dtype=np.float64)
    if DE.ndim != 6 or DEE.ndim != 7 or q.shape != DEE.shape:
        raise ValueError("invalid DE/DEE/q dimensions")
    if DU.ndim != 3 or DU.shape[1] != DE.shape[1]:
        raise ValueError("invalid DU dimensions or asset axis")
    if DEE.shape[1] != DE.shape[1]:
        raise ValueError("DEE origin-worker asset axis must match DE")
    if wage_grid.shape != (DE.shape[2],):
        raise ValueError("wage_grid length must match the DE wage axis")
    if asset_grid.shape != (DE.shape[1],):
        raise ValueError("asset_grid length must match the asset axis")
    if aggregation_tolerance < 0.0:
        raise ValueError("aggregation_tolerance must be nonnegative")
    if not all(np.isfinite(x).all()
               for x in (DU, DE, DEE, q, wage_grid, asset_grid)):
        raise ValueError("wealth-moment inputs must be finite")
    if min(float(DU.min()), float(DE.min()), float(DEE.min())) < -1e-14:
        raise ValueError("distribution and flow inputs must be nonnegative")

    split = worker_asset_quantile_weights(DU, DE, quantile=quantile)
    wage = wage_grid[None, None, :, None, None, None]
    aggregate_employment = float(DE.sum())
    aggregate_wage_bill = float(np.sum(wage * DE))
    aggregate_ee_flow = float(np.sum(q * DEE))
    result = {
        "median_asset_index": split["median_asset_index"],
        "median_asset_value": float(asset_grid[split["median_asset_index"]]),
        "median_asset_boundary_fraction": split["median_boundary_fraction"],
        "wealth_worker_mass": split["worker_mass"],
        "wealth_aggregate_employment_mass": aggregate_employment,
        "wealth_aggregate_wage_bill": aggregate_wage_bill,
        "wealth_aggregate_EE_flow": aggregate_ee_flow,
    }
    for label in ("low", "high"):
        asset_weight = split[label]
        worker_weight_u = asset_weight[None, :, None]
        worker_weight_e = asset_weight[None, :, None, None, None, None]
        ee_weight = asset_weight[None, :, None, None, None, None, None]
        worker_mass = float(
            np.sum(worker_weight_u * DU) + np.sum(worker_weight_e * DE)
        )
        employment_mass = float(np.sum(worker_weight_e * DE))
        if employment_mass <= 0.0:
            raise ValueError(f"{label}-wealth employed mass must be positive")
        wage_bill = float(np.sum(worker_weight_e * wage * DE))
        ee_flow = float(np.sum(ee_weight * (q * DEE)))
        result[f"wealth_worker_mass_{label}"] = worker_mass
        result[f"wealth_employment_mass_{label}"] = employment_mass
        result[f"wealth_wage_bill_{label}"] = wage_bill
        result[f"wealth_EE_flow_{label}"] = ee_flow
        result[f"mean_earnings_{label}_wealth"] = wage_bill / employment_mass
        result[f"EE_rate_{label}_wealth"] = ee_flow / employment_mass

    errors = {
        "wealth_low_target_mass_error": abs(
            result["wealth_worker_mass_low"] - split["target_mass_low"]
        ),
        "wealth_high_target_mass_error": abs(
            result["wealth_worker_mass_high"] - split["target_mass_high"]
        ),
        "wealth_worker_mass_aggregation_error": abs(
            result["wealth_worker_mass_low"] + result["wealth_worker_mass_high"]
            - split["worker_mass"]
        ),
        "wealth_employment_mass_aggregation_error": abs(
            result["wealth_employment_mass_low"] + result["wealth_employment_mass_high"]
            - aggregate_employment
        ),
        "wealth_wage_bill_aggregation_error": abs(
            result["wealth_wage_bill_low"] + result["wealth_wage_bill_high"]
            - aggregate_wage_bill
        ),
        "wealth_EE_flow_aggregation_error": abs(
            result["wealth_EE_flow_low"] + result["wealth_EE_flow_high"]
            - aggregate_ee_flow
        ),
    }
    result.update(errors)
    scales = {
        "wealth_low_target_mass_error": max(split["target_mass_low"], 1.0),
        "wealth_high_target_mass_error": max(split["target_mass_high"], 1.0),
        "wealth_worker_mass_aggregation_error": max(split["worker_mass"], 1.0),
        "wealth_employment_mass_aggregation_error": max(aggregate_employment, 1.0),
        "wealth_wage_bill_aggregation_error": max(abs(aggregate_wage_bill), 1.0),
        "wealth_EE_flow_aggregation_error": max(abs(aggregate_ee_flow), 1.0),
    }
    failed = [name for name, error in errors.items()
              if error > aggregation_tolerance * scales[name]]
    if failed:
        raise ValueError("wealth aggregation identity failed: " + ", ".join(failed))
    return result


def stack_moment_history(history):
    """Stack a sequence of scalar moment dictionaries into time paths."""
    if not history:
        return {}
    keys = history[0].keys()
    return {key: np.asarray([row[key] for row in history]) for key in keys}
