"""Continue the seven-quarter Great Recession shock from 0.05 to 0.10."""

import json
import pickle
from pathlib import Path

import numpy as np

import main_result_GreatRecession as gr
from nonlinear_ge_adapted import (
    UNKNOWNS, reconstruct_parameters, solve_nonlinear_transition,
)


# The source run already validated the steady state and solved scale 0.05.
TT = 120
SHOCK_PERIODS = 7
PREVIOUS_SCALE = 0.05
TRIAL_SCALE = 0.10
TERMINAL_TOLERANCE = 0.01  # L1 distance of one percent of total worker mass.
WALRAS_TOLERANCE = 0.002
SOURCE_FILE = (
    Path("results_adapted") / "great_recession_iterative_T120_short7"
    / "great_recession_failure.pkl"
)
OUTPUT_DIRECTORY = (
    Path("results_adapted") / "great_recession_iterative_T120_short7_s010"
)


def distribution_summary(terminal, ss, par):
    """Describe where terminal worker mass differs from steady state."""
    difference_u = np.asarray(terminal["DU"]) - np.asarray(ss["QUss"])
    difference_e = np.asarray(terminal["DE"]) - np.asarray(ss["QEss"])
    difference_asset = (
        difference_u.sum(axis=(0, 2))
        + difference_e.sum(axis=(0, 2, 3, 4, 5))
    )
    difference_wage = difference_e.sum(axis=(0, 1, 3, 4, 5))
    gross_asset = (
        np.abs(difference_u).sum(axis=(0, 2))
        + np.abs(difference_e).sum(axis=(0, 2, 3, 4, 5))
    )
    gross_wage = np.abs(difference_e).sum(axis=(0, 1, 3, 4, 5))
    asset_grid = np.asarray(par["a_grid"])
    wage_grid = np.asarray(par["w_grid"])

    largest_asset_indices = np.argsort(gross_asset)[-10:][::-1]
    largest_wage_indices = np.argsort(gross_wage)[-10:][::-1]
    asset_rows = [
        {
            "index": int(index),
            "asset": float(asset_grid[index]),
            "net_mass_change": float(difference_asset[index]),
            "gross_cell_distance": float(gross_asset[index]),
        }
        for index in largest_asset_indices
    ]
    wage_rows = [
        {
            "index": int(index),
            "wage": float(wage_grid[index]),
            "net_employed_mass_change": float(difference_wage[index]),
            "gross_cell_distance": float(gross_wage[index]),
        }
        for index in largest_wage_indices
    ]
    return {
        "distribution_L1_distance": float(
            np.abs(difference_u).sum() + np.abs(difference_e).sum()
        ),
        "largest_single_cell_difference": float(max(
            np.abs(difference_u).max(), np.abs(difference_e).max()
        )),
        "unemployed_net_mass_change": float(difference_u.sum()),
        "employed_net_mass_change": float(difference_e.sum()),
        "unemployed_cell_L1_distance": float(np.abs(difference_u).sum()),
        "employed_cell_L1_distance": float(np.abs(difference_e).sum()),
        "asset_marginal_L1_distance": float(np.abs(difference_asset).sum()),
        "wage_marginal_L1_distance": float(np.abs(difference_wage).sum()),
        "largest_asset_cells": asset_rows,
        "largest_wage_cells": wage_rows,
    }


# Load the previous solved state and reconstruct its exact shock paths.
OUTPUT_DIRECTORY.mkdir(parents=True, exist_ok=True)
with SOURCE_FILE.open("rb") as file:
    previous_run = pickle.load(file)
previous_solution = previous_run["solution"]
if not np.isclose(previous_solution["solved_shock_scale"], PREVIOUS_SCALE):
    raise ValueError("saved solution does not match PREVIOUS_SCALE")

ss = gr._load_pickle_compatible(gr.STEADY_STATE_FILE.resolve())
jacobian = gr._load_pickle_compatible(gr.JACOBIAN_FILE.resolve())
par = reconstruct_parameters(ss)
shock_deviations = previous_run["identification"]["deviations"]
previous_summary = distribution_summary(
    previous_solution["terminal_distribution"], ss, par
)

linear_initial_guess = previous_solution["linear_initial_guess"]
trial_initial_guess = {
    name: (
        np.asarray(previous_solution["unknowns"][name])
        + (TRIAL_SCALE - PREVIOUS_SCALE)
        * (np.asarray(linear_initial_guess[name]) - ss[name])
    )
    for name in UNKNOWNS
}
trial_shocks = {
    name: TRIAL_SCALE * np.asarray(path)
    for name, path in shock_deviations.items()
}


# Continue the nonlinear transition and save the complete attempted state.
solution = solve_nonlinear_transition(
    ss, par, jacobian["J"], trial_shocks, TT,
    initial_guess=trial_initial_guess,
    tolerance=gr.SOLVER_TOLERANCE,
    max_iterations=8,
    max_line_search_trials=4,
    homotopy_scales=(),
    terminal_tail=TT - SHOCK_PERIODS,
    terminal_tolerance=TERMINAL_TOLERANCE,
    walras_tolerance=WALRAS_TOLERANCE,
)
terminal_summary = (
    None if solution["terminal_distribution"] is None
    else distribution_summary(solution["terminal_distribution"], ss, par)
)
terminal_checks = solution["diagnostics"].get("terminal_diagnostics", {})
report = {
    "previous_scale": PREVIOUS_SCALE,
    "trial_scale": TRIAL_SCALE,
    "terminal_tolerance": TERMINAL_TOLERANCE,
    "walras_tolerance": WALRAS_TOLERANCE,
    "converged": bool(solution["converged"]),
    "market_converged": bool(solution["diagnostics"]["market_converged"]),
    "failure_reason": solution["diagnostics"].get("failure_reason"),
    "iterations": solution["diagnostics"].get("iterations"),
    "walras_max_residual": terminal_checks.get("walras_max_residual"),
    "endogenous_terminal_max_scaled_deviation": terminal_checks.get(
        "endogenous_terminal_max_scaled_deviation"
    ),
    "previous_distribution": previous_summary,
    "trial_distribution": terminal_summary,
}
(OUTPUT_DIRECTORY / "distribution_report.json").write_text(
    json.dumps(report, indent=2), encoding="utf-8"
)
with (OUTPUT_DIRECTORY / "solution.pkl").open("wb") as file:
    pickle.dump({"solution": solution, "report": report}, file)
print(json.dumps({
    "converged": report["converged"],
    "market_converged": report["market_converged"],
    "failure_reason": report["failure_reason"],
    "walras_max_residual": report["walras_max_residual"],
    "endogenous_terminal_max_scaled_deviation": (
        report["endogenous_terminal_max_scaled_deviation"]
    ),
    "previous_distribution_L1_distance": (
        previous_summary["distribution_L1_distance"]
    ),
    "trial_distribution_L1_distance": (
        None if terminal_summary is None
        else terminal_summary["distribution_L1_distance"]
    ),
}, indent=2))
